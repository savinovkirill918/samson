/** Группа/должность сотрудника */
export interface Group {
  id: number;
  name: string;
  sort: number;
}

/** Сотрудник склада */
export interface Member {
  id: number;
  fio: string;
  login: string;
  password: string;
  email: string;
  emailPassword: string;
  groupId: number;
  tsdId: number | null;
  kkmId: number | null;
  tg: string;
  group?: Group;
  tsd?: TSD | null;
  kkm?: KKM | null;
}

/** ТСД — терминал сбора данных */
export interface TSD {
  id: number;
  number: number;
  sn: string;
  inv: string;
  model: string;
  isMulti: boolean;
  members?: Member[];
  repairs?: Repair[];
}

/** ККМ — контрольно-кассовая машина */
export interface KKM {
  id: number;
  number: number;
  sn: string;
  inv: string;
  isMulti: boolean;
  members?: Member[];
}

/** Ремонт ТСД */
export interface Repair {
  id: number;
  tsdId: number;
  brokenDate: string;
  sentDate: string;
  returnedDate: string;
  status: number;
  description: string;
  isGuilty: boolean;
  cost: number;
  tsd?: TSD;
}

/** Принтер */
export interface Printer {
  id: number;
  number: number;
  sn: string;
  inv: string;
  model: string;
  type: string;
  location: string;
  ipAddress: string;
  purchaseDate: string;
  status: number;
  isMulti: boolean;
  cartridgeModelId: number | null;
  cartridgeModel?: CartridgeModel | null;
  repairs?: PrinterRepair[];
  consumptions?: PrinterConsumption[];
  cartridges?: Cartridge[];
}

/** Ремонт принтера */
export interface PrinterRepair {
  id: number;
  printerId: number;
  brokenDate: string;
  sentDate: string;
  returnedDate: string;
  status: number;
  description: string;
  isGuilty: boolean;
  cost: number;
  printer?: Printer;
}

/** Месячный расход принтера (счётчик) */
export interface PrinterConsumption {
  id: number;
  printerId: number;
  month: string;
  totalCounter: number;
  printer?: Printer;
}

/** Модель картриджа (справочник) */
export interface CartridgeModel {
  id: number;
  name: string;
  printerModel: string;
  expectedYield: number;
  total: number;
  needsRefill: number;
  newCount: number;
  usedCount: number;
  cartridges?: Cartridge[];
}

/** Картридж (экземпляр) */
export interface Cartridge {
  id: number;
  cartridgeModelId: number;
  printerId: number | null;
  status: number;
  condition: number;
  cartridgeModel?: CartridgeModel;
  printer?: Printer | null;
  history?: CartridgeHistory[];
}

/** История перемещений картриджа */
export interface CartridgeHistory {
  id: number;
  cartridgeId: number;
  action: string;
  printerId: number | null;
  date: string;
  notes: string;
}

/** Сводка по картриджам (из модели) */
export interface CartridgeSummary {
  cartridgeModel: CartridgeModel;
  total: number;
  onStock: number;
  needsRefill: number;
  newCount: number;
  usedCount: number;
}

/** Запись лога действий */
export interface LogEntry {
  id: number;
  adminId: number;
  text: string;
  date: string;
}

/** Пользователь системы (администратор) */
export interface AdminUser {
  id: number;
  login: string;
  hash: string;
  fio: string;
  role: string;
  groupId: number;
}

/** Типы страниц навигации */
export type PageId =
  | 'home'
  | 'members' | 'member-add' | 'member-edit'
  | 'groups' | 'group-add' | 'group-edit'
  | 'tsd-list' | 'tsd-add' | 'tsd-edit' | 'tsd-repairs' | 'tsd-repair-add' | 'tsd-repair-edit' | 'tsd-repair-sz'
  | 'printer-list' | 'printer-add' | 'printer-edit'
  | 'printer-repairs' | 'printer-repair-add' | 'printer-repair-edit' | 'printer-repair-sz'
  | 'printer-consumption' | 'printer-consumption-add' | 'printer-consumption-edit'
  | 'cartridge-inventory' | 'cartridge-add' | 'cartridge-edit' | 'cartridge-history'
  | 'cartridge-models' | 'cartridge-model-add' | 'cartridge-model-edit'
  | 'kkm-list' | 'kkm-add'
  | 'stat-starshie' | 'stat-kladovshiki' | 'stat-import'
  | 'tools'
  | 'logs'
  | 'print-tsd' | 'print-kkm' | 'print-barcode'
  | 'settings-users' | 'settings-user-add' | 'settings-user-edit'
  | 'inventory-balance';

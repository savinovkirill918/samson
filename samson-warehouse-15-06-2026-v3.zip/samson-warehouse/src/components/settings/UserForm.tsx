'use client';

import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { AdminUser, Group, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface UserFormProps {
  groups: Group[];
  editingAdmin?: AdminUser | null;
  onSave: (admin: { login: string; hash?: string; fio: string; role?: string; groupId?: number }) => void;
  onUpdate?: (admin: { id: number; login: string; hash?: string; fio: string; role?: string; groupId?: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function UserForm({ groups, editingAdmin, onSave, onUpdate, onNavigate }: UserFormProps) {
  const isEditing = !!editingAdmin;
  const [form, setForm] = useState({ fio: '', login: '', password: '', role: 'Пользователь', groupId: 1 });

  useEffect(() => {
    if (editingAdmin) {
      setForm({
        fio: editingAdmin.fio,
        login: editingAdmin.login,
        password: '',
        role: editingAdmin.role,
        groupId: editingAdmin.groupId,
      });
    }
  }, [editingAdmin]);

  const handleSave = () => {
    if (!form.fio || !form.login) return;
    if (isEditing && editingAdmin && onUpdate) {
      onUpdate({
        id: editingAdmin.id,
        fio: form.fio,
        login: form.login,
        hash: form.password || undefined,
        role: form.role,
        groupId: form.groupId,
      });
    } else {
      onSave({
        fio: form.fio,
        login: form.login,
        hash: form.password,
        role: form.role,
        groupId: form.groupId,
      });
    }
    onNavigate('settings-users');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Пользователи', page: 'settings-users', onNavigate },
        { label: isEditing ? 'Редактирование' : 'Добавить', onNavigate }
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEditing ? 'Редактировать пользователя' : 'Добавить пользователя'}
      </h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ФИО *</label>
          <input type="text" value={form.fio} onChange={e => setForm(p => ({ ...p, fio: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин *</label>
          <input type="text" value={form.login} onChange={e => setForm(p => ({ ...p, login: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>
            Пароль {isEditing ? '(оставьте пустым, чтобы не менять)' : '*'}
          </label>
          <input type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Роль</label>
          <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300" style={{ borderColor: '#dee2e6' }}>
            <option>Админ</option><option>Пользователь</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Должность</label>
          <select value={form.groupId} onChange={e => setForm(p => ({ ...p, groupId: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300" style={{ borderColor: '#dee2e6' }}>
            {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> {isEditing ? 'Сохранить' : 'Создать'}
        </button>
      </div>
    </div>
  );
}

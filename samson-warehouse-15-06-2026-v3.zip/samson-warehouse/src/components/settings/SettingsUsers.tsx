'use client';

import React from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { AdminUser, Group, PageId } from '@/lib/types';
import { getGroupName } from '@/lib/helpers';

interface SettingsUsersProps {
  admins: AdminUser[];
  groups: Group[];
  onNavigate: (page: PageId) => void;
  onEditAdmin?: (admin: AdminUser) => void;
  onDeleteAdmin?: (id: number) => void;
}

export default function SettingsUsers({ admins, groups, onNavigate, onEditAdmin, onDeleteAdmin }: SettingsUsersProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="flex items-center justify-between mb-4">
        <div />
        <button
          onClick={() => onNavigate('settings-user-add')}
          className="flex items-center gap-2 px-4 py-2 text-white rounded-lg font-medium hover:opacity-90 transition text-sm"
          style={{ backgroundColor: COLORS.primary }}
        >
          <Plus className="w-4 h-4" /> Добавить пользователя
        </button>
      </div>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
        <table className="w-full text-sm">
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Логин</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Должность</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Роль</th>
              <th className="text-center px-4 py-3 font-semibold" style={{ color: COLORS.heading, width: '100px' }}>Действия</th>
            </tr>
          </thead>
          <tbody>
            {admins.length > 0 ? admins.map(admin => (
              <tr key={admin.id} className="border-t hover:bg-gray-50 transition-colors" style={{ borderColor: '#f0f0f0' }}>
                <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>{admin.fio}</td>
                <td className="px-4 py-3" style={{ color: COLORS.text }}>{admin.login}</td>
                <td className="px-4 py-3" style={{ color: COLORS.text }}>{getGroupName(admin.groupId, groups)}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${admin.role === 'Админ' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'}`}>
                    {admin.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-center" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-center gap-1">
                    <button
                      title="Редактировать"
                      onClick={() => onEditAdmin?.(admin)}
                      className="p-1.5 rounded text-white transition hover:opacity-80"
                      style={{ backgroundColor: COLORS.primary }}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      title="Удалить"
                      onClick={() => { if (confirm(`Удалить пользователя "${admin.fio}"?`)) onDeleteAdmin?.(admin.id); }}
                      className="p-1.5 rounded text-white transition hover:opacity-80"
                      style={{ backgroundColor: '#dc3545' }}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет пользователей</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

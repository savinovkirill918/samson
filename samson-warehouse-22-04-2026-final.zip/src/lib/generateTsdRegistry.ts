import jsPDF from 'jspdf'
import fs from 'node:fs'
import path from 'node:path'

// =====================================================================
// Генерация PDF: Реестр выдачи терминалов сбора данных
// Формат: A3 ландшафт, шрифт Liberation Serif (аналог Times New Roman)
// Единая таблица — autotable сам управляет переносом страниц.
// rowPageBreak: 'avoid' не даёт разрывать одну строку между листами.
// =====================================================================

interface RegistryGroup {
  name: string
  sort: number
  members: Array<{ fio: string; fioShort: string; tsdNumber: number }>
}

interface RegistryData {
  date: string
  groups: RegistryGroup[]
}

const FONT_NAME = 'LibSerif'

function registerFonts(doc: jsPDF) {
  const fontsDir = '/usr/share/fonts/truetype/liberation'
  const regular = fs.readFileSync(path.join(fontsDir, 'LiberationSerif-Regular.ttf'), 'base64')
  const bold = fs.readFileSync(path.join(fontsDir, 'LiberationSerif-Bold.ttf'), 'base64')
  doc.addFileToVFS('LibSerif-Regular.ttf', regular)
  doc.addFileToVFS('LibSerif-Bold.ttf', bold)
  doc.addFont('LibSerif-Regular.ttf', FONT_NAME, 'normal')
  doc.addFont('LibSerif-Bold.ttf', FONT_NAME, 'bold')
}

export async function generateTsdRegistryPdf(data: RegistryData): Promise<Buffer> {
  const autoTableModule = await import('jspdf-autotable')
  const autoTable = autoTableModule.default || autoTableModule

  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'pt',
    format: [841.89, 595.28], // A3 ландшафт
    compress: true,
  })

  registerFonts(doc)
  doc.setFont(FONT_NAME, 'normal')

  // Размеры страницы
  const pageW = 841.89
  const marginL = 14.17  // 5mm — как в mPDF margin_left=5
  const marginR = 14.17  // 5mm — как в mPDF margin_right=5
  const marginT = 53.86  // 19mm — дефолт mPDF (margin_top не задан)
  const marginB = 14.17  // 5mm — как в mPDF margin_bottom=5
  const usableW = pageW - marginL - marginR

  // Ширины колонок
  const col0 = usableW * 0.10
  const col1 = usableW * 0.15
  const col2 = usableW * 0.10
  const col3 = usableW * 0.10
  const col4 = usableW * 0.10
  const col5 = usableW * 0.45

  // Собираем ВСЕ строки в один массив
  const allRows: string[][] = []
  for (const group of data.groups) {
    for (const member of group.members) {
      allRows.push([group.name, member.fioShort, String(member.tsdNumber), '', '', ''])
    }
  }

  // Один вызов autotable — естественный поток с автопереносом страниц
  autoTable(doc, {
    startY: marginT,
    margin: { left: marginL, top: marginT, right: marginR, bottom: marginB },
    body: allRows,
    theme: 'grid',

    // Не разрывать строку между страницами — если не влезает, уходит целиком на новый лист
    rowPageBreak: 'avoid',

    styles: {
      font: FONT_NAME,
      fontSize: 11,
      cellPadding: { top: 4, bottom: 4, left: 4, right: 4 },
      lineColor: [0, 0, 0],
      lineWidth: 0.75,
      textColor: [0, 0, 0],
      fillColor: [255, 255, 255],
      valign: 'middle',
    },
    columnStyles: {
      0: { cellWidth: col0, fontStyle: 'normal', fontSize: 9.1 },
      1: { cellWidth: col1, fontStyle: 'normal' },
      2: { cellWidth: col2, fontStyle: 'bold', halign: 'center' },
      3: { cellWidth: col3 },
      4: { cellWidth: col4 },
      5: { cellWidth: col5 },
    },
    head: [
      [
        {
          content: `Дата: ${data.date}`,
          colSpan: 2,
          styles: {
            fontStyle: 'bold', fontSize: 11,
            halign: 'center', valign: 'middle',
            cellPadding: { top: 5, bottom: 5 },
          },
        },
        {
          content: 'Реестр выдачи терминалов сбора данных',
          colSpan: 4,
          styles: {
            fontStyle: 'bold', fontSize: 11,
            halign: 'center', valign: 'middle',
            cellPadding: { top: 5, bottom: 5 },
          },
        },
      ],
      [
        { content: 'Должность', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
        { content: 'ФИО', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
        { content: '№ ТСД', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
        { content: 'Принял', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
        { content: 'Сдал', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
        { content: 'Отметка о неисправности ТСД', styles: { fontStyle: 'bold', halign: 'center', valign: 'middle' } },
      ],
    ],
  })

  const pdfBytes = doc.output('arraybuffer')
  return Buffer.from(pdfBytes)
}

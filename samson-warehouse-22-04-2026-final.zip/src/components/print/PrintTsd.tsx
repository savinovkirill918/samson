'use client';

import React, { useState, useEffect, useRef } from 'react';
import { FileText, Calendar, Loader2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Member } from '@/lib/types';

interface PrintTsdProps {
  members: Member[];
}

/** Форматирует Date в dd.mm.yyyy */
function formatDate(d: Date): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

/** Возвращает завтрашнюю дату */
function getTomorrow(): Date {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d;
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  padding: '10px 14px',
  border: '1px solid #dee2e6',
  borderRadius: '8px',
  fontSize: '14px',
  color: '#212529',
  backgroundColor: '#ffffff',
  cursor: 'pointer',
  boxSizing: 'border-box',
  outline: 'none',
};

export default function PrintTsd({ members }: PrintTsdProps) {
  const [selectedDate, setSelectedDate] = useState<string>(formatDate(getTomorrow()));
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const fpInstance = useRef<any>(null);

  const membersWithTsd = members.filter(m => m.tsdId !== null);

  useEffect(() => {
    if (!inputRef.current) return;

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css';
    document.head.appendChild(link);

    import('flatpickr').then((flatpickr) => {
      import('flatpickr/dist/l10n/ru.js').then((ru) => {
        fpInstance.current = flatpickr.default(inputRef.current!, {
          locale: ru.default.ru,
          dateFormat: 'd.m.Y',
          defaultDate: selectedDate,
          allowInput: false,
          disableMobile: true,
          onChange: (selectedDates: Date[]) => {
            if (selectedDates.length > 0) {
              setSelectedDate(formatDate(selectedDates[0]));
            }
          },
        });
      });
    });

    return () => {
      try { document.head.removeChild(link); } catch {}
      if (fpInstance.current) {
        fpInstance.current.destroy();
        fpInstance.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const url = `/api/print/tsd-pdf?date=${encodeURIComponent(selectedDate)}`;
      window.open(url, '_blank');
    } catch (err) {
      console.error('Error opening PDF:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        <FileText className="w-5 h-5 inline-block mr-2 -mt-0.5" />
        Реестр ТСД
      </h2>

      <div className="bg-white rounded-xl shadow p-6">
        <p className="text-sm mb-6" style={{ color: COLORS.text }}>
          Формирование реестра выдачи терминалов сбора данных. PDF откроется в новой вкладке.
          Всего сотрудников с ТСД: <strong style={{ color: COLORS.heading }}>{membersWithTsd.length}</strong>
        </p>

        <div className="flex flex-wrap items-end gap-6">
          <div className="w-64">
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>
              <Calendar className="w-4 h-4 inline-block mr-1.5 -mt-0.5" />
              Дата реестра
            </label>
            <input
              ref={inputRef}
              type="text"
              readOnly
              style={inputStyle}
            />
          </div>

          <div>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="flex items-center gap-2 px-6 py-2.5 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
              style={{ backgroundColor: COLORS.primary }}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              {loading ? 'Формирование...' : 'Сформировать'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

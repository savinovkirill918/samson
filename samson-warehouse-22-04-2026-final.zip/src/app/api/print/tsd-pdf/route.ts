import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { generateTsdRegistryPdf } from '@/lib/generateTsdRegistry'

// GET /api/print/tsd-pdf?date=dd.mm.yyyy — генерация и отдача PDF реестра ТСД
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const date = searchParams.get('date') || ''

    if (!date) {
      return NextResponse.json({ error: 'Укажите дату параметром ?date=dd.mm.yyyy' }, { status: 400 })
    }

    // Группы, исключаемые из реестра ТСД
    const excludedGroupIds = [8, 9, 15] // Водитель КОР, Системный администратор WMS, Водитель ОПТ

    // Получаем всех сотрудников с привязанными ТСД
    const members = await prisma.member.findMany({
      where: {
        tsdId: { not: null },
        groupId: { notIn: excludedGroupIds },
      },
      include: { group: true, tsd: true },
      orderBy: { fio: 'asc' },
    })

    // Группируем по должности
    const groupMap = new Map<string, { name: string; sort: number; members: Array<{ fioShort: string; tsdNumber: number }> }>()

    for (const m of members) {
      const groupName = m.group?.name || 'Без должности'
      const groupSort = m.group?.sort ?? 999

      if (!groupMap.has(groupName)) {
        groupMap.set(groupName, { name: groupName, sort: groupSort, members: [] })
      }

      const parts = (m.fio || '').trim().split(/\s+/)
      let fioShort = m.fio
      if (parts.length >= 3) {
        fioShort = `${parts[0]} ${parts[1].charAt(0)}. ${parts[2].charAt(0)}.`
      } else if (parts.length === 2) {
        fioShort = `${parts[0]} ${parts[1].charAt(0)}.`
      }

      groupMap.get(groupName)!.members.push({
        fio: m.fio,
        fioShort,
        tsdNumber: m.tsd?.number ?? 0,
      })
    }

    const groups = Array.from(groupMap.values())
      .sort((a, b) => a.sort - b.sort || a.name.localeCompare(b.name))

    for (const g of groups) {
      g.members.sort((a, b) => a.fio.localeCompare(b.fio))
    }

    // Генерируем PDF
    const pdfBuffer = await generateTsdRegistryPdf({ date, groups })

    // Отдаём PDF
    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="reestr-tsd-${date}.pdf"`,
        'Content-Length': String(pdfBuffer.length),
      },
    })
  } catch (error) {
    console.error('Error generating TSD registry PDF:', error)
    return NextResponse.json({ error: 'Ошибка генерации реестра' }, { status: 500 })
  }
}

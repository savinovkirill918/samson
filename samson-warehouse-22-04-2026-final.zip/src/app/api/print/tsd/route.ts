import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/print/tsd?date=dd.mm.yyyy — данные для реестра ТСД
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const date = searchParams.get('date') || ''

    // Группы, исключаемые из реестра ТСД
    const excludedGroupIds = [8, 9, 15] // Водитель КОР, Системный администратор WMS, Водитель ОПТ

    // Получаем всех сотрудников с привязанными ТСД, включая должность и само ТСД
    const members = await prisma.member.findMany({
      where: {
        tsdId: { not: null },
        groupId: { notIn: excludedGroupIds },
      },
      include: { group: true, tsd: true },
      orderBy: { fio: 'asc' },
    })

    // Группируем по должности (sort asc, name asc)
    const groupMap = new Map<string, { name: string; sort: number; members: Array<{ fio: string; fioShort: string; tsdNumber: number }> }>()

    for (const m of members) {
      const groupName = m.group?.name || 'Без должности'
      const groupSort = m.group?.sort ?? 999

      if (!groupMap.has(groupName)) {
        groupMap.set(groupName, { name: groupName, sort: groupSort, members: [] })
      }

      const parts = (m.fio || '').trim().split(/\s+/)
      let fioShort = m.fio
      if (parts.length >= 3) {
        fioShort = `${parts[0]} ${parts[1].charAt(0)}. ${parts[2].charAt(0)}.`
      } else if (parts.length === 2) {
        fioShort = `${parts[0]} ${parts[1].charAt(0)}.`
      }

      groupMap.get(groupName)!.members.push({
        fio: m.fio,
        fioShort,
        tsdNumber: m.tsd?.number ?? 0,
      })
    }

    // Сортируем группы по sort, внутри — по ФИО
    const groups = Array.from(groupMap.values())
      .sort((a, b) => a.sort - b.sort || a.name.localeCompare(b.name))

    for (const g of groups) {
      g.members.sort((a, b) => a.fio.localeCompare(b.fio))
    }

    return NextResponse.json({ date, groups })
  } catch (error) {
    console.error('Error fetching TSD registry data:', error)
    return NextResponse.json({ error: 'Ошибка получения данных реестра' }, { status: 500 })
  }
}

// =====================================================================
// PM2 конфигурация — Самсон Склад
//
// ПЕРЕД ЗАПУСКОМ на новом сервере измените:
//   1. cwd           — путь к директории проекта
//   2. DATABASE_URL  — абсолютный путь к файлу базы данных
//   3. error_file / out_file / log_file — пути к логам (по желанию)
//
// Запуск: pm2 start ecosystem.config.js
// =====================================================================

module.exports = {
  apps: [
    {
      name: 'samson-warehouse',
      script: '.next/standalone/server.js',
      cwd: '/home/z/my-project/samson/app',
      env: {
        NODE_ENV: 'production',
        DATABASE_URL: 'file:/home/z/my-project/samson/app/db/custom.db',
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      error_file: '/home/z/.pm2/logs/samson-warehouse-error.log',
      out_file: '/home/z/.pm2/logs/samson-warehouse-out.log',
      log_file: '/home/z/.pm2/logs/samson-warehouse.log',
      time: true,
      merge_logs: true,
    },
  ],
};

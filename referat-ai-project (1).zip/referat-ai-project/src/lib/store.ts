import { create } from 'zustand';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  status: string;
  createdAt: string;
}

export interface SessionInfo {
  id: string;
  title: string;
  targetPages: number;
  status: string;
  messages: Message[];
  createdAt: string;
}

interface AppState {
  // Current session
  currentSession: SessionInfo | null;
  isGenerating: boolean;
  streamingContent: string;
  currentPhase: string;
  phaseIndex: number;
  totalPhases: number;
  progress: number;
  error: string | null;

  // Actions
  setCurrentSession: (session: SessionInfo | null) => void;
  setIsGenerating: (val: boolean) => void;
  setStreamingContent: (content: string) => void;
  appendStreamingContent: (chunk: string) => void;
  setCurrentPhase: (phase: string, index: number, total: number, progress: number) => void;
  setProgress: (progress: number) => void;
  setError: (error: string | null) => void;
  reset: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentSession: null,
  isGenerating: false,
  streamingContent: '',
  currentPhase: '',
  phaseIndex: 0,
  totalPhases: 0,
  progress: 0,
  error: null,

  setCurrentSession: (session) => set({ currentSession: session }),
  setIsGenerating: (val) => set({ isGenerating: val }),
  setStreamingContent: (content) => set({ streamingContent: content }),
  appendStreamingContent: (chunk) =>
    set((state) => ({ streamingContent: state.streamingContent + chunk })),
  setCurrentPhase: (phase, index, total, progress) =>
    set({ currentPhase: phase, phaseIndex: index, totalPhases: total, progress }),
  setProgress: (progress) => set({ progress }),
  setError: (error) => set({ error }),
  reset: () =>
    set({
      currentSession: null,
      isGenerating: false,
      streamingContent: '',
      currentPhase: '',
      phaseIndex: 0,
      totalPhases: 0,
      progress: 0,
      error: null,
    }),
}));

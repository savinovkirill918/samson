import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// Timeout constants
const PHASE_TIMEOUT_MS = 300_000;  // 5 minutes per phase
const READ_TIMEOUT_MS = 90_000;    // 90 seconds for each read from stream
const MAX_GENERATION_MS = 3_600_000;  // 60 minutes total for full referat (up to 50 pages)
const MAX_RETRIES_PER_SECTION = 2;  // Max retries for short sections

/**
 * Create a promise that rejects after `ms` milliseconds.
 */
function timeoutPromise(ms: number, label: string): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error(`Timeout (${label}) after ${ms / 1000}s`)), ms);
  });
}

export interface GenerationPhase {
  name: string;
  prompt: string;
  temperature?: number;
}

interface SubsectionInfo {
  title: string;
  description: string;
}

interface ChapterInfo {
  title: string;
  description: string;
  subsections: SubsectionInfo[];
}

// ============================================================
// УРОВЕНЬ 1: SYSTEM_PROMPT (Глобальные правила)
// ============================================================
const SYSTEM_PROMPT = `Ты — академический писатель-аналитик, эксперт в систематизации информации. Пиши СТРОГО на русском языке. Английские термины запрещены в основном тексте (кроме общепринятых аббревиатур).

=== 1. СТИЛЬ И ТОН ===
- Научный, академический, объективный, безэмоциональный.
- СТРОГО ЗАПРЕЩЕНО: Местоимения «я», «мы», «мне», «наш». Разговорные выражения, сленг, публицистические штампы, оценочные суждения без опоры на источники.
- РЕКОМЕНДОВАНО: Безличные конструкции («рассмотрено», «представляется целесообразным», «исследование показало»), пассивный залог, строгая терминология.

=== 2. СТРУКТУРНЫЕ ПРАВИЛА ===
- Введение: 10-15% объёма | Основная часть: 70-80% | Заключение: 10-15%.
- Заголовки ВВЕДЕНИЕ, ЗАКЛЮЧЕНИЕ, СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ пишутся ЗАГЛАВНЫМИ БУКВАМИ (H1).
- Точка в конце заголовков ЗАПРЕЩЕНА. Подчеркивание заголовков ЗАПРЕЩЕНО.
- ЗАГОЛОВКИ должны быть ПОЛНЫМИ предложениями или завершёнными фразами. ЗАПРЕЩЕНО обрывать заголовок на союзе/предлоге (например, «Система управления процессами и» — ОШИБКА). Каждый заголовок должен быть грамматически завершён.

=== 3. ПРАВИЛА СОДЕРЖАНИЯ (АНТИ-ВОДА) ===
1. УНИКАЛЬНОСТЬ: Каждая глава и параграф раскрывают УНИКАЛЬНЫЙ аспект. Повторение одного и того же смысла, фактов или примеров в разных разделах ЗАПРЕЩЕНО.
2. НЕТ ШАБЛОНАМ: ЗАПРЕЩЕНО писать «Заключение по главе», «Выводы по главе», «Введение в главу», «Список литературы» внутри глав. Пиши только содержательный анализ.
3. ПЛОТНОСТЬ: 1 абзац = 1 новая мысль/факт/аргумент. ЗАПРЕЩЕНО писать абзацы-вступления к главам (например, «В данной главе будут рассмотрены...»). Сразу переходи к сути.
4. ЗАПРЕЩЕННЫЕ ФРАЗЫ: «Как было сказано ранее», «Как упоминалось выше», «Нельзя не сказать», «Важно отметить» (без конкретного факта).
5. НЕЙТРАЛИТЕТ: Если есть разные подходы, объективно представь основные точки зрения без перекоса.
6. ГЛУБИНА: Избегай поверхностного пересказа. Текст должен иметь аналитическую глубину (причинно-следственные связи, классификации, критика).

=== 4. ЛОГИЧЕСКИЕ СВЯЗКИ ===
ВАРЬИРУЙ связки! НЕ используй одну и ту же связку чаще 2-3 раз на весь текст. Чередуй:
- Итоговые: «Таким образом», «Следовательно», «Стало быть», «Подытоживая», «Резюмируя», «На основании вышеизложенного»
- Противительные: «В отличие от», «Напротив», «Однако», «Вместе с тем», «С другой стороны», «В то же время»
- Причинные: «В связи с этим», «Исходя из этого», «В силу этого», «По этой причине», «Вследствие чего»
- Присоединительные: «Кроме того», «Помимо этого», «Наряду с этим», «К тому же», «Более того»
ЗАПРЕЩЕНО: использовать «В отличие от» как единственную форму сравнения. ЗАПРЕЩЕНО: использовать «Таким образом» как единственную итоговую связку.

=== 5. ФАКТОЛОГИЧЕСКАЯ ТОЧНОСТЬ ===
- ЗАПРЕЩЕНО придумывать несуществующие факты, даты, имена исследователей, названия компаний. Если не уверен в факте — НЕ включай его.
- ЗАПРЕЩЕНО приводить конкретные примеры использования продукта в проектах, если ты не уверен на 100%, что этот факт реален. Лучше общий анализ, чем ложный пример.
- ЗАПРЕЩЕНО вставлять ссылки на источники в тексте глав в формате [1], [2, с. 15] и подобные. Текст должен быть без внутритекстовых ссылок.
- ЗАПРЕЩЕНО указывать имена сооснователей, разработчиков, CEO и т.д., если ты не уверен на 100% в их правильности.
- Если тема касается конкретного программного продукта — ОБЯЗАТЕЛЬНО уточняй актуальную версию (например, «QNX Neutrino 7.x», а не просто «QNX»). ЗАПРЕЩЕНО смешивать информацию о разных версиях продукта.
- ЗАПРЕЩЕНО писать «впервые реализованный» или «впервые созданный» без подтверждения — почти у каждой технологии были предшественники.
- ТИПИЧНЫЕ ОШИБКИ, КОТОРЫХ НУЖНО ИЗБЕГАТЬ:
  * НЕ пиши «впервые реализованный в QNX» — микроядро существовало ДО QNX (HYDRA, Mach).
  * НЕ путай версии QNX: QNX 2 (1988), QNX 4 (1991), QNX Neutrino 6 (1999+). Проверяй даты.
  * ОБЯЗАТЕЛЬНО используй полное название «QNX Neutrino» при упоминании версий 6.x+.
  * НЕ пиши «сбояируется» — такого слова нет. Правильно: «изолируется».
  * НЕ пиши «алгоритум» — правильно: «алгоритм».
  * НЕ пиши «предпочтительной выбором» — правильно: «предпочтительным выбором».
  * НЕ пиши «занить» — правильно: «занять».
  * НЕ пиши «функцианирование» — правильно: «функционирование».
  * НЕ пиши «О общего назначения» — правильно: «ОС общего назначения».
- ПРИНЦИП: сомневаешься — не пиши. Общее утверждение лучше ложной конкретики.

=== 6. ПРАВИЛО ОБЪЁМА ===
- ОБЯЗАТЕЛЬНО пиши текст указанного объёма. Если указано «минимум 4000 символов» — пиши НЕ МЕНЕЕ 4000 символов. Краткость НЕ ценится — ценится глубина анализа.
- Каждый параграф должен содержать развёрнутый анализ с примерами, классификациями, причинно-следственными связями.

=== 7. ЯЗЫКОВАЯ ЧИСТОТА ===
- Текст пишется СТРОГО на русском языке.
- ЗАПРЕЩЕНО использование китайских, японских, корейских иероглифов и символов.
- Английские термины в основном тексте ЗАПРЕЩЕНЫ, КРОМЕ:
  а) Общепринятых аббревиатур: IPC, TCP/IP, POSIX, API, IoT, SDK, IDE, OTA, ECU, SMP, PID, FAT, NTFS, USB, PCI, SATA, CAN, TLS, IPsec, VPN, SSH, AES, RSA, SHA, TPM, GPU, CPU, URL, HTTP, FTP, SNMP, AWS, ARM, MIPS, x86, RISC-V, PowerPC, VxWorks, FreeRTOS, RTLinux, Modbus, CANopen, Profibus, OPC, Wi-Fi, QNX и подобных.
  б) Английские термины В СКОБКАХ после русского перевода — РАЗРЕШЕНО и ЖЕЛАТЕЛЬНО. Пример: «межпроцессное взаимодействие (IPC)», «управление памятью (Memory Management)», «цепочка доверия (chain of trust)».
- ЗАПРЕЩЕНО смешение языков в одном предложении (кроме случая 7б — английский термин в скобках после русского).
- ЗАПРЕЩЕНО вставлять иноязычные фрагменты любого рода ВНЕ скобок.
- КРИТИЧЕСКИ ВАЖНО: Если ты добавляешь скобки с английским термином — ОБЯЗАТЕЛЬНО пиши термин внутри. НИКОГДА не оставляй скобки пустыми. Пример правильно: «управление памятью (MMU)». Пример ОШИБКА: «управление памятью ()» — пустые скобки ЗАПРЕЩЕНЫ. Если не знаешь английский термин — не ставь скобки вообще.

=== 8. АНТИ-ПОВТОР (КРИТИЧЕСКИ ВАЖНО — ПРОВЕРЯЙ КАЖДЫЙ АБЗАЦ) ===
ЗАПРЕЩЕНО использовать одни и те же формулировки и конструкции из абзаца в абзац:

СПИСОК ЗАПРЕЩЁННЫХ ФРАЗ (можно использовать НЕ БОЛЕЕ указанного количества раз на ВЕСЬ текст):
- «предпочтительным выбором» — МАКСИМУМ 1 раз. Замены: «оптимальным решением», «наиболее подходящим вариантом», «целесообразным выбором», «обоснованным решением»
- «высочайший уровень» — МАКСИМУМ 2 раза. Замены: «максимальный», «исключительный», «беспрецедентный», «наивысший», «непревзойдённый»
- «критически важных» — МАКСИМУМ 2 раза. Замены: «ключевых», «стратегических», «принципиальных», «существенных», «ответственных», «наиболее значимых»
- «работают в комплексе» — МАКСИМУМ 1 раз. Замены: «взаимодополняют друг друга», «действуют совместно», «образуют единую систему», «функционируют согласованно»
- «что делает её незаменимым» — МАКСИМУМ 0 раз. ЗАПРЕЩЕНО ПОЛНОСТЬЮ. Замены: «что определяет её уникальную роль», «что повышает её значимость»
- «где недопустимы сбои и отказы» — МАКСИМУМ 1 раз. Замены: «где цена ошибки недопустимо высока», «где надёжность является безусловным требованием»
- «Данный подход/механизм/принцип позволяет» — МАКСИМУМ 2 раза. Замены: «Рассматриваемый метод позволяет», «Этот принцип обеспечивает», «Анализируемый механизм даёт возможность»

ЗАПРЕЩЕНО начинать более 2 абзацев с «Классификация». Используй: «Типология», «Разновидности», «Группировка», «Систематизация».

ШАБЛОННЫЕ ОКОНЧАНИЯ АБЗАЦЕВ — ЗАПРЕЩЕНЫ ПОЛНОСТЬЮ (0 раз):
- «что делает её предпочтительным выбором для критически важных приложений» — НИКОГДА не пиши
- «Данные X работают в комплексе, обеспечивая высочайший уровень Y» — НИКОГДА не пиши
- «что делает её незаменимым инструментом/элементом» — НИКОГДА не пиши

КАЖДЫЙ абзац должен заканчиваться УНИКАЛЬНЫМ конкретным выводом. НЕ пиши общие фразы в конце — пиши конкретное следствие или факт.

ПРАВИЛО «НЕ ПОВТОРЯЙ СЕБЯ»: Перед написанием каждого абзаца проверяй — использовал ли ты уже эту формулировку? Если ДА — выбери другой способ выразить ту же мысль. ВЕСЬ текст должен содержать МИНИМУМ повторяющихся конструкций.`;

// ============================================================
// Динамическое определение количества глав и подглав
// ============================================================
function getChaptersCount(pages: number): number {
  if (pages <= 5) return 2;
  if (pages <= 15) return 3;
  if (pages <= 25) return 4;
  return 5;
}

function getSubsectionsPerChapter(pages: number): number {
  if (pages <= 10) return 2;
  if (pages <= 25) return 3;
  return 4;  // 26-50 pages: 4 subsections per chapter for more volume
}

// ============================================================
// Stream a single phase from the LLM with timeout protection
// ============================================================
export async function* streamPhase(
  systemPrompt: string,
  userPrompt: string,
  phaseTimeoutMs: number = PHASE_TIMEOUT_MS,
  temperature: number = 0.7
): AsyncGenerator<string, void, unknown> {
  const zai = await getZAI();
  const controller = new AbortController();
  const phaseStart = Date.now();

  const phaseTimer = setTimeout(() => {
    controller.abort();
  }, phaseTimeoutMs);

  try {
    const stream = await Promise.race([
      zai.chat.completions.create({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        stream: true,
        temperature,
        max_tokens: 32768,
      }),
      timeoutPromise(45_000, 'LLM connection'),
    ]);

    const reader = (stream as ReadableStream<Uint8Array>).getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        if (Date.now() - phaseStart > phaseTimeoutMs) {
          throw new Error(`Phase timeout after ${phaseTimeoutMs / 1000}s`);
        }

        const { done, value } = await Promise.race([
          reader.read(),
          timeoutPromise(READ_TIMEOUT_MS, 'stream read'),
        ]);

        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed === 'data: [DONE]') continue;
          if (trimmed.startsWith('data: ')) {
            try {
              const parsed = JSON.parse(trimmed.slice(6));
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                yield content;
              }
            } catch {
              // Skip unparseable lines
            }
          }
        }
      }

      if (buffer.trim()) {
        const trimmed = buffer.trim();
        if (trimmed.startsWith('data: ') && trimmed !== 'data: [DONE]') {
          try {
            const parsed = JSON.parse(trimmed.slice(6));
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              yield content;
            }
          } catch {
            // Skip
          }
        }
      }
    } finally {
      try { reader.releaseLock(); } catch { /* ignore */ }
    }
  } finally {
    clearTimeout(phaseTimer);
  }
}

// ============================================================
// Collect full text from a stream (non-streaming helper)
// ============================================================
async function collectStream(
  systemPrompt: string,
  userPrompt: string,
  phaseTimeoutMs: number = PHASE_TIMEOUT_MS,
  temperature: number = 0.5
): Promise<string> {
  let result = '';
  for await (const chunk of streamPhase(systemPrompt, userPrompt, phaseTimeoutMs, temperature)) {
    result += chunk;
  }
  return result;
}

// ============================================================
// Parse plan — extract chapters and subsections
// ============================================================
function parsePlan(planText: string): ChapterInfo[] {
  const chapters: ChapterInfo[] = [];
  const lines = planText.split('\n');
  let currentChapter: ChapterInfo | null = null;

  for (const line of lines) {
    // Match ## Глава N. Title
    const chapterMatch = line.match(/^##\s*Глава\s+\d+\.\s*(.+)/i);
    if (chapterMatch) {
      if (currentChapter) {
        chapters.push(currentChapter);
      }
      currentChapter = {
        title: chapterMatch[1].trim(),
        description: '',
        subsections: [],
      };
      continue;
    }

    // Match ### N.M. Title — Description
    const subMatch = line.match(/^###\s*\d+\.\d+\.\s*(.+)/i);
    if (subMatch && currentChapter) {
      const subText = subMatch[1].trim();
      const dashIdx = subText.indexOf(' — ');
      if (dashIdx !== -1) {
        currentChapter.subsections.push({
          title: subText.slice(0, dashIdx).trim(),
          description: subText.slice(dashIdx + 3).trim(),
        });
      } else {
        const dashIdx2 = subText.indexOf('- ');
        if (dashIdx2 !== -1) {
          currentChapter.subsections.push({
            title: subText.slice(0, dashIdx2).trim(),
            description: subText.slice(dashIdx2 + 2).trim(),
          });
        } else {
          currentChapter.subsections.push({
            title: subText,
            description: '',
          });
        }
      }
      continue;
    }

    // Description text after chapter heading (before subsections)
    if (currentChapter && !line.match(/^###/) && line.trim()) {
      if (currentChapter.subsections.length === 0) {
        currentChapter.description += (currentChapter.description ? ' ' : '') + line.trim();
      }
    }
  }

  if (currentChapter) {
    chapters.push(currentChapter);
  }

  return chapters;
}

// ============================================================
// Extract tasks from Introduction text
// ============================================================
function extractTasks(introText: string): string {
  const taskPatterns = [
    /(?:задач[а-я]*\s*(?:исследования\s*)?(?:являются|состоят в|:\s*|—\s*|–\s*))([\s\S]*?)(?=\n\n|\n[А-Я][а-я])/i,
    /(?:для\s*достижения\s*цели\s*поставлены\s*следующие\s*задачи:\s*)([\s\S]*?)(?=\n\n|\n[А-Я][а-я])/i,
  ];

  for (const pattern of taskPatterns) {
    const match = introText.match(pattern);
    if (match && match[1]) {
      return match[1].trim();
    }
  }

  // Fallback: look for lines with task verbs
  const taskVerbs = /(?:изучить|проанализировать|сравнить|систематизировать|рассмотреть|исследовать|определить|выявить|оценить|охарактеризовать)/i;
  const lines = introText.split('\n');
  const taskLines: string[] = [];
  let inTasks = false;

  for (const line of lines) {
    if (taskVerbs.test(line)) {
      inTasks = true;
      taskLines.push(line.trim());
    } else if (inTasks && line.trim() && !line.match(/^#\s/)) {
      taskLines.push(line.trim());
    } else if (inTasks) {
      break;
    }
  }

  return taskLines.join(' ').trim() || 'задачи не найдены';
}

// ============================================================
// Create summary of previously written text
// ============================================================
function createSummary(text: string, maxLen: number = 800): string {
  if (text.length <= maxLen) return text;
  const head = text.slice(0, 400);
  const tail = text.slice(maxLen - 400);
  return head + '\n[...]\n' + tail;
}

// ============================================================
// Main generation function
// ============================================================
export async function generateFullReferat(
  topic: string,
  pages: number,
  onChunk: (chunk: string) => Promise<void>,
  onPhaseStart: (phaseName: string, phaseIndex: number, totalPhases: number) => Promise<void>
): Promise<string> {
  const chaptersCount = getChaptersCount(pages);
  const subsPerChapter = getSubsectionsPerChapter(pages);
  const charsPerPage = 1800;
  const totalChars = pages * charsPerPage;
  // Cap total to prevent massive overshoot (max +20% over target)
  const maxTotalChars = Math.round(totalChars * 1.2);
  const introChars = Math.round(totalChars * 0.12);
  const chapterChars = Math.round((totalChars * 0.75) / chaptersCount);
  const subsectionChars = Math.round(chapterChars / subsPerChapter);
  const conclusionChars = Math.round(totalChars * 0.12);
  const referencesCount = Math.min(30, Math.max(5, Math.round(pages * 1.5)));

  let fullText = '';
  let planText = '';
  let chapterInfos: ChapterInfo[] = [];
  let tasksFromIntro = '';

  // Overall generation timeout
  const generationStart = Date.now();

  const checkGlobalTimeout = () => {
    if (Date.now() - generationStart > MAX_GENERATION_MS) {
      throw new Error(`Общая генерация превысила лимит в ${MAX_GENERATION_MS / 1000}s.`);
    }
  };

  // Helper: stream text to client and collect
  const streamAndCollect = async (systemPrompt: string, userPrompt: string, temp: number = 0.5): Promise<string> => {
    let result = '';
    try {
      for await (const chunk of streamPhase(systemPrompt, userPrompt, PHASE_TIMEOUT_MS, temp)) {
        result += chunk;
        fullText += chunk;
        await onChunk(chunk);
      }
    } catch (err) {
      console.error('Stream error:', err);
    }
    return result;
  };

  // ============================================================
  // PHASE 0: План (internal)
  // ============================================================
  checkGlobalTimeout();
  await onPhaseStart('План', 0, 6 + chaptersCount * subsPerChapter);

  const planPrompt = `Составь подробный ПЛАН реферата на тему "${topic}".
Реферат должен содержать ${chaptersCount} глав. В каждой главе ОБЯЗАТЕЛЬНО ${subsPerChapter} параграфа (H3).

ЖЕСТКАЯ СТРУКТУРА:
- Введение (10-15%)
- ${chaptersCount} глав, каждая с ОБЯЗАТЕЛЬНОЙ внутренней разбивкой на ${subsPerChapter} параграфов (H3).
- Заключение (10-15%)
- Список литературы

ПРАВИЛА ПЛАНИРОВАНИЯ:
- Изложение от общего к частному.
- Название главы НЕ дублирует тему реферата "${topic}".
- НАЗВАНИЯ ВСЕХ ГЛАВ ДОЛЖНЫ БЫТЬ УНИКАЛЬНЫМИ МЕЖДУ СОБОЙ — ЗАПРЕЩЕНО дублирование или смысловое сходство названий разных глав. Каждая глава — принципиально другой аспект темы.
- Названия параграфов НЕ дублируют названия глав и тему реферата.
- Названия параграфов внутри одной главы также должны быть уникальными.
- Каждая глава и параграф раскрывают УНИКАЛЬНЫЙ аспект (строгий запрет на пересечение тем между главами).
- ЗАГЛАВИЯ параграфов должны быть ПОЛНЫМИ и ЗАВЕРШЁННЫМИ. Запрещено обрывать название на союзе или предлоге (например, «Система управления процессами и» — ОШИБКА).

Формат вывода — СТРОГО:
## Глава 1. [Название главы]
### 1.1. [Название параграфа] — [1 предложение описания сути]
### 1.2. [Название параграфа] — [1 предложение описания сути]${subsPerChapter >= 3 ? `\n### 1.3. [Название параграфа] — [1 предложение описания сути]` : ''}${subsPerChapter >= 4 ? `\n### 1.4. [Название параграфа] — [1 предложение описания сути]` : ''}

## Глава 2. [Название главы]
### 2.1. [Название параграфа] — [1 предложение описания сути]
### 2.2. [Название параграфа] — [1 предложение описания сути]${subsPerChapter >= 3 ? `\n### 2.3. [Название параграфа] — [1 предложение описания сути]` : ''}${subsPerChapter >= 4 ? `\n### 2.4. [Название параграфа] — [1 предложение описания сути]` : ''}
${chaptersCount >= 3 ? `\n## Глава 3. [Название главы]\n### 3.1. [Название параграфа] — [1 предложение описания сути]\n### 3.2. [Название параграфа] — [1 предложение описания сути]${subsPerChapter >= 3 ? `\n### 3.3. [Название параграфа] — [1 предложение описания сути]` : ''}${subsPerChapter >= 4 ? `\n### 3.4. [Название параграфа] — [1 предложение описания сути]` : ''}` : ''}
${chaptersCount >= 4 ? `\n## Глава 4. [Название главы]\n### 4.1. [Название параграфа] — [1 предложение описания сути]\n### 4.2. [Название параграфа] — [1 предложение описания сути]${subsPerChapter >= 3 ? `\n### 4.3. [Название параграфа] — [1 предложение описания сути]` : ''}${subsPerChapter >= 4 ? `\n### 4.4. [Название параграфа] — [1 предложение описания сути]` : ''}` : ''}
${chaptersCount >= 5 ? `\n## Глава 5. [Название главы]\n### 5.1. [Название параграфа] — [1 предложение описания сути]\n### 5.2. [Название параграфа] — [1 предложение описания сути]${subsPerChapter >= 3 ? `\n### 5.3. [Название параграфа] — [1 предложение описания сути]` : ''}${subsPerChapter >= 4 ? `\n### 5.4. [Название параграфа] — [1 предложение описания сути]` : ''}` : ''}

Пиши ТОЛЬКО план.`;

  planText = await collectStream(SYSTEM_PROMPT, planPrompt, PHASE_TIMEOUT_MS, 0.7);
  chapterInfos = parsePlan(planText);

  // Check for duplicate chapter titles — re-request plan if duplicates found
  const chapterTitles = chapterInfos.map(ch => ch.title.toLowerCase().replace(/\s+/g, ' ').trim());
  const hasDuplicateTitles = new Set(chapterTitles).size !== chapterTitles.length;
  if (hasDuplicateTitles && chapterInfos.length > 0) {
    console.log('Duplicate chapter titles detected, re-requesting plan...');
    const retryPlanPrompt = planPrompt + '\n\nВНИМАНИЕ: В предыдущей попытке названия глав дублировались или были слишком похожи. КАЖДАЯ глава должна иметь ПРИНЦИПИАЛЬНО ОТЛИЧНОЕ название, раскрывающее РАЗНЫЕ аспекты темы. Не используйте синонимы или перефразировки одного и того же.';
    planText = await collectStream(SYSTEM_PROMPT, retryPlanPrompt, PHASE_TIMEOUT_MS, 0.7);
    const retryChapters = parsePlan(planText);
    if (retryChapters.length >= chaptersCount) {
      chapterInfos = retryChapters;
    }
  }

  // Fallback if plan parsing failed
  if (chapterInfos.length === 0) {
    const fallbackTitles = chaptersCount === 2
      ? ['Теоретические основы', 'Практическое применение и анализ']
      : chaptersCount === 3
        ? ['Теоретические основы', 'Механизмы и особенности', 'Практическое применение и перспективы']
        : chaptersCount === 4
          ? ['Теоретические основы', 'История развития', 'Механизмы и особенности', 'Практическое применение']
          : ['Теоретические основы', 'История развития', 'Механизмы и особенности', 'Практическое применение', 'Перспективы развития'];
    chapterInfos = fallbackTitles.map(title => ({
      title,
      description: '',
      subsections: Array.from({ length: subsPerChapter }, (_, j) => ({
        title: `Параграф ${j + 1}`,
        description: '',
      })),
    }));
  }

  // Ensure each chapter has enough subsections
  for (const ch of chapterInfos) {
    while (ch.subsections.length < subsPerChapter) {
      ch.subsections.push({
        title: `Дополнительный аспект ${ch.subsections.length + 1}`,
        description: '',
      });
    }
  }

  // Validate subsection titles are not incomplete (e.g. ending with "и")
  for (const ch of chapterInfos) {
    for (const sub of ch.subsections) {
      const trimmed = sub.title.trim();
      if (trimmed.endsWith(' и') || trimmed.endsWith(' или') || trimmed.endsWith(' на')) {
        sub.title = trimmed.replace(/\s+(и|или|на)$/, '');
      }
    }
  }

  // ============================================================
  // PHASE 1: Введение — with explicit chapter plan context
  // ============================================================
  checkGlobalTimeout();
  await onPhaseStart('Введение', 1, 6 + chaptersCount * subsPerChapter);

  // Build explicit chapter→task mapping for introduction
  const chapterTaskMapping = chapterInfos.map((ch, idx) => {
    const taskVerbs = ['изучить', 'проанализировать', 'рассмотреть', 'систематизировать', 'исследовать', 'оценить', 'охарактеризовать', 'выявить'];
    const verb = taskVerbs[idx % taskVerbs.length];
    return `${idx + 1}. ${verb} ${ch.title.toLowerCase()} (Глава ${idx + 1} «${ch.title}»)`;
  }).join('; ');

  const introPrompt = `Напиши ВВЕДЕНИЕ для реферата на тему "${topic}".
Объём — МИНИМУМ ${introChars} символов, но НЕ БОЛЕЕ ${Math.round(introChars * 1.5)} символов. Строго соблюдай лимит!

СТРУКТУРА (строго обязательно, каждый пункт — отдельный абзац):
1. Актуальность темы исследования (почему это важно сейчас, объективно).
2. Объект исследования (широкая область).
3. Предмет исследования (конкретный аспект объекта).
4. Цель реферата («Целью данного реферата является...»).
5. Задачи исследования (строго глаголами). РОВНО ${chaptersCount} задач — по одной на каждую главу. ЗАДАЧИ ДОЛЖНЫ СТРОГО СООТВЕТСТВОВАТЬ ГЛАВАМ:
${chapterTaskMapping}
6. Методы исследования (например: анализ, синтез, дедукция, обобщение).
7. Планируемые результаты (что будет результатом анализа).

СТИЛЬ: Безличный. Без «я», «мы».
Формат: # ВВЕДЕНИЕ (H1, по центру)`;

  await streamAndCollect(SYSTEM_PROMPT, introPrompt, 0.7);
  tasksFromIntro = extractTasks(fullText);

  fullText += '\n\n';
  await onChunk('\n\n');

  // ============================================================
  // PHASE 2..N: Главы — генерация по подглавам (H3)
  // ============================================================
  const planSummary = chapterInfos.map((ch, idx) => `Глава ${idx + 1}. ${ch.title}`).join('\n');
  const coveredTopics: string[] = [];
  // Track recently used phrases to inject into prompts for anti-repeat
  const usedPhrases: string[] = [];

  // Anti-template rotation: vary writing instructions for each subsection
  const writingStyles = [
    'Раскрывай тему через анализ архитектурных решений и их влияние на практику.',
    'Строй изложение от конкретных примеров к общим закономерностям.',
    'Используй сравнительный подход: сопоставляй альтернативные решения.',
    'Опирайся на хронологическую логику: от предпосылок к результатам.',
    'Применяй проблемный подход: сформулируй проблему, затем покажи пути решения.',
    'Структурируй через декомпозицию: от целого к частям, от системы к элементам.',
    'Веди анализ через призму компромиссов: каждое решение имеет плюсы и минусы.',
    'Рассматривай тему в контексте эволюции: как менялись подходы со временем.',
  ];

  for (let chapterNum = 1; chapterNum <= chapterInfos.length; chapterNum++) {
    checkGlobalTimeout();
    const chapterInfo = chapterInfos[chapterNum - 1];
    const chapterIndex = chapterNum - 1;

    // Check if we've exceeded max chars — if so, skip remaining chapters
    if (fullText.length >= maxTotalChars) {
      console.log(`Max chars reached (${fullText.length}/${maxTotalChars}), skipping remaining chapters`);
      break;
    }

    // Stream chapter heading first
    const chapterHeading = `## Глава ${chapterNum}. ${chapterInfo.title}\n\n`;
    fullText += chapterHeading;
    await onChunk(chapterHeading);

    // Generate each subsection separately
    for (let subIdx = 0; subIdx < chapterInfo.subsections.length; subIdx++) {
      checkGlobalTimeout();

      // Check if we've exceeded max chars — if so, skip remaining subsections
      if (fullText.length >= maxTotalChars) {
        console.log(`Max chars reached in subsection (${fullText.length}/${maxTotalChars}), skipping`);
        break;
      }

      const sub = chapterInfo.subsections[subIdx];
      const subNum = `${chapterNum}.${subIdx + 1}`;

      await onPhaseStart(
        `Глава ${chapterNum}, ${subNum}`,
        2 + chapterIndex * subsPerChapter + subIdx,
        6 + chaptersCount * subsPerChapter
      );

      // Build context for this subsection
      const tasksContext = tasksFromIntro
        ? `Задачи из Введения: ${tasksFromIntro}`
        : '';
      const summaryOfPrevious = fullText.length > 500
        ? `Краткая выжимка написанного: ${createSummary(fullText)}`
        : '';
      const lastChars = fullText.length > 500
        ? `Последний написанный текст: ${fullText.slice(-2000)}`
        : '';

      // Covered topics block — prevents duplication across chapters
      const coveredBlock = coveredTopics.length > 0
        ? `\nУЖЕ РАСКРЫТЫЕ ТЕМЫ (ЗАПРЕЩЕНО повторять их содержание, факты и аргументы):\n${coveredTopics.map(t => `- ${t}`).join('\n')}\n`
        : '';

      // Build used-phrases block — inject recently used phrases to prevent repetition
      const usedPhrasesBlock = usedPhrases.length > 0
        ? `\nФРАЗЫ, КОТОРЫЕ УЖЕ ИСПОЛЬЗОВАНЫ (ЗАПРЕЩЕНО повторять — используй синонимы):\n${usedPhrases.slice(-15).map(p => `- «${p}»`).join('\n')}\n`
        : '';

      const contextBlock = `[КОНТЕКСТ ДЛЯ СВЯЗНОСТИ]:
План реферата:
${planSummary}
${tasksContext ? `${tasksContext}\n` : ''}${coveredBlock}${usedPhrasesBlock}${summaryOfPrevious ? `${summaryOfPrevious}\n` : ''}${lastChars ? `${lastChars}\n` : ''}`;

      // Rotate writing style instructions to prevent template-like text
      const styleIdx = (chapterIndex * subsPerChapter + subIdx) % writingStyles.length;
      const currentStyle = writingStyles[styleIdx];

      // Calculate adjusted subsection target based on how much text we've already written
      const remainingChars = maxTotalChars - fullText.length;
      const remainingSubsCount = (chaptersCount - chapterNum) * subsPerChapter + (chapterInfo.subsections.length - subIdx);
      const adjustedSubsectionChars = remainingSubsCount > 0
        ? Math.min(subsectionChars, Math.round(remainingChars / remainingSubsCount * 0.8))
        : subsectionChars;

      const subPrompt = `Напиши ПОДГЛАВУ ${subNum} для реферата на тему "${topic}".
Объём — МИНИМУМ ${adjustedSubsectionChars} символов, но НЕ БОЛЕЕ ${Math.round(adjustedSubsectionChars * 1.5)} символов. НЕ пиши лишнего!

${contextBlock}
ТЕМА ГЛАВЫ: "${chapterInfo.title}"
ТЕКУЩАЯ ПОДГЛАВА: ${subNum}. ${sub.title}${sub.description ? ` — ${sub.description}` : ''}

КРИТИЧЕСКИ ВАЖНО:
- Начинай СРАЗУ с существа дела. ЗАПРЕЩЕНЫ абзацы-вступления («В данном параграфе рассматривается...»).
- Пиши развёрнуто: каждый тезис подкрепляй анализом, примерами, сравнениями.
- Раскрывай причинно-следственные связи, делай обобщения.
- ЗАПРЕЩЕНО вставлять ссылки на источники в формате [1], [2, с. 15] и подобные.
- ВАРЬИРУЙ формулировки! ЗАПРЕЩЕНО использовать одни и те же конструкции в соседних абзацах.
- ЗАПРЕЩЕНО повторять факты, примеры и аргументы из уже раскрытых тем.
- КАЖДАЯ подглава должна содержать НОВУЮ информацию, не дублирующую предыдущие разделы.
- ЗАПРЕЩЕНО завершать абзац шаблонной фразой «что делает её предпочтительным выбором для критически важных приложений». Каждый абзац должен заканчиваться уникальным выводом.
- ПОДХОД К ИЗЛОЖЕНИЮ: ${currentStyle}
- Если используешь русский перевод английского термина — ОБЯЗАТЕЛЬНО добавляй оригинальный термин в скобках. НЕ оставляй скобки пустыми.

Формат: ### ${subNum}. ${sub.title} (H3) и далее параграфы текста.`;

      // Generate subsection with retry on short content
      let subText = '';
      let attempt = 0;

      while (attempt < MAX_RETRIES_PER_SECTION) {
        const result = await streamAndCollect(SYSTEM_PROMPT, subPrompt, 0.5);
        subText = result;

        // Check if content is long enough (allow 60% of target as minimum)
        const minAcceptable = Math.round(adjustedSubsectionChars * 0.6);
        if (result.length >= minAcceptable || attempt >= MAX_RETRIES_PER_SECTION - 1) {
          break;
        }

        // Retry with stronger emphasis on length
        console.log(`Subsection ${subNum} too short (${result.length}/${adjustedSubsectionChars}), retry ${attempt + 1}`);
        attempt++;
      }

      // Track covered topic to prevent future duplication
      coveredTopics.push(`${subNum}. ${sub.title}: ${sub.description || 'основные положения'}`);

      // Track used phrases from generated text for anti-repeat in next subsections
      const phrasePatterns = [
        /предпочтительн\w+\s+выбор\w*/gi,
        /высочайш\w+\s+уров\w+/gi,
        /критически\s+важн\w+/gi,
        /работают\s+в\s+комплексе/gi,
        /Данный\s+(?:подход|механизм|принцип)\s+(?:позволяет|обеспечивает)/gi,
        /что\s+(?:делает|обеспечивает|позволяет)\s+е[ёе]/gi,
        /в\s+комплексе.*?обеспечивая/gi,
      ];
      for (const pat of phrasePatterns) {
        const found = subText.match(pat);
        if (found) {
          for (const f of found) {
            const clean = f.trim();
            if (!usedPhrases.includes(clean)) {
              usedPhrases.push(clean);
            }
          }
        }
      }

      // Add separator after subsection
      fullText += '\n\n';
      await onChunk('\n\n');
    }
  }

  // ============================================================
  // Заключение
  // ============================================================
  checkGlobalTimeout();
  await onPhaseStart('Заключение', 3 + chaptersCount * subsPerChapter, 6 + chaptersCount * subsPerChapter);

  const tasksContextConclusion = tasksFromIntro
    ? `\nЗадачи из Введения: ${tasksFromIntro}\n`
    : '';

  // Build exact chapter structure for conclusion context
  const chapterStructureForConclusion = chapterInfos.map((ch, idx) =>
    `Глава ${idx + 1}: "${ch.title}"`
  ).join('\n');

  const conclusionPrompt = `Напиши ЗАКЛЮЧЕНИЕ для реферата на тему "${topic}".
Объём — МИНИМУМ ${conclusionChars} символов, но НЕ БОЛЕЕ ${Math.round(conclusionChars * 1.5)} символов.

[КОНТЕКСТ — СТРУКТУРА РЕФЕРАТА]:
В реферате РОВНО ${chaptersCount} глав:
${chapterStructureForConclusion}

${tasksContextConclusion}
СТРУКТУРА (строго обязательно):
1. Краткие выводы ПО КАЖДОЙ ИЗ ${chaptersCount} ГЛАВ (одна глава = один абзац-вывод, с указанием названия главы).
2. Общий итог: достигнута ли цель реферата.
3. Перспективы развития темы.

КРИТИЧЕСКИ ВАЖНО:
- В реферате РОВНО ${chaptersCount} глав, НЕ больше и НЕ меньше. Упоминай РОВНО ${chaptersCount} глав.
- Используй ТОЧНЫЕ названия глав из плана, приведённого выше.
- ЗАПРЕЩЕНО придумывать несуществующие главы или разделы.
- ЗАПРЕЩЕНО дословно копировать текст из глав. Синтезируй и обобщай.
- Стиль: безличный, научный.
- Пиши развёрнуто — каждый вывод подкрепляй конкретными результатами анализа.

Формат: # ЗАКЛЮЧЕНИЕ (H1, по центру)`;

  await streamAndCollect(SYSTEM_PROMPT, conclusionPrompt, 0.5);

  fullText += '\n\n';
  await onChunk('\n\n');

  // ============================================================
  // Список литературы
  // ============================================================
  checkGlobalTimeout();
  await onPhaseStart('Список литературы', 4 + chaptersCount * subsPerChapter, 6 + chaptersCount * subsPerChapter);

  // IMPORTANT: Use a SPECIAL system prompt for bibliography that ALLOWS English
  const BIB_SYSTEM_PROMPT = `Ты — академический библиограф, эксперт в составлении списков литературы по ГОСТ 7.1-2003.
КРИТИЧЕСКИ ВАЖНО — ПРАВИЛА СОХРАНЕНИЯ АНГЛИЙСКОГО ТЕКСТА:
1. В списке литературы АНГЛИЙСКИЙ ЯЗЫК РАЗРЕШЁН и ОБЯЗАТЕЛЕН. Названия книг, статей, стандартов, имена авторов, издательства пишутся НА ЯЗЫКЕ ОРИГИНАЛА.
2. URL-адреса ДОЛЖНЫ быть ПОЛНЫМИ и НАЧИНАТЬСЯ с https:// — это КРИТИЧЕСКИ ВАЖНО.
3. ЗАПРЕЩЕНО сокращать, обрезать или удалять любые части URL-адреса.
4. ЗАПРЕЩЕНО удалять английские слова из названий книг, статей или имён авторов.

ПРИМЕРЫ ПРАВИЛЬНЫХ URL:
✅ https://www.qnx.com/products/qnx-neutrino-rtos/
✅ https://www.iso.org/standard/42136.html
✅ https://standards.ieee.org/standard/754-2019.html

ПРИМЕРЫ ОШИБОК (ЗАПРЕЩЕНО):
❌ ://www.qnx.com/products/ (нет https)
❌ https://www.qnx.com///7.1/ (двойные слеши)
❌ www.qnx.com/products (нет протокола)
❌ qnx.com/products (нет протокола)`;

  const refsPrompt = `Составь СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ для реферата на тему "${topic}".
Количество источников — ${referencesCount}.

КРИТИЧЕСКИЕ ПРАВИЛА:
1. Включай ТОЛЬКО источники, в существовании которых ты УВЕРЕН на 100%.
2. Если ты не уверен в реальности источника — НЕ включай его. Лучше меньше источников, чем выдуманные.
3. РЕАЛЬНЫЕ источники, которые МОЖНО использовать:
   - Официальная документация продукта/технологии (с указанием полного URL, начиная с https://)
   - Международные и отраслевые стандарты (ISO, IEC, IEEE, ГОСТ и т.д.) — с полными названиями на языке оригинала
   - Общеизвестные учебники по теме (Таненбаум, Силберчатц, Столлингс и аналогичные) — с полными библиографическими данными
   - Статьи из реальных рецензируемых журналов (IEEE, ACM, и т.д.) — только если уверен на 100%
   - Электронные ресурсы (официальные сайты, документация) — с полными URL
4. ЗАПРЕЩЕНО придумывать авторов, названия книг и издательства.
5. Если не хватает реальных источников — добавь электронные ресурсы (URL официальной документации, стандарты, технические отчёты).
6. ЗАПРЕЩЕНО генерировать источники с типичными русскими фамилиями, если ты не уверен в их реальности — это самая частая ошибка.
7. URL-ПРАВИЛА (КРИТИЧЕСКИ ВАЖНО):
   - КАЖДЫЙ URL ДОЛЖЕН начинаться с https://
   - URL ДОЛЖЕН быть полностью читаемым и корректным
   - ЗАПРЕЩЕНО обрезать URL — пиши ПОЛНЫЙ путь
   - В URL НЕ ДОЛЖНО быть двойных слешей (кроме https://)
   - ПРИМЕР ПРАВИЛЬНОГО ФОРМАТА: URL: https://www.qnx.com/products/qnx-neutrino-rtos/
8. Английские названия книг, стандартов и статей пиши НА АНГЛИЙСКОМ — это стандартная практика!
9. Имена авторов пиши ПОЛНОСТЬЮ на языке оригинала — A.S. Tanenbaum, W. Stallings и т.д.

ТРЕБОВАНИЯ (ГОСТ 7.1-2003):
- АЛФАВИТНЫЙ ПОРЯДОК авторов/названий.
- Нумерация сплошная (1, 2, 3...).

Форматы:
- Книги: Автор. Название. — Город: Издательство, Год. — Страницы.
- Статьи: Автор. Название // Журнал. — Год. — №. — Страницы.
- Электронные: Название [Электронный ресурс]. — URL: https://полный_адрес (дата обращения: ДД.ММ.ГГГГ)

Формат: # СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ (H1, по центру)`;

  await streamAndCollect(BIB_SYSTEM_PROMPT, refsPrompt, 0.5);

  // ============================================================
  // POST-GENERATION: 2 verification passes
  // ============================================================
  for (let passNum = 1; passNum <= 2; passNum++) {
    checkGlobalTimeout();
    await onPhaseStart(
      `Проверка (${passNum}/2)`,
      5 + chaptersCount * subsPerChapter + passNum - 1,
      6 + chaptersCount * subsPerChapter
    );

    const verifyPrompt = `Ты — строгий редактор-корректор академических текстов. Твоя задача — найти и исправить ошибки в реферате.

ПРОВЕРЯЙ ПО 10 КАТЕГОРИЯМ:
1. ГРАММАТИКА: опечатки, ошибки согласования, пунктуация, орфография, падежи, окончания, несуществующие слова (например, «сбояируется» вместо «изолируется», «алгоритум» вместо «алгоритм», «занить» вместо «занять»).
2. ФАКТЫ: противоречия внутри текста, логические ошибки, невозможные утверждения, противоречия между Введением (задачи) и Заключением (выводы).
3. ССЫЛКИ И ЛИТЕРАТУРА: проверь раздел "СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ" — нет ли дублирующихся источников, нарушений алфавитного порядка, неверного форматирования ГОСТ 7.1-2003, выдуманных авторов и несуществующих книг. URL должны быть полными (начинаться с https://).
4. ЯЗЫКОВАЯ ЧИСТОТА: проверь, нет ли в тексте (КРОМЕ списка литературы!) китайских/японских/корейских иероглифов, английских слов вне скобок (кроме общепринятых аббревиатур типа IPC, TCP, POSIX, API, IoT и т.д.), смешения алфавитов в одном слове. ВНИМАНИЕ: в списке литературы английский язык РАЗРЕШЁН!
5. СТРУКТУРНОЕ СООТВЕТСТВИЕ: В реферате РОВНО ${chaptersCount} глав. Заключение должно содержать выводы РОВНО по ${chaptersCount} главам — не больше и не меньше. Названия глав в Заключении должны совпадать с фактическими названиями в тексте.
6. ВНУТРИГЛАВНЫЕ СПИСКИ ЛИТЕРАТУРЫ: внутри глав НЕ должно быть заголовков "Список литературы" или "Список использованной литературы" — список литературы может быть только один, в конце реферата.
7. ПУСТЫЕ СКОБКИ: проверь, нет ли в тексте пустых скобок () или скобок с пробелами внутри ( ). Если английский термин в скобках был удалён — либо восстанови термин, либо удали скобки целиком.
8. НЕПОЛНЫЕ ЗАГОЛОВКИ: проверь, что все заголовки завершены и не обрываются на союзе/предлоге (например, «Система управления процессами и» — неполный заголовок).
9. ШАБЛОННЫЕ ПОВТОРЫ: проверь, не повторяется ли одна и та же фраза в конце разных абзацев (например, «что делает её предпочтительным выбором для критически важных приложений»). Если фраза повторяется более 2 раз — замени на синонимичные формулировки.
10. URL В БИБЛИОГРАФИИ: проверь, что все URL в списке литературы ПОЛНЫЕ и начинаются с https://. Если URL обрезан или не содержит протокол — исправь.

ФОРМАТ ОТВЕТА — СТРОГО:
Если ошибок нет, напиши: ОШИБОК НЕ НАЙДЕНО
Если ошибки есть, для каждой ошибки напиши:
[ОШИБКА]
Тип: [грамматика/факт/ссылки/язык/структура/внутриглавный_список/пустые_скобки/неполный_заголовок/шаблонные_повторы/url_библиография]
Оригинал: "точный фрагмент текста с ошибкой"
Исправление: "исправленный фрагмент"
[/ОШИБКА]

Пиши ТОЛЬКО найденные ошибки. НЕ переписывай весь текст. НЕ придумывай несуществующие ошибки.

ТЕКСТ ДЛЯ ПРОВЕРКИ:
${fullText}`;

    let verifyResult = '';
    try {
      for await (const chunk of streamPhase(SYSTEM_PROMPT, verifyPrompt, PHASE_TIMEOUT_MS, 0.3)) {
        verifyResult += chunk;
      }
    } catch (err) {
      console.error(`Verification pass ${passNum} error:`, err);
      continue;
    }

    // Parse and apply corrections ONLY to main text (NOT bibliography)
    // This prevents verification from damaging URLs and English text in bibliography
    if (verifyResult.trim() !== 'ОШИБОК НЕ НАЙДЕНО') {
      const corrections = parseCorrections(verifyResult);

      // Split fullText into main and bibliography parts
      const bibSplitPat = /^#\s+(?:СПИСОК|Список)\s+(?:ИСПОЛЬЗОВАННОЙ|использованной)?\s*(?:ЛИТЕРАТУРЫ|литературы)/m;
      const bibSplitMatch = fullText.match(bibSplitPat);
      let mainPart = fullText;
      let bibPart = '';

      if (bibSplitMatch && bibSplitMatch.index !== undefined) {
        mainPart = fullText.slice(0, bibSplitMatch.index);
        bibPart = fullText.slice(bibSplitMatch.index);
      }

      // Apply corrections only to main text
      for (const correction of corrections) {
        // Skip corrections that target bibliography content (URLs, English text)
        if (correction.type.includes('ссылки') || correction.type.includes('url') || correction.type.includes('библиограф')) {
          continue;
        }
        if (correction.original && correction.fixed && mainPart.includes(correction.original)) {
          mainPart = mainPart.replace(correction.original, correction.fixed);
        }
      }

      fullText = mainPart + bibPart;
    }
  }

  // ============================================================
  // POST-PROCESSING: Programmatic cleanup
  // ============================================================
  fullText = cleanGeneratedText(fullText);
  fullText = removeIntraChapterBibliographies(fullText);
  fullText = fixAntiRepeatViolations(fullText);

  // Log structural validation results
  const structErrors = validateStructure(fullText, chaptersCount);
  if (structErrors.length > 0) {
    console.warn('Structural validation warnings:', structErrors);
  }

  return fullText;
}

// ============================================================
// Clean generated text — V4: COMPREHENSIVE safe cleanup
// KEY PRINCIPLES:
// 1. NEVER remove English words — this was root cause of 25+ empty brackets,
//    destroyed URLs, broken book titles, and garbled sentences.
// 2. Protect URLs everywhere with placeholder mechanism.
// 3. Split bibliography from main text and preserve it entirely.
// 4. Clean structural/typographic issues with multiple passes.
// ============================================================
function cleanGeneratedText(text: string): string {
  // === STEP 0: Protect ALL URLs with placeholders BEFORE any processing ===
  // This prevents ANY modification to URLs during cleanup steps.
  const urlPlaceholders: string[] = [];
  const URL_PLACEHOLDER_PREFIX = '\x00URL_';

  const textWithProtectedUrls = text.replace(/https?:\/\/[^\s,)\]»"']+/g, (match) => {
    const idx = urlPlaceholders.length;
    urlPlaceholders.push(match);
    return `${URL_PLACEHOLDER_PREFIX}${idx}\x00`;
  });

  // === STEP 1: Split text into bibliography and non-bibliography sections ===
  const bibHeadingPattern = /^#\s+(?:СПИСОК|Список)\s+(?:ИСПОЛЬЗОВАННОЙ|использованной)?\s*(?:ЛИТЕРАТУРЫ|литературы)/m;
  const bibMatch = textWithProtectedUrls.match(bibHeadingPattern);

  let mainText: string;
  let bibliographyText: string;

  if (bibMatch && bibMatch.index !== undefined) {
    mainText = textWithProtectedUrls.slice(0, bibMatch.index);
    bibliographyText = textWithProtectedUrls.slice(bibMatch.index);
  } else {
    mainText = textWithProtectedUrls;
    bibliographyText = '';
  }

  // === STEP 2: Remove CJK characters from MAIN TEXT only ===
  const cjkRegex = /[\u4e00-\u9fff\u3400-\u4dbf\u3000-\u303f\uff00-\uffef\uac00-\ud7af]/g;
  mainText = mainText.replace(cjkRegex, '');

  // === STEP 3: Fix bracket issues in MAIN TEXT ===
  // 3a. Fix parentheses with only dashes/spaces/dots: (--) ( - ) ( . ) → remove entirely
  mainText = mainText.replace(/\(\s*[-–—.]+\s*\)/g, '');

  // 3b. Fix empty parentheses: () or ( ) or (  ) → remove entirely
  mainText = mainText.replace(/\(\s*\)/g, '');

  // 3c. Fix parentheses with only common English prepositions: ( of ) ( the ) → remove
  mainText = mainText.replace(/\(\s*(?:of|by|for|in|on|at|to|the|a|an|and|or|with|from)\s*\)/gi, '');

  // 3d. SECOND PASS: Remove any remaining empty brackets (after 3a-3c may create new ones)
  mainText = mainText.replace(/\(\s*\)/g, '');

  // 3e. Remove space before empty brackets that weren't caught: "AES ()" → "AES"
  mainText = mainText.replace(/\s+\(\s*\)/g, '');

  // 3f. THIRD PASS for stubborn cases
  mainText = mainText.replace(/\(\s*\)/g, '');

  // === STEP 4: Fix punctuation and typographic issues ===
  // 4a. Fix orphan space before comma: "QNX ," → "QNX,"
  mainText = mainText.replace(/\s+,/g, ',');

  // 4b. Fix known broken patterns (LLM sometimes drops "С" from "ОС")
  mainText = mainText.replace(/\bО\s+общего\s+назначения/g, 'ОС общего назначения');
  mainText = mainText.replace(/\bО\s+назначения/g, 'ОС назначения');

  // 4c. Fix grammar: "предпочтительной выбором" → "предпочтительным выбором"
  mainText = mainText.replace(/предпочтительной\s+выбором/g, 'предпочтительным выбором');

  // 4d. Fix missing space between Russian and English: "иVRTX" → "и VRTX"
  mainText = mainText.replace(/([а-яё])([A-Z][a-z])/g, '$1 $2');

  // === STEP 5: Fix known non-existent words from LLM generation ===
  const typoFixes: [RegExp, string][] = [
    [/\bсбояируется\b/g, 'изолируется'],
    [/\bсбояируются\b/g, 'изолируются'],
    [/\bсбояировать\b/g, 'изолировать'],
    [/\bзанить\b/g, 'занять'],
    [/\bалгоритум\b/g, 'алгоритм'],
    [/\bразработывания\b/g, 'разработки'],
    [/\bпрограмного\b/g, 'программного'],
    [/\bвычислительнные\b/g, 'вычислительные'],
    [/\bобеспечиние\b/g, 'обеспечение'],
    [/\bфункцианирование\b/g, 'функционирование'],
    [/\bкомпеляция\b/g, 'компиляция'],
    [/\bобеспечинный\b/g, 'обеспеченный'],
    [/\bпредусматревает\b/g, 'предусматривает'],
    [/\bосущесвляет\b/g, 'осуществляет'],
    [/\bреализовывание\b/g, 'реализация'],
  ];
  for (const [pattern, replacement] of typoFixes) {
    mainText = mainText.replace(pattern, replacement);
  }

  // === STEP 6: Fix incomplete headings ending with conjunctions/prepositions ===
  const incompleteEndings = [' и', ' или', ' на', ' с', ' для', ' от', ' к', ' по', ' без', ' из', ' о', ' об', ' при', ' через', ' между', ' над', ' под', ' перед'];
  for (const ending of incompleteEndings) {
    const escaped = ending.replace(/\s/g, '\\s+');
    // Fix markdown headings
    mainText = mainText.replace(
      new RegExp(`^(#{1,4}\\s+\\d+[\\.\\d]*\\s+.+?)${escaped}\\s*$`, 'gm'),
      '$1'
    );
    // Fix numbered headings without markdown (e.g. "2.3. Система управления процессами и")
    mainText = mainText.replace(
      new RegExp(`^(\\d+\\.\\d+\\.\\s+.+?)${escaped}\\s*$`, 'gm'),
      '$1'
    );
  }

  // === STEP 7: Fix broken text patterns ===
  // 7a. Fix empty quotes: "" or «» → remove
  mainText = mainText.replace(/«\s*»/g, '');
  mainText = mainText.replace(/""/g, '');

  // 7b. Fix broken words with dash: "пре - " → "преемптивный"
  mainText = mainText.replace(/алгоритм[аы]?\s+"пре\s*-\s*"/g, 'алгоритм преемптивного планирования');
  mainText = mainText.replace(/"пре\s*-\s*"/g, 'преемптивного планирования');
  mainText = mainText.replace(/пре\s*-\s*(?=[а-яё])/g, 'преемптивного ');

  // 7c. Fix "в все" → "в QNX все" (missing subject)
  mainText = mainText.replace(/\bв\s+все\s+коммуникации/g, 'в QNX все коммуникации');
  mainText = mainText.replace(/\bв\s+все\s+взаимодействия/g, 'в QNX все взаимодействия');

  // === STEP 8: Clean up whitespace ===
  // 8a. Clean up double spaces (but not in URLs/placeholders)
  mainText = mainText.replace(/([^/\n\x00])  +/g, '$1 ');

  // 8b. Clean up excessive newlines
  mainText = mainText.replace(/\n{3,}/g, '\n\n');

  // 8c. Clean spaces at line beginnings
  mainText = mainText.replace(/^ +$/gm, '');

  // === STEP 9: Bibliography is kept ENTIRELY as-is ===
  let fullResult = mainText + bibliographyText;

  // === STEP 10: Restore ALL URLs from placeholders ===
  for (let i = urlPlaceholders.length - 1; i >= 0; i--) {
    fullResult = fullResult.replace(`${URL_PLACEHOLDER_PREFIX}${i}\x00`, urlPlaceholders[i]);
  }

  // === STEP 11: Repair broken URLs in bibliography ===
  // Fix URLs that lost their "https" prefix or have double slashes in paths
  fullResult = repairBibliographyUrls(fullResult);

  return fullResult;
}

// ============================================================
// Repair broken URLs in bibliography section
// Fixes: missing protocol, double slashes from word removal
// ============================================================
function repairBibliographyUrls(text: string): string {
  const bibHeadingPattern = /^#\s+(?:СПИСОК|Список)\s+(?:ИСПОЛЬЗОВАННОЙ|использованной)?\s*(?:ЛИТЕРАТУРЫ|литературы)/m;
  const bibMatch = text.match(bibHeadingPattern);

  if (!bibMatch || bibMatch.index === undefined) return text;

  const mainText = text.slice(0, bibMatch.index);
  let bibText = text.slice(bibMatch.index);

  // Fix 1: Add "https" prefix to URLs that start with "://"
  // Pattern: "URL: ://www.example.com" → "URL: https://www.example.com"
  bibText = bibText.replace(/(URL:\s*):\/\/(?=\w)/g, '$1https://');

  // Fix 2: Remove double slashes in URL paths (but not the :// protocol separator)
  // e.g. "https://www.qnx.com///7.1/" → "https://www.qnx.com/7.1/"
  bibText = bibText.replace(/(https?:\/\/[^/\s]+)\/{2,}/g, (_, domain) => domain + '/');

  // Fix 3: Remove stray dots in URL paths
  // e.g. "com.qnx.doc..kernel" → "com.qnx.doc.kernel"
  bibText = bibText.replace(/(https?:\/\/[^\s]*?)\.\.(?=[^\s/])/g, '$1.');

  // Fix 4: Remove trailing dots before spaces or line ends in URLs
  bibText = bibText.replace(/(https?:\/\/[^\s]+?)\.+(\s|$)/g, '$1$2');

  return mainText + bibText;
}

// ============================================================
// Fix anti-repeat violations programmatically — V3: Comprehensive
// Catches word-level repeats, template endings, structural patterns,
// and broader phrase variations that LLM generates
// ============================================================
function fixAntiRepeatViolations(text: string): string {

  // === PHASE 1: Word/phrase-level repeats ===
  const repeatRules: { pattern: RegExp; maxCount: number; replacements: string[] }[] = [
    // --- Core repetitive phrases (with broader regex) ---
    {
      pattern: /предпочтительн\w+\s+выбор\w*/gi,
      maxCount: 1,
      replacements: [
        'оптимальным решением', 'рациональной альтернативой', 'наиболее подходящим вариантом',
        'эффективным средством', 'целесообразным выбором', 'практичным вариантом',
        'обоснованным решением', 'адекватным инструментом', 'перспективным вариантом',
        'логичным решением', 'разумной альтернативой', 'подходящим инструментом',
      ],
    },
    {
      pattern: /высочайш\w+\s+уров\w+/gi,
      maxCount: 2,
      replacements: [
        'максимальный уровень', 'исключительный уровень', 'беспрецедентный уровень',
        'наивысший уровень', 'непревзойдённый уровень', 'выдающийся уровень',
        'первоклассный уровень', 'высший уровень', 'столь же высокий уровень',
        'исключительную степень', 'наивысшую степень', 'выдающуюся степень',
      ],
    },
    {
      pattern: /критически\s+важн\w+/gi,
      maxCount: 2,
      replacements: [
        'ключевых', 'стратегических', 'принципиальных', 'существенных', 'ответственных',
        'наиболее значимых', 'первостепенных', 'жизненно важных', 'особо значимых',
        'фундаментальных', 'приоритетных', 'наиболее требовательных', 'особо ответственных',
      ],
    },
    {
      pattern: /работают\s+в\s+комплексе/gi,
      maxCount: 1,
      replacements: [
        'взаимодополняют друг друга', 'действуют совместно', 'образуют единую систему',
        'интегрированы между собой', 'функционируют согласованно', 'составляют целостный механизм',
        'действуют в синергии', 'координируют свою работу', 'формируют согласованный ансамбль',
        'взаимосвязаны и взаимообусловлены', 'дополняют и усиливают друг друга',
      ],
    },
    {
      pattern: /в\s+комплексе[,،]\s*обеспечивая\s+/gi,
      maxCount: 1,
      replacements: [
        'совместно, гарантируя ', 'в единстве, формируя ', 'согласованно, создавая ',
        'во взаимодействии, обеспечивая ', 'интегрированно, формируя ',
      ],
    },
    {
      pattern: /критически\s+важно\s+для\s+систем\s+реального\s+времени/gi,
      maxCount: 2,
      replacements: [
        'имеет определяющее значение для систем реального времени',
        'принципиально для ОСРВ', 'существенно для систем жёсткого реального времени',
        'является обязательным требованием для систем реального времени',
        'составляет непременное условие для ОСРВ',
      ],
    },
    {
      pattern: /что\s+особенно\s+важно\s+для/gi,
      maxCount: 2,
      replacements: [
        'что имеет особое значение для', 'что принципиально для',
        'что приобретает особую значимость в', 'что существенно для',
        'что играет ключевую роль в', 'что представляет особую ценность для',
      ],
    },
    {
      pattern: /Данный\s+(?:подход|метод|принцип)\s+(?:позволяет|обеспечивает|даёт)/gi,
      maxCount: 2,
      replacements: [
        'Рассматриваемый метод позволяет', 'Описываемая стратегия даёт возможность',
        'Этот принцип обеспечивает', 'Такое решение позволяет',
        'Анализируемый механизм даёт возможность', 'Предлагаемая концепция обеспечивает',
        'Изучаемый подход предоставляет возможность', 'Данная методология позволяет',
      ],
    },
    {
      pattern: /Данный\s+(?:механизм|инструмент|способ)\s+(?:обеспечивает|гарантирует|создаёт|формирует)/gi,
      maxCount: 2,
      replacements: [
        'Этот механизм гарантирует', 'Описываемый механизм предоставляет',
        'Рассматриваемый механизм создаёт', 'Указанный механизм формирует',
        'Данное средство обеспечивает', 'Приведённый способ формирует',
      ],
    },
    {
      pattern: /В\s+отличие\s+от\s+(?:традиционн\w+|классическ\w+|обычн\w+)\s+(?:систем|подходов|решений|архитектур)/gi,
      maxCount: 2,
      replacements: [
        'В сопоставлении с традиционными системами', 'По сравнению с классическими решениями',
        'В противоположность монолитным подходам', 'Если сравнивать с общепринятыми архитектурами',
        'В контрасте с классическими архитектурами', 'На фоне традиционных подходов',
      ],
    },
    {
      pattern: /Таким\s+образом,/gi,
      maxCount: 3,
      replacements: [
        'Следовательно,', 'Подытоживая,', 'Резюмируя,',
        'На основании вышеизложенного,', 'Стало быть,', 'Обобщая сказанное,',
        'Суммируя вышеописанное,', 'В итоге,', 'Как показал анализ,',
      ],
    },
    {
      pattern: /что\s+делает\s+е[ёе]\s+(?:незаменим\w+|уникальн\w+|особ\w+)/gi,
      maxCount: 1,
      replacements: [
        'что определяет её уникальную роль в', 'что обеспечивает ей особое место среди',
        'что делает эту систему ценной для', 'что повышает её значимость в',
        'что обуславливает её ценность для', 'что подчёркивает её значимость в',
      ],
    },
    {
      pattern: /где\s+недопустимы\s+сбои\s+и\s+отказы/gi,
      maxCount: 1,
      replacements: [
        'где цена ошибки недопустимо высока', 'где надёжность является безусловным требованием',
        'где любые отказы неприемлемы', 'где требуется безотказная работа',
        'где отказы могут привести к катастрофическим последствиям',
      ],
    },
  ];

  for (const rule of repeatRules) {
    let count = 0;
    let replacementIdx = 0;
    text = text.replace(rule.pattern, (match) => {
      count++;
      if (count <= rule.maxCount) {
        return match;
      }
      const replacement = rule.replacements[replacementIdx % rule.replacements.length];
      replacementIdx++;
      return replacement;
    });
  }

  // === PHASE 2: Template paragraph endings ===
  const templateEndingRules: { pattern: RegExp; maxCount: number; replacements: string[] }[] = [
    {
      pattern: /что\s+делает\s+е[ёе]\s+предпочтительн\w+\s+выбор\w+\s+для\s+критически\s+важн\w+/gi,
      maxCount: 0,
      replacements: [
        'что обусловливает востребованность системы в ответственных областях',
        'что определяет её ценность для наиболее требовательных задач',
        'что обеспечивает ей широкое применение в ответственных системах',
        'что является ключевым фактором её востребованности',
        'что обуславливает интерес к данной системе со стороны разработчиков',
      ],
    },
    {
      pattern: /Данные\s+\w+\s+работают\s+в\s+комплексе,\s*обеспечивая\s+высочайш\w+\s+уров\w+/gi,
      maxCount: 0,
      replacements: [
        'Совокупность данных механизмов формирует надёжную защиту, обеспечивая',
        'Взаимодействие этих компонентов создаёт многоуровневую систему, гарантирующую',
        'Интеграция описанных средств позволяет достичь',
        'Синергия данных механизмов формирует комплексную защиту, обеспечивая',
        'Совместное действие указанных компонентов гарантирует',
      ],
    },
    {
      pattern: /Данные\s+\w+\s+работают\s+в\s+комплексе,\s*обеспечивая/gi,
      maxCount: 0,
      replacements: [
        'Совокупность данных компонентов формирует систему, обеспечивающую',
        'Взаимодействие этих элементов создаёт механизм, гарантирующий',
        'Интеграция описанных средств позволяет обеспечить',
        'Совместное действие указанных компонентов обеспечивает',
        'Координация данных элементов формирует целостный подход к',
      ],
    },
    {
      pattern: /что\s+делает\s+е[ёе]\s+незаменим\w+/gi,
      maxCount: 1,
      replacements: [
        'что определяет её уникальную роль в', 'что обеспечивает ей особое место среди',
        'что делает эту систему ценной для', 'что повышает её значимость в',
        'что обуславливает её ценность для',
      ],
    },
    {
      pattern: /где\s+недопустимы\s+сбои\s+и\s+отказы/gi,
      maxCount: 1,
      replacements: [
        'где цена ошибки недопустимо высока', 'где надёжность является безусловным требованием',
        'где любые отказы неприемлемы', 'где требуется безотказная работа',
        'где отказы могут привести к катастрофическим последствиям',
      ],
    },
  ];

  for (const rule of templateEndingRules) {
    let count = 0;
    let replacementIdx = 0;
    text = text.replace(rule.pattern, (match) => {
      count++;
      if (count <= rule.maxCount) {
        return match;
      }
      const replacement = rule.replacements[replacementIdx % rule.replacements.length];
      replacementIdx++;
      return replacement;
    });
  }

  // === PHASE 3: "Классификация" at paragraph start ===
  const lines = text.split('\n');
  let classificationCount = 0;
  for (let i = 0; i < lines.length; i++) {
    if (/^Классификация\s/.test(lines[i].trim())) {
      classificationCount++;
      if (classificationCount > 2) {
        const synonyms = ['Типология', 'Систематизация', 'Разновидности', 'Группировка', 'Структура', 'Ранжирование', 'Категоризация', 'Дифференциация', 'Характеристика типов', 'Обзор категорий'];
        const syn = synonyms[(classificationCount - 3) % synonyms.length];
        lines[i] = lines[i].replace(/^(\s*)Классификация\s/, `$1${syn} `);
      }
    }
  }
  text = lines.join('\n');

  // === PHASE 4: Generic template structures ===
  // Detect "Данные X Y в комплексе, обеспечивая Z" pattern and diversify
  const genericComplexPattern = /Данные\s+(\w+)\s+работают\s+в\s+комплексе/gi;
  let complexCount = 0;
  text = text.replace(genericComplexPattern, (match, word) => {
    complexCount++;
    if (complexCount <= 1) return match;
    const alternatives = [
      `Совокупность данных ${word} формирует систему`,
      `Указанные ${word} действуют согласованно`,
      `Интеграция перечисленных ${word} позволяет`,
      `Взаимодействие данных ${word} создаёт механизм`,
      `Синергия указанных ${word} обеспечивает`,
    ];
    return alternatives[(complexCount - 2) % alternatives.length];
  });

  // === PHASE 5: "Данный X" pattern diversification ===
  // Count all "Данный" at sentence starts and diversify
  const dannyPattern = /Данный\s+(подход|механизм|принцип|метод|способ|инструмент|функционал|компонент|элемент)/gi;
  let dannyCount = 0;
  const dannyAlternatives = [
    'Рассматриваемый', 'Описываемый', 'Указанный', 'Этот',
    'Анализируемый', 'Изучаемый', 'Приведённый', 'Представленный',
  ];
  text = text.replace(dannyPattern, (match, word) => {
    dannyCount++;
    if (dannyCount <= 3) return match;
    const alt = dannyAlternatives[(dannyCount - 4) % dannyAlternatives.length];
    return `${alt} ${word}`;
  });

  return text;
}

// ============================================================
// Remove intra-chapter bibliographies (lists of references inside chapters)
// ============================================================
function removeIntraChapterBibliographies(text: string): string {
  const lines = text.split('\n');
  const result: string[] = [];

  // Find the index of the final "СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ" H1 heading
  let lastBibH1Index = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].match(/^#\s+(СПИСОК|Список)\s+(ИСПОЛЬЗОВАННОЙ|использованной)?\s*(ЛИТЕРАТУРЫ|литературы)/i)) {
      lastBibH1Index = i;
      break;
    }
  }

  let inIntraBib = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Detect bibliography headings that appear BEFORE the final H1 bibliography section
    if (i < lastBibH1Index && line.match(/^#+\s*(СПИСОК|Список)\s*(ИСПОЛЬЗОВАННОЙ|использованной)?\s*(ЛИТЕРАТУРЫ|литературы)/i)) {
      inIntraBib = true;
      continue;
    }

    if (inIntraBib) {
      // Skip bibliography content: numbered items, empty lines within the bib section
      if (line.match(/^\s*\d+\.\s/) || line.trim() === '') {
        continue;
      }
      // Stop skipping when we hit a new heading or non-bibliography content
      if (line.match(/^#+\s/) || (line.trim() && !line.match(/^\s*\d+\.\s/))) {
        inIntraBib = false;
        result.push(line);
      }
      continue;
    }

    result.push(line);
  }

  return result.join('\n');
}

// ============================================================
// Validate document structure — V3: Extended checks + URL validation
// ============================================================
function validateStructure(text: string, expectedChapters: number): string[] {
  const errors: string[] = [];

  // Count H2 chapter headings
  const h2Matches = text.match(/^##\s+Глава\s+\d+/gm);
  if (h2Matches && h2Matches.length !== expectedChapters) {
    errors.push(`Ожидалось ${expectedChapters} глав, найдено ${h2Matches.length}`);
  }

  // Check for CJK characters
  if (/[\u4e00-\u9fff\u3400-\u4dbf\uac00-\ud7af]/.test(text)) {
    errors.push('Обнаружены китайские/японские/корейские иероглифы в тексте');
  }

  // Check for empty parentheses (sign of broken post-processing)
  const emptyParens = text.match(/\(\s*\)/g);
  if (emptyParens && emptyParens.length > 0) {
    errors.push(`Обнаружены пустые скобки: ${emptyParens.length} случаев`);
  }

  // Check for parentheses with only dashes (sign of broken English removal)
  const dashParens = text.match(/\(\s*[-–—]+\s*\)/g);
  if (dashParens && dashParens.length > 0) {
    errors.push(`Обнаружены скобки с тире внутри: ${dashParens.length} случаев`);
  }

  // Check for incomplete headings (ending with conjunction/preposition)
  const incompleteHeadings = text.match(/^#{1,4}\s+\d+[\.\d]*\s+.+?\s+(и|или|на|с|для|от|к|по|без|из|о|об|при|через|между|над|под|перед)\s*$/gm);
  if (incompleteHeadings && incompleteHeadings.length > 0) {
    errors.push(`Обнаружены неполные заголовки: ${incompleteHeadings.join('; ')}`);
  }

  // Also check numbered headings without markdown
  const incompleteNumbered = text.match(/^\d+\.\d+\.\s+.+?\s+(и|или|на|с|для|от|к|по|без|из|о|об|при|через|между|над|под|перед)\s*$/gm);
  if (incompleteNumbered && incompleteNumbered.length > 0) {
    errors.push(`Обнаружены неполные нумерованные заголовки: ${incompleteNumbered.join('; ')}`);
  }

  // Check for orphan space before comma
  const orphanCommas = text.match(/\w\s+,/g);
  if (orphanCommas && orphanCommas.length > 3) {
    errors.push(`Обнаружены пробелы перед запятой: ${orphanCommas.length} случаев`);
  }

  // Count bibliography sections
  const bibSections = text.match(/^#+\s*(?:СПИСОК|Список)\s*(?:ИСПОЛЬЗОВАННОЙ|использованной)?\s*(?:ЛИТЕРАТУРЫ|литературы)/gm);
  if (bibSections && bibSections.length > 1) {
    errors.push(`Найдено ${bibSections.length} разделов «Список литературы» вместо 1`);
  }

  // Check for broken URLs in bibliography
  const bibSection = text.match(/СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ[\s\S]*/)?.[0] || '';
  // URLs without https:// protocol
  const urlsInBib = bibSection.match(/URL:\s*\S+/g) || [];
  const brokenProtocolUrls = urlsInBib.filter(u => !u.includes('https://'));
  if (brokenProtocolUrls.length > 0) {
    errors.push(`Обнаружены URL без протокола https://: ${brokenProtocolUrls.length} случаев`);
  }
  // Double slashes in URL paths (except ://)
  const doubleSlashUrls = bibSection.match(/https?:\/\/[^\s]*?\/{2,}/g);
  if (doubleSlashUrls && doubleSlashUrls.length > 0) {
    errors.push(`Обнаружены двойные слеши в URL: ${doubleSlashUrls.length} случаев`);
  }

  // Check for excessive phrase repetition
  const repeatChecks = [
    { phrase: /предпочтительн\w+\s+выбор\w*/gi, label: 'предпочтительным выбором', max: 1 },
    { phrase: /высочайш\w+\s+уров\w+/gi, label: 'высочайший уровень', max: 2 },
    { phrase: /критически\s+важн\w+/gi, label: 'критически важных', max: 2 },
    { phrase: /работают\s+в\s+комплексе/gi, label: 'работают в комплексе', max: 1 },
    { phrase: /Данный\s+(?:подход|механизм|принцип)/gi, label: 'Данный подход/механизм/принцип', max: 3 },
    { phrase: /что\s+делает\s+е[ёе]\s+незаменим\w+/gi, label: 'что делает её незаменимым', max: 0 },
    { phrase: /что\s+особенно\s+важно\s+для/gi, label: 'что особенно важно для', max: 2 },
  ];
  for (const check of repeatChecks) {
    const matches = text.match(check.phrase);
    if (matches && matches.length > check.max + 3) {
      // Only warn if significantly exceeding (after fixAntiRepeatViolations should have fixed it)
      errors.push(`Фраза «${check.label}» повторяется ${matches.length} раз (лимит: ${check.max})`);
    }
  }

  // Check for known non-existent words (sign of LLM hallucination)
  const badWords = ['сбояируется', 'занить', 'алгоритум', 'програмного', 'функцианирование', 'компеляция', 'сбояируются', 'обеспечиние', 'предпочтительной выбором'];
  for (const w of badWords) {
    if (text.includes(w)) {
      errors.push(`Обнаружено несуществующее слово: «${w}»`);
    }
  }

  // Check for "О общего назначения" (missing "С")
  if (/\bО общего назначения/.test(text)) {
    errors.push('Обнаружено «О общего назначения» — пропущена буква «С»');
  }

  // Check for "QNX Neutrino" absence in QNX-related text
  if (/QNX/i.test(text) && !/QNX\s+Neutrino/i.test(text)) {
    errors.push('Упоминания QNX есть, но «QNX Neutrino» отсутствует — необходимо добавить');
  }

  return errors;
}

// ============================================================
// Parse corrections from verification output
// ============================================================
interface Correction {
  type: string;
  original: string;
  fixed: string;
}

function parseCorrections(text: string): Correction[] {
  const corrections: Correction[] = [];
  const regex = /\[ОШИБКА\]\s*Тип:\s*(.+?)\s*Оригинал:\s*"([\s\S]*?)"\s*Исправление:\s*"([\s\S]*?)"\s*\[\/ОШИБКА\]/gi;
  let match;

  while ((match = regex.exec(text)) !== null) {
    corrections.push({
      type: match[1].trim(),
      original: match[2].trim(),
      fixed: match[3].trim(),
    });
  }

  return corrections;
}

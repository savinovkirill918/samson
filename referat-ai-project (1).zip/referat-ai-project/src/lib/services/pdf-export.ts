import { PDFDocument, rgb } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import MarkdownIt from 'markdown-it';
import fs from 'fs';
import path from 'path';

const md = MarkdownIt();

// Convert mm to PDF points (1mm ≈ 2.835pt)
const mmToPt = (mm: number) => mm * 2.835;
// Convert cm to PDF points
const cmToPt = (cm: number) => cm * 28.35;

// Page margins per GOST: left 30mm, right 15mm, top 20mm, bottom 20mm
const PAGE_MARGINS = {
  top: mmToPt(20),
  bottom: mmToPt(20),
  left: mmToPt(30),
  right: mmToPt(15),
};

// Font sizes per GOST
const FONT_SIZE_BODY = 12;       // 12pt for body text
const FONT_SIZE_H1 = 16;         // 16pt for chapter headings
const FONT_SIZE_H2 = 14;         // 14pt for subheadings
const FONT_SIZE_H3 = 12;         // 12pt bold for sub-subheadings
const FONT_SIZE_TITLE = 16;      // 16pt bold for title page
const FONT_SIZE_TOC = 12;        // 12pt for table of contents

const LINE_HEIGHT = 1.5;         // 1.5 line spacing
const PARAGRAPH_INDENT = cmToPt(1.25); // 1.25cm first-line indent

// Spacing after headings
const SPACING_AFTER_H1 = 2.5;    // 2.5pt after chapter heading
const SPACING_AFTER_H2 = 2;      // 2pt after subheading

interface HeadingItem {
  text: string;
  level: number;
  pageNumber?: number;
}

interface Block {
  type: 'heading' | 'paragraph' | 'listItem';
  text: string;
  level?: number;
  ordered?: boolean;
}

// Section names that should be uppercase and centered
const UPPERCASE_SECTIONS = ['ВВЕДЕНИЕ', 'ЗАКЛЮЧЕНИЕ', 'СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ', 'СОДЕРЖАНИЕ', 'ОГЛАВЛЕНИЕ', 'ПРИЛОЖЕНИЯ', 'ПРИЛОЖЕНИЕ'];

function isUppercaseSection(text: string): boolean {
  return UPPERCASE_SECTIONS.some(s => text.toUpperCase().includes(s.toUpperCase()));
}

function toTitleCase(text: string): string {
  // Find first Cyrillic/Latin letter and capitalize it
  if (!text) return text;
  const match = text.match(/[а-яёa-z]/i);
  if (!match || match.index === undefined) return text;
  const idx = match.index;
  return text.slice(0, idx) + text[idx].toUpperCase() + text.slice(idx + 1);
}

function parseMarkdown(markdown: string): { blocks: Block[]; headings: HeadingItem[] } {
  const tokens = md.parse(markdown, {});
  const blocks: Block[] = [];
  const headings: HeadingItem[] = [];

  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];

    if (token.type === 'heading_open') {
      const level = parseInt(token.tag.replace('h', ''));
      i++;
      if (tokens[i] && tokens[i].type === 'inline') {
        const text = tokens[i].content;
        headings.push({ text, level });
        blocks.push({ type: 'heading', level, text });
      }
      i += 2;
      continue;
    }

    if (token.type === 'paragraph_open') {
      i++;
      if (tokens[i] && tokens[i].type === 'inline') {
        blocks.push({ type: 'paragraph', text: tokens[i].content });
      }
      i += 2;
      continue;
    }

    if (token.type === 'bullet_list_open' || token.type === 'ordered_list_open') {
      const isOrdered = token.type === 'ordered_list_open';
      i++;
      let idx = 1;
      while (i < tokens.length && tokens[i].type !== (isOrdered ? 'ordered_list_close' : 'bullet_list_close')) {
        if (tokens[i].type === 'list_item_open') {
          i++;
          if (tokens[i] && tokens[i].type === 'paragraph_open') {
            i++;
            if (tokens[i] && tokens[i].type === 'inline') {
              blocks.push({
                type: 'listItem',
                text: isOrdered ? `${idx}. ${tokens[i].content}` : `\u2022 ${tokens[i].content}`,
                ordered: isOrdered,
              });
              idx++;
            }
            i += 2;
          }
          i++;
        } else {
          i++;
        }
      }
      i++;
      continue;
    }

    i++;
  }

  return { blocks, headings };
}

function wrapText(text: string, font: import('pdf-lib').PDFFont, maxWidth: number, fontSize: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let currentLine = '';

  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const testWidth = font.widthOfTextAtSize(testLine, fontSize);

    if (testWidth > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }

  if (currentLine) {
    lines.push(currentLine);
  }

  return lines.length > 0 ? lines : [''];
}

function wrapTextJustified(text: string, font: import('pdf-lib').PDFFont, maxWidth: number, fontSize: number): { lines: string[]; isLastLine: boolean[] } {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  const isLastLine: boolean[] = [];
  let currentLineWords: string[] = [];

  for (const word of words) {
    const testLine = [...currentLineWords, word].join(' ');
    const testWidth = font.widthOfTextAtSize(testLine, fontSize);

    if (testWidth > maxWidth && currentLineWords.length > 0) {
      lines.push(currentLineWords.join(' '));
      isLastLine.push(false);
      currentLineWords = [word];
    } else {
      currentLineWords.push(word);
    }
  }

  if (currentLineWords.length > 0) {
    lines.push(currentLineWords.join(' '));
    isLastLine.push(true);
  }

  return { lines: lines.length > 0 ? lines : [''], isLastLine: isLastLine.length > 0 ? isLastLine : [true] };
}

function getFontPath(name: string): string {
  const possiblePaths = [
    path.join(process.cwd(), 'src', 'lib', 'services', 'fonts', name),
    path.join(process.cwd(), 'fonts', name),
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }

  throw new Error(`Font file not found: ${name}`);
}

export async function generatePdf(topic: string, markdown: string): Promise<Buffer> {
  const { blocks, headings } = parseMarkdown(markdown);

  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  // Embed Liberation Serif fonts (metrically equivalent to Times New Roman, supports Cyrillic)
  const regularFontBytes = fs.readFileSync(getFontPath('LiberationSerif-Regular.ttf'));
  const boldFontBytes = fs.readFileSync(getFontPath('LiberationSerif-Bold.ttf'));
  const italicFontBytes = fs.readFileSync(getFontPath('LiberationSerif-Italic.ttf'));

  const fontRegular = await pdfDoc.embedFont(regularFontBytes);
  const fontBold = await pdfDoc.embedFont(boldFontBytes);
  const fontItalic = await pdfDoc.embedFont(italicFontBytes);

  const pageWidth = 595.28;  // A4 width in points
  const pageHeight = 841.89; // A4 height in points
  const contentWidth = pageWidth - PAGE_MARGINS.left - PAGE_MARGINS.right;
  const lineHeightFn = (size: number) => size * LINE_HEIGHT;

  // Track pages for TOC page numbers
  let currentPageIndex = 0;
  let currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
  let y = pageHeight - PAGE_MARGINS.top;

  const ensureSpace = (needed: number) => {
    if (y - needed < PAGE_MARGINS.bottom) {
      currentPageIndex++;
      currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
      y = pageHeight - PAGE_MARGINS.top;
    }
  };

  const newPage = () => {
    currentPageIndex++;
    currentPage = pdfDoc.addPage([pageWidth, pageHeight]);
    y = pageHeight - PAGE_MARGINS.top;
  };

  // Draw justified text with first-line indent for paragraphs
  const drawJustifiedText = (text: string, x: number, size: number, font: import('pdf-lib').PDFFont, indent: number = 0) => {
    const availableWidth = contentWidth - (x - PAGE_MARGINS.left);
    const { lines, isLastLine: lastLineFlags } = wrapTextJustified(text, font, availableWidth - indent, size);

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const isLastLine = lastLineFlags[i];
      ensureSpace(lineHeightFn(size));

      const textX = x + (i === 0 ? indent : 0);

      if (!isLastLine) {
        // Justified: spread words across full width
        const words = line.split(/\s+/);
        if (words.length > 1) {
          const totalWordsWidth = words.reduce((sum, w) => sum + font.widthOfTextAtSize(w, size), 0);
          const totalSpaces = words.length - 1;
          const spaceWidth = (availableWidth - (i === 0 ? indent : 0) - totalWordsWidth) / totalSpaces;

          let wordX = textX;
          for (const word of words) {
            currentPage.drawText(word, {
              x: wordX,
              y,
              size,
              font,
              color: rgb(0, 0, 0),
            });
            wordX += font.widthOfTextAtSize(word, size) + spaceWidth;
          }
        } else {
          currentPage.drawText(line, {
            x: textX,
            y,
            size,
            font,
            color: rgb(0, 0, 0),
          });
        }
      } else {
        // Last line of paragraph: left-aligned within content area
        currentPage.drawText(line, {
          x: textX,
          y,
          size,
          font,
          color: rgb(0, 0, 0),
        });
      }

      y -= lineHeightFn(size);
    }
  };

  // Draw centered text
  const drawCenteredText = (text: string, size: number, font: import('pdf-lib').PDFFont) => {
    const lines = wrapText(text, font, contentWidth, size);
    for (const line of lines) {
      ensureSpace(lineHeightFn(size));
      const textWidth = font.widthOfTextAtSize(line, size);
      const textX = PAGE_MARGINS.left + (contentWidth - textWidth) / 2;
      currentPage.drawText(line, {
        x: textX,
        y,
        size,
        font,
        color: rgb(0, 0, 0),
      });
      y -= lineHeightFn(size);
    }
  };

  // Draw page number (centered bottom, no period, Arabic numerals)
  const addPageNumber = (page: import('pdf-lib').PDFPage, pageNum: number) => {
    if (pageNum <= 1) return; // Title page not numbered
    const text = String(pageNum);
    const textWidth = fontRegular.widthOfTextAtSize(text, FONT_SIZE_BODY);
    const textX = (pageWidth - textWidth) / 2;
    page.drawText(text, {
      x: textX,
      y: PAGE_MARGINS.bottom / 2,
      size: FONT_SIZE_BODY,
      font: fontRegular,
      color: rgb(0, 0, 0),
    });
  };

  // ===== FIRST PASS: Render content to count actual page numbers =====
  // We need to know the actual page number for each heading to build accurate TOC.
  // Strategy: render content first, track which page each H1/H2 heading falls on,
  // then build the TOC page with correct page numbers.

  // ===== TITLE PAGE =====
  // Page 1 — no page number
  y = pageHeight / 2 + 120;
  drawCenteredText('РЕФЕРАТ', FONT_SIZE_TITLE, fontBold);
  y -= lineHeightFn(FONT_SIZE_BODY);
  drawCenteredText(`Тема: ${topic}`, FONT_SIZE_BODY, fontBold);

  // Date at bottom center
  y = pageHeight / 2 - 80;
  const dateStr = new Date().toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  drawCenteredText(dateStr, FONT_SIZE_BODY, fontRegular);

  // ===== CONTENT PAGES =====
  // The first H1/H2 heading will trigger newPage() itself

  // Track which page each heading lands on (page index + 1 for display)
  const headingPageMap: Map<number, number> = new Map(); // heading index -> page number
  let headingIdx = 0;

  for (const block of blocks) {
    if (block.type === 'heading' && block.level) {
      const isSection = isUppercaseSection(block.text);

      // Each H1 section (ВВЕДЕНИЕ, ЗАКЛЮЧЕНИЕ, etc.) starts on a new page
      // Each H2 chapter also starts on a new page
      if (block.level === 1 || block.level === 2) {
        newPage();
      }

      // Record the page number for this heading
      headingPageMap.set(headingIdx, currentPageIndex + 1); // +1 for 1-based page numbering
      headingIdx++;

      const displayText = isSection ? block.text.toUpperCase() : block.text;

      if (block.level === 1) {
        // H1: Section heading — centered, bold, 16pt, UPPERCASE
        drawCenteredText(displayText, FONT_SIZE_H1, fontBold);
        y -= SPACING_AFTER_H1;
      } else if (block.level === 2) {
        // H2: Chapter heading — centered, bold, 14pt
        drawCenteredText(displayText, FONT_SIZE_H2, fontBold);
        y -= SPACING_AFTER_H2;
      } else if (block.level === 3) {
        // H3: Subheading — left-aligned, bold, 12pt, capital first letter
        y -= lineHeightFn(FONT_SIZE_H3) * 0.5;
        ensureSpace(lineHeightFn(FONT_SIZE_H3));
        const subText = toTitleCase(displayText);
        currentPage.drawText(subText, {
          x: PAGE_MARGINS.left,
          y,
          size: FONT_SIZE_H3,
          font: fontBold,
          color: rgb(0, 0, 0),
        });
        y -= lineHeightFn(FONT_SIZE_H3);
        y -= SPACING_AFTER_H2;
      }
    } else if (block.type === 'paragraph') {
      drawJustifiedText(block.text, PAGE_MARGINS.left, FONT_SIZE_BODY, fontRegular, PARAGRAPH_INDENT);
    } else if (block.type === 'listItem') {
      drawJustifiedText(block.text, PAGE_MARGINS.left + cmToPt(1.25), FONT_SIZE_BODY, fontRegular, 0);
    }
  }

  // ===== NOW INSERT TOC PAGE (after title page, before content) =====
  // We insert the TOC as page 2 by inserting a page into the PDF
  // Since pdf-lib doesn't support page insertion easily, we'll rebuild:
  // Instead, let's use a different approach — we know all page numbers now.
  // We insert the TOC page between title page and content.

  // Actually, with pdf-lib we can copy pages and rearrange.
  // But it's complex. A simpler approach: we already built the PDF without TOC.
  // Now we know all page numbers. Let's rebuild the entire PDF with TOC included.

  // ===== FULL REBUILD WITH TOC =====
  const fullPdfDoc = await PDFDocument.create();
  fullPdfDoc.registerFontkit(fontkit);

  const fullFontRegular = await fullPdfDoc.embedFont(regularFontBytes);
  const fullFontBold = await fullPdfDoc.embedFont(boldFontBytes);
  const fullFontItalic = await fullPdfDoc.embedFont(italicFontBytes);

  let fCurrentPage = fullPdfDoc.addPage([pageWidth, pageHeight]);
  let fY = pageHeight - PAGE_MARGINS.top;
  let fCurrentPageIndex = 0;

  const fEnsureSpace = (needed: number) => {
    if (fY - needed < PAGE_MARGINS.bottom) {
      fCurrentPageIndex++;
      fCurrentPage = fullPdfDoc.addPage([pageWidth, pageHeight]);
      fY = pageHeight - PAGE_MARGINS.top;
    }
  };

  const fNewPage = () => {
    fCurrentPageIndex++;
    fCurrentPage = fullPdfDoc.addPage([pageWidth, pageHeight]);
    fY = pageHeight - PAGE_MARGINS.top;
  };

  const fDrawCenteredText = (text: string, size: number, font: import('pdf-lib').PDFFont) => {
    const lines = wrapText(text, font, contentWidth, size);
    for (const line of lines) {
      fEnsureSpace(lineHeightFn(size));
      const textWidth = font.widthOfTextAtSize(line, size);
      const textX = PAGE_MARGINS.left + (contentWidth - textWidth) / 2;
      fCurrentPage.drawText(line, {
        x: textX,
        y: fY,
        size,
        font,
        color: rgb(0, 0, 0),
      });
      fY -= lineHeightFn(size);
    }
  };

  const fDrawJustifiedText = (text: string, x: number, size: number, font: import('pdf-lib').PDFFont, indent: number = 0) => {
    const availableWidth = contentWidth - (x - PAGE_MARGINS.left);
    const { lines, isLastLine: lastLineFlags } = wrapTextJustified(text, font, availableWidth - indent, size);

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const isLastLine = lastLineFlags[i];
      fEnsureSpace(lineHeightFn(size));

      const textX = x + (i === 0 ? indent : 0);

      if (!isLastLine) {
        const words = line.split(/\s+/);
        if (words.length > 1) {
          const totalWordsWidth = words.reduce((sum, w) => sum + font.widthOfTextAtSize(w, size), 0);
          const totalSpaces = words.length - 1;
          const spaceWidth = (availableWidth - (i === 0 ? indent : 0) - totalWordsWidth) / totalSpaces;

          let wordX = textX;
          for (const word of words) {
            fCurrentPage.drawText(word, {
              x: wordX,
              y: fY,
              size,
              font,
              color: rgb(0, 0, 0),
            });
            wordX += font.widthOfTextAtSize(word, size) + spaceWidth;
          }
        } else {
          fCurrentPage.drawText(line, {
            x: textX,
            y: fY,
            size,
            font,
            color: rgb(0, 0, 0),
          });
        }
      } else {
        fCurrentPage.drawText(line, {
          x: textX,
          y: fY,
          size,
          font,
          color: rgb(0, 0, 0),
        });
      }

      fY -= lineHeightFn(size);
    }
  };

  // ===== TITLE PAGE (page 1, not numbered) =====
  fY = pageHeight / 2 + 120;
  fDrawCenteredText('РЕФЕРАТ', FONT_SIZE_TITLE, fullFontBold);
  fY -= lineHeightFn(FONT_SIZE_BODY);
  fDrawCenteredText(`Тема: ${topic}`, FONT_SIZE_BODY, fullFontBold);

  fY = pageHeight / 2 - 80;
  fDrawCenteredText(dateStr, FONT_SIZE_BODY, fullFontRegular);

  // ===== TABLE OF CONTENTS (page 2) =====
  fNewPage();

  // Header: "Содержание" centered, no period
  fDrawCenteredText('Содержание', FONT_SIZE_H1, fullFontBold);
  fY -= lineHeightFn(FONT_SIZE_TOC); // extra space after header

  // Calculate page offset: TOC takes 1 page (page 2), so content pages are shifted by 1
  // The headingPageMap was built with 0-based page index + 1
  // Title page = page 1, content starts at page 3 (after TOC on page 2)
  // So we add +1 to all page numbers from headingPageMap (since TOC adds 1 page)
  // But we also need to account for TOC taking potentially more than 1 page.
  // For simplicity, we calculate TOC page count and adjust.

  // Build TOC entries
  const tocEntries = headings.filter(h => h.level <= 3); // Include H1, H2, H3
  let tocPageCount = 1; // at least 1 page for TOC
  // Estimate if TOC fits on one page
  const tocLinesHeight = tocEntries.length * lineHeightFn(FONT_SIZE_TOC);
  const tocAvailableHeight = pageHeight - PAGE_MARGINS.top - PAGE_MARGINS.bottom - lineHeightFn(FONT_SIZE_H1) * 2;
  if (tocLinesHeight > tocAvailableHeight) {
    tocPageCount = Math.ceil(tocLinesHeight / tocAvailableHeight);
  }

  // Render TOC entries
  let hIdx = 0;

  for (const heading of tocEntries) {
    const isSection = isUppercaseSection(heading.text);

    // Indentation: H1 = 0, H2 = one indent, H3 = double indent
    let indent = 0;
    if (heading.level === 2) indent = PARAGRAPH_INDENT;
    if (heading.level === 3) indent = PARAGRAPH_INDENT * 2;

    // Display text rules:
    // Section names (ВВЕДЕНИЕ, ЗАКЛЮЧЕНИЕ, etc.): UPPERCASE
    // Chapter names (level 2): as-is
    // Subsection names (level 3): toTitleCase (capital first letter)
    let displayText = heading.text;
    if (isSection && heading.level === 1) {
      displayText = heading.text.toUpperCase();
    } else if (heading.level === 3) {
      displayText = toTitleCase(heading.text);
    }

    const tocFont = heading.level === 1 ? fullFontBold : fullFontRegular;

    fEnsureSpace(lineHeightFn(FONT_SIZE_TOC));

    // Draw heading text
    const textWidth = tocFont.widthOfTextAtSize(displayText, FONT_SIZE_TOC);

    fCurrentPage.drawText(displayText, {
      x: PAGE_MARGINS.left + indent,
      y: fY,
      size: FONT_SIZE_TOC,
      font: tocFont,
      color: rgb(0, 0, 0),
    });

    // Page number with dot leaders (отточие)
    const originalPageNum = headingPageMap.get(hIdx) || 2;
    const adjustedPageNum = originalPageNum + tocPageCount;
    const pageNumText = String(adjustedPageNum);
    const pageNumWidth = fullFontRegular.widthOfTextAtSize(pageNumText, FONT_SIZE_TOC);
    const rightEdge = PAGE_MARGINS.left + contentWidth;

    // Draw leader dots (отточие)
    const dotWidth = fullFontRegular.widthOfTextAtSize('.', FONT_SIZE_TOC);
    let dotX = PAGE_MARGINS.left + indent + textWidth + 5;
    while (dotX < rightEdge - pageNumWidth - 5) {
      fCurrentPage.drawText('.', {
        x: dotX,
        y: fY,
        size: FONT_SIZE_TOC,
        font: fullFontRegular,
        color: rgb(0.5, 0.5, 0.5),
      });
      dotX += dotWidth + 1;
    }

    // Page number right-aligned
    fCurrentPage.drawText(pageNumText, {
      x: rightEdge - pageNumWidth,
      y: fY,
      size: FONT_SIZE_TOC,
      font: fullFontRegular,
      color: rgb(0, 0, 0),
    });

    fY -= lineHeightFn(FONT_SIZE_TOC);
    hIdx++;
  }

  // ===== CONTENT PAGES =====
  // The first H1/H2 heading will trigger fNewPage() itself

  for (const block of blocks) {
    if (block.type === 'heading' && block.level) {
      const isSection = isUppercaseSection(block.text);

      // Each H1 section and H2 chapter starts on a new page
      if (block.level === 1 || block.level === 2) {
        fNewPage();
      }

      const displayText = isSection ? block.text.toUpperCase() : block.text;

      if (block.level === 1) {
        fDrawCenteredText(displayText, FONT_SIZE_H1, fullFontBold);
        fY -= SPACING_AFTER_H1;
      } else if (block.level === 2) {
        fDrawCenteredText(displayText, FONT_SIZE_H2, fullFontBold);
        fY -= SPACING_AFTER_H2;
      } else if (block.level === 3) {
        fY -= lineHeightFn(FONT_SIZE_H3) * 0.5;
        fEnsureSpace(lineHeightFn(FONT_SIZE_H3));
        const subText = toTitleCase(displayText);
        fCurrentPage.drawText(subText, {
          x: PAGE_MARGINS.left,
          y: fY,
          size: FONT_SIZE_H3,
          font: fullFontBold,
          color: rgb(0, 0, 0),
        });
        fY -= lineHeightFn(FONT_SIZE_H3);
        fY -= SPACING_AFTER_H2;
      }
    } else if (block.type === 'paragraph') {
      fDrawJustifiedText(block.text, PAGE_MARGINS.left, FONT_SIZE_BODY, fullFontRegular, PARAGRAPH_INDENT);
    } else if (block.type === 'listItem') {
      fDrawJustifiedText(block.text, PAGE_MARGINS.left + cmToPt(1.25), FONT_SIZE_BODY, fullFontRegular, 0);
    }
  }

  // ===== ADD PAGE NUMBERS =====
  const totalPages = fullPdfDoc.getPageCount();
  for (let i = 0; i < totalPages; i++) {
    const page = fullPdfDoc.getPage(i);
    addPageNumber(page, i + 1);
  }

  fullPdfDoc.setTitle(`Реферат: ${topic}`);
  fullPdfDoc.setAuthor('Реферат ИИ');

  const pdfBytes = await fullPdfDoc.save();
  return Buffer.from(pdfBytes);
}

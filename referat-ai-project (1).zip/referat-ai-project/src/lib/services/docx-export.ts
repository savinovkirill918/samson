import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  PageBreak,
  convertInchesToTwip,
  Footer,
  PageNumber,
  TabStopType,
  TabStopPosition,
  BookmarkStart,
  BookmarkEnd,
} from 'docx';
import MarkdownIt from 'markdown-it';

const md = MarkdownIt();

// GOST margins in cm -> inches -> twips
// left 30mm, right 15mm, top 20mm, bottom 20mm
const MARGIN_LEFT = convertInchesToTwip(3.0 / 2.54);
const MARGIN_RIGHT = convertInchesToTwip(1.5 / 2.54);
const MARGIN_TOP = convertInchesToTwip(2.0 / 2.54);
const MARGIN_BOTTOM = convertInchesToTwip(2.0 / 2.54);

// Paragraph indent: 1.25cm
const PARAGRAPH_INDENT = convertInchesToTwip(1.25 / 2.54);

// Font sizes in half-points
const FONT_SIZE_BODY = 24;      // 12pt
const FONT_SIZE_H1 = 32;        // 16pt
const FONT_SIZE_H2 = 28;        // 14pt
const FONT_SIZE_H3 = 24;        // 12pt bold

// Line spacing: 1.5 = 360 twips
const LINE_SPACING = 360;

// Section names that should be uppercase and centered
const UPPERCASE_SECTIONS = ['ВВЕДЕНИЕ', 'ЗАКЛЮЧЕНИЕ', 'СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ', 'СОДЕРЖАНИЕ', 'ОГЛАВЛЕНИЕ', 'ПРИЛОЖЕНИЯ', 'ПРИЛОЖЕНИЕ'];

function isUppercaseSection(text: string): boolean {
  return UPPERCASE_SECTIONS.some(s => text.toUpperCase().includes(s.toUpperCase()));
}

function toTitleCase(text: string): string {
  // Find first Cyrillic/Latin letter and capitalize it
  if (!text) return text;
  const match = text.match(/[а-яёa-z]/i);
  if (!match || match.index === undefined) return text;
  const idx = match.index;
  return text.slice(0, idx) + text[idx].toUpperCase() + text.slice(idx + 1);
}

interface HeadingItem {
  text: string;
  level: number;
  index: number;
}

interface InlineRun {
  text: string;
  bold: boolean;
  italic: boolean;
}

function parseInlineTokens(children: MarkdownIt.Token[]): InlineRun[] {
  const runs: InlineRun[] = [];
  let inBold = false;
  let inItalic = false;

  for (const child of children) {
    if (child.type === 'text' || child.type === 'text_special') {
      runs.push({
        text: child.content,
        bold: inBold,
        italic: inItalic,
      });
    } else if (child.type === 'strong_open') {
      inBold = true;
    } else if (child.type === 'strong_close') {
      inBold = false;
    } else if (child.type === 'em_open') {
      inItalic = true;
    } else if (child.type === 'em_close') {
      inItalic = false;
    } else if (child.type === 'softbreak') {
      runs.push({ text: '', bold: false, italic: false });
    } else if (child.type === 'code_inline') {
      runs.push({
        text: child.content,
        bold: false,
        italic: false,
      });
    }
  }

  if (runs.length === 0) {
    runs.push({ text: '', bold: false, italic: false });
  }
  return runs;
}

function inlineRunsToTextRuns(runs: InlineRun[]): TextRun[] {
  return runs.map(run =>
    new TextRun({
      text: run.text,
      font: 'Times New Roman',
      size: FONT_SIZE_BODY,
      bold: run.bold,
      italics: run.italic,
    })
  );
}

function parseMarkdownToDocxElements(markdown: string): { elements: Paragraph[]; headings: HeadingItem[] } {
  const tokens = md.parse(markdown, {});
  const elements: Paragraph[] = [];
  const headings: HeadingItem[] = [];
  let headingIndex = 0;

  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];

    if (token.type === 'heading_open') {
      const level = parseInt(token.tag.replace('h', ''));
      i++;
      const contentToken = tokens[i];
      if (contentToken && contentToken.type === 'inline') {
        const text = contentToken.content;
        const bookmarkName = `heading_${headingIndex}`;
        const bookmarkId = headingIndex + 100; // unique ID
        headings.push({ text, level, index: headingIndex++ });

        const isSection = isUppercaseSection(text);
        const displayText = isSection ? text.toUpperCase() : text;

        if (level === 1) {
          // H1: Section heading — centered, bold, 16pt, starts new page
          elements.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 240, after: 50, line: LINE_SPACING },
              pageBreakBefore: true, // Each section starts on a new page
              children: [
                new BookmarkStart(bookmarkName, bookmarkId),
                new TextRun({
                  text: displayText,
                  font: 'Times New Roman',
                  size: FONT_SIZE_H1,
                  bold: true,
                }),
                new BookmarkEnd(bookmarkId),
              ],
            })
          );
        } else if (level === 2) {
          // H2: Chapter heading — centered, bold, 14pt, starts new page
          elements.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 200, after: 40, line: LINE_SPACING },
              pageBreakBefore: true, // Each chapter starts on a new page
              children: [
                new BookmarkStart(bookmarkName, bookmarkId),
                new TextRun({
                  text: displayText,
                  font: 'Times New Roman',
                  size: FONT_SIZE_H2,
                  bold: true,
                }),
                new BookmarkEnd(bookmarkId),
              ],
            })
          );
        } else if (level === 3) {
          // H3: Subheading — left-aligned, bold, 12pt, capital first letter
          elements.push(
            new Paragraph({
              alignment: AlignmentType.LEFT,
              spacing: { before: 160, after: 40, line: LINE_SPACING },
              children: [
                new BookmarkStart(bookmarkName, bookmarkId),
                new TextRun({
                  text: toTitleCase(displayText),
                  font: 'Times New Roman',
                  size: FONT_SIZE_H3,
                  bold: true,
                }),
                new BookmarkEnd(bookmarkId),
              ],
            })
          );
        }
      }
      i++;
      i++; // skip heading_close
      continue;
    }

    if (token.type === 'paragraph_open') {
      i++;
      const contentToken = tokens[i];
      if (contentToken && contentToken.type === 'inline') {
        const runs = parseInlineTokens(contentToken.children || []);
        elements.push(
          new Paragraph({
            children: inlineRunsToTextRuns(runs),
            spacing: { after: 0, line: LINE_SPACING },
            alignment: AlignmentType.JUSTIFIED,
            indent: { firstLine: PARAGRAPH_INDENT },
          })
        );
      } else if (contentToken) {
        elements.push(
          new Paragraph({
            spacing: { after: 0, line: LINE_SPACING },
            alignment: AlignmentType.JUSTIFIED,
            indent: { firstLine: PARAGRAPH_INDENT },
          })
        );
      }
      i++;
      i++; // skip paragraph_close
      continue;
    }

    if (token.type === 'bullet_list_open' || token.type === 'ordered_list_open') {
      const isOrdered = token.type === 'ordered_list_open';
      i++;
      let itemIndex = 1;
      while (i < tokens.length && tokens[i].type !== (isOrdered ? 'ordered_list_close' : 'bullet_list_close')) {
        if (tokens[i].type === 'list_item_open') {
          i++;
          if (tokens[i] && tokens[i].type === 'paragraph_open') {
            i++;
            if (tokens[i] && tokens[i].type === 'inline') {
              const runs = parseInlineTokens(tokens[i].children || []);
              elements.push(
                new Paragraph({
                  children: [
                    new TextRun({
                      text: isOrdered ? `${itemIndex}. ` : '\u2022 ',
                      font: 'Times New Roman',
                      size: FONT_SIZE_BODY,
                    }),
                    ...inlineRunsToTextRuns(runs),
                  ],
                  spacing: { after: 0, line: LINE_SPACING },
                  indent: { left: PARAGRAPH_INDENT, hanging: convertInchesToTwip(0.3 / 2.54) },
                  alignment: AlignmentType.JUSTIFIED,
                })
              );
              itemIndex++;
            }
            i++; // inline
            i++; // paragraph_close
          }
          i++; // list_item_close
        } else {
          i++;
        }
      }
      i++; // list_close
      continue;
    }

    i++;
  }

  return { elements, headings };
}

function createTitlePage(topic: string): Paragraph[] {
  const emptyLine = () =>
    new Paragraph({
      spacing: { after: 0, line: LINE_SPACING },
      children: [new TextRun({ text: '', font: 'Times New Roman', size: FONT_SIZE_BODY })],
    });

  return [
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 240, line: LINE_SPACING },
      children: [
        new TextRun({
          text: 'РЕФЕРАТ',
          font: 'Times New Roman',
          size: FONT_SIZE_H1,
          bold: true,
        }),
      ],
    }),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 240, line: LINE_SPACING },
      children: [
        new TextRun({
          text: `Тема: ${topic}`,
          font: 'Times New Roman',
          size: FONT_SIZE_H2,
          bold: true,
        }),
      ],
    }),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 120, line: LINE_SPACING },
      children: [
        new TextRun({
          text: `Дата: ${new Date().toLocaleDateString('ru-RU', { year: 'numeric', month: 'long', day: 'numeric' })}`,
          font: 'Times New Roman',
          size: FONT_SIZE_BODY,
        }),
      ],
    }),
    new Paragraph({
      children: [new PageBreak()],
    }),
  ];
}

function createTocSection(headings: HeadingItem[]): Paragraph[] {
  // Filter headings for TOC: include H1 (sections), H2 (chapters), H3 (subsections)
  const tocEntries = headings.filter((h) => h.level <= 3);

  const tocParagraphs: Paragraph[] = [];

  // Header: "Содержание" centered, no period
  tocParagraphs.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 240, after: 240, line: LINE_SPACING },
      children: [
        new TextRun({
          text: 'Содержание',
          font: 'Times New Roman',
          size: FONT_SIZE_H1,
          bold: true,
        }),
      ],
    })
  );

  // TOC entries with dot leaders and page numbers
  // Use internal hyperlink references (PAGEREF) for clickable links
  let entryIdx = 0;
  for (const entry of tocEntries) {
    const isSection = isUppercaseSection(entry.text);
    // Section names: UPPERCASE; Chapter names: as-is; Subsection names: toTitleCase
    let displayText = entry.text;
    if (isSection && entry.level === 1) {
      displayText = entry.text.toUpperCase();
    } else if (entry.level === 3) {
      displayText = toTitleCase(entry.text);
    }

    // Indentation: H1 = 0, H2 = one indent, H3 = double indent
    let indent = 0;
    if (entry.level === 2) indent = PARAGRAPH_INDENT;
    if (entry.level === 3) indent = PARAGRAPH_INDENT * 2;

    const bookmarkName = `heading_${entryIdx}`;

    // Create TOC entry with hyperlink to bookmark and dot leaders
    tocParagraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: displayText,
            font: 'Times New Roman',
            size: FONT_SIZE_BODY,
            bold: entry.level === 1,
            internalHyperlink: {
              bookmark: bookmarkName,
            },
          }),
          new TextRun({
            text: '\t', // Tab to the right-aligned position
            font: 'Times New Roman',
            size: FONT_SIZE_BODY,
          }),
          new TextRun({
            children: [PageNumber.CURRENT],
            font: 'Times New Roman',
            size: FONT_SIZE_BODY,
          }),
        ],
        spacing: { after: 60, line: LINE_SPACING },
        indent: { left: indent },
        alignment: AlignmentType.LEFT,
        tabStops: [
          {
            type: TabStopType.RIGHT,
            position: TabStopPosition.MAX,
            leader: 'dot', // Dot leader (отточие)
          },
        ],
      })
    );
    entryIdx++;
  }

  // Page break after TOC
  tocParagraphs.push(
    new Paragraph({
      children: [new PageBreak()],
    })
  );

  return tocParagraphs;
}

// Get list of TOC bookmark names (must match createTocSection)
function getTocBookmarkNames(headings: HeadingItem[]): string[] {
  const tocEntries = headings.filter((h) => h.level <= 3);
  return tocEntries.map((_, idx) => `heading_${idx}`);
}

export async function generateDocx(topic: string, markdown: string): Promise<Buffer> {
  const { elements, headings } = parseMarkdownToDocxElements(markdown);
  const titlePage = createTitlePage(topic);
  const tocSection = createTocSection(headings);

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: 'Times New Roman',
            size: FONT_SIZE_BODY, // 12pt
          },
          paragraph: {
            spacing: { line: LINE_SPACING }, // 1.5 line spacing
          },
        },
        heading1: {
          run: {
            font: 'Times New Roman',
            size: FONT_SIZE_H1, // 16pt
            bold: true,
          },
          paragraph: {
            spacing: { before: 240, after: 50, line: LINE_SPACING },
            alignment: AlignmentType.CENTER,
          },
        },
        heading2: {
          run: {
            font: 'Times New Roman',
            size: FONT_SIZE_H2, // 14pt
            bold: true,
          },
          paragraph: {
            spacing: { before: 200, after: 40, line: LINE_SPACING },
            alignment: AlignmentType.CENTER,
          },
        },
        heading3: {
          run: {
            font: 'Times New Roman',
            size: FONT_SIZE_H3, // 12pt bold
            bold: true,
          },
          paragraph: {
            spacing: { before: 160, after: 40, line: LINE_SPACING },
          },
        },
      },
    },
    features: {
      updateFields: true, // Enable automatic field updates (for TOC)
    },
    sections: [
      // Title page section — no page number
      {
        properties: {
          page: {
            margin: {
              top: MARGIN_TOP,
              bottom: MARGIN_BOTTOM,
              left: MARGIN_LEFT,
              right: MARGIN_RIGHT,
            },
          },
        },
        children: titlePage,
      },
      // TOC + Content section — page numbering starts here (page 2)
      {
        properties: {
          page: {
            margin: {
              top: MARGIN_TOP,
              bottom: MARGIN_BOTTOM,
              left: MARGIN_LEFT,
              right: MARGIN_RIGHT,
            },
            pageNumbers: {
              start: 2,
            },
          },
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    font: 'Times New Roman',
                    size: FONT_SIZE_BODY,
                  }),
                ],
              }),
            ],
          }),
        },
        children: [...tocSection, ...elements],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return Buffer.from(buffer);
}

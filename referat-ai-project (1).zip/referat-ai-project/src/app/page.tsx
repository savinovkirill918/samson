'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useAppStore } from '@/lib/store';
import { useStreamGeneration } from '@/hooks/useStreamGeneration';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  FileText,
  Download,
  FileDown,
  Send,
  Loader2,
  BookOpen,
  Sparkles,
  RotateCcw,
  AlertCircle,
  Info,
  Wifi,
  WifiOff,
} from 'lucide-react';

export default function HomePage() {
  const [topic, setTopic] = useState('');
  const [pages, setPages] = useState('5');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const {
    currentSession,
    isGenerating,
    streamingContent,
    currentPhase,
    phaseIndex,
    totalPhases,
    progress,
    error,
    reset,
  } = useAppStore();

  const { startGeneration, restoreSession, stopGeneration, connectToStream } = useStreamGeneration();

  // Auto-scroll to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [streamingContent]);

  // Restore session from URL on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sessionId = params.get('session');
    if (sessionId) {
      restoreSession(sessionId);
    }
  }, [restoreSession]);

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!topic.trim() || isGenerating) return;

      const pagesNum = parseInt(pages);
      if (isNaN(pagesNum) || pagesNum < 1 || pagesNum > 50) return;

      await startGeneration(topic.trim(), pagesNum);
    },
    [topic, pages, isGenerating, startGeneration]
  );

  const handleNewReferat = useCallback(() => {
    stopGeneration();
    reset();
    setTopic('');
    setPages('5');
    window.history.replaceState({}, '', '/');
  }, [stopGeneration, reset]);

  const handleRetryConnection = useCallback(() => {
    if (currentSession?.id) {
      useAppStore.setState({ error: null, isGenerating: true });
      connectToStream(currentSession.id);
    }
  }, [currentSession, connectToStream]);

  const handleDownload = useCallback(
    async (format: 'pdf' | 'docx') => {
      if (!currentSession || currentSession.status !== 'completed') return;

      try {
        const response = await fetch(
          `/api/sessions/${currentSession.id}/export?format=${format}`
        );
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error || 'Ошибка скачивания');
        }

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${currentSession.title}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } catch (err) {
        console.error('Download error:', err);
      }
    },
    [currentSession]
  );

  const isCompleted = currentSession?.status === 'completed';
  const isErrored = !!error && !isGenerating;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-semibold">Реферат ИИ</h1>
          </div>
          {currentSession && (
            <div className="flex items-center gap-2 ml-auto">
              <Badge variant={isCompleted ? 'default' : isGenerating ? 'secondary' : 'outline'}>
                {isCompleted ? 'Готово' : isGenerating ? 'Генерация...' : currentSession.status}
              </Badge>
              <Button variant="ghost" size="sm" onClick={handleNewReferat}>
                <RotateCcw className="w-4 h-4 mr-1" />
                Новый
              </Button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-6 flex flex-col gap-4">
        {/* Input Form */}
        {!currentSession && (
          <Card className="border-2">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-semibold">Генерация реферата</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Введите тему и укажите количество страниц. ИИ сгенерирует структурированный реферат
                с введением, 2–3 главами, заключением и списком литературы. Готовый документ можно скачать
                в формате PDF или DOCX с оформлением по ГОСТ (Times New Roman, 12pt, полуторный интервал).
              </p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Тема реферата</label>
                  <Input
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Например: История Древнего Рима"
                    className="text-base"
                    disabled={isGenerating}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">Количество страниц</label>
                  <Input
                    type="number"
                    min={1}
                    max={50}
                    value={pages}
                    onChange={(e) => setPages(e.target.value)}
                    className="w-32 text-base"
                    disabled={isGenerating}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    От 1 до 50 страниц (1 стр. ≈ 1800 знаков)
                  </p>
                </div>
                <Button
                  type="submit"
                  disabled={!topic.trim() || isGenerating}
                  className="w-full sm:w-auto"
                  size="lg"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Генерация...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Сгенерировать реферат
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Progress Bar */}
        {isGenerating && (
          <Card>
            <CardContent className="py-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {currentPhase
                    ? `Генерация: ${currentPhase} (${phaseIndex + 1}/${totalPhases})`
                    : 'Подготовка к генерации...'}
                </span>
                <span className="text-sm text-muted-foreground">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </CardContent>
          </Card>
        )}

        {/* Error with reconnect option */}
        {isErrored && (
          <Card className="border-destructive">
            <CardContent className="py-4">
              <div className="flex items-center gap-2 text-destructive">
                <WifiOff className="w-5 h-5" />
                <span className="font-medium">Соединение прервано</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{error}</p>
              <p className="text-xs text-muted-foreground mt-1">
                Генерация продолжается на сервере. Нажмите «Подключиться» чтобы продолжить просмотр.
              </p>
              <div className="flex gap-2 mt-3">
                <Button variant="outline" size="sm" onClick={handleRetryConnection} className="gap-1.5">
                  <Wifi className="w-3.5 h-3.5" />
                  Подключиться
                </Button>
                <Button variant="outline" size="sm" onClick={handleNewReferat}>
                  Новый реферат
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Chat Area */}
        {currentSession && (streamingContent || isGenerating) && (
          <div className="flex-1 flex flex-col gap-4">
            {/* User Message */}
            {currentSession.messages?.find((m) => m.role === 'user') && (
              <div className="flex justify-end">
                <div className="bg-primary text-primary-foreground rounded-2xl rounded-br-sm px-4 py-2.5 max-w-[80%]">
                  <p className="text-sm">
                    {currentSession.messages.find((m) => m.role === 'user')?.content}
                  </p>
                </div>
              </div>
            )}

            {/* Assistant Message */}
            <div className="flex justify-start">
              <div className="bg-card border rounded-2xl rounded-bl-sm px-4 py-3 max-w-[90%] shadow-sm">
                <div className="flex items-center gap-1.5 mb-2">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground font-medium">Реферат</span>
                  {isGenerating && (
                    <span className="text-xs text-muted-foreground ml-1">(генерируется...)</span>
                  )}
                </div>
                <div className={`markdown-content text-sm ${isGenerating ? 'streaming-cursor' : ''}`}>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {streamingContent || 'Генерация начинается...'}
                  </ReactMarkdown>
                </div>
              </div>
            </div>

            <div ref={chatEndRef} />
          </div>
        )}

        {/* Download Panel */}
        {isCompleted && (
          <Card className="border-2 border-primary/20 bg-primary/5">
            <CardContent className="py-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-semibold flex items-center gap-2">
                    <Download className="w-5 h-5" />
                    Реферат готов!
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Скачайте документ с оформлением по ГОСТ (шрифт Times New Roman, 12pt, полуторный интервал, поля по ГОСТ)
                  </p>
                  <div className="flex items-center gap-1.5 mt-2 text-xs text-muted-foreground">
                    <Info className="w-3.5 h-3.5" />
                    <span>Файл отформатирован по ГОСТ: титульный лист, содержание, нумерация страниц, поля 30/15/20/20 мм</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="lg"
                          onClick={() => handleDownload('pdf')}
                          className="gap-2"
                        >
                          <FileDown className="w-4 h-4" />
                          PDF
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Скачать в формате PDF (Академическое оформление)</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="lg"
                          onClick={() => handleDownload('docx')}
                          className="gap-2"
                        >
                          <FileDown className="w-4 h-4" />
                          DOCX
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Скачать в формате Word (Академическое оформление)</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* New referat button when completed */}
        {isCompleted && (
          <div className="flex justify-center">
            <Button variant="outline" size="lg" onClick={handleNewReferat} className="gap-2">
              <Sparkles className="w-4 h-4" />
              Создать новый реферат
            </Button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-auto">
        <div className="max-w-4xl mx-auto px-4 text-center text-sm text-muted-foreground">
          Сервис генерации рефератов с ИИ — текст генерируется искусственным интеллектом и требует проверки
        </div>
      </footer>
    </div>
  );
}

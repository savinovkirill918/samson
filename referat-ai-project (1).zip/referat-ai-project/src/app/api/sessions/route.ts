import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generateFullReferat } from '@/lib/services/llm';

// Track active generation processes so we don't start duplicates
const activeGenerations = new Set<string>();

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { topic, pages } = body;

    if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
      return NextResponse.json({ error: 'Тема реферата обязательна' }, { status: 400 });
    }

    const targetPages = parseInt(pages);
    if (isNaN(targetPages) || targetPages < 1 || targetPages > 50) {
      return NextResponse.json({ error: 'Количество страниц должно быть от 1 до 50' }, { status: 400 });
    }

    // Create or get default user
    let user = await db.user.findFirst();
    if (!user) {
      user = await db.user.create({ data: {} });
    }

    // Create session
    const session = await db.session.create({
      data: {
        userId: user.id,
        title: topic.trim(),
        targetPages,
        status: 'generating',
      },
    });

    // Create user message
    await db.message.create({
      data: {
        sessionId: session.id,
        role: 'user',
        content: `Напиши реферат на тему "${topic.trim()}" на ${targetPages} страниц.`,
        status: 'completed',
      },
    });

    // Create assistant message (will be filled during generation)
    await db.message.create({
      data: {
        sessionId: session.id,
        role: 'assistant',
        content: '',
        status: 'generating',
      },
    });

    // Start background generation — fire and forget
    // This continues even if the HTTP response completes
    startBackgroundGeneration(session.id, topic.trim(), targetPages);

    return NextResponse.json({
      id: session.id,
      title: session.title,
      targetPages: session.targetPages,
      status: 'generating',
    });
  } catch (error) {
    console.error('Error creating session:', error);
    return NextResponse.json({ error: 'Ошибка при создании сессии' }, { status: 500 });
  }
}

export async function GET() {
  try {
    const sessions = await db.session.findMany({
      orderBy: { createdAt: 'desc' },
      take: 20,
    });
    return NextResponse.json(sessions);
  } catch (error) {
    console.error('Error fetching sessions:', error);
    return NextResponse.json({ error: 'Ошибка при получении сессий' }, { status: 500 });
  }
}

async function startBackgroundGeneration(sessionId: string, topic: string, targetPages: number) {
  // Prevent duplicate generation
  if (activeGenerations.has(sessionId)) return;
  activeGenerations.add(sessionId);

  let dbBuffer = '';
  let lastDbSave = Date.now();
  const DB_SAVE_INTERVAL = 500;

  const flushToDb = async (messageId: string) => {
    if (!dbBuffer) return;
    const textToSave = dbBuffer;
    dbBuffer = '';
    try {
      const current = await db.message.findUnique({ where: { id: messageId } });
      if (current) {
        await db.message.update({
          where: { id: messageId },
          data: { content: current.content + textToSave },
        });
      }
    } catch (e) {
      console.error('DB flush error:', e);
      dbBuffer = textToSave + dbBuffer;
    }
    lastDbSave = Date.now();
  };

  try {
    // Get the assistant message ID
    const messages = await db.message.findMany({
      where: { sessionId, role: 'assistant' },
    });
    const assistantMsg = messages[0];
    if (!assistantMsg) {
      throw new Error('Assistant message not found');
    }

    const fullText = await generateFullReferat(
      topic,
      targetPages,
      // onChunk — buffer and periodically flush to DB
      async (chunk: string) => {
        dbBuffer += chunk;
        if (Date.now() - lastDbSave > DB_SAVE_INTERVAL) {
          await flushToDb(assistantMsg.id);
        }
      },
      // onPhaseStart — flush DB and update phase info
      async (phaseName: string, phaseIndex: number, totalPhases: number) => {
        await flushToDb(assistantMsg.id);
      }
    );

    // Final flush
    await flushToDb(assistantMsg.id);

    // Mark as completed
    await db.message.update({
      where: { id: assistantMsg.id },
      data: { status: 'completed', content: fullText },
    });
    await db.session.update({
      where: { id: sessionId },
      data: { status: 'completed' },
    });
  } catch (error) {
    console.error('Background generation error:', error);

    // Try to flush remaining buffer
    try {
      const messages = await db.message.findMany({
        where: { sessionId, role: 'assistant' },
      });
      if (messages[0]) {
        await flushToDb(messages[0].id);
      }
    } catch { /* ignore */ }

    // Mark as error
    try {
      await db.session.update({
        where: { id: sessionId },
        data: { status: 'error' },
      });
      const messages = await db.message.findMany({
        where: { sessionId, role: 'assistant' },
      });
      if (messages[0]) {
        await db.message.update({
          where: { id: messages[0].id },
          data: { status: 'interrupted' },
        });
      }
    } catch { /* ignore */ }
  } finally {
    activeGenerations.delete(sessionId);
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generateDocx } from '@/lib/services/docx-export';
import { generatePdf } from '@/lib/services/pdf-export';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> }
) {
  try {
    const { sessionId } = await params;
    const format = request.nextUrl.searchParams.get('format');

    if (!format || !['pdf', 'docx'].includes(format)) {
      return NextResponse.json(
        { error: 'Укажите формат: pdf или docx' },
        { status: 400 }
      );
    }

    const session = await db.session.findUnique({
      where: { id: sessionId },
      include: { messages: true },
    });

    if (!session) {
      return NextResponse.json({ error: 'Сессия не найдена' }, { status: 404 });
    }

    if (session.status !== 'completed') {
      return NextResponse.json(
        { error: 'Реферат ещё не завершён. Дождитесь окончания генерации.' },
        { status: 400 }
      );
    }

    const assistantMessage = session.messages.find((m) => m.role === 'assistant');
    if (!assistantMessage || !assistantMessage.content) {
      return NextResponse.json(
        { error: 'Содержимое реферата не найдено' },
        { status: 404 }
      );
    }

    const topic = session.title;
    const markdown = assistantMessage.content;

    if (format === 'docx') {
      const buffer = await generateDocx(topic, markdown);
      const filename = encodeURIComponent(`${topic}.docx`);

      return new NextResponse(buffer, {
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'Content-Disposition': `attachment; filename="${filename}"`,
        },
      });
    }

    if (format === 'pdf') {
      const buffer = await generatePdf(topic, markdown);
      const filename = encodeURIComponent(`${topic}.pdf`);

      return new NextResponse(buffer, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': `attachment; filename="${filename}"`,
        },
      });
    }

    return NextResponse.json({ error: 'Неподдерживаемый формат' }, { status: 400 });
  } catch (error) {
    console.error('Export error:', error);
    return NextResponse.json(
      { error: 'Ошибка при экспорте документа' },
      { status: 500 }
    );
  }
}

import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> }
) {
  const { sessionId } = await params;

  const session = await db.session.findUnique({
    where: { id: sessionId },
    include: { messages: true },
  });

  if (!session) {
    return new Response('Session not found', { status: 404 });
  }

  const assistantMessage = session.messages.find((m) => m.role === 'assistant');

  const encoder = new TextEncoder();

  const send = (data: Record<string, unknown>) => {
    return encoder.encode(`data: ${JSON.stringify(data)}\n\n`);
  };

  // If already completed — return full content immediately
  if (session.status === 'completed') {
    const stream = new ReadableStream({
      start(controller) {
        try {
          controller.enqueue(send({ type: 'content', text: assistantMessage?.content || '' }));
          controller.enqueue(send({ type: 'done' }));
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    });
  }

  // If errored
  if (session.status === 'error') {
    const stream = new ReadableStream({
      start(controller) {
        try {
          controller.enqueue(send({ type: 'error', message: 'Генерация завершена с ошибкой' }));
        } finally {
          controller.close();
        }
      },
    });
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    });
  }

  // Generating — poll DB and stream new content
  let lastContentLength = 0;
  let clientConnected = true;
  let lastPhaseIndex = -1;

  // Send existing content first
  if (assistantMessage && assistantMessage.content) {
    lastContentLength = assistantMessage.content.length;
  }

  const stream = new ReadableStream({
    async start(controller) {
      // Send existing content if any
      if (assistantMessage && assistantMessage.content) {
        try {
          controller.enqueue(send({ type: 'content', text: assistantMessage.content }));
        } catch {
          return;
        }
      }

      // Poll DB for changes
      const pollInterval = setInterval(async () => {
        if (!clientConnected) {
          clearInterval(pollInterval);
          return;
        }

        try {
          const currentSession = await db.session.findUnique({
            where: { id: sessionId },
            include: { messages: true },
          });

          if (!currentSession) {
            clearInterval(pollInterval);
            controller.enqueue(send({ type: 'error', message: 'Сессия не найдена' }));
            controller.close();
            return;
          }

          const currentMsg = currentSession.messages.find((m) => m.role === 'assistant');

          // Send new content (only the delta)
          if (currentMsg && currentMsg.content.length > lastContentLength) {
            const newContent = currentMsg.content.slice(lastContentLength);
            lastContentLength = currentMsg.content.length;

            // Split into small chunks for smoother rendering
            const chunkSize = 50;
            for (let i = 0; i < newContent.length; i += chunkSize) {
              const chunk = newContent.slice(i, i + chunkSize);
              controller.enqueue(send({ type: 'chunk', text: chunk }));
            }
          }

          // Check completion
          if (currentSession.status === 'completed') {
            clearInterval(pollInterval);
            // Send any remaining content
            if (currentMsg && currentMsg.content.length > lastContentLength) {
              const remaining = currentMsg.content.slice(lastContentLength);
              if (remaining) {
                controller.enqueue(send({ type: 'chunk', text: remaining }));
              }
            }
            controller.enqueue(send({ type: 'done' }));
            controller.close();
            return;
          }

          if (currentSession.status === 'error') {
            clearInterval(pollInterval);
            controller.enqueue(send({ type: 'error', message: 'Ошибка генерации' }));
            controller.close();
            return;
          }

          // Estimate progress from content length vs target
          const targetChars = currentSession.targetPages * 1800;
          const currentChars = currentMsg?.content?.length || 0;
          const estimatedProgress = Math.min(95, Math.round((currentChars / targetChars) * 100));

          // Send progress update
          controller.enqueue(send({
            type: 'progress',
            progress: estimatedProgress,
          }));

        } catch (err) {
          console.error('Poll error:', err);
          // Don't close on poll error, just continue
        }
      }, 1000); // Poll every second

      // Clean up on disconnect
      request.signal.addEventListener('abort', () => {
        clientConnected = false;
        clearInterval(pollInterval);
        try { controller.close(); } catch { /* ignore */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    },
  });
}

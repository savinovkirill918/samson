'use client';

import { useCallback, useRef } from 'react';
import { useAppStore } from '@/lib/store';

export function useStreamGeneration() {
  const abortControllerRef = useRef<AbortController | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const startGeneration = useCallback(
    async (topic: string, pages: number) => {
      // Reset state
      useAppStore.setState({
        isGenerating: true,
        error: null,
        streamingContent: '',
        currentPhase: '',
        progress: 0,
      });

      try {
        // 1. Create session (this also starts background generation)
        const response = await fetch('/api/sessions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ topic, pages }),
        });

        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error || 'Ошибка при создании сессии');
        }

        const session = await response.json();
        useAppStore.setState({ currentSession: session });

        // 2. Update browser URL so refresh works
        window.history.replaceState({}, '', `/?session=${session.id}`);

        // 3. Connect to SSE stream
        await connectToStream(session.id);
      } catch (error: unknown) {
        if (error instanceof Error && error.name !== 'AbortError') {
          useAppStore.setState({ error: error.message || 'Неизвестная ошибка', isGenerating: false });
        }
      }
    },
    [] // no deps — we use useAppStore.setState directly
  );

  const connectToStream = useCallback(
    async (sessionId: string) => {
      // Clean up previous connection
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }

      abortControllerRef.current = new AbortController();

      try {
        const streamResponse = await fetch(
          `/api/sessions/${sessionId}/stream`,
          { signal: abortControllerRef.current.signal }
        );

        if (!streamResponse.ok) {
          throw new Error('Ошибка при подключении к стриму');
        }

        const reader = streamResponse.body?.getReader();
        if (!reader) throw new Error('Нет потока данных');

        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6));

                switch (data.type) {
                  case 'content':
                    // Full content (session completed)
                    useAppStore.setState({ streamingContent: data.text });
                    break;
                  case 'chunk':
                    useAppStore.setState((state) => ({
                      streamingContent: state.streamingContent + data.text,
                    }));
                    break;
                  case 'phase':
                    useAppStore.setState({
                      currentPhase: data.phaseName,
                      phaseIndex: data.phaseIndex,
                      totalPhases: data.totalPhases,
                      progress: data.progress,
                    });
                    break;
                  case 'progress':
                    useAppStore.setState({ progress: data.progress });
                    break;
                  case 'done':
                    useAppStore.setState({
                      isGenerating: false,
                      progress: 100,
                      currentSession: {
                        ...useAppStore.getState().currentSession!,
                        status: 'completed',
                      },
                    });
                    break;
                  case 'error':
                    useAppStore.setState({
                      error: data.message || 'Ошибка генерации',
                      isGenerating: false,
                    });
                    break;
                }
              } catch {
                // Ignore parse errors for individual lines
              }
            }
          }
        }

        // If we got here and generation is still running, the stream closed unexpectedly
        // Try to reconnect
        const state = useAppStore.getState();
        if (state.isGenerating && state.currentSession?.status !== 'completed') {
          console.log('Stream ended unexpectedly, reconnecting in 2s...');
          reconnectTimeoutRef.current = setTimeout(() => {
            connectToStream(sessionId);
          }, 2000);
        }
      } catch (error: unknown) {
        if (error instanceof Error && error.name === 'AbortError') {
          return; // Intentional abort
        }

        // Network error — try to reconnect if still generating
        const state = useAppStore.getState();
        if (state.isGenerating && state.currentSession?.status !== 'completed') {
          console.log('Stream error, reconnecting in 3s...', error);
          useAppStore.setState({ error: null }); // Clear error — we're reconnecting
          reconnectTimeoutRef.current = setTimeout(() => {
            connectToStream(sessionId);
          }, 3000);
        } else {
          useAppStore.setState({
            error: error instanceof Error ? error.message : 'Сетевая ошибка',
            isGenerating: false,
          });
        }
      }
    },
    []
  );

  const restoreSession = useCallback(
    async (sessionId: string) => {
      try {
        const response = await fetch(`/api/sessions/${sessionId}`);
        if (!response.ok) throw new Error('Сессия не найдена');

        const session = await response.json();
        const assistantMessage = session.messages?.find(
          (m: { role: string }) => m.role === 'assistant'
        );

        if (session.status === 'completed' && assistantMessage) {
          useAppStore.setState({
            currentSession: session,
            streamingContent: assistantMessage.content,
            progress: 100,
            isGenerating: false,
          });
          return;
        }

        if (session.status === 'generating') {
          // Set what we have so far
          useAppStore.setState({
            currentSession: session,
            streamingContent: assistantMessage?.content || '',
            isGenerating: true,
            progress: 0,
          });

          // Connect to stream to continue receiving updates
          await connectToStream(sessionId);
          return;
        }

        if (session.status === 'error') {
          useAppStore.setState({
            currentSession: session,
            streamingContent: assistantMessage?.content || '',
            error: 'Генерация была прервана',
            isGenerating: false,
          });
          return;
        }

        // Active but not generating
        useAppStore.setState({ currentSession: session });
      } catch (error: unknown) {
        if (error instanceof Error && error.name !== 'AbortError') {
          useAppStore.setState({
            error: error.message || 'Ошибка восстановления',
            isGenerating: false,
          });
        }
      }
    },
    [connectToStream]
  );

  const stopGeneration = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    useAppStore.setState({ isGenerating: false });
  }, []);

  return { startGeneration, restoreSession, stopGeneration, connectToStream };
}

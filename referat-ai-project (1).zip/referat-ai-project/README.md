# Реферат ИИ — AI Referat Generator

Веб-приложение для генерации академических рефератов с помощью ИИ. Пользователь вводит тему и количество страниц, ИИ генерирует структурированный реферат (план, введение, главы, заключение) в реальном времени, а затем позволяет экспортировать готовый документ в PDF или DOCX с оформлением по ГОСТ.

## Технологии

- **Frontend**: Next.js 16 (App Router), React 19, Tailwind CSS 4, shadcn/ui, Zustand
- **Backend**: Next.js API Routes, Prisma ORM, SQLite
- **AI**: z-ai-web-dev-sdk (LLM с потоковой генерацией)
- **Экспорт**: pdf-lib + Liberation Sans (PDF), docx (DOCX), markdown-it
- **Форматирование**: Times New Roman 14pt, полуторный интервал, поля по ГОСТ
- **Деплой**: PM2 (ecosystem.config.js), Caddy (reverse proxy)

## Структура проекта

```
referat-ai-project/
  .env                              — Переменные окружения (DATABASE_URL)
  .env.example                      — Шаблон переменных окружения
  .gitignore                        — Исключения для Git
  Caddyfile                         — Конфиг Caddy reverse proxy
  ecosystem.config.js               — Конфиг PM2 для production
  package.json                      — Зависимости и скрипты
  tsconfig.json                     — Конфиг TypeScript
  tailwind.config.ts                — Конфиг Tailwind CSS
  next.config.ts                    — Конфиг Next.js
  components.json                   — Конфиг shadcn/ui
  prisma/
    schema.prisma                   — Схема БД (User, Session, Message)
  db/
    custom.db                       — SQLite база данных (с данными)
  logs/                             — Логи PM2 (создаётся автоматически)
  public/
    robots.txt                      — Robots.txt
  src/
    app/
      page.tsx                      — Главная страница с формой и чатом
      layout.tsx                    — Корневой layout
      globals.css                   — Глобальные стили + Markdown стили
      api/
        route.ts                    — Health check
        sessions/
          route.ts                  — POST создание сессии, GET список
          [sessionId]/
            route.ts                — GET сессия с сообщениями
            stream/route.ts         — SSE стрим генерации (polling DB)
            export/route.ts         — GET экспорт в PDF/DOCX
    components/ui/                  — shadcn/ui компоненты
    hooks/
      useStreamGeneration.ts        — Хук для SSE стриминга и восстановления сессии
      use-mobile.ts                 — Мобильная адаптация
      use-toast.ts                  — Toast уведомления
    lib/
      db.ts                         — Prisma клиент (singleton)
      store.ts                      — Zustand store
      utils.ts                      — Утилиты (cn)
      services/
        llm.ts                      — LLM сервис (multi-phase генерация + постобработка)
        docx-export.ts              — Экспорт в DOCX (GOST форматирование)
        pdf-export.ts               — Экспорт в PDF (Liberation Sans, кириллица)
        fonts/                      — TTF шрифты для PDF
```

## Требования

- **Node.js** >= 18 или **Bun** >= 1.0
- npm или bun для установки зависимостей
- (Для production) PM2, Caddy

## Установка и запуск

### 1. Клонируйте репозиторий

```bash
git clone <url-репозитория>
cd referat-ai-project
```

### 2. Установите зависимости

```bash
npm install
# или
bun install
```

### 3. Настройте переменные окружения

Файл `.env` уже включён в репозиторий с настройкой по умолчанию:

```
DATABASE_URL="file:./db/custom.db"
```

Если нужна новая база данных:

```bash
cp .env.example .env
npx prisma generate
npx prisma db push
```

### 4. Запустите dev-сервер

```bash
npm run dev
# или
bun run dev
```

Приложение будет доступно по адресу: **http://localhost:3000**

### 5. (Опционально) Production сборка

```bash
npm run build
npm run start
# или через PM2:
pm2 start ecosystem.config.js
```

### 6. (Опционально) Настройка Caddy

```bash
# Скопируйте Caddyfile в конфиг Caddy
sudo cp Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

## Использование

1. Откройте http://localhost:3000
2. Введите тему реферата (например: «История Древнего Рима»)
3. Укажите количество страниц (1–50)
4. Нажмите «Сгенерировать реферат»
5. Наблюдайте за генерацией в реальном времени
6. После завершения скачайте документ в PDF или DOCX

## Архитектура генерации

Генерация происходит в несколько фаз:
1. **План** — структура реферата с заголовками глав
2. **Введение** — актуальность, цель, задачи, методы
3. **Главы 1..N** — основное содержание (N зависит от кол-ва страниц)
4. **Заключение** — выводы и перспективы

Каждая фаза генерируется отдельным запросом к LLM с потоковым ответом. Текст сохраняется в БД инкрементально (каждые 500мс). Клиент получает обновления через SSE (Server-Sent Events) с polling-ом БД.

## Постобработка текста (llm.ts)

После генерации LLM текст проходит несколько этапов очистки и исправления:

1. **cleanGeneratedText()** — защита URL, удаление CJK-символов, исправление пустых скобок, опечаток, неполных заголовков, повреждённых паттернов
2. **fixAntiRepeatViolations()** — замена повторяющихся фраз и шаблонных конструкций синонимами (5 фаз: фразы → шаблонные окончания → «Классификация» → общие шаблоны → «Данный X»)
3. **repairBibliographyUrls()** — восстановление повреждённых URL в библиографии (протоколы, двойные слеши)
4. **validateStructure()** — валидация структуры: пустые скобки, повторы, несуществующие слова, неполные заголовки, битые URL
5. **removeIntraChapterBibliographies()** — удаление дублирующихся списков литературы внутри глав

## Экспорт документов

### PDF
- Шрифт: Liberation Sans (встроенный, поддерживает кириллицу)
- Титульный лист, оглавление, содержание
- Формат: A4, поля 3/1.5/2/2 см (левое/правое/верхнее/нижнее)

### DOCX
- Шрифт: Times New Roman, 14pt
- Полуторный интервал (1.5 line spacing)
- Титульный лист, оглавление, содержание
- Формат: A4, поля по ГОСТ

## Возможные проблемы

1. **Генерация прерывается** — LLM может вернуть ошибку; генерация продолжится со следующей фазы
2. **Страница обновляется** — сессия сохраняется в БД; при обновлении страницы с `?session=id` состояние восстанавливается
3. **PDF не отображает кириллицу** — шрифты Liberation Sans встроены в проект и поддерживают кириллицу
4. **Пустые скобки в тексте** — исправляется автоматически на этапе постобработки

## Лицензия

MIT

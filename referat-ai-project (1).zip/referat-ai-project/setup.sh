#!/bin/bash
# =============================================================
# Скрипт развёртывания referat-ai-project
# Запуск: chmod +x setup.sh && ./setup.sh
# =============================================================

set -e

echo "============================================"
echo "  Реферат ИИ — Установка и развёртывание"
echo "============================================"
echo ""

# Определяем пакетный менеджер
if command -v bun &> /dev/null; then
  PKG="bun"
  INSTALL_CMD="bun install"
  RUN_CMD="bun run"
elif command -v npm &> /dev/null; then
  PKG="npm"
  INSTALL_CMD="npm install"
  RUN_CMD="npm run"
else
  echo "❌ Не найден ни npm, ни bun. Установите Node.js >= 18 или Bun >= 1.0"
  exit 1
fi

echo "✓ Используется пакетный менеджер: $PKG"
echo ""

# 1. Установка зависимостей
echo "📦 Установка зависимостей..."
$INSTALL_CMD
echo "✓ Зависимости установлены"
echo ""

# 2. Проверка .env
if [ ! -f .env ]; then
  echo "📝 Создание .env из шаблона..."
  cp .env.example .env
  echo "✓ Файл .env создан"
else
  echo "✓ Файл .env уже существует"
fi
echo ""

# 3. Проверка базы данных
if [ -f db/custom.db ]; then
  echo "✓ База данных найдена (db/custom.db)"
else
  echo "📊 Создание базы данных..."
  mkdir -p db
  npx prisma generate
  npx prisma db push
  echo "✓ База данных создана"
fi
echo ""

# 4. Генерация Prisma клиента
echo "🔧 Генерация Prisma клиента..."
npx prisma generate
echo "✓ Prisma клиент сгенерирован"
echo ""

# 5. Создание директории для логов
mkdir -p logs

# Выбор режима
echo "============================================"
echo "  Выберите режим запуска:"
echo "  1) Development (dev-сервер с hot reload)"
echo "  2) Production (build + start)"
echo "  3) Production + PM2"
echo "============================================"
read -p "Ваш выбор [1/2/3]: " choice

case $choice in
  1)
    echo ""
    echo "🚀 Запуск dev-сервера..."
    echo "   Приложение: http://localhost:3000"
    $RUN_CMD dev
    ;;
  2)
    echo ""
    echo "🏗️  Сборка production..."
    $RUN_CMD build
    echo "🚀 Запуск production-сервера..."
    echo "   Приложение: http://localhost:3000"
    $RUN_CMD start
    ;;
  3)
    if ! command -v pm2 &> /dev/null; then
      echo "⚠️  PM2 не установлен. Устанавливаю..."
      npm install -g pm2
    fi
    echo ""
    echo "🏗️  Сборка production..."
    $RUN_CMD build
    echo "🚀 Запуск через PM2..."
    pm2 start ecosystem.config.js
    pm2 save
    echo "✓ Приложение запущено через PM2"
    echo "   Приложение: http://localhost:3000"
    echo "   Мониторинг: pm2 monit"
    echo "   Логи: pm2 logs referat-ai"
    ;;
  *)
    echo "Неверный выбор. Запуск dev-сервера..."
    $RUN_CMD dev
    ;;
esac

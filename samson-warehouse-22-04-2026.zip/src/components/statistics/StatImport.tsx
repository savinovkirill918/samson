'use client';

import React, { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle, memo } from 'react';
import { Upload, CheckCircle, AlertCircle, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import { uploadStats, getStatUploads } from '@/lib/api';

interface UploadRecord {
  id: number;
  dateFrom: string;
  dateTo: string;
  groupName?: string;
  uploadedAt: string;
}

const arr = (v: any): any[] => (!v ? [] : Array.isArray(v) ? v : [v]);

/* ================================================================== */
/*  Parse Report 13 XML                                                */
/*  Structure: CrystalReport > Group > GroupHeader > Section > Text/Field
/*            CrystalReport > Group > Details(Level="2") > Section > Field
/* ================================================================== */
const parseReport13 = (xmlText: string) => {
  const { XMLParser } = require('fast-xml-parser');
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    textNodeName: '__text',
    removeNSPrefix: true,
    isArray: (name: string, jpath: string) => {
      // Force arrays for elements that repeat
      if (['Group', 'Details', 'Section', 'Field', 'Text'].includes(name)) return true;
      return false;
    },
  });
  const parsed = parser.parse(xmlText);

  const report = parsed?.CrystalReport;
  if (!report) throw new Error('Неверный формат XML: не найден корневой элемент CrystalReport');

  let period = '';
  let groupName = '';
  const rows: any[] = [];

  const groups = arr(report?.Group);

  for (const group of groups) {
    // --- GroupHeader: extract group name and period ---
    const ghSections = arr(group?.GroupHeader?.Section);
    for (const section of ghSections) {
      // Text elements (column headers + period info)
      for (const text of arr(section?.Text)) {
        const value: string = text?.TextValue || text?.__text || '';
        if (value.includes('период') || value.match(/\d{2}[\/]\d{2}[\/]\d{4}/)) {
          period = value;
        }
      }
      // Field elements (USERDEF51 = group name)
      for (const field of arr(section?.Field)) {
        const name: string = field?.['@_Name'] || '';
        const value: string = field?.Value || field?.FormattedValue || '';
        if (name === 'USERDEF51') {
          groupName = value;
        }
      }
    }

    // --- Details: employee rows (check Level attribute if present) ---
    const detailsList = arr(group?.Details);
    for (const details of detailsList) {
      const level = details?.['@_Level'];
      // Accept Level="2" or any Details that doesn't have a Level attr
      if (level !== undefined && String(level) !== '2') continue;

      const sections = arr(details?.Section);
      for (const section of sections) {
        const rowData: Record<string, string> = {};
        const fields = arr(section?.Field);
        for (const field of fields) {
          const name: string = field?.['@_Name'] || '';
          // Value can be a child element or FormattedValue
          const value = field?.Value ?? field?.FormattedValue ?? '';
          if (name) rowData[name] = String(value);
        }

        if (rowData.uz1 || rowData.cnt1) {
          rows.push({
            rowNum: parseInt(rowData.cnt1) || 0,
            fio: (rowData.uz1 || '').trim(),
            shtCnt: parseInt(rowData.ShtCnt1) || 0,
            krCnt: parseInt(rowData.KrCnt1) || 0,
            pshtCnt: parseInt(rowData.PshtCnt1) || 0,
            razmCnt: parseInt(rowData.RazmCnt1) || 0,
            pkrCnt: parseInt(rowData.PkrCnt1) || 0,
            ktu: parseFloat(rowData.ktu1) || 0,
            hours: parseFloat(rowData.vv1) || 0,
            avgPerHour: parseFloat(rowData.xx1) || 0,
          });
        }
      }
    }
  }

  if (rows.length === 0) {
    throw new Error('Не найдены данные сотрудников в XML. Проверьте формат файла.');
  }

  return { period, groupName, rows };
};

/* ================================================================== */
/*  Parse Report 49 XML                                                */
/*  Structure: CrystalReport > Details(Level="1") > Section > Subreport
/*            > CrystalReport > Group(Level="1") > Details(Level="2") > Section > Field
/* ================================================================== */
const parseReport49 = (xmlText: string) => {
  const { XMLParser } = require('fast-xml-parser');
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    textNodeName: '__text',
    removeNSPrefix: true,
    isArray: (name: string, jpath: string) => {
      if (['Group', 'Details', 'Section', 'Field', 'Text', 'Subreport'].includes(name)) return true;
      return false;
    },
  });
  const parsed = parser.parse(xmlText);

  const report = parsed?.CrystalReport;
  if (!report) throw new Error('Неверный формат XML: не найден корневой элемент CrystalReport');

  let period = '';
  const avgRows: any[] = [];
  const dailyRows: any[] = [];

  // --- Extract period from ReportHeader ---
  const rhSections = arr(report?.ReportHeader?.Section);
  for (const section of rhSections) {
    for (const text of arr(section?.Text)) {
      const value: string = text?.TextValue || text?.__text || '';
      if (value.match(/\d{2}\.\d{2}\.\d{4}/)) {
        period = value;
      }
    }
  }

  // --- Recursively collect data rows from all nesting levels ---
  const collectRows = (obj: any) => {
    if (!obj || typeof obj !== 'object') return;

    // Extract data from Field elements in any Section
    const sections = arr(obj?.Section);
    for (const section of sections) {
      const rowData: Record<string, string> = {};
      const fields = arr(section?.Field);
      for (const field of fields) {
        const name: string = field?.['@_Name'] || '';
        const value = field?.Value ?? field?.FormattedValue ?? '';
        if (name) rowData[name] = String(value);
      }

      if (rowData.USERDEF41 || rowData.ORDERTYPE1) {
        // Use FormattedValue for date (dd.mm.yyyy) instead of Value (ISO)
        const dateField = fields.find((f: any) => f?.['@_Name'] === 'PLANNEDSHIPDATE1');
        const dateFormatted = dateField?.FormattedValue || '';

        const row = {
          controller: (rowData.USERDEF41 || '').trim(),
          orderType: (rowData.ORDERTYPE1 || '').trim(),
          allErp: parseInt(rowData.ALLERP1) || 0,
          avgProizvod: parseFloat(rowData.AVGPROIZVOD1) || 0,
          date: dateFormatted || (rowData.PLANNEDSHIPDATE1 || '').trim(),
        };
        if (row.date) {
          dailyRows.push(row);
        } else {
          avgRows.push(row);
        }
      }

      // IMPORTANT: recurse into Section's children (Subreport, etc.)
      collectRows(section);
    }

    // Recurse into all other nested objects (Groups, Details, Subreports, etc.)
    for (const key of Object.keys(obj)) {
      if (key.startsWith('@_')) continue;
      if (key === 'Section' || key === 'Field' || key === 'Text') continue;
      const child = obj[key];
      if (Array.isArray(child)) {
        for (const item of child) {
          if (item && typeof item === 'object') {
            collectRows(item);
          }
        }
      } else if (child && typeof child === 'object') {
        collectRows(child);
      }
    }
  };

  collectRows(report);

  if (avgRows.length === 0 && dailyRows.length === 0) {
    throw new Error('Не найдены данные контролёров в XML. Проверьте формат файла.');
  }

  return { period, avgRows, dailyRows };
};

/* ================================================================== */
/*  Extract period dates                                               */
/* ================================================================== */
const extractDates = (periodStr: string): { dateFrom: string; dateTo: string } => {
  // Try formats: dd/mm/yyyy — dd/mm/yyyy or dd.mm.yyyy — dd.mm.yyyy
  const match = periodStr.match(/(\d{2}[.\/]\d{2}[.\/]\d{4})\s*[—\-–\sпо]*\s*(\d{2}[.\/]\d{2}[.\/]\d{4})/);
  if (match) {
    return { dateFrom: match[1].replace(/\//g, '.'), dateTo: match[2].replace(/\//g, '.') };
  }
  const single = periodStr.match(/(\d{2}[.\/]\d{2}[.\/]\d{4})/);
  if (single) {
    return { dateFrom: single[1].replace(/\//g, '.'), dateTo: single[1].replace(/\//g, '.') };
  }
  return { dateFrom: '', dateTo: '' };
};

/* ================================================================== */
/*  File input wrapper — stable component (not recreated on parent render) */
/* ================================================================== */
const FileInputWrapper = memo(({ onFileSelect, accept }: { onFileSelect: (file: File | null) => void; accept: string }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onFileSelect(file);
  }, [onFileSelect]);

  return (
    <input
      ref={inputRef}
      type="file"
      accept={accept}
      onChange={handleChange}
      className="hidden"
    />
  );
});

/* ================================================================== */
/*  Component                                                          */
/* ================================================================== */
export default function StatImport() {
  const [selectedFile13, setSelectedFile13] = useState<File | null>(null);
  const [selectedFile49, setSelectedFile49] = useState<File | null>(null);
  const [loading13, setLoading13] = useState(false);
  const [loading49, setLoading49] = useState(false);
  const [message13, setMessage13] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [message49, setMessage49] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [uploads13, setUploads13] = useState<UploadRecord[]>([]);
  const [uploads49, setUploads49] = useState<UploadRecord[]>([]);
  const [expanded13, setExpanded13] = useState(true);
  const [expanded49, setExpanded49] = useState(true);
  const file13Ref = useRef<HTMLInputElement>(null);
  const file49Ref = useRef<HTMLInputElement>(null);

  const fetchUploads = useCallback(async () => {
    try {
      const [u13, u49] = await Promise.all([getStatUploads('13'), getStatUploads('49')]);
      setUploads13(u13);
      setUploads49(u49);
    } catch { /* silent */ }
  }, []);

  useEffect(() => { fetchUploads(); }, [fetchUploads]);
  useEffect(() => { if (message13) { const t = setTimeout(() => setMessage13(null), 5000); return () => clearTimeout(t); } }, [message13]);
  useEffect(() => { if (message49) { const t = setTimeout(() => setMessage49(null), 5000); return () => clearTimeout(t); } }, [message49]);

  const handleUpload13 = async () => {
    if (!selectedFile13) { setMessage13({ type: 'error', text: 'Выберите файл' }); return; }
    setLoading13(true); setMessage13(null);
    try {
      const xmlText = await selectedFile13.text();
      const { period, groupName, rows } = parseReport13(xmlText);
      const { dateFrom, dateTo } = extractDates(period);
      await uploadStats({ type: '13', dateFrom, dateTo, groupName, rows });
      setMessage13({ type: 'success', text: `Загружено: ${rows.length} записей. Период: ${dateFrom} — ${dateTo}` });
      setSelectedFile13(null);
      // Clear file input
      if (file13Ref.current) file13Ref.current.value = '';
      fetchUploads();
    } catch (err: any) {
      setMessage13({ type: 'error', text: `Ошибка: ${err.message}` });
    } finally { setLoading13(false); }
  };

  const handleUpload49 = async () => {
    if (!selectedFile49) { setMessage49({ type: 'error', text: 'Выберите файл' }); return; }
    setLoading49(true); setMessage49(null);
    try {
      const xmlText = await selectedFile49.text();
      const { period, avgRows, dailyRows } = parseReport49(xmlText);
      const { dateFrom, dateTo } = extractDates(period);
      await uploadStats({ type: '49', dateFrom, dateTo, avgRows, dailyRows });
      setMessage49({ type: 'success', text: `Загружено: ${avgRows.length} средних, ${dailyRows.length} дневных. Период: ${dateFrom} — ${dateTo}` });
      setSelectedFile49(null);
      if (file49Ref.current) file49Ref.current.value = '';
      fetchUploads();
    } catch (err: any) {
      setMessage49({ type: 'error', text: `Ошибка: ${err.message}` });
    } finally { setLoading49(false); }
  };

  const fmtDate = (s: string) => { if (!s) return '—'; const d = new Date(s); return isNaN(d.getTime()) ? s : d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); };

  const renderHistory = (uploads: UploadRecord[], type: '13' | '49') => {
    if (!uploads.length) return <p className="text-sm py-3" style={{ color: COLORS.text }}>Загрузок пока нет</p>;
    return (
      <div className="mt-3 overflow-x-auto max-h-48 overflow-y-auto rounded-lg border" style={{ borderColor: '#f0f0f0' }}>
        <table className="w-full text-sm">
          <thead className="sticky top-0" style={{ backgroundColor: '#f8f9fa' }}>
            <tr>
              <th className="px-3 py-2 text-left font-medium" style={{ color: COLORS.heading }}>ID</th>
              <th className="px-3 py-2 text-left font-medium" style={{ color: COLORS.heading }}>Период</th>
              {type === '13' && <th className="px-3 py-2 text-left font-medium" style={{ color: COLORS.heading }}>Группа</th>}
              <th className="px-3 py-2 text-left font-medium" style={{ color: COLORS.heading }}>Загружено</th>
            </tr>
          </thead>
          <tbody>
            {uploads.map((u) => (
              <tr key={u.id} className="border-t" style={{ borderColor: '#f0f0f0' }}>
                <td className="px-3 py-2" style={{ color: COLORS.heading }}>{u.id}</td>
                <td className="px-3 py-2" style={{ color: COLORS.heading }}>{u.dateFrom === u.dateTo ? u.dateFrom : `${u.dateFrom} — ${u.dateTo}`}</td>
                {type === '13' && <td className="px-3 py-2" style={{ color: COLORS.text }}>{u.groupName || '—'}</td>}
                <td className="px-3 py-2" style={{ color: COLORS.text }}>{fmtDate(u.uploadedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Импорт статистики WMS</h2>
      <div className="space-y-4 max-w-2xl">
        {/* Report 13 */}
        <div className="bg-white rounded-xl shadow overflow-hidden">
          <button onClick={() => setExpanded13(!expanded13)} className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: COLORS.primary }}>13</div>
              <div className="text-left">
                <h3 className="font-semibold" style={{ color: COLORS.heading }}>Отчёт кладовщиков (13)</h3>
                <p className="text-xs" style={{ color: COLORS.text }}>CrystalReport XML — КТУ по размещению/набору/перемещениям</p>
              </div>
            </div>
            {expanded13 ? <ChevronUp className="w-5 h-5" style={{ color: COLORS.text }} /> : <ChevronDown className="w-5 h-5" style={{ color: COLORS.text }} />}
          </button>
          {expanded13 && (
            <div className="px-6 pb-5 border-t" style={{ borderColor: '#f0f0f0' }}>
              <div className="mt-4">
                <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>XML файл отчёта 13</label>
                <div className="flex items-center gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: '#dee2e6' }}>
                    <Upload className="w-5 h-5" style={{ color: COLORS.text }} />
                    <span className="text-sm" style={{ color: COLORS.text }}>{selectedFile13 ? selectedFile13.name : 'Выберите файл .xml'}</span>
                    <input
                      ref={file13Ref}
                      type="file"
                      accept=".xml"
                      onChange={(e) => setSelectedFile13(e.target.files?.[0] || null)}
                    />
                  </label>
                  <button onClick={handleUpload13} disabled={loading13} className="px-5 py-3 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center gap-2 whitespace-nowrap" style={{ backgroundColor: COLORS.primary }}>
                    {loading13 ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Upload className="w-4 h-4" />}
                    Загрузить
                  </button>
                </div>
              </div>
              {message13 && (
                <div className={`mt-3 flex items-center gap-2 px-4 py-3 rounded-lg text-sm ${message13.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                  {message13.type === 'success' ? <CheckCircle className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
                  {message13.text}
                </div>
              )}
              <div className="mt-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4" style={{ color: COLORS.text }} />
                  <span className="text-sm font-medium" style={{ color: COLORS.heading }}>История загрузок (13)</span>
                </div>
                {renderHistory(uploads13, '13')}
              </div>
            </div>
          )}
        </div>

        {/* Report 49 */}
        <div className="bg-white rounded-xl shadow overflow-hidden">
          <button onClick={() => setExpanded49(!expanded49)} className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: COLORS.primary }}>49</div>
              <div className="text-left">
                <h3 className="font-semibold" style={{ color: COLORS.heading }}>Отчёт старших (49)</h3>
                <p className="text-xs" style={{ color: COLORS.text }}>CrystalReport XML — производительность контролёров</p>
              </div>
            </div>
            {expanded49 ? <ChevronUp className="w-5 h-5" style={{ color: COLORS.text }} /> : <ChevronDown className="w-5 h-5" style={{ color: COLORS.text }} />}
          </button>
          {expanded49 && (
            <div className="px-6 pb-5 border-t" style={{ borderColor: '#f0f0f0' }}>
              <div className="mt-4">
                <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>XML файл отчёта 49</label>
                <div className="flex items-center gap-3">
                  <label className="flex-1 flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: '#dee2e6' }}>
                    <Upload className="w-5 h-5" style={{ color: COLORS.text }} />
                    <span className="text-sm" style={{ color: COLORS.text }}>{selectedFile49 ? selectedFile49.name : 'Выберите файл .xml'}</span>
                    <input
                      ref={file49Ref}
                      type="file"
                      accept=".xml"
                      onChange={(e) => setSelectedFile49(e.target.files?.[0] || null)}
                    />
                  </label>
                  <button onClick={handleUpload49} disabled={loading49} className="px-5 py-3 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center gap-2 whitespace-nowrap" style={{ backgroundColor: COLORS.primary }}>
                    {loading49 ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Upload className="w-4 h-4" />}
                    Загрузить
                  </button>
                </div>
              </div>
              {message49 && (
                <div className={`mt-3 flex items-center gap-2 px-4 py-3 rounded-lg text-sm ${message49.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                  {message49.type === 'success' ? <CheckCircle className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
                  {message49.text}
                </div>
              )}
              <div className="mt-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4" style={{ color: COLORS.text }} />
                  <span className="text-sm font-medium" style={{ color: COLORS.heading }}>История загрузок (49)</span>
                </div>
                {renderHistory(uploads49, '49')}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Member, Group, TSD, KKM, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface MemberFormProps {
  memberId: number | null;
  members: Member[];
  groups: Group[];
  tsds: TSD[];
  kkms: KKM[];
  onSave: (member: Member & { isNew?: boolean }) => void;
  onDelete: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

export default function MemberForm({ memberId, members, groups, tsds, kkms, onSave, onDelete, onNavigate }: MemberFormProps) {
  const isNew = memberId === null;
  const existing = isNew ? null : members.find(m => m.id === memberId);

  const [form, setForm] = useState<Member>({
    id: existing?.id || 0,
    fio: existing?.fio || '',
    login: existing?.login || '',
    password: existing?.password || '',
    email: existing?.email || '',
    emailPassword: existing?.emailPassword || '',
    groupId: existing?.groupId || 1,
    tsdId: existing?.tsdId ?? null,
    kkmId: existing?.kkmId ?? null,
    tg: existing?.tg || '',
  });

  const updateField = (field: keyof Member, value: string | number | boolean | null) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    if (!form.fio || !form.login) return;
    onSave({ ...form, isNew });
    onNavigate('members');
  };

  const handleDelete = () => {
    if (memberId && confirm('Удалить сотрудника?')) {
      onDelete(memberId);
      onNavigate('members');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Сотрудники', page: 'members', onNavigate },
        { label: isNew ? 'Добавить' : 'Редактировать', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isNew ? 'Добавить сотрудника' : `Редактировать: ${existing?.fio}`}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ФИО *</label>
            <input type="text" value={form.fio} onChange={e => updateField('fio', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин *</label>
            <input type="text" value={form.login} onChange={e => updateField('login', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль *</label>
            <input type="text" value={form.password} onChange={e => updateField('password', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Почта *</label>
            <input type="text" value={form.email} onChange={e => updateField('email', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль от почты *</label>
            <input type="text" value={form.emailPassword} onChange={e => updateField('emailPassword', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Группа / Должность</label>
            <select value={form.groupId} onChange={e => updateField('groupId', Number(e.target.value))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }}>
              {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>ТСД</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
              <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.tsdId === null ? COLORS.primary : '#dee2e6' }}>
                <input type="radio" name="tsd" checked={form.tsdId === null} onChange={() => updateField('tsdId', null)} className="accent-[#3a57e8]" />
                <span className="text-sm" style={{ color: COLORS.text }}>Нет</span>
              </label>
              {tsds.map(tsd => (
                <label key={tsd.id} className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.tsdId === tsd.id ? COLORS.primary : '#dee2e6' }}>
                  <input type="radio" name="tsd" checked={form.tsdId === tsd.id} onChange={() => updateField('tsdId', tsd.id)} className="accent-[#3a57e8]" />
                  <span className="text-sm" style={{ color: COLORS.heading }}>№{tsd.number}</span>
                  <span className="text-xs" style={{ color: COLORS.text }}>{tsd.model}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>ККМ</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.kkmId === null ? COLORS.primary : '#dee2e6' }}>
                <input type="radio" name="kkm" checked={form.kkmId === null} onChange={() => updateField('kkmId', null)} className="accent-[#3a57e8]" />
                <span className="text-sm" style={{ color: COLORS.text }}>Нет</span>
              </label>
              {kkms.map(kkm => (
                <label key={kkm.id} className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.kkmId === kkm.id ? COLORS.primary : '#dee2e6' }}>
                  <input type="radio" name="kkm" checked={form.kkmId === kkm.id} onChange={() => updateField('kkmId', kkm.id)} className="accent-[#3a57e8]" />
                  <span className="text-sm" style={{ color: COLORS.heading }}>№{kkm.number}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            {!isNew && (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
                <Trash2 className="w-4 h-4" /> Удалить
              </button>
            )}
            <button onClick={handleSave} className="ml-auto flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { COLORS } from '@/lib/colors';

export default function StatStarshie() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Статистика — Старшие</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>ОПТ</th>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>КОР</th>
              </tr>
            </thead>
            <tbody>
              {['Петрова М.С.', 'Козлова А.В.', 'Волкова Е.Д.'].map((name, i) => (
                <tr key={i}>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.heading }}>{name}</td>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.text }}>{['Соколова О.И.', 'Михайлова Т.А.', ''][i]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

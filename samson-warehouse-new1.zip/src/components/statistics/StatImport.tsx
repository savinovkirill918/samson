'use client';

import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { COLORS } from '@/lib/colors';

export default function StatImport() {
  const [file13, setFile13] = useState<string>('');
  const [file49, setFile49] = useState<string>('');

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Импорт WMS</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-6">
        <div>
          <h3 className="font-semibold mb-2" style={{ color: COLORS.heading }}>13 отчёт (XML)</h3>
          <input type="file" accept=".xml" onChange={e => setFile13(e.target.files?.[0]?.name || '')} className="w-full text-sm" style={{ color: COLORS.text }} />
          {file13 && <p className="text-sm mt-1" style={{ color: COLORS.primary }}>Выбран: {file13}</p>}
          <button className="mt-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Upload className="w-4 h-4 inline mr-1" /> Загрузить 13 отчёт
          </button>
        </div>

        <div className="border-t pt-6" style={{ borderColor: '#e9ecef' }}>
          <h3 className="font-semibold mb-2" style={{ color: COLORS.heading }}>49 отчёт (XML)</h3>
          <input type="file" accept=".xml" onChange={e => setFile49(e.target.files?.[0]?.name || '')} className="w-full text-sm" style={{ color: COLORS.text }} />
          {file49 && <p className="text-sm mt-1" style={{ color: COLORS.primary }}>Выбран: {file49}</p>}
          <button className="mt-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Upload className="w-4 h-4 inline mr-1" /> Загрузить 49 отчёт
          </button>
        </div>
      </div>
    </div>
  );
}

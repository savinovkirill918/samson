'use client';

import React from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Repair, TSD, Member, PageId } from '@/lib/types';
import { formatDate, repairStatusText } from '@/lib/helpers';

interface RepairsListProps {
  repairs: Repair[];
  tsds: TSD[];
  members: Member[];
  onNavigate: (page: PageId) => void;
}

export default function RepairsList({ repairs, tsds, members, onNavigate }: RepairsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Ремонты ТСД</h2>
        <button onClick={() => onNavigate('tsd-repair-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {repairs.map(repair => {
          const tsd = tsds.find(t => t.id === repair.tsdId);
          const member = members.find(m => m.tsdId === repair.tsdId);
          const statusText = repairStatusText(repair.status);
          return (
            <div key={repair.id} className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold" style={{ color: COLORS.heading }}>
                  ТСД №{tsd?.number || '?'} {tsd ? `(${tsd.model})` : ''}
                </h4>
                <span className={`text-xs px-2 py-0.5 rounded font-medium ${statusText === 'На ремонте' ? 'bg-yellow-200 text-yellow-800' : statusText === 'Возвращён' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                  {statusText}
                </span>
              </div>
              {member && <p className="text-sm" style={{ color: COLORS.text }}>Сотрудник: {member.fio}</p>}
              <p className="text-sm" style={{ color: COLORS.text }}>Описание: {repair.description}</p>
              <div className="flex gap-4 text-xs mt-2" style={{ color: COLORS.text }}>
                <span>Сломан: {formatDate(repair.brokenDate)}</span>
                <span>Отправлен: {formatDate(repair.sentDate)}</span>
                <span>Возвращён: {formatDate(repair.returnedDate)}</span>
              </div>
              {!repair.isGuilty && <span className="text-xs mt-1 inline-block px-2 py-0.5 bg-green-100 text-green-700 rounded">Гарантия</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

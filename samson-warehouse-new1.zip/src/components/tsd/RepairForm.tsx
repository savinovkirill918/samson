'use client';

import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface RepairFormProps {
  tsds: TSD[];
  onSave: (repair: {
    tsdId: number;
    brokenDate: string;
    sentDate?: string;
    returnedDate?: string;
    status?: number;
    description: string;
    isGuilty?: boolean;
    cost?: number;
  }) => void;
  onNavigate: (page: PageId) => void;
}

export default function RepairForm({ tsds, onSave, onNavigate }: RepairFormProps) {
  const [form, setForm] = useState({ tsdId: '', brokenDate: '', description: '', warranty: false });

  const handleSave = () => {
    const tsdId = parseInt(form.tsdId);
    if (!tsdId || !form.brokenDate) return;
    onSave({
      tsdId,
      brokenDate: form.brokenDate,
      sentDate: form.brokenDate,
      status: 1, // На ремонте
      description: form.description,
      isGuilty: !form.warranty,
    });
    onNavigate('tsd-repairs');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ремонт</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ТСД *</label>
          <select value={form.tsdId} onChange={e => setForm(p => ({ ...p, tsdId: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            <option value="">Выберите ТСД</option>
            {tsds.map(t => <option key={t.id} value={t.id}>№{t.number} ({t.model})</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата поломки *</label>
          <input type="date" value={form.brokenDate} onChange={e => setForm(p => ({ ...p, brokenDate: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание поломки</label>
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} rows={3} />
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.warranty} onChange={e => setForm(p => ({ ...p, warranty: e.target.checked }))} className="w-4 h-4 accent-[#3a57e8]" />
          <span className="text-sm" style={{ color: COLORS.heading }}>Гарантия</span>
        </label>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
}

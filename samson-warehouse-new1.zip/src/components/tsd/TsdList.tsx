'use client';

import React from 'react';
import { Plus, Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, Member, PageId } from '@/lib/types';

interface TsdListProps {
  tsds: TSD[];
  members: Member[];
  onNavigate: (page: PageId) => void;
}

export default function TsdList({ tsds, members, onNavigate }: TsdListProps) {
  const openStickerPdf = (tsd: TSD) => {
    const assignedMembers = members.filter(m => m.tsdId === tsd.id);
    const memberFio = assignedMembers.length > 0 ? assignedMembers[0].fio : '';
    const params = new URLSearchParams({
      number: String(tsd.number),
      fio: memberFio,
      sn: tsd.sn,
      inv: tsd.inv,
    });
    window.open(`/api/sticker?${params.toString()}`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>ТСД</h2>
        <button onClick={() => onNavigate('tsd-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {tsds.map(tsd => {
          const assignedMembers = members.filter(m => m.tsdId === tsd.id);
          return (
            <div key={tsd.id} className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold" style={{ color: COLORS.heading }}>ТСД №{tsd.number}</h4>
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2 py-0.5 rounded" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>{tsd.model}</span>
                  <button
                    title="Наклейка на ТСД"
                    onClick={() => openStickerPdf(tsd)}
                    className="p-1 rounded text-white transition hover:opacity-80"
                    style={{ backgroundColor: '#198754' }}
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-sm" style={{ color: COLORS.text }}>С/N: {tsd.sn}</p>
              <p className="text-sm" style={{ color: COLORS.text }}>Инв. №: {tsd.inv}</p>
              <p className="text-sm mt-1" style={{ color: assignedMembers.length > 0 ? COLORS.heading : '#dc3545' }}>
                {assignedMembers.length > 0 ? assignedMembers.map(m => m.login).join(', ') : 'Отсутствует'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

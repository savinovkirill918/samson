import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// POST /api/stats/upload — загрузка XML данных статистики
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, dateFrom, dateTo, groupName, rows } = body

    if (type === '13') {
      // Создать загрузку отчёта 13
      const upload = await prisma.stat13Upload.create({
        data: {
          dateFrom,
          dateTo,
          groupName: groupName ?? '',
          uploadedAt: new Date().toISOString(),
          rows: {
            create: (rows || []).map((r: any, idx: number) => ({
              rowNum: r.rowNum ?? idx + 1,
              fio: r.fio ?? '',
              shtCnt: r.shtCnt ?? 0,
              krCnt: r.krCnt ?? 0,
              pshtCnt: r.pshtCnt ?? 0,
              razmCnt: r.razmCnt ?? 0,
              pkrCnt: r.pkrCnt ?? 0,
              ktu: r.ktu ?? 0,
              hours: r.hours ?? 0,
              avgPerHour: r.avgPerHour ?? 0,
            }))
          }
        },
        include: { rows: true }
      })
      return NextResponse.json(upload, { status: 201 })
    }

    if (type === '49') {
      // Создать загрузку отчёта 49
      const upload = await prisma.stat49Upload.create({
        data: {
          dateFrom,
          dateTo,
          uploadedAt: new Date().toISOString(),
          avgRows: {
            create: (body.avgRows || []).map((r: any) => ({
              controller: r.controller ?? '',
              orderType: r.orderType ?? '',
              allErp: r.allErp ?? 0,
              avgProizvod: r.avgProizvod ?? 0,
            }))
          },
          dailyRows: {
            create: (body.dailyRows || []).map((r: any) => ({
              date: r.date ?? '',
              controller: r.controller ?? '',
              orderType: r.orderType ?? '',
              allErp: r.allErp ?? 0,
              avgProizvod: r.avgProizvod ?? 0,
            }))
          }
        },
        include: { avgRows: true, dailyRows: true }
      })
      return NextResponse.json(upload, { status: 201 })
    }

    return NextResponse.json({ error: 'Неизвестный тип отчёта' }, { status: 400 })
  } catch (error) {
    console.error('Error uploading stats:', error)
    return NextResponse.json({ error: 'Ошибка загрузки статистики' }, { status: 500 })
  }
}

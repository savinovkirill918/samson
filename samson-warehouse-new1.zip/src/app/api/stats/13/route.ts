import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/stats/13?uploadId=N — данные отчёта 13
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const uploadId = searchParams.get('uploadId')

    if (uploadId) {
      // Получить конкретную загрузку с рядами
      const upload = await prisma.stat13Upload.findUnique({
        where: { id: Number(uploadId) },
        include: { rows: { orderBy: { rowNum: 'asc' } } }
      })
      if (!upload) {
        return NextResponse.json({ error: 'Загрузка не найдена' }, { status: 404 })
      }
      return NextResponse.json(upload)
    }

    // Получить последнюю загрузку
    const latestUpload = await prisma.stat13Upload.findFirst({
      orderBy: { id: 'desc' },
      include: { rows: { orderBy: { rowNum: 'asc' } } }
    })

    return NextResponse.json(latestUpload || { rows: [] })
  } catch (error) {
    console.error('Error fetching stat13:', error)
    return NextResponse.json({ error: 'Ошибка получения отчёта 13' }, { status: 500 })
  }
}

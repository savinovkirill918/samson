import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/stats/49?uploadId=N — данные отчёта 49
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const uploadId = searchParams.get('uploadId')

    if (uploadId) {
      // Получить конкретную загрузку с рядами
      const upload = await prisma.stat49Upload.findUnique({
        where: { id: Number(uploadId) },
        include: {
          avgRows: { orderBy: [{ controller: 'asc' }, { orderType: 'asc' }] },
          dailyRows: { orderBy: [{ date: 'asc' }, { controller: 'asc' }] },
        }
      })
      if (!upload) {
        return NextResponse.json({ error: 'Загрузка не найдена' }, { status: 404 })
      }
      return NextResponse.json(upload)
    }

    // Получить последнюю загрузку
    const latestUpload = await prisma.stat49Upload.findFirst({
      orderBy: { id: 'desc' },
      include: {
        avgRows: { orderBy: [{ controller: 'asc' }, { orderType: 'asc' }] },
        dailyRows: { orderBy: [{ date: 'asc' }, { controller: 'asc' }] },
      }
    })

    return NextResponse.json(latestUpload || { avgRows: [], dailyRows: [] })
  } catch (error) {
    console.error('Error fetching stat49:', error)
    return NextResponse.json({ error: 'Ошибка получения отчёта 49' }, { status: 500 })
  }
}

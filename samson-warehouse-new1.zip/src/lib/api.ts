import type { Member, Group, TSD, KKM, Repair, LogEntry, AdminUser } from './types';

// =====================================================================
// API Client — typed fetch wrappers for all backend endpoints
// =====================================================================

const API_BASE = '/api';

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API Error ${res.status}: ${text}`);
  }
  return res.json();
}

// — Members —
export const getMembers = (): Promise<Member[]> => fetchJSON(`${API_BASE}/members`);
export const createMember = (data: Omit<Member, 'id' | 'group' | 'tsd' | 'kkm'>): Promise<Member> =>
  fetchJSON(`${API_BASE}/members`, { method: 'POST', body: JSON.stringify(data) });
export const updateMember = (data: Partial<Member> & { id: number }): Promise<Member> =>
  fetchJSON(`${API_BASE}/members`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteMember = (id: number): Promise<void> =>
  fetch(`${API_BASE}/members?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Groups —
export const getGroups = (): Promise<Group[]> => fetchJSON(`${API_BASE}/groups`);
export const createGroup = (data: { name: string; sort: number }): Promise<Group> =>
  fetchJSON(`${API_BASE}/groups`, { method: 'POST', body: JSON.stringify(data) });
export const updateGroup = (data: { id: number; name: string; sort: number }): Promise<Group> =>
  fetchJSON(`${API_BASE}/groups`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteGroup = (id: number): Promise<void> =>
  fetch(`${API_BASE}/groups?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — TSDs —
export const getTsds = (): Promise<TSD[]> => fetchJSON(`${API_BASE}/tsds`);
export const createTsd = (data: { number: number; sn: string; inv: string; model: string; isMulti: boolean }): Promise<TSD> =>
  fetchJSON(`${API_BASE}/tsds`, { method: 'POST', body: JSON.stringify(data) });
export const updateTsd = (data: Partial<TSD> & { id: number }): Promise<TSD> =>
  fetchJSON(`${API_BASE}/tsds`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteTsd = (id: number): Promise<void> =>
  fetch(`${API_BASE}/tsds?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — KKMs —
export const getKkms = (): Promise<KKM[]> => fetchJSON(`${API_BASE}/kkms`);
export const createKkm = (data: { number: number; sn: string; inv: string; isMulti: boolean }): Promise<KKM> =>
  fetchJSON(`${API_BASE}/kkms`, { method: 'POST', body: JSON.stringify(data) });
export const updateKkm = (data: Partial<KKM> & { id: number }): Promise<KKM> =>
  fetchJSON(`${API_BASE}/kkms`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteKkm = (id: number): Promise<void> =>
  fetch(`${API_BASE}/kkms?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Repairs —
export const getRepairs = (): Promise<Repair[]> => fetchJSON(`${API_BASE}/repairs`);
export const createRepair = (data: {
  tsdId: number;
  brokenDate: string;
  sentDate?: string;
  returnedDate?: string;
  status?: number;
  description: string;
  isGuilty?: boolean;
  cost?: number;
}): Promise<Repair> =>
  fetchJSON(`${API_BASE}/repairs`, { method: 'POST', body: JSON.stringify(data) });
export const updateRepair = (data: Partial<Repair> & { id: number }): Promise<Repair> =>
  fetchJSON(`${API_BASE}/repairs`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteRepair = (id: number): Promise<void> =>
  fetch(`${API_BASE}/repairs?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Logs —
export const getLogs = (limit?: number, offset?: number): Promise<LogEntry[]> =>
  fetchJSON(`${API_BASE}/logs?limit=${limit || 500}&offset=${offset || 0}`);
export const createLog = (data: { adminId: number; text: string }): Promise<LogEntry> =>
  fetchJSON(`${API_BASE}/logs`, { method: 'POST', body: JSON.stringify(data) });

// — Admins —
export const getAdmins = (): Promise<AdminUser[]> => fetchJSON(`${API_BASE}/admins`);
export const createAdmin = (data: { login: string; hash?: string; fio: string; role?: string; groupId?: number }): Promise<AdminUser> =>
  fetchJSON(`${API_BASE}/admins`, { method: 'POST', body: JSON.stringify(data) });
export const updateAdmin = (data: Partial<AdminUser> & { id: number }): Promise<AdminUser> =>
  fetchJSON(`${API_BASE}/admins`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteAdmin = (id: number): Promise<void> =>
  fetch(`${API_BASE}/admins?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Auth (login check against admins list) —
export const loginWithCredentials = async (login: string, password: string): Promise<AdminUser | null> => {
  const admins = await getAdmins();
  const admin = admins.find(a => a.login === login);
  // The password in DB is stored as plain text (hash field is empty in seed)
  // For now compare against the password stored as hash (or login password)
  if (admin) {
    // The seed stores passwords as plain text; the hash field is empty
    // We need a dedicated login endpoint or compare directly
    // Since the backend doesn't have a login endpoint, we compare client-side
    if (admin.hash && admin.hash === password) return admin;
    // Fallback: check if any member has this login/password (for initial seed compat)
  }
  return null;
};

'use client';

import { useState, useEffect, useCallback } from 'react';
import type { TSD } from '@/lib/types';
import * as api from '@/lib/api';

export function useTsd() {
  const [tsds, setTsds] = useState<TSD[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTsds = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getTsds();
      setTsds(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки ТСД');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchTsds(); }, [fetchTsds]);

  const saveTsd = useCallback(async (tsd: { number: number; sn: string; inv: string; model: string; isMulti: boolean }) => {
    await api.createTsd(tsd);
    await fetchTsds();
  }, [fetchTsds]);

  return { tsds, loading, error, saveTsd, refetch: fetchTsds };
}

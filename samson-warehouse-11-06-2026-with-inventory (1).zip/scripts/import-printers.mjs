import XLSX from 'xlsx';
import { PrismaClient } from '../src/generated/prisma/client.js';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3';
const adapter = new PrismaBetterSqlite3({ url: 'file:' + path.join(__dirname, '..', 'db', 'custom.db') });
const prisma = new PrismaClient({ adapter });
const XLSX_PATH = path.join(__dirname, '..', 'Принтеры.xlsx');

// =====================================================================
// Парсинг данных из Excel
// =====================================================================

function parseExcel() {
  const workbook = XLSX.readFile(XLSX_PATH);
  
  // --- Лист «Расход» ---
  const расходSheet = workbook.Sheets['Расход'];
  const расходData = XLSX.utils.sheet_to_json(расходSheet, { header: 1, defval: null });

  // Месяцы потребления: пары (счётчик, расход) начиная со столбца 11
  const monthPairs = [
    { month: '2025-08', counterCol: 11, consumptionCol: 12 },
    { month: '2025-09', counterCol: 13, consumptionCol: 14 },
    { month: '2025-10', counterCol: 15, consumptionCol: 16 },
    { month: '2025-11', counterCol: 17, consumptionCol: 18 },
    { month: '2025-12', counterCol: 19, consumptionCol: 20 },
    { month: '2026-01', counterCol: 21, consumptionCol: 22 },
    { month: '2026-02', counterCol: 23, consumptionCol: 24 },
    { month: '2026-03', counterCol: 25, consumptionCol: 26 },
    { month: '2026-04', counterCol: 27, consumptionCol: 28 },
  ];

  const printers = [];
  const consumptions = [];

  for (let rowIdx = 1; rowIdx < расходData.length; rowIdx++) {
    const row = расходData[rowIdx];
    if (!row || !row[0]) continue;

    const modelRaw = String(row[0] || '').trim();
    const location = String(row[1] || '').trim();
    const sn = String(row[2] || '').trim();
    const inv = String(row[3] || '').trim();
    const purchaseDate = String(row[4] || '').trim();
    let ipAddress = String(row[5] || '').trim();
    const cartridgeName = String(row[6] || '').trim();
    const expectedYield = row[7] ? Number(row[7]) : 0;

    // Исправляем опечатку в IP
    if (ipAddress.includes('/')) {
      ipAddress = ipAddress.replace(/\//g, '.');
    }

    // Определяем тип и МФУ
    let type = 'laser';
    let isMulti = false;
    if (modelRaw.toLowerCase().includes('мфу') || modelRaw.toLowerCase().includes('копир')) {
      isMulti = true;
    }

    // Определяем статус — списан?
    let status = 0;
    const rowStr = JSON.stringify(row);
    if (rowStr.includes('списан') || rowStr.includes('Списан')) {
      status = 2;
    }

    // Извлекаем чистое название модели (без текста в скобках)
    let model = modelRaw;
    const parenMatch = modelRaw.match(/^(.+?)\s*[\((]/);
    if (parenMatch) {
      model = parenMatch[1].trim();
    }
    model = model.replace(/\s+/g, ' ').trim();

    printers.push({
      model,
      sn,
      inv,
      location,
      ipAddress,
      purchaseDate,
      type,
      status,
      isMulti,
      cartridgeName,
      expectedYield,
      rowIdx,
    });

    // Парсим расход по месяцам
    for (const mp of monthPairs) {
      const consumptionRaw = row[mp.consumptionCol];
      if (consumptionRaw == null) continue;

      const consumptionStr = String(consumptionRaw).trim();
      if (!consumptionStr || consumptionStr === 'списан' || consumptionStr === 'Списан') continue;

      let pages = 0;
      if (consumptionStr.includes('/')) {
        const parts = consumptionStr.split('/');
        const numStr = parts[0].replace(/\s/g, '').replace(',', '.');
        pages = parseInt(numStr, 10);
      } else {
        const numVal = parseInt(consumptionStr, 10);
        if (!isNaN(numVal) && numVal > 0 && numVal < 100000) {
          pages = numVal;
        } else {
          continue;
        }
      }

      if (!isNaN(pages) && pages > 0) {
        consumptions.push({
          printerRowIdx: rowIdx,
          month: mp.month,
          pages,
        });
      }
    }
  }

  // --- Лист «Картриджи» ---
  const картриджиSheet = workbook.Sheets['Картриджи'];
  const картриджиData = XLSX.utils.sheet_to_json(картриджиSheet, { header: 1, defval: null });

  const cartridgeModels = [];
  for (let rowIdx = 1; rowIdx < картриджиData.length; rowIdx++) {
    const row = картриджиData[rowIdx];
    if (!row || !row[1]) continue;

    const printerModel = String(row[0] || '').trim();
    const cartridgeName = String(row[1] || '').trim();
    const usedCount = Number(row[2]) || 0;
    const newCount = Number(row[3]) || 0;

    // Ищем expectedYield из листа «Расход»
    let expectedYield = 0;
    const matchPrinter = printers.find(p => {
      if (!p.cartridgeName) return false;
      // CF226 → CF226X (расход короткий, картриджи длинный)
      return cartridgeName.toUpperCase().startsWith(p.cartridgeName.toUpperCase());
    });
    if (matchPrinter) {
      expectedYield = matchPrinter.expectedYield;
    }

    cartridgeModels.push({
      name: cartridgeName,
      printerModel,
      expectedYield,
      maxRefills: 3,
      usedCount,
      newCount,
    });
  }

  return { printers, consumptions, cartridgeModels };
}

// =====================================================================
// Импорт в БД
// =====================================================================

async function importData() {
  console.log('Чтение Excel файла...');
  const { printers, consumptions, cartridgeModels } = parseExcel();
  
  console.log(`Найдено: ${printers.length} принтеров, ${consumptions.length} записей расхода, ${cartridgeModels.length} моделей картриджей`);

  // Очистка старых данных
  console.log('Очистка старых данных...');
  await prisma.cartridgeHistory.deleteMany();
  await prisma.cartridge.deleteMany();
  await prisma.cartridgeModel.deleteMany();
  await prisma.printerConsumption.deleteMany();
  await prisma.printerRepair.deleteMany();
  await prisma.printer.deleteMany();

  // Импорт принтеров
  console.log('Импорт принтеров...');
  const printerMap = new Map();
  
  for (let i = 0; i < printers.length; i++) {
    const p = printers[i];
    const printer = await prisma.printer.create({
      data: {
        number: i + 1,
        sn: p.sn || '',
        inv: p.inv || '',
        model: p.model,
        type: p.type,
        location: p.location,
        ipAddress: p.ipAddress,
        purchaseDate: p.purchaseDate,
        status: p.status,
        isMulti: p.isMulti,
      }
    });
    printerMap.set(p.rowIdx, printer.id);
    console.log(`  №${printer.number} ${printer.model} [${p.location}] (id=${printer.id}, status=${p.status})`);
  }

  // Импорт моделей картриджей
  console.log('Импорт моделей картриджей...');
  for (const cm of cartridgeModels) {
    const model = await prisma.cartridgeModel.create({
      data: {
        name: cm.name,
        printerModel: cm.printerModel,
        expectedYield: cm.expectedYield,
        maxRefills: cm.maxRefills,
      }
    });
    console.log(`  ${model.name} → id=${model.id} (бу=${cm.usedCount}, нов=${cm.newCount}, ресурс=${cm.expectedYield})`);

    for (let j = 0; j < cm.usedCount; j++) {
      await prisma.cartridge.create({
        data: {
          cartridgeModelId: model.id,
          status: 1,
          refillsCount: 1,
          notes: 'б/у',
        }
      });
    }
    for (let j = 0; j < cm.newCount; j++) {
      await prisma.cartridge.create({
        data: {
          cartridgeModelId: model.id,
          status: 0,
          refillsCount: 0,
          notes: 'новый',
        }
      });
    }
  }

  // Импорт расхода
  console.log('Импорт расхода...');
  let consumptionCount = 0;
  for (const c of consumptions) {
    const printerId = printerMap.get(c.printerRowIdx);
    if (!printerId) continue;

    try {
      await prisma.printerConsumption.create({
        data: {
          printerId,
          month: c.month,
          pages: c.pages,
          copies: 0,
          notes: '',
        }
      });
      consumptionCount++;
    } catch (e) {
      if (e.code === 'P2002') {
        console.log(`  Дубликат: printer=${printerId} month=${c.month}`);
      } else {
        throw e;
      }
    }
  }
  console.log(`  Импортировано ${consumptionCount} записей расхода`);

  const totalPrinters = await prisma.printer.count();
  const totalCartridgeModels = await prisma.cartridgeModel.count();
  const totalCartridges = await prisma.cartridge.count();
  const totalConsumption = await prisma.printerConsumption.count();

  console.log('\n=== ИТОГИ ИМПОРТА ===');
  console.log(`Принтеров: ${totalPrinters}`);
  console.log(`Моделей картриджей: ${totalCartridgeModels}`);
  console.log(`Картриджей (экземпляров): ${totalCartridges}`);
  console.log(`Записей расхода: ${totalConsumption}`);
}

importData()
  .catch(e => {
    console.error('Ошибка импорта:', e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());

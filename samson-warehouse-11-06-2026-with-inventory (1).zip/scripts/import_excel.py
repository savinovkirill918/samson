#!/usr/bin/env python3
"""
Импорт данных из Excel "Принтеры.xlsx" в SQLite БД:
1. Привязка картриджей к принтерам (cartridgeModelId)
2. Данные расхода (счётчики) по месяцам
"""
import sqlite3
import openpyxl
import re
import sys

DB_PATH = '/home/z/my-project/samson-project/db/custom.db'
XLSX_PATH = '/home/z/my-project/upload/Принтеры.xlsx'

# Маппинг: короткое имя картриджа из Excel → ID модели картриджа в БД
# Строится динамически из таблицы БД

def normalize_cart_name(name):
    """Нормализация имени картриджа для сопоставления"""
    if not name:
        return ''
    name = str(name).strip().upper()
    # Убираем общие суффиксы
    name = name.replace('A/X', '').replace('/X', '').replace('X', '')
    # Снова убираем X в конце (для CF226X → CF226)
    # Но оставляем для Q5949X → Q5949
    # На самом деле оставляем как есть, просто убираем A/X и /X
    return name

def get_cart_db_mapping(cursor):
    """Получить маппинг имён картриджей из БД → ID"""
    cursor.execute("SELECT id, name FROM CartridgeModel")
    mapping = {}
    for row in cursor.fetchall():
        db_id, db_name = row
        # Полное имя как в БД
        mapping[db_name.upper().strip()] = db_id
        # Без суффикса A/X
        base = db_name.upper().replace('A/X', '').replace('/X', '').strip()
        if base not in mapping:
            mapping[base] = db_id
        # Без последнего X (CF226X → CF226)
        if db_name.upper().endswith('X') and len(db_name) > 2:
            short = db_name.upper()[:-1].strip()
            if short not in mapping:
                mapping[short] = db_id
    return mapping

def match_cartridge(excel_cart_name, db_mapping):
    """Найти ID модели картриджа в БД по имени из Excel"""
    if not excel_cart_name:
        return None
    
    name = str(excel_cart_name).strip().upper()
    
    # Прямое совпадение
    if name in db_mapping:
        return db_mapping[name]
    
    # Пробуем убрать суффиксы
    cleaned = name.replace('A/X', '').replace('/X', '').replace('CS-', '').replace('SF-', '').strip()
    if cleaned in db_mapping:
        return db_mapping[cleaned]
    
    # Убираем X в конце
    if cleaned.endswith('X') and len(cleaned) > 2:
        short = cleaned[:-1].strip()
        if short in db_mapping:
            return db_mapping[short]
    
    # Пробуем добавить X
    if cleaned + 'X' in db_mapping:
        return db_mapping[cleaned + 'X']
    
    # Пробуем добавить A/X
    if cleaned + 'A/X' in db_mapping:
        return db_mapping[cleaned + 'A/X']
    
    # Пробуем TC- → TK-
    if cleaned.startswith('TC-'):
        alt = 'TK-' + cleaned[3:]
        if alt in db_mapping:
            return db_mapping[alt]
    
    # Fuzzy: ищем вхождение
    for db_name, db_id in db_mapping.items():
        if cleaned in db_name or db_name in cleaned:
            return db_id
    
    return None

def parse_month_header(header):
    """Парсинг заголовка месяца: '08_2025' → '2025-08', '10.2025' → '2025-10'"""
    if not header:
        return None
    header = str(header).strip()
    
    # Формат "08_2025"
    m = re.match(r'^(\d{2})_(\d{4})$', header)
    if m:
        return f'{m.group(2)}-{m.group(1)}'
    
    # Формат "10.2025"
    m = re.match(r'^(\d{2})\.(\d{4})$', header)
    if m:
        return f'{m.group(2)}-{m.group(1)}'
    
    return None

def main():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Получаем маппинг картриджей из БД
    db_mapping = get_cart_db_mapping(cursor)
    print(f"Найдено моделей картриджей в БД: {len(db_mapping)}")
    for name, id_ in sorted(db_mapping.items(), key=lambda x: x[1]):
        print(f"  {name} → ID {id_}")
    
    # Загружаем Excel
    wb = openpyxl.load_workbook(XLSX_PATH, data_only=True)
    ws = wb['Расход']
    
    # Получаем принтеры из БД
    cursor.execute("SELECT id, number, model, location FROM Printer ORDER BY number")
    db_printers = cursor.fetchall()
    print(f"\nПринтеров в БД: {len(db_printers)}")
    
    # Строим маппинг: номер принтера → id
    printer_by_number = {p[1]: p[0] for p in db_printers}
    
    # Парсим заголовки месяцев
    month_columns = {}  # col_index → 'YYYY-MM'
    counter_columns = {}  # col_index → 'YYYY-MM' (только столбцы со счётчиками, не "Расход")
    
    for col in range(9, 31):
        header = ws.cell(row=1, column=col).value
        if header and header != 'Расход' and header != 'Средний расход':
            month_str = parse_month_header(header)
            if month_str:
                counter_columns[col] = month_str
                month_columns[col] = month_str
    
    print(f"\nСтолбцы со счётчиками: {counter_columns}")
    
    # Собираем данные из Excel
    excel_printers = []
    for row_idx in range(2, 37):  # строки 2-36
        model = ws.cell(row=row_idx, column=1).value
        location = ws.cell(row=row_idx, column=2).value
        cart_name = ws.cell(row=row_idx, column=7).value
        cart_yield = ws.cell(row=row_idx, column=8).value
        
        if not model:
            continue
        
        # Собираем счётчики по месяцам
        counters = {}  # 'YYYY-MM' → totalCounter (int)
        for col, month_str in counter_columns.items():
            val = ws.cell(row=row_idx, column=col).value
            if val is not None:
                try:
                    counter_val = int(val)
                    counters[month_str] = counter_val
                except (ValueError, TypeError):
                    # "Списан" или текст — пропускаем
                    pass
        
        excel_printers.append({
            'row': row_idx,
            'model': model,
            'location': location,
            'cart_name': cart_name,
            'cart_yield': cart_yield,
            'counters': counters,
        })
    
    print(f"\nПринтеров в Excel: {len(excel_printers)}")
    
    # Маппинг строк Excel → принтеры БД (по номеру/порядку)
    # Принтеры в БД нумеруются 1-35, строки в Excel 2-36
    # Сопоставление по порядковому номеру (номер принтера = row_idx - 1)
    
    linked_count = 0
    consumption_count = 0
    unmatched_carts = set()
    
    for ep in excel_printers:
        printer_number = ep['row'] - 1  # row 2 = printer #1, etc.
        
        if printer_number not in printer_by_number:
            print(f"  ⚠ Принтер №{printer_number} ({ep['model']}) не найден в БД")
            continue
        
        printer_id = printer_by_number[printer_number]
        
        # Привязка картриджа
        cart_id = match_cartridge(ep['cart_name'], db_mapping)
        if ep['cart_name'] and cart_id:
            cursor.execute(
                "UPDATE Printer SET cartridgeModelId = ? WHERE id = ?",
                (cart_id, printer_id)
            )
            linked_count += 1
            print(f"  ✅ Принтер №{printer_number} ({ep['model']}) → картридж {ep['cart_name']} → ID {cart_id}")
        elif ep['cart_name']:
            unmatched_carts.add(ep['cart_name'])
            print(f"  ❌ Принтер №{printer_number} ({ep['model']}) → картридж '{ep['cart_name']}' НЕ НАЙДЕН в справочнике")
        
        # Данные расхода
        for month_str, counter_val in ep['counters'].items():
            # Проверяем, есть ли уже запись
            cursor.execute(
                "SELECT id FROM PrinterConsumption WHERE printerId = ? AND month = ?",
                (printer_id, month_str)
            )
            existing = cursor.fetchone()
            if existing:
                cursor.execute(
                    "UPDATE PrinterConsumption SET totalCounter = ? WHERE printerId = ? AND month = ?",
                    (counter_val, printer_id, month_str)
                )
            else:
                cursor.execute(
                    "INSERT INTO PrinterConsumption (printerId, month, totalCounter) VALUES (?, ?, ?)",
                    (printer_id, month_str, counter_val)
                )
            consumption_count += 1
    
    conn.commit()
    
    print(f"\n{'='*60}")
    print(f"Привязано картриджей: {linked_count} из {len([e for e in excel_printers if e['cart_name']])}")
    print(f"Записей расхода: {consumption_count}")
    
    if unmatched_carts:
        print(f"\n⚠ Ненайденные картриджи: {unmatched_carts}")
    
    conn.close()
    print("\n✅ Импорт завершён!")

if __name__ == '__main__':
    main()

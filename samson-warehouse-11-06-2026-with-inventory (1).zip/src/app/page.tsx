'use client';

// =====================================================================
// ОФИСМАГ Склад — Система управления складом
// Orchestrator page — imports all components and hooks
// =====================================================================

import React, { useState, useEffect, useCallback } from 'react';
import { Menu, LogOut, ChevronDown, PanelLeftClose, PanelLeft } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId, Member, AdminUser, Printer, PrinterRepair, PrinterConsumption, CartridgeModel, Cartridge, Group } from '@/lib/types';
import { getGroupName } from '@/lib/helpers';

// Hooks
import { useMembers } from '@/hooks/useMembers';
import { useGroups } from '@/hooks/useGroups';
import { useTsd } from '@/hooks/useTsd';
import { useKkm } from '@/hooks/useKkm';
import { useRepairs } from '@/hooks/useRepairs';
import { useLogs } from '@/hooks/useLogs';
import { useAdmins } from '@/hooks/useAdmins';
import { usePrinters } from '@/hooks/usePrinters';
import { usePrinterRepairs } from '@/hooks/usePrinterRepairs';
import { usePrinterConsumption } from '@/hooks/usePrinterConsumption';
import { useCartridgeModels } from '@/hooks/useCartridgeModels';
import { useCartridges } from '@/hooks/useCartridges';

// Components
import LoginPage from '@/components/auth/LoginPage';
import Sidebar from '@/components/layout/Sidebar';
import HomePage from '@/components/home/HomePage';
import MembersList from '@/components/members/MembersList';
import MemberForm from '@/components/members/MemberForm';
import GroupsList from '@/components/groups/GroupsList';
import GroupForm from '@/components/groups/GroupForm';
import TsdList from '@/components/tsd/TsdList';
import TsdForm from '@/components/tsd/TsdForm';
import RepairsList from '@/components/tsd/RepairsList';
import RepairForm from '@/components/tsd/RepairForm';
import RepairEditForm from '@/components/tsd/RepairEditForm';
import RepairSZPage from '@/components/tsd/RepairSZPage';
import PrinterList from '@/components/printer/PrinterList';
import PrinterForm from '@/components/printer/PrinterForm';
import PrinterRepairList from '@/components/printer/PrinterRepairList';
import PrinterRepairForm from '@/components/printer/PrinterRepairForm';
import PrinterRepairEditForm from '@/components/printer/PrinterRepairEditForm';
import PrinterRepairSZPage from '@/components/printer/PrinterRepairSZPage';
import PrinterConsumptionPage from '@/components/printer/PrinterConsumptionPage';
import PrinterConsumptionForm from '@/components/printer/PrinterConsumptionForm';
import CartridgeInventory from '@/components/cartridge/CartridgeInventory';
import CartridgeList from '@/components/cartridge/CartridgeList';
import CartridgeForm from '@/components/cartridge/CartridgeForm';
import CartridgeHistoryPage from '@/components/cartridge/CartridgeHistoryPage';
import CartridgeModelList from '@/components/cartridge/CartridgeModelList';
import CartridgeModelForm from '@/components/cartridge/CartridgeModelForm';
import KkmList from '@/components/kkm/KkmList';
import KkmForm from '@/components/kkm/KkmForm';
import StatStarshie from '@/components/statistics/StatStarshie';
import StatKladovshiki from '@/components/statistics/StatKladovshiki';
import StatImport from '@/components/statistics/StatImport';
import ToolsPage from '@/components/tools/ToolsPage';
import LogsPage from '@/components/logs/LogsPage';
import PrintTsd from '@/components/print/PrintTsd';
import PrintKkm from '@/components/print/PrintKkm';
import PrintBarcode from '@/components/print/PrintBarcode';
import SettingsUsers from '@/components/settings/SettingsUsers';
import UserForm from '@/components/settings/UserForm';
import InventoryBalancePage from '@/components/inventory/InventoryBalancePage';

// =====================================================================
// ГЛАВНЫЙ КОМПОНЕНТ ПРИЛОЖЕНИЯ
// =====================================================================
export default function SamsonSkladApp() {
  // Navigation state
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  // ID of the entity being edited
  const [editingMemberId, setEditingMemberId] = useState<number | null>(null);
  const [editingTsdId, setEditingTsdId] = useState<number | null>(null);
  const [editingRepairId, setEditingRepairId] = useState<number | null>(null);
  const [editingPrinterId, setEditingPrinterId] = useState<number | null>(null);
  const [editingPrinterRepairId, setEditingPrinterRepairId] = useState<number | null>(null);
  const [editingConsumptionRecord, setEditingConsumptionRecord] = useState<PrinterConsumption | null>(null);
  const [addConsumptionPrefill, setAddConsumptionPrefill] = useState<{ printerId: number; month: string } | null>(null);
  const [editingCartridge, setEditingCartridge] = useState<Cartridge | null>(null);
  const [editingCartridgeModel, setEditingCartridgeModel] = useState<CartridgeModel | null>(null);
  const [editingGroup, setEditingGroup] = useState<Group | null>(null);

  // Auth state — lazy init from localStorage
  const [authUser, setAuthUser] = useState<AdminUser | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('samson_auth');
      if (stored) {
        try { return JSON.parse(stored); } catch { localStorage.removeItem('samson_auth'); }
      }
    }
    return null;
  });
  const [authChecked, setAuthChecked] = useState<boolean>(typeof window === 'undefined' ? false : true);

  // Data hooks
  const { members, saveMember, deleteMember } = useMembers();
  const { groups, saveGroup, updateGroup, deleteGroup } = useGroups();
  const { tsds, saveTsd, updateTsd } = useTsd();
  const { kkms, saveKkm } = useKkm();
  const { repairs, saveRepair, updateRepair, refetch: refetchRepairs } = useRepairs();
  const { logs, addLog } = useLogs();
  const { admins, saveAdmin } = useAdmins();
  const { printers, savePrinter, updatePrinter, deletePrinter, refetch: refetchPrinters } = usePrinters();
  const { repairs: printerRepairs, saveRepair: savePrinterRepair, updateRepair: updatePrinterRepair, refetch: refetchPrinterRepairs } = usePrinterRepairs();
  const { consumption, saveConsumption, updateConsumption } = usePrinterConsumption();
  const { models: cartridgeModels, saveModel: saveCartridgeModel, updateModel: updateCartridgeModel, deleteModel: deleteCartridgeModel } = useCartridgeModels();
  const { cartridges, summary: cartridgeSummary, saveCartridge, updateCartridge, deleteCartridge, doAction: doCartridgeAction } = useCartridges();

  // Login handler
  const handleLogin = useCallback(async (user: AdminUser) => {
    setAuthUser(user);
    await addLog(user.id, 'Вход в систему');
  }, [addLog]);

  // Logout handler
  const handleLogout = useCallback(() => {
    if (authUser) {
      addLog(authUser.id, 'Выход из системы');
    }
    setAuthUser(null);
    setProfileOpen(false);
    setCurrentPage('home');
    localStorage.removeItem('samson_auth');
  }, [authUser, addLog]);

  // Карта заголовков страниц
  const pageTitles: Record<PageId, string> = {
    'home': 'Главная',
    'members': 'Сотрудники', 'member-add': 'Добавить сотрудника', 'member-edit': 'Редактирование сотрудника',
    'groups': 'Должности', 'group-add': 'Добавить должность', 'group-edit': 'Редактирование должности',
    'tsd-list': 'ТСД', 'tsd-add': 'Добавить ТСД', 'tsd-edit': 'Редактирование ТСД',
    'tsd-repairs': 'Ремонт ТСД', 'tsd-repair-add': 'Добавить ремонт ТСД', 'tsd-repair-edit': 'Редактирование ремонта ТСД', 'tsd-repair-sz': 'Служебная записка ТСД',
    'printer-list': 'Принтеры', 'printer-add': 'Добавить принтер', 'printer-edit': 'Редактирование принтера',
    'printer-repairs': 'Ремонт принтеров', 'printer-repair-add': 'Добавить ремонт принтера', 'printer-repair-edit': 'Редактирование ремонта принтера', 'printer-repair-sz': 'Служебная записка принтера',
    'printer-consumption': 'Расход принтеров', 'printer-consumption-add': 'Ввести счётчик', 'printer-consumption-edit': 'Редактирование счётчика',
    'cartridge-inventory': 'Картриджи — Сводка', 'cartridge-add': 'Добавить картридж', 'cartridge-edit': 'Редактирование картриджа', 'cartridge-history': 'История картриджа',
    'cartridge-models': 'Справочник картриджей', 'cartridge-model-add': 'Добавить модель картриджа', 'cartridge-model-edit': 'Редактирование модели картриджа',
    'kkm-list': 'ККМ', 'kkm-add': 'Добавить ККМ',
    'stat-starshie': 'Статистика — Старшие', 'stat-kladovshiki': 'Статистика — Кладовщики', 'stat-import': 'Импорт WMS',
    'tools': 'Инструменты', 'logs': 'Логи',
    'print-tsd': 'Печать — Реестр ТСД', 'print-kkm': 'Печать — Реестр ККМ', 'print-barcode': 'Печать — Штрихкод',
    'settings-users': 'Настройки — Пользователи', 'settings-user-add': 'Добавить пользователя',
    'inventory-balance': 'Учет остатков',
  };

  // Navigation
  const navigate = useCallback((page: PageId) => {
    setCurrentPage(page);
    setProfileOpen(false);
  }, []);

  // Member handlers
  const handleSaveMember = useCallback(async (member: Member & { isNew?: boolean }) => {
    await saveMember(member);
    await addLog(authUser?.id || 1, member.isNew
      ? `Добавление сотрудника: ${member.fio}`
      : `Редактирование сотрудника: ${member.fio}`);
  }, [saveMember, addLog, authUser]);

  const handleDeleteMember = useCallback(async (id: number) => {
    const member = members.find(m => m.id === id);
    await deleteMember(id);
    if (member) {
      await addLog(authUser?.id || 1, `Удаление сотрудника: ${member.fio}`);
    }
  }, [deleteMember, members, addLog, authUser]);

  // TSD handlers
  const handleSaveTSD = useCallback(async (tsd: { number: number; sn: string; inv: string; model: string; isMulti: boolean }) => {
    await saveTsd(tsd);
    await addLog(authUser?.id || 1, `Добавление ТСД №${tsd.number}`);
  }, [saveTsd, addLog, authUser]);

  const handleUpdateTSD = useCallback(async (tsd: Partial<import('@/lib/types').TSD> & { id: number }) => {
    await updateTsd(tsd);
    await addLog(authUser?.id || 1, `Редактирование ТСД №${tsd.number}`);
  }, [updateTsd, addLog, authUser]);

  // KKM handler
  const handleSaveKKM = useCallback(async (kkm: { number: number; sn: string; inv: string; isMulti: boolean }) => {
    await saveKkm(kkm);
    await addLog(authUser?.id || 1, `Добавление ККМ №${kkm.number}`);
  }, [saveKkm, addLog, authUser]);

  // Repair handlers
  const handleSaveRepair = useCallback(async (repair: Parameters<typeof saveRepair>[0]) => {
    await saveRepair(repair);
    await addLog(authUser?.id || 1, 'Добавление ремонта ТСД');
  }, [saveRepair, addLog, authUser]);

  const handleUpdateRepair = useCallback(async (repair: Parameters<typeof updateRepair>[0]) => {
    await updateRepair(repair);
    await addLog(authUser?.id || 1, `Редактирование ремонта ТСД #${repair.id}`);
  }, [updateRepair, addLog, authUser]);

  // Printer handlers
  const handleSavePrinter = useCallback(async (data: { number: number; sn: string; inv: string; model: string; type: string; location: string; ipAddress: string; purchaseDate: string; status: number; isMulti: boolean; cartridgeModelId: number | null }) => {
    await savePrinter(data);
    await addLog(authUser?.id || 1, `Добавление принтера №${data.number}`);
  }, [savePrinter, addLog, authUser]);

  const handleUpdatePrinter = useCallback(async (data: Partial<Printer> & { id: number }) => {
    await updatePrinter(data);
    await addLog(authUser?.id || 1, `Редактирование принтера №${data.number}`);
  }, [updatePrinter, addLog, authUser]);

  // Printer repair handlers
  const handleSavePrinterRepair = useCallback(async (data: Parameters<typeof savePrinterRepair>[0]) => {
    await savePrinterRepair(data);
    await refetchPrinters();
    await addLog(authUser?.id || 1, 'Добавление ремонта принтера');
  }, [savePrinterRepair, refetchPrinters, addLog, authUser]);

  const handleUpdatePrinterRepair = useCallback(async (data: Parameters<typeof updatePrinterRepair>[0]) => {
    await updatePrinterRepair(data);
    await refetchPrinters();
    await addLog(authUser?.id || 1, `Редактирование ремонта принтера #${data.id}`);
  }, [updatePrinterRepair, refetchPrinters, addLog, authUser]);

  // Printer consumption handlers
  const handleSaveConsumption = useCallback(async (data: { printerId: number; month: string; totalCounter: number }) => {
    await saveConsumption(data);
    await addLog(authUser?.id || 1, `Добавление счётчика принтера за ${data.month}`);
  }, [saveConsumption, addLog, authUser]);

  const handleUpdateConsumption = useCallback(async (data: Partial<PrinterConsumption> & { id: number }) => {
    await updateConsumption(data);
    await addLog(authUser?.id || 1, `Редактирование расхода #${data.id}`);
  }, [updateConsumption, addLog, authUser]);

  // Printer delete handler
  const handleDeletePrinter = useCallback(async (id: number) => {
    await deletePrinter(id);
    await addLog(authUser?.id || 1, `Удаление принтера #${id}`);
  }, [deletePrinter, addLog, authUser]);

  // Cartridge model handlers
  const handleSaveCartridgeModel = useCallback(async (data: { name: string; printerModel: string; expectedYield: number; total?: number; needsRefill?: number; newCount?: number; usedCount?: number }) => {
    await saveCartridgeModel(data);
    await addLog(authUser?.id || 1, `Добавление модели картриджа: ${data.name}`);
  }, [saveCartridgeModel, addLog, authUser]);

  const handleUpdateCartridgeModel = useCallback(async (data: Partial<CartridgeModel> & { id: number }) => {
    await updateCartridgeModel(data);
    await addLog(authUser?.id || 1, `Редактирование модели картриджа: ${data.name}`);
  }, [updateCartridgeModel, addLog, authUser]);

  const handleDeleteCartridgeModel = useCallback(async (id: number) => {
    await deleteCartridgeModel(id);
    await addLog(authUser?.id || 1, `Удаление модели картриджа #${id}`);
  }, [deleteCartridgeModel, addLog, authUser]);

  // Cartridge handlers
  const handleSaveCartridge = useCallback(async (data: { cartridgeModelId: number; status?: number; condition?: number }) => {
    await saveCartridge(data);
    await addLog(authUser?.id || 1, 'Добавление картриджа');
  }, [saveCartridge, addLog, authUser]);

  const handleUpdateCartridge = useCallback(async (data: Partial<Cartridge> & { id: number }) => {
    await updateCartridge(data);
    await addLog(authUser?.id || 1, `Редактирование картриджа #${data.id}`);
  }, [updateCartridge, addLog, authUser]);

  const handleDeleteCartridge = useCallback(async (id: number) => {
    await deleteCartridge(id);
    await addLog(authUser?.id || 1, `Удаление картриджа #${id}`);
  }, [deleteCartridge, addLog, authUser]);

  const handleCartridgeAction = useCallback(async (data: { cartridgeId: number; action: string; printerId?: number | null; date?: string; notes?: string }) => {
    await doCartridgeAction(data);
    await addLog(authUser?.id || 1, `Действие с картриджем #${data.cartridgeId}: ${data.action}`);
  }, [doCartridgeAction, addLog, authUser]);

  // Group handlers
  const handleSaveGroup = useCallback(async (group: { name: string; sort: number }) => {
    await saveGroup(group);
  }, [saveGroup]);

  const handleUpdateGroup = useCallback(async (group: { id: number; name: string; sort: number }) => {
    await updateGroup(group);
  }, [updateGroup]);

  const handleDeleteGroup = useCallback(async (id: number) => {
    await deleteGroup(id);
  }, [deleteGroup]);

  // Admin handler
  const handleSaveAdmin = useCallback(async (admin: { login: string; hash?: string; fio: string; role?: string; groupId?: number }) => {
    await saveAdmin(admin);
    await addLog(authUser?.id || 1, `Добавление пользователя: ${admin.login}`);
  }, [saveAdmin, addLog, authUser]);

  // Loading spinner while checking auth
  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
        <div className="w-8 h-8 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
      </div>
    );
  }

  // Login page
  if (!authUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Render current page content
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} printers={printers} printerRepairs={printerRepairs} cartridgeSummary={cartridgeSummary} onNavigate={navigate} />;
      case 'members':
        return <MembersList members={members} groups={groups} tsds={tsds} kkms={kkms} onEdit={id => { setEditingMemberId(id); navigate('member-edit'); }} onNavigate={navigate} />;
      case 'member-add':
        return <MemberForm memberId={null} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'member-edit':
        return <MemberForm memberId={editingMemberId} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'groups':
        return <GroupsList groups={groups} onNavigate={navigate} onEditGroup={(g) => { setEditingGroup(g); navigate('group-edit'); }} onDeleteGroup={handleDeleteGroup} />;
      case 'group-add':
        return <GroupForm onSave={handleSaveGroup} onNavigate={navigate} />;
      case 'group-edit':
        return <GroupForm editingGroup={editingGroup} onSave={handleSaveGroup} onUpdate={handleUpdateGroup} onDelete={handleDeleteGroup} onNavigate={navigate} />;
      case 'tsd-list':
        return <TsdList tsds={tsds} members={members} onNavigate={navigate} onEditTsd={(tsd) => { setEditingTsdId(tsd.id); navigate('tsd-edit'); }} />;
      case 'tsd-add':
        return <TsdForm onSave={handleSaveTSD} onNavigate={navigate} />;
      case 'tsd-edit':
        return <TsdForm editingTsdId={editingTsdId} tsds={tsds} onSave={handleSaveTSD} onUpdate={handleUpdateTSD} onNavigate={navigate} />;
      case 'tsd-repairs':
        return <RepairsList repairs={repairs} tsds={tsds} members={members} onNavigate={navigate} onEditRepair={(repair) => { setEditingRepairId(repair.id); navigate('tsd-repair-edit'); }} />;
      case 'tsd-repair-add':
        return <RepairForm tsds={tsds} onSave={handleSaveRepair} onNavigate={navigate} />;
      case 'tsd-repair-edit':
        return <RepairEditForm repairId={editingRepairId ?? 0} repairs={repairs} tsds={tsds} onUpdate={handleUpdateRepair} onNavigate={navigate} />;
      case 'tsd-repair-sz':
        return <RepairSZPage repairs={repairs} tsds={tsds} onNavigate={navigate} />;
      // ====== Принтеры ======
      case 'printer-list':
        return <PrinterList printers={printers} onNavigate={navigate} onEditPrinter={(p) => { setEditingPrinterId(p.id); navigate('printer-edit'); }} />;
      case 'printer-add':
        return <PrinterForm cartridgeModels={cartridgeModels} onSave={handleSavePrinter} onNavigate={navigate} />;
      case 'printer-edit':
        return <PrinterForm editingPrinterId={editingPrinterId} printers={printers} cartridgeModels={cartridgeModels} onSave={handleSavePrinter} onUpdate={handleUpdatePrinter} onDelete={handleDeletePrinter} onNavigate={navigate} />;
      case 'printer-repairs':
        return <PrinterRepairList repairs={printerRepairs} printers={printers} onNavigate={navigate} onEditRepair={(r) => { setEditingPrinterRepairId(r.id); navigate('printer-repair-edit'); }} />;
      case 'printer-repair-add':
        return <PrinterRepairForm printers={printers} onSave={handleSavePrinterRepair} onNavigate={navigate} />;
      case 'printer-repair-edit':
        return <PrinterRepairEditForm repairId={editingPrinterRepairId ?? 0} repairs={printerRepairs} printers={printers} onUpdate={handleUpdatePrinterRepair} onNavigate={navigate} />;
      case 'printer-repair-sz':
        return <PrinterRepairSZPage repairs={printerRepairs} printers={printers} onNavigate={navigate} />;
      case 'printer-consumption':
        return <PrinterConsumptionPage consumption={consumption} printers={printers} onNavigate={navigate} onEdit={(r) => { setEditingConsumptionRecord(r); navigate('printer-consumption-edit'); }} onAdd={(data) => { setAddConsumptionPrefill(data); navigate('printer-consumption-add'); }} onEditPrinter={(p) => { setEditingPrinterId(p.id); navigate('printer-edit'); }} />;
      case 'printer-consumption-add':
        return <PrinterConsumptionForm printers={printers} onSave={handleSaveConsumption} onNavigate={navigate} initialData={addConsumptionPrefill} />;
      case 'printer-consumption-edit':
        return <PrinterConsumptionForm editingRecord={editingConsumptionRecord} printers={printers} onSave={handleSaveConsumption} onUpdate={handleUpdateConsumption} onNavigate={navigate} />;
      // ====== Картриджи ======
      case 'cartridge-inventory':
        return <CartridgeInventory models={cartridgeModels} onUpdateModel={handleUpdateCartridgeModel} onNavigate={navigate} />;
      case 'cartridge-add':
        return <CartridgeForm cartridgeModels={cartridgeModels} printers={printers} onSave={handleSaveCartridge} onNavigate={navigate} />;
      case 'cartridge-edit':
        return <CartridgeForm editingCartridge={editingCartridge} cartridgeModels={cartridgeModels} printers={printers} onSave={handleSaveCartridge} onUpdate={handleUpdateCartridge} onDelete={handleDeleteCartridge} onNavigate={navigate} />;
      case 'cartridge-history':
        return editingCartridge ? <CartridgeHistoryPage cartridge={editingCartridge} cartridgeModels={cartridgeModels} printers={printers} onNavigate={navigate} /> : null;
      case 'cartridge-models':
        return <CartridgeModelList models={cartridgeModels} onNavigate={navigate} onEdit={(m) => { setEditingCartridgeModel(m); navigate('cartridge-model-edit'); }} />;
      case 'cartridge-model-add':
        return <CartridgeModelForm onSave={handleSaveCartridgeModel} onNavigate={navigate} />;
      case 'cartridge-model-edit':
        return <CartridgeModelForm editingModel={editingCartridgeModel} onSave={handleSaveCartridgeModel} onUpdate={handleUpdateCartridgeModel} onDelete={handleDeleteCartridgeModel} onNavigate={navigate} />;
      // ====== ККМ ======
      case 'kkm-list':
        return <KkmList kkms={kkms} members={members} onNavigate={navigate} />;
      case 'kkm-add':
        return <KkmForm onSave={handleSaveKKM} onNavigate={navigate} />;
      case 'stat-starshie':
        return <StatStarshie members={members} groups={groups} />;
      case 'stat-kladovshiki':
        return <StatKladovshiki members={members} groups={groups} />;
      case 'stat-import':
        return <StatImport />;
      case 'tools':
        return <ToolsPage />;
      case 'logs':
        return <LogsPage logs={logs} admins={admins} />;
      case 'print-tsd':
        return <PrintTsd tsds={tsds} members={members} />;
      case 'print-kkm':
        return <PrintKkm kkms={kkms} members={members} />;
      case 'print-barcode':
        return <PrintBarcode />;
      case 'settings-users':
        return <SettingsUsers admins={admins} groups={groups} onNavigate={navigate} />;
      case 'settings-user-add':
        return <UserForm groups={groups} onSave={handleSaveAdmin} onNavigate={navigate} />;
      case 'inventory-balance':
        return <InventoryBalancePage />;
      default:
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} printers={printers} printerRepairs={printerRepairs} cartridgeSummary={cartridgeSummary} onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: COLORS.bodyBg }}>
      <div className="flex flex-1">
        <Sidebar currentPage={currentPage} onNavigate={navigate} isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} isCollapsed={sidebarCollapsed} onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} />

        <div className="flex-1" style={{ marginLeft: sidebarCollapsed ? 60 : 260, display: 'flex', flexDirection: 'column', transition: 'margin-left 0.3s cubic-bezier(0.4, 0, 0.2, 1)', height: '100vh', overflow: 'hidden' }}>
          <header className="bg-white shadow-sm px-4 py-3 flex items-center justify-between" style={{ zIndex: 30, flexShrink: 0 }}>
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100">
                <Menu className="w-5 h-5" style={{ color: COLORS.heading }} />
              </button>
              <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)} className="hidden lg:flex p-1.5 rounded-lg hover:bg-gray-100 transition" title={sidebarCollapsed ? 'Развернуть меню' : 'Свернуть меню'}>
                {sidebarCollapsed ? <PanelLeft className="w-5 h-5" style={{ color: COLORS.heading }} /> : <PanelLeftClose className="w-5 h-5" style={{ color: COLORS.heading }} />}
              </button>
              <h1 className="text-lg font-bold hidden sm:block" style={{ color: COLORS.heading }}>{pageTitles[currentPage] || 'ОФИСМАГ Склад'}</h1>
            </div>

            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition"
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold" style={{ backgroundColor: COLORS.primary }}>
                  {authUser.fio.charAt(0)}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                  <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                </div>
                <ChevronDown className="w-4 h-4" style={{ color: COLORS.text }} />
              </button>

              {profileOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border py-2 w-48 z-50" style={{ borderColor: '#e9ecef' }}>
                  <div className="px-4 py-2 border-b" style={{ borderColor: '#f0f0f0' }}>
                    <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                    <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                  </div>
                  <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 transition">
                    <LogOut className="w-4 h-4" /> Выход
                  </button>
                </div>
              )}
            </div>
          </header>

          <main className="p-4 md:p-6 flex-1" style={{ overflowY: 'auto', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            {renderPage()}
          </main>

        </div>
      </div>
    </div>
  );
}

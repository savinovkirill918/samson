import { NextRequest, NextResponse } from 'next/server'
import jsPDF from 'jspdf'
import { createCanvas } from 'canvas'
import JsBarcode from 'jsbarcode'
import fs from 'node:fs'
import path from 'node:path'

const FONT_NAME = 'LibSerif'

function registerFonts(doc: jsPDF) {
  const fontsDir = '/usr/share/fonts/truetype/liberation'
  const regular = fs.readFileSync(path.join(fontsDir, 'LiberationSerif-Regular.ttf'), 'base64')
  const bold = fs.readFileSync(path.join(fontsDir, 'LiberationSerif-Bold.ttf'), 'base64')
  doc.addFileToVFS('LibSerif-Regular.ttf', regular)
  doc.addFileToVFS('LibSerif-Bold.ttf', bold)
  doc.addFont('LibSerif-Regular.ttf', FONT_NAME, 'normal')
  doc.addFont('LibSerif-Bold.ttf', FONT_NAME, 'bold')
}

function generateBarcodeImage(value: string): Buffer {
  const canvas = createCanvas(400, 160)
  JsBarcode(canvas, value, {
    format: 'CODE128',
    width: 2,
    height: 80,
    displayValue: true,
    fontSize: 18,
    margin: 10,
    background: '#ffffff',
    lineColor: '#000000',
  })
  return canvas.toBuffer('image/png')
}

// GET /api/print/barcode-pdf?codes=code1,code2,code3
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const codesParam = searchParams.get('codes') || ''

    if (!codesParam) {
      return NextResponse.json({ error: 'Укажите штрихкоды параметром ?codes=code1,code2' }, { status: 400 })
    }

    const codes = codesParam.split(',').map(c => c.trim()).filter(Boolean)

    if (codes.length === 0) {
      return NextResponse.json({ error: 'Нет штрихкодов для генерации' }, { status: 400 })
    }

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    })

    registerFonts(doc)
    doc.setFont(FONT_NAME, 'normal')

    const pageWidth = doc.internal.pageSize.getWidth()
    const pageHeight = doc.internal.pageSize.getHeight()
    const marginX = 15
    const marginY = 15
    const labelWidth = (pageWidth - marginX * 2 - 10) / 2 // 2 columns with 10mm gap
    const labelHeight = 40
    const gapX = 10
    const gapY = 8

    let xPos = marginX
    let yPos = marginY

    for (let i = 0; i < codes.length; i++) {
      // Check if we need a new page
      if (yPos + labelHeight > pageHeight - marginY) {
        doc.addPage()
        yPos = marginY
        xPos = marginX
      }

      const code = codes[i]

      // Draw border
      doc.setDrawColor(0)
      doc.setLineWidth(0.5)
      doc.rect(xPos, yPos, labelWidth, labelHeight)

      // Generate barcode image
      const barcodePng = generateBarcodeImage(code)
      const barcodeBase64 = barcodePng.toString('base64')

      // Add barcode image (centered in label, taking most of the space)
      const imgWidth = labelWidth - 8
      const imgHeight = labelHeight - 10
      const imgX = xPos + (labelWidth - imgWidth) / 2
      const imgY = yPos + 3

      doc.addImage(
        `data:image/png;base64,${barcodeBase64}`,
        'PNG',
        imgX,
        imgY,
        imgWidth,
        imgHeight
      )

      // Move to next position
      xPos += labelWidth + gapX

      // If second column, move to next row
      if (xPos + labelWidth > pageWidth - marginX) {
        xPos = marginX
        yPos += labelHeight + gapY
      }
    }

    const pdfBytes = doc.output('arraybuffer')
    return new NextResponse(Buffer.from(pdfBytes), {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'inline; filename="barcodes.pdf"',
        'Content-Length': String(pdfBytes.byteLength),
      },
    })
  } catch (error) {
    console.error('Error generating barcode PDF:', error)
    return NextResponse.json({ error: 'Ошибка генерации PDF со штрихкодами' }, { status: 500 })
  }
}

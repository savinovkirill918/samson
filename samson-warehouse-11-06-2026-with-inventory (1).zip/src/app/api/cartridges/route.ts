import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/cartridges
export async function GET() {
  try {
    const cartridges = await prisma.cartridge.findMany({
      include: { cartridgeModel: true, printer: true, history: { orderBy: { id: 'desc' } } },
      orderBy: { id: 'desc' }
    })
    return NextResponse.json(cartridges)
  } catch (error) {
    console.error('Error fetching cartridges:', error)
    return NextResponse.json({ error: 'Ошибка получения картриджей' }, { status: 500 })
  }
}

// POST /api/cartridges
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const cartridge = await prisma.cartridge.create({
      data: {
        cartridgeModelId: body.cartridgeModelId,
        printerId: body.printerId ?? null,
        status: body.status ?? 0,
        condition: body.condition ?? 0,
      }
    })
    return NextResponse.json(cartridge, { status: 201 })
  } catch (error) {
    console.error('Error creating cartridge:', error)
    return NextResponse.json({ error: 'Ошибка создания картриджа' }, { status: 500 })
  }
}

// PUT /api/cartridges
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const cartridge = await prisma.cartridge.update({
      where: { id: body.id },
      data: {
        cartridgeModelId: body.cartridgeModelId,
        printerId: body.printerId ?? null,
        status: body.status,
        condition: body.condition ?? 0,
      }
    })
    return NextResponse.json(cartridge)
  } catch (error) {
    console.error('Error updating cartridge:', error)
    return NextResponse.json({ error: 'Ошибка обновления картриджа' }, { status: 500 })
  }
}

// DELETE /api/cartridges?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    // Удалить историю картриджа, затем сам картридж
    await prisma.cartridgeHistory.deleteMany({ where: { cartridgeId: id } })
    await prisma.cartridge.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting cartridge:', error)
    return NextResponse.json({ error: 'Ошибка удаления картриджа' }, { status: 500 })
  }
}

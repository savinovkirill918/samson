import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/cartridges/[id]/history — история одного картриджа
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const cartridgeId = Number(id)
    const history = await prisma.cartridgeHistory.findMany({
      where: { cartridgeId },
      orderBy: { id: 'desc' }
    })
    return NextResponse.json(history)
  } catch (error) {
    console.error('Error fetching cartridge history:', error)
    return NextResponse.json({ error: 'Ошибка получения истории картриджа' }, { status: 500 })
  }
}

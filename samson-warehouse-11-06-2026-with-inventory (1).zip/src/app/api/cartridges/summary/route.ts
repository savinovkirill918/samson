import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/cartridges/summary — сводка по картриджам (данные из модели)
export async function GET() {
  try {
    const models = await prisma.cartridgeModel.findMany({
      orderBy: { name: 'asc' }
    })

    const summary = models.map(model => ({
      cartridgeModel: {
        id: model.id,
        name: model.name,
        printerModel: model.printerModel,
        expectedYield: model.expectedYield,
        total: model.total,
        needsRefill: model.needsRefill,
        newCount: model.newCount,
        usedCount: model.usedCount,
      },
      total: model.total,
      onStock: model.total - model.needsRefill,
      needsRefill: model.needsRefill,
      newCount: model.newCount,
      usedCount: model.usedCount,
    }))

    return NextResponse.json(summary)
  } catch (error) {
    console.error('Error fetching cartridge summary:', error)
    return NextResponse.json({ error: 'Ошибка получения сводки картриджей' }, { status: 500 })
  }
}

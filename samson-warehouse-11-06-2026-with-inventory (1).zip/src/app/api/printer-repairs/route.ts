import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/printer-repairs
export async function GET() {
  try {
    const repairs = await prisma.printerRepair.findMany({
      include: { printer: true },
      orderBy: { id: 'desc' }
    })
    return NextResponse.json(repairs)
  } catch (error) {
    console.error('Error fetching printer repairs:', error)
    return NextResponse.json({ error: 'Ошибка получения ремонтов принтеров' }, { status: 500 })
  }
}

// POST /api/printer-repairs
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.printerRepair.create({
      data: {
        printerId: body.printerId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status ?? -1,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })

    // Автоматически установить статус принтера «В ремонте» (1)
    await prisma.printer.update({
      where: { id: body.printerId },
      data: { status: 1 },
    })

    return NextResponse.json(repair, { status: 201 })
  } catch (error) {
    console.error('Error creating printer repair:', error)
    return NextResponse.json({ error: 'Ошибка создания ремонта принтера' }, { status: 500 })
  }
}

// PUT /api/printer-repairs
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.printerRepair.update({
      where: { id: body.id },
      data: {
        printerId: body.printerId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })

    // Если ремонт завершён (статус 1 = «Вернулся с ремонта»),
    // проверить есть ли ещё активные ремонты у этого принтера
    if (body.status === 1) {
      const activeRepairs = await prisma.printerRepair.count({
        where: {
          printerId: body.printerId,
          status: { not: 1 },
        },
      })
      if (activeRepairs === 0) {
        // Активных ремонтов больше нет — вернуть статус «Работает» (0)
        await prisma.printer.update({
          where: { id: body.printerId },
          data: { status: 0 },
        })
      }
    }

    return NextResponse.json(repair)
  } catch (error) {
    console.error('Error updating printer repair:', error)
    return NextResponse.json({ error: 'Ошибка обновления ремонта принтера' }, { status: 500 })
  }
}

// DELETE /api/printer-repairs?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))

    // Получить ремонт перед удалением, чтобы знать printerId
    const repair = await prisma.printerRepair.findUnique({ where: { id } })
    await prisma.printerRepair.delete({ where: { id } })

    // Если у принтера больше нет активных ремонтов, вернуть статус «Работает»
    if (repair) {
      const activeRepairs = await prisma.printerRepair.count({
        where: {
          printerId: repair.printerId,
          status: { not: 1 },
        },
      })
      if (activeRepairs === 0) {
        const printer = await prisma.printer.findUnique({ where: { id: repair.printerId } })
        if (printer && printer.status === 1) {
          await prisma.printer.update({
            where: { id: repair.printerId },
            data: { status: 0 },
          })
        }
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting printer repair:', error)
    return NextResponse.json({ error: 'Ошибка удаления ремонта принтера' }, { status: 500 })
  }
}

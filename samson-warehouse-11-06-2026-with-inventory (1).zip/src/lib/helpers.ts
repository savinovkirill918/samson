import { Group, TSD, KKM, Repair, Printer, CartridgeModel } from './types';

/** Статус принтера: число → текст */
export const printerStatusText = (status: number): string => {
  switch (status) {
    case 0: return 'Работает';
    case 1: return 'В ремонте';
    case 2: return 'Списан';
    case 3: return 'Запасной';
    default: return 'Неизвестно';
  }
};

/** Статус принтера → цвет бейджа */
export const printerStatusColor = (status: number): { bg: string; text: string } => {
  switch (status) {
    case 0: return { bg: '#d1e7dd', text: '#0f5132' };
    case 1: return { bg: '#fff3cd', text: '#664d03' };
    case 2: return { bg: '#e2e3e5', text: '#41464b' };
    case 3: return { bg: '#cfe2ff', text: '#084298' };
    default: return { bg: '#e2e3e5', text: '#41464b' };
  }
};

/** Получить название группы по ID */
export const getGroupName = (groupId: number, groups: Group[]): string => {
  return groups.find(g => g.id === groupId)?.name || 'Не указана';
};

/** Получить ТСД по ID */
export const getTsd = (tsdId: number | null, tsds: TSD[]): TSD | null => {
  if (!tsdId) return null;
  return tsds.find(t => t.id === tsdId) || null;
};

/** Получить ККМ по ID */
export const getKkm = (kkmId: number | null, kkms: KKM[]): KKM | null => {
  if (!kkmId) return null;
  return kkms.find(k => k.id === kkmId) || null;
};

/** Получить модель картриджа по ID */
export const getCartridgeModel = (modelId: number | null, models: CartridgeModel[]): CartridgeModel | null => {
  if (!modelId) return null;
  return models.find(m => m.id === modelId) || null;
};

/** Форматирование даты для отображения */
export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

/** Форматирование даты и времени для логов */
export const formatDateTime = (isoStr: string): string => {
  const d = new Date(isoStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
};

/** Статус ремонта: число → текст */
export const repairStatusText = (status: number): string => {
  switch (status) {
    case 0: return 'Отправлен';
    case 1: return 'Вернулся с ремонта';
    default: return 'Сломан не отправлен';
  }
};

/** Статус ремонта: текст → число */
export const repairStatusToNumber = (status: string): number => {
  switch (status) {
    case 'Отправлен': return 0;
    case 'Вернулся с ремонта': return 1;
    default: return -1;
  }
};

/** Проверить, что ремонт активен (не вернулся с ремонта) */
export const isRepairActive = (repair: Repair): boolean => {
  return repair.status !== 1;
};

/** Статус картриджа: число → текст */
export const cartridgeStatusText = (status: number): string => {
  switch (status) {
    case 0: return 'На остатке';
    case 1: return 'В работе';
    case 2: return 'Требует заправки';
    case 3: return 'В заправке';
    case 4: return 'Списан';
    default: return 'Неизвестно';
  }
};

/** Статус картриджа → цвет фона бейджа */
export const cartridgeStatusColor = (status: number): { bg: string; text: string } => {
  switch (status) {
    case 0: return { bg: '#d1e7dd', text: '#0f5132' };   // зелёный
    case 1: return { bg: '#cfe2ff', text: '#084298' };   // синий
    case 2: return { bg: '#fff3cd', text: '#664d03' };   // оранжевый/жёлтый
    case 3: return { bg: '#ffe5d0', text: '#9a4800' };   // оранжевый
    case 4: return { bg: '#e2e3e5', text: '#41464b' };   // серый
    default: return { bg: '#e2e3e5', text: '#41464b' };
  }
};

/** Состояние картриджа: число → текст */
export const cartridgeConditionText = (condition: number): string => {
  switch (condition) {
    case 0: return 'Новый';
    case 1: return 'Б/у';
    default: return 'Неизвестно';
  }
};

/** Состояние картриджа → цвет бейджа */
export const cartridgeConditionColor = (condition: number): { bg: string; text: string } => {
  switch (condition) {
    case 0: return { bg: '#d1e7dd', text: '#0f5132' };   // зелёный — новый
    case 1: return { bg: '#ffe5d0', text: '#9a4800' };   // оранжевый — б/у
    default: return { bg: '#e2e3e5', text: '#41464b' };
  }
};

/** Действие с картриджем → текст на русском */
export const cartridgeActionText = (action: string): string => {
  switch (action) {
    case 'installed': return 'Установлен в принтер';
    case 'removed': return 'Снят с принтера';
    case 'sent_refill': return 'Отправлен на заправку';
    case 'returned_refill': return 'Вернулся с заправки';
    case 'written_off': return 'Списан';
    default: return action;
  }
};

/** Тип принтера → текст */
export const printerTypeText = (type: string): string => {
  switch (type) {
    case 'thermal': return 'Термопринтер';
    case 'label': return 'Этикетки';
    case 'laser': return 'Лазерный';
    case 'inkjet': return 'Струйный';
    default: return type;
  }
};

/** Текущий месяц в формате YYYY-MM */
export const currentMonth = (): string => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

/** Сегодня в формате YYYY-MM-DD */
export const todayStr = (): string => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};

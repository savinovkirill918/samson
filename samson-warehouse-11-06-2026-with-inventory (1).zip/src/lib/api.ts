import type { Member, Group, TSD, KKM, Repair, LogEntry, AdminUser, Printer, PrinterRepair, PrinterConsumption, CartridgeModel, Cartridge, CartridgeHistory, CartridgeSummary } from './types';

// =====================================================================
// API Client — typed fetch wrappers for all backend endpoints
// =====================================================================

const API_BASE = '/api';

async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API Error ${res.status}: ${text}`);
  }
  return res.json();
}

// — Members —
export const getMembers = (): Promise<Member[]> => fetchJSON(`${API_BASE}/members`);
export const createMember = (data: Omit<Member, 'id' | 'group' | 'tsd' | 'kkm'>): Promise<Member> =>
  fetchJSON(`${API_BASE}/members`, { method: 'POST', body: JSON.stringify(data) });
export const updateMember = (data: Partial<Member> & { id: number }): Promise<Member> =>
  fetchJSON(`${API_BASE}/members`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteMember = (id: number): Promise<void> =>
  fetch(`${API_BASE}/members?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Groups —
export const getGroups = (): Promise<Group[]> => fetchJSON(`${API_BASE}/groups`);
export const createGroup = (data: { name: string; sort: number }): Promise<Group> =>
  fetchJSON(`${API_BASE}/groups`, { method: 'POST', body: JSON.stringify(data) });
export const updateGroup = (data: { id: number; name: string; sort: number }): Promise<Group> =>
  fetchJSON(`${API_BASE}/groups`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteGroup = (id: number): Promise<void> =>
  fetch(`${API_BASE}/groups?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — TSDs —
export const getTsds = (): Promise<TSD[]> => fetchJSON(`${API_BASE}/tsds`);
export const createTsd = (data: { number: number; sn: string; inv: string; model: string; isMulti: boolean }): Promise<TSD> =>
  fetchJSON(`${API_BASE}/tsds`, { method: 'POST', body: JSON.stringify(data) });
export const updateTsd = (data: Partial<TSD> & { id: number }): Promise<TSD> =>
  fetchJSON(`${API_BASE}/tsds`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteTsd = (id: number): Promise<void> =>
  fetch(`${API_BASE}/tsds?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — KKMs —
export const getKkms = (): Promise<KKM[]> => fetchJSON(`${API_BASE}/kkms`);
export const createKkm = (data: { number: number; sn: string; inv: string; isMulti: boolean }): Promise<KKM> =>
  fetchJSON(`${API_BASE}/kkms`, { method: 'POST', body: JSON.stringify(data) });
export const updateKkm = (data: Partial<KKM> & { id: number }): Promise<KKM> =>
  fetchJSON(`${API_BASE}/kkms`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteKkm = (id: number): Promise<void> =>
  fetch(`${API_BASE}/kkms?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Repairs —
export const getRepairs = (): Promise<Repair[]> => fetchJSON(`${API_BASE}/repairs`);
export const createRepair = (data: {
  tsdId: number;
  brokenDate: string;
  sentDate?: string;
  returnedDate?: string;
  status?: number;
  description: string;
  isGuilty?: boolean;
  cost?: number;
}): Promise<Repair> =>
  fetchJSON(`${API_BASE}/repairs`, { method: 'POST', body: JSON.stringify(data) });
export const updateRepair = (data: Partial<Repair> & { id: number }): Promise<Repair> =>
  fetchJSON(`${API_BASE}/repairs`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteRepair = (id: number): Promise<void> =>
  fetch(`${API_BASE}/repairs?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Printers —
export const getPrinters = (): Promise<Printer[]> => fetchJSON(`${API_BASE}/printers`);
export const createPrinter = (data: { number: number; sn: string; inv: string; model: string; type: string; location: string; ipAddress: string; purchaseDate: string; status: number; isMulti: boolean; cartridgeModelId: number | null }): Promise<Printer> =>
  fetchJSON(`${API_BASE}/printers`, { method: 'POST', body: JSON.stringify(data) });
export const updatePrinter = (data: Partial<Printer> & { id: number }): Promise<Printer> =>
  fetchJSON(`${API_BASE}/printers`, { method: 'PUT', body: JSON.stringify(data) });
export const deletePrinter = (id: number): Promise<void> =>
  fetch(`${API_BASE}/printers?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Printer Repairs —
export const getPrinterRepairs = (): Promise<PrinterRepair[]> => fetchJSON(`${API_BASE}/printer-repairs`);
export const createPrinterRepair = (data: {
  printerId: number;
  brokenDate: string;
  sentDate?: string;
  returnedDate?: string;
  status?: number;
  description: string;
  isGuilty?: boolean;
  cost?: number;
}): Promise<PrinterRepair> =>
  fetchJSON(`${API_BASE}/printer-repairs`, { method: 'POST', body: JSON.stringify(data) });
export const updatePrinterRepair = (data: Partial<PrinterRepair> & { id: number }): Promise<PrinterRepair> =>
  fetchJSON(`${API_BASE}/printer-repairs`, { method: 'PUT', body: JSON.stringify(data) });
export const deletePrinterRepair = (id: number): Promise<void> =>
  fetch(`${API_BASE}/printer-repairs?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Printer Consumption —
export const getPrinterConsumption = (): Promise<PrinterConsumption[]> => fetchJSON(`${API_BASE}/printer-consumption`);
export const createPrinterConsumption = (data: { printerId: number; month: string; totalCounter: number }): Promise<PrinterConsumption> =>
  fetchJSON(`${API_BASE}/printer-consumption`, { method: 'POST', body: JSON.stringify(data) });
export const updatePrinterConsumption = (data: Partial<PrinterConsumption> & { id: number }): Promise<PrinterConsumption> =>
  fetchJSON(`${API_BASE}/printer-consumption`, { method: 'PUT', body: JSON.stringify(data) });
export const deletePrinterConsumption = (id: number): Promise<void> =>
  fetch(`${API_BASE}/printer-consumption?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Cartridge Models —
export const getCartridgeModels = (): Promise<CartridgeModel[]> => fetchJSON(`${API_BASE}/cartridge-models`);
export const createCartridgeModel = (data: { name: string; printerModel: string; expectedYield: number; total?: number; needsRefill?: number; newCount?: number; usedCount?: number }): Promise<CartridgeModel> =>
  fetchJSON(`${API_BASE}/cartridge-models`, { method: 'POST', body: JSON.stringify(data) });
export const updateCartridgeModel = (data: Partial<CartridgeModel> & { id: number }): Promise<CartridgeModel> =>
  fetchJSON(`${API_BASE}/cartridge-models`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteCartridgeModel = (id: number): Promise<void> =>
  fetch(`${API_BASE}/cartridge-models?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Cartridges —
export const getCartridges = (): Promise<Cartridge[]> => fetchJSON(`${API_BASE}/cartridges`);
export const createCartridge = (data: { cartridgeModelId: number; status?: number; condition?: number }): Promise<Cartridge> =>
  fetchJSON(`${API_BASE}/cartridges`, { method: 'POST', body: JSON.stringify(data) });
export const updateCartridge = (data: Partial<Cartridge> & { id: number }): Promise<Cartridge> =>
  fetchJSON(`${API_BASE}/cartridges`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteCartridge = (id: number): Promise<void> =>
  fetch(`${API_BASE}/cartridges?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Cartridge Summary —
export const getCartridgeSummary = (): Promise<CartridgeSummary[]> => fetchJSON(`${API_BASE}/cartridges/summary`);

// — Cartridge History —
export const getCartridgeHistory = (cartridgeId: number): Promise<CartridgeHistory[]> =>
  fetchJSON(`${API_BASE}/cartridges/${cartridgeId}/history`);
export const createCartridgeHistory = (data: { cartridgeId: number; action: string; printerId?: number | null; date: string; notes?: string }): Promise<CartridgeHistory> =>
  fetchJSON(`${API_BASE}/cartridges/history`, { method: 'POST', body: JSON.stringify(data) });

// — Logs —
export const getLogs = (limit?: number, offset?: number): Promise<LogEntry[]> =>
  fetchJSON(`${API_BASE}/logs?limit=${limit || 500}&offset=${offset || 0}`);
export const createLog = (data: { adminId: number; text: string }): Promise<LogEntry> =>
  fetchJSON(`${API_BASE}/logs`, { method: 'POST', body: JSON.stringify(data) });

// — Admins —
export const getAdmins = (): Promise<AdminUser[]> => fetchJSON(`${API_BASE}/admins`);
export const createAdmin = (data: { login: string; hash?: string; fio: string; role?: string; groupId?: number }): Promise<AdminUser> =>
  fetchJSON(`${API_BASE}/admins`, { method: 'POST', body: JSON.stringify(data) });
export const updateAdmin = (data: Partial<AdminUser> & { id: number }): Promise<AdminUser> =>
  fetchJSON(`${API_BASE}/admins`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteAdmin = (id: number): Promise<void> =>
  fetch(`${API_BASE}/admins?id=${id}`, { method: 'DELETE' }).then(r => { if (!r.ok) throw new Error('Delete failed'); });

// — Stats —
export const getStat13 = (params?: { uploadId?: number; dateFrom?: string; dateTo?: string }): Promise<any> => {
  if (params?.uploadId) return fetchJSON(`${API_BASE}/stats/13?uploadId=${params.uploadId}`);
  if (params?.dateFrom && params?.dateTo) return fetchJSON(`${API_BASE}/stats/13?dateFrom=${encodeURIComponent(params.dateFrom)}&dateTo=${encodeURIComponent(params.dateTo)}`);
  return fetchJSON(`${API_BASE}/stats/13`);
};
export const getStat49 = (params?: { uploadId?: number; dateFrom?: string; dateTo?: string }): Promise<any> => {
  if (params?.uploadId) return fetchJSON(`${API_BASE}/stats/49?uploadId=${params.uploadId}`);
  if (params?.dateFrom && params?.dateTo) return fetchJSON(`${API_BASE}/stats/49?dateFrom=${encodeURIComponent(params.dateFrom)}&dateTo=${encodeURIComponent(params.dateTo)}`);
  return fetchJSON(`${API_BASE}/stats/49`);
};
export const getStatUploads = (type: '13' | '49'): Promise<any[]> =>
  fetchJSON(`${API_BASE}/stats/uploads?type=${type}`);
export const uploadStats = (data: any): Promise<any> =>
  fetchJSON(`${API_BASE}/stats/upload`, { method: 'POST', body: JSON.stringify(data) });

// — Auth (login check against admins list) —
export const loginWithCredentials = async (login: string, password: string): Promise<AdminUser | null> => {
  const admins = await getAdmins();
  const admin = admins.find(a => a.login === login);
  if (admin) {
    if (admin.hash && admin.hash === password) return admin;
  }
  return null;
};

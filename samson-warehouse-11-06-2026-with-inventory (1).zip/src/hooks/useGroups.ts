'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Group } from '@/lib/types';
import * as api from '@/lib/api';

export function useGroups() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchGroups = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getGroups();
      setGroups(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки должностей');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchGroups(); }, [fetchGroups]);

  const saveGroup = useCallback(async (group: { name: string; sort: number }) => {
    await api.createGroup(group);
    await fetchGroups();
  }, [fetchGroups]);

  const updateGroup = useCallback(async (group: { id: number; name: string; sort: number }) => {
    await api.updateGroup(group);
    await fetchGroups();
  }, [fetchGroups]);

  const deleteGroup = useCallback(async (id: number) => {
    await api.deleteGroup(id);
    await fetchGroups();
  }, [fetchGroups]);

  return { groups, loading, error, saveGroup, updateGroup, deleteGroup, refetch: fetchGroups };
}

'use client';

import { useState, useEffect, useCallback } from 'react';
import type { PrinterRepair } from '@/lib/types';
import * as api from '@/lib/api';

export function usePrinterRepairs() {
  const [repairs, setRepairs] = useState<PrinterRepair[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRepairs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getPrinterRepairs();
      setRepairs(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки ремонтов принтеров');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchRepairs(); }, [fetchRepairs]);

  const saveRepair = useCallback(async (repair: {
    printerId: number;
    brokenDate: string;
    sentDate?: string;
    returnedDate?: string;
    status?: number;
    description: string;
    isGuilty?: boolean;
    cost?: number;
  }) => {
    await api.createPrinterRepair(repair);
    await fetchRepairs();
  }, [fetchRepairs]);

  const updateRepair = useCallback(async (repair: Partial<PrinterRepair> & { id: number }) => {
    await api.updatePrinterRepair(repair);
    await fetchRepairs();
  }, [fetchRepairs]);

  return { repairs, loading, error, saveRepair, updateRepair, refetch: fetchRepairs };
}

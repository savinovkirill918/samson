'use client';

import React, { useState } from 'react';
import { Tag, X, Loader2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';

export default function PrintBarcode() {
  const [barcode, setBarcode] = useState('');
  const [codes, setCodes] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleAdd = () => {
    if (!barcode.trim()) return;
    setCodes(prev => [...prev, barcode.trim()]);
    setBarcode('');
  };

  const handleRemove = (index: number) => {
    setCodes(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = () => {
    if (codes.length === 0) return;
    setLoading(true);
    try {
      const url = `/api/print/barcode-pdf?codes=${encodeURIComponent(codes.join(','))}`;
      window.open(url, '_blank');
    } catch (err) {
      console.error('Error opening PDF:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Штрихкод</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={barcode}
            onChange={e => setBarcode(e.target.value)}
            placeholder="Введите штрихкод"
            className="flex-1 px-4 py-2 border rounded-lg focus:outline-none"
            style={{ borderColor: '#dee2e6' }}
            onKeyDown={e => e.key === 'Enter' && handleAdd()}
          />
          <button
            onClick={handleAdd}
            className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition"
            style={{ backgroundColor: COLORS.primary }}
          >
            <Tag className="w-4 h-4" /> Добавить
          </button>
        </div>

        {codes.length > 0 && (
          <>
            <div className="space-y-2 mb-4">
              {codes.map((code, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }}>
                  <span className="font-mono text-sm" style={{ color: COLORS.heading }}>{code}</span>
                  <button
                    onClick={() => handleRemove(i)}
                    className="p-1 rounded hover:bg-gray-100 transition"
                    style={{ color: '#dc3545' }}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
              style={{ backgroundColor: COLORS.primary }}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Tag className="w-4 h-4" />}
              {loading ? 'Генерация...' : 'Генерировать PDF'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

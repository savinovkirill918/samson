'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { AdminUser, Group, PageId } from '@/lib/types';
import { getGroupName } from '@/lib/helpers';

interface SettingsUsersProps {
  admins: AdminUser[];
  groups: Group[];
  onNavigate: (page: PageId) => void;
}

export default function SettingsUsers({ admins, groups, onNavigate }: SettingsUsersProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
        <table className="w-full">
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Должность</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Роль</th>
            </tr>
          </thead>
          <tbody>
            {admins.map(admin => (
              <tr key={admin.id} className="border-t hover:bg-gray-50" style={{ borderColor: '#f0f0f0' }}>
                <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{admin.fio}</td>
                <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{getGroupName(admin.groupId, groups)}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded text-xs font-medium ${admin.role === 'Админ' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'}`}>
                    {admin.role}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

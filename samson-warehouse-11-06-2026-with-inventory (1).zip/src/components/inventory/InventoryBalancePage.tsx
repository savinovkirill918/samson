'use client';

import React, { useState, useRef, useCallback } from 'react';
import { Upload, CheckCircle, AlertCircle, Search, FileSpreadsheet, X, RefreshCw, Download } from 'lucide-react';
import { COLORS } from '@/lib/colors';

/* ================================================================== */
/*  Types                                                               */
/* ================================================================== */

interface ResultRow {
  num: number;
  code1c: string;
  name: string;
  excelQty: number;
  wmsQty: number;
}

interface CompareStats {
  excelTotal: number;
  excelFiltered: number;
  wmsTotal: number;
  wmsAfterFilter: number;
  matchedCount: number;
}

/* ================================================================== */
/*  Component                                                           */
/* ================================================================== */

export default function InventoryBalancePage() {
  const [file1, setFile1] = useState<File | null>(null);
  const [file2, setFile2] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ResultRow[]>([]);
  const [stats, setStats] = useState<CompareStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const file1Ref = useRef<HTMLInputElement>(null);
  const file2Ref = useRef<HTMLInputElement>(null);

  const handleFile1Change = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    setFile1(f);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);
  }, []);

  const handleFile2Change = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    setFile2(f);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);
  }, []);

  const clearFile1 = useCallback(() => {
    setFile1(null);
    if (file1Ref.current) file1Ref.current.value = '';
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
  }, []);

  const clearFile2 = useCallback(() => {
    setFile2(null);
    if (file2Ref.current) file2Ref.current.value = '';
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
  }, []);

  const handleCompare = async () => {
    if (!file1 || !file2) {
      setError('Загрузите оба файла для сверки');
      return;
    }

    setLoading(true);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);

    try {
      const formData = new FormData();
      formData.append('file1', file1);
      formData.append('file2', file2);

      const response = await fetch('/api/inventory-balance', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Ошибка сервера при обработке файлов');
      }

      const matched: ResultRow[] = data.results || [];
      const compareStats: CompareStats = data.stats || {};

      setResults(matched);
      setStats(compareStats);

      if (matched.length === 0) {
        setError('Нет номенклатуры с совпадающими остатками. Проверьте файлы и ключи сопоставления.');
      } else {
        setSuccess(`Найдено ${matched.length} позиций с совпадающими остатками`);
      }
    } catch (err: any) {
      setError(`Ошибка обработки: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const hasResults = results.length > 0 && !loading;

  // Filter results by search
  const filteredResults = searchQuery
    ? results.filter(r =>
        r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.code1c.includes(searchQuery)
      )
    : results;

  const handleExportExcel = useCallback(() => {
    if (filteredResults.length === 0) return;

    const XLSX = require('xlsx');
    const wsData = [
      ['№ п.п', 'Код 1С', 'Наименование', 'Остаток Excel (Главный + Учет)', 'Остаток WMS'],
      ...filteredResults.map(r => [r.num, r.code1c, r.name, r.excelQty, r.wmsQty]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws['!cols'] = [{ wch: 8 }, { wch: 14 }, { wch: 50 }, { wch: 22 }, { wch: 16 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Сверка остатков');
    XLSX.writeFile(wb, 'сверка_остатков.xlsx');
  }, [filteredResults]);

  const handleReset = useCallback(() => {
    setFile1(null);
    setFile2(null);
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
    setSearchQuery('');
    if (file1Ref.current) file1Ref.current.value = '';
    if (file2Ref.current) file2Ref.current.value = '';
  }, []);

  return (
    <div>
      {/* ====== Заголовок, описание, загрузка файлов + кнопка (скрываются при наличии результатов) ====== */}
      {!hasResults && (
        <>
          <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Учет остатков</h2>
          <p className="text-sm mb-6" style={{ color: COLORS.text }}>
            Сверка складских остатков из двух источников. Загрузите оба файла и нажмите «Сверить остатки» для получения списка номенклатуры, где остатки совпадают.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* File 1 — Учет + Главный */}
            <div className="bg-white rounded-xl shadow p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileSpreadsheet className="w-5 h-5" style={{ color: COLORS.primary }} />
                <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>Учет + Главный</h3>
              </div>
              <p className="text-xs mb-3" style={{ color: COLORS.text }}>Excel файл с остатками по складам Главный и Учет (.xls / .xlsx)</p>
              <div className="relative">
                <label className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: file1 ? '#3a57e8' : '#dee2e6', backgroundColor: file1 ? '#f0f4ff' : 'transparent' }}>
                  <Upload className="w-4 h-4" style={{ color: file1 ? COLORS.primary : COLORS.text }} />
                  <span className="text-sm" style={{ color: file1 ? COLORS.primary : COLORS.text }}>
                    {file1 ? file1.name : 'Выберите файл .xls / .xlsx'}
                  </span>
                  <input
                    ref={file1Ref}
                    type="file"
                    accept=".xls,.xlsx"
                    onChange={handleFile1Change}
                    className="hidden"
                  />
                </label>
                {file1 && (
                  <button onClick={clearFile1} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* File 2 — WMS остатки */}
            <div className="bg-white rounded-xl shadow p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileSpreadsheet className="w-5 h-5" style={{ color: COLORS.primary }} />
                <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>Остатки товаров 31 отчет</h3>
              </div>
              <p className="text-xs mb-3" style={{ color: COLORS.text }}>Excel файл с остатками товаров из WMS (.xls / .xlsx)</p>
              <div className="relative">
                <label className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: file2 ? '#3a57e8' : '#dee2e6', backgroundColor: file2 ? '#f0f4ff' : 'transparent' }}>
                  <Upload className="w-4 h-4" style={{ color: file2 ? COLORS.primary : COLORS.text }} />
                  <span className="text-sm" style={{ color: file2 ? COLORS.primary : COLORS.text }}>
                    {file2 ? file2.name : 'Выберите файл .xls / .xlsx'}
                  </span>
                  <input
                    ref={file2Ref}
                    type="file"
                    accept=".xls,.xlsx"
                    onChange={handleFile2Change}
                    className="hidden"
                  />
                </label>
                {file2 && (
                  <button onClick={clearFile2} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Кнопка сверки */}
          <div className="mb-6">
            <button
              onClick={handleCompare}
              disabled={!file1 || !file2 || loading}
              className="px-6 py-3 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              style={{ backgroundColor: COLORS.primary }}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Обработка...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Сверить остатки
                </>
              )}
            </button>
          </div>
        </>
      )}

      {/* ====== Сообщения ====== */}
      {error && (
        <div className="mb-2 flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-red-50 text-red-700">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}



      {/* ====== Loading spinner ====== */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="w-10 h-10 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
          <span className="ml-3 text-sm" style={{ color: COLORS.text }}>Обработка файлов на сервере...</span>
        </div>
      )}

      {/* ====== Результаты ====== */}
      {hasResults && (
        <div className="bg-white rounded-xl shadow overflow-hidden">
          {/* Заголовок с поиском и кнопкой сброса */}
          <div className="px-5 py-3 border-b flex items-center justify-between gap-3" style={{ borderColor: '#f0f0f0' }}>
            <h3 className="font-semibold text-sm whitespace-nowrap" style={{ color: COLORS.heading }}>
              Результаты сверки ({filteredResults.length} из {results.length})
            </h3>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: COLORS.text }} />
                <input
                  type="text"
                  placeholder="Поиск по коду или наименованию..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-3 py-1.5 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 w-72"
                  style={{ borderColor: '#dee2e6' }}
                />
              </div>
              <button
                onClick={handleExportExcel}
                className="px-4 py-1.5 text-sm font-medium rounded-lg transition flex items-center gap-1.5 whitespace-nowrap text-white"
                style={{ backgroundColor: '#22c55e' }}
              >
                <Download className="w-3.5 h-3.5" />
                Выгрузить в Excel
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-1.5 text-sm font-medium rounded-lg border hover:bg-gray-50 transition flex items-center gap-1.5 whitespace-nowrap"
                style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Новая сверка
              </button>
            </div>
          </div>

          {/* Таблица */}
          <div className="overflow-x-auto max-h-[calc(100vh-200px)] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-10" style={{ backgroundColor: '#f8f9fa' }}>
                <tr>
                  <th className="px-4 py-2.5 text-left font-medium w-16" style={{ color: COLORS.heading }}>№ п.п</th>
                  <th className="px-4 py-2.5 text-left font-medium w-28" style={{ color: COLORS.heading }}>Код 1С</th>
                  <th className="px-4 py-2.5 text-left font-medium" style={{ color: COLORS.heading }}>Наименование</th>
                  <th className="px-4 py-2.5 text-right font-medium w-40" style={{ color: COLORS.heading }}>Остаток Excel (Главный + Учет)</th>
                  <th className="px-4 py-2.5 text-right font-medium w-32" style={{ color: COLORS.heading }}>Остаток WMS</th>
                </tr>
              </thead>
              <tbody>
                {filteredResults.map((row) => (
                  <tr key={row.code1c} className="border-t hover:bg-gray-50 transition" style={{ borderColor: '#f0f0f0' }}>
                    <td className="px-4 py-2.5" style={{ color: COLORS.text }}>{row.num}</td>
                    <td className="px-4 py-2.5 font-mono text-xs" style={{ color: COLORS.heading }}>{row.code1c}</td>
                    <td className="px-4 py-2.5" style={{ color: COLORS.heading }}>{row.name}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.excelQty.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.wmsQty.toLocaleString('ru-RU')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Пустое состояние — до сверки */}
      {results.length === 0 && !loading && !error && success === null && (
        <div className="bg-white rounded-xl shadow p-8 text-center">
          <FileSpreadsheet className="w-12 h-12 mx-auto mb-3" style={{ color: '#d1d5db' }} />
          <p className="text-sm" style={{ color: COLORS.text }}>
            Загрузите оба файла и нажмите «Сверить остатки» для получения результатов
          </p>
        </div>
      )}
    </div>
  );
}

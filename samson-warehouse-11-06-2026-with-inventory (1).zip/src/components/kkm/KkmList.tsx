'use client';

import React from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { KKM, Member, PageId } from '@/lib/types';

interface KkmListProps {
  kkms: KKM[];
  members: Member[];
  onNavigate: (page: PageId) => void;
}

export default function KkmList({ kkms, members, onNavigate }: KkmListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>ККМ</h2>
        <button onClick={() => onNavigate('kkm-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {kkms.map(kkm => {
          const assignedMembers = members.filter(m => m.kkmId === kkm.id);
          return (
            <div key={kkm.id} className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold" style={{ color: COLORS.heading }}>ККМ №{kkm.number}</h4>
              </div>
              <p className="text-sm" style={{ color: COLORS.text }}>С/N: {kkm.sn}</p>
              <p className="text-sm" style={{ color: COLORS.text }}>Инв. №: {kkm.inv}</p>
              <p className="text-sm mt-1" style={{ color: assignedMembers.length > 0 ? COLORS.heading : '#198754' }}>
                {assignedMembers.length > 0 ? assignedMembers.map(m => m.login).join(', ') : 'Свободен'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

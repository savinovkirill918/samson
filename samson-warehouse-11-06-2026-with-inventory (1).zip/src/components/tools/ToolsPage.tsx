'use client';

import React, { useState, useMemo } from 'react';
import { Calculator, Package, ChevronDown, ChevronUp, Box, ArrowRight, ArrowUp } from 'lucide-react';
import { COLORS } from '@/lib/colors';

/* =====================================================================
   Типы данных
   ===================================================================== */

interface OriResult {
  label: string;
  byLen: number;
  byWid: number;
  byHei: number;
  total: number;
  boxAlongLen: number;
  boxAlongWid: number;
  boxAlongHei: number;
}

interface MixedRegion {
  oriLabel: string;
  offsetL: number;
  offsetW: number;
  byLen: number;
  byWid: number;
  byHei: number;
  boxL: number;
  boxW: number;
  boxH: number;
  count: number;
}

interface MixedResult {
  label: string;
  regions: MixedRegion[];
  splitDirection: 'length' | 'width';
  splitAt: number;
  total: number;
}

interface CalcResult {
  best: OriResult;
  variants: OriResult[];
  bestMixed: MixedResult | null;
}

/* =====================================================================
   Генерация перестановок ориентаций
   ===================================================================== */

function generatePerms(
  boxL: number, boxW: number, boxH: number, canRotateFull: boolean,
): { perms: [number, number, number][]; labels: string[] } {
  if (canRotateFull) {
    const allPerms: [number, number, number][] = [
      [boxL, boxW, boxH],
      [boxL, boxH, boxW],
      [boxW, boxL, boxH],
      [boxW, boxH, boxL],
      [boxH, boxL, boxW],
      [boxH, boxW, boxL],
    ];
    const allLabels = [
      'Д \u00d7 Ш \u00d7 В',
      'Д \u00d7 В \u00d7 Ш',
      'Ш \u00d7 Д \u00d7 В',
      'Ш \u00d7 В \u00d7 Д',
      'В \u00d7 Д \u00d7 Ш',
      'В \u00d7 Ш \u00d7 Д',
    ];
    // Убираем дубли (если размеры совпадают)
    const seen = new Set<string>();
    const perms: [number, number, number][] = [];
    const labels: string[] = [];
    for (let i = 0; i < allPerms.length; i++) {
      const key = allPerms[i].join(',');
      if (!seen.has(key)) {
        seen.add(key);
        perms.push(allPerms[i]);
        labels.push(allLabels[i]);
      }
    }
    return { perms, labels };
  }
  // Высота фиксирована — поворот только Д ↔ Ш
  if (boxL === boxW) {
    return { perms: [[boxL, boxW, boxH]], labels: ['Д \u00d7 Ш \u00d7 В'] };
  }
  return {
    perms: [[boxL, boxW, boxH], [boxW, boxL, boxH]],
    labels: ['Д \u00d7 Ш \u00d7 В', 'Ш \u00d7 Д \u00d7 В'],
  };
}

/* =====================================================================
   Расчёт раскладок — однородные + смешанные (полный перебор пар)
   ===================================================================== */

function calcOrientations(
  boxL: number, boxW: number, boxH: number,
  cellL: number, cellW: number, effH: number,
  canRotateFull: boolean,
): CalcResult {
  const { perms, labels } = generatePerms(boxL, boxW, boxH, canRotateFull);

  // --- Однородные раскладки ---
  const variants: OriResult[] = perms.map(([bl, bw, bh], i) => {
    const byLen = Math.floor(cellL / bl);
    const byWid = Math.floor(cellW / bw);
    const byHei = Math.floor(effH / bh);
    return {
      label: labels[i], byLen, byWid, byHei,
      total: byLen * byWid * byHei,
      boxAlongLen: bl, boxAlongWid: bw, boxAlongHei: bh,
    };
  });

  const best = variants.reduce((a, b) => (b.total > a.total ? b : a), variants[0]);

  // --- Смешанные раскладки: перебор всех пар ориентаций ---
  let bestMixed: MixedResult | null = null;

  if (perms.length >= 2) {
    for (let i = 0; i < perms.length; i++) {
      for (let j = 0; j < perms.length; j++) {
        if (i === j) continue; // одинаковые ориентации — это однородная раскладка

        const [bl1, bw1, bh1] = perms[i];
        const [bl2, bw2, bh2] = perms[j];

        const byHei1 = Math.floor(effH / bh1);
        const byHei2 = Math.floor(effH / bh2);
        if (byHei1 === 0 && byHei2 === 0) continue;

        // Стратегия: разделение вдоль ДЛИНЫ ячейки
        // Регион 1 (ori i): k1 рядов вдоль длины, на всю ширину
        // Регион 2 (ori j): k2 рядов в остатке длины, на всю ширину
        const maxK1_len = Math.floor(cellL / bl1);
        for (let k1 = 0; k1 <= maxK1_len; k1++) {
          const usedL = k1 * bl1;
          const remainL = cellL - usedL;
          const k2 = Math.floor(remainL / bl2);
          if (k1 === 0 && k2 === 0) continue;

          const r1ByWid = Math.floor(cellW / bw1);
          const r2ByWid = Math.floor(cellW / bw2);
          const r1Count = k1 * r1ByWid;
          const r2Count = k2 * r2ByWid;

          const total = r1Count * byHei1 + r2Count * byHei2;
          if (total <= best.total) continue;
          if (bestMixed && total <= bestMixed.total) continue;

          bestMixed = {
            label: `Микс: ${r1Count * byHei1}шт ${labels[i]} + ${r2Count * byHei2}шт ${labels[j]}`,
            regions: [
              { oriLabel: labels[i], offsetL: 0, offsetW: 0, byLen: k1, byWid: r1ByWid, byHei: byHei1, boxL: bl1, boxW: bw1, boxH: bh1, count: r1Count * byHei1 },
              { oriLabel: labels[j], offsetL: usedL, offsetW: 0, byLen: k2, byWid: r2ByWid, byHei: byHei2, boxL: bl2, boxW: bw2, boxH: bh2, count: r2Count * byHei2 },
            ],
            splitDirection: 'length',
            splitAt: usedL,
            total,
          };
        }

        // Стратегия: разделение вдоль ШИРИНЫ ячейки
        const maxK1_wid = Math.floor(cellW / bw1);
        for (let k1 = 0; k1 <= maxK1_wid; k1++) {
          const usedW = k1 * bw1;
          const remainW = cellW - usedW;
          const k2 = Math.floor(remainW / bw2);
          if (k1 === 0 && k2 === 0) continue;

          const r1ByLen = Math.floor(cellL / bl1);
          const r2ByLen = Math.floor(cellL / bl2);
          const r1Count = r1ByLen * k1;
          const r2Count = r2ByLen * k2;

          const total = r1Count * byHei1 + r2Count * byHei2;
          if (total <= best.total) continue;
          if (bestMixed && total <= bestMixed.total) continue;

          bestMixed = {
            label: `Микс: ${r1Count * byHei1}шт ${labels[i]} + ${r2Count * byHei2}шт ${labels[j]}`,
            regions: [
              { oriLabel: labels[i], offsetL: 0, offsetW: 0, byLen: r1ByLen, byWid: k1, byHei: byHei1, boxL: bl1, boxW: bw1, boxH: bh1, count: r1Count * byHei1 },
              { oriLabel: labels[j], offsetL: 0, offsetW: usedW, byLen: r2ByLen, byWid: k2, byHei: byHei2, boxL: bl2, boxW: bw2, boxH: bh2, count: r2Count * byHei2 },
            ],
            splitDirection: 'width',
            splitAt: usedW,
            total,
          };
        }
      }
    }
  }

  return { best, variants, bestMixed };
}

/* =====================================================================
   Компонент страницы
   ===================================================================== */

export default function ToolsPage() {
  const [inputs, setInputs] = useState({
    taraLen: '', taraWid: '', taraHei: '',
    cellLen: '', cellWid: '', cellHei: '',
    kr3: '', heightPercent: '10',
  });

  const [canRotateFull, setCanRotateFull] = useState(false);
  const [showAllOri, setShowAllOri] = useState(false);

  const result = useMemo(() => {
    const tL = parseFloat(inputs.taraLen) || 0;
    const tW = parseFloat(inputs.taraWid) || 0;
    const tH = parseFloat(inputs.taraHei) || 0;
    const cL = parseFloat(inputs.cellLen) || 0;
    const cW = parseFloat(inputs.cellWid) || 0;
    const cH = parseFloat(inputs.cellHei) || 0;
    const kr3 = parseFloat(inputs.kr3) || 1;
    const hPct = parseFloat(inputs.heightPercent) || 0;

    if (!tL || !tW || !tH || !cL || !cW || !cH) return null;

    const effectiveHeight = cH * (1 - hPct / 100);
    const taraCalc = calcOrientations(tL, tW, tH, cL, cW, effectiveHeight, canRotateFull);

    return { taraCalc, kr3, effectiveHeight };
  }, [inputs, canRotateFull]);

  const bestTotal = result
    ? Math.max(result.taraCalc.best.total, result.taraCalc.bestMixed?.total ?? 0)
    : 0;

  const updateInput = (key: string, value: string) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  const inputField = (key: string, label: string) => (
    <div>
      <label className="block text-xs mb-1" style={{ color: COLORS.text }}>{label}</label>
      <input
        type="number" min="0" step="any"
        value={(inputs as Record<string, string>)[key]}
        onChange={e => updateInput(key, e.target.value)}
        className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-200"
        style={{ borderColor: '#dee2e6' }}
      />
    </div>
  );

  const renderOriTable = (items: { label: string; byLen: number; byWid: number; byHei: number; total: number }[], bestTotalVal: number) => (
    <table className="w-full text-xs mt-2">
      <thead>
        <tr style={{ color: COLORS.text }}>
          <th className="text-left py-1 font-medium">Раскладка</th>
          <th className="text-center py-1 font-medium">По длине</th>
          <th className="text-center py-1 font-medium">По ширине</th>
          <th className="text-center py-1 font-medium">Ярусов</th>
          <th className="text-center py-1 font-medium">Тар в ячейке</th>
        </tr>
      </thead>
      <tbody>
        {items.map((v) => {
          const isBest = v.total === bestTotalVal && v.total > 0;
          return (
            <tr key={v.label} className={isBest ? 'font-bold' : ''} style={{ color: isBest ? COLORS.primary : COLORS.heading }}>
              <td className="py-1">{isBest && <span className="mr-1">&#9733;</span>}{v.label}</td>
              <td className="text-center py-1">{v.byLen}</td>
              <td className="text-center py-1">{v.byWid}</td>
              <td className="text-center py-1">{v.byHei}</td>
              <td className="text-center py-1">{v.total}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Инструменты</h2>

      <div className="flex gap-4 items-start" style={{ flexWrap: 'wrap' }}>
        {/* ЛЕВАЯ КОЛОНКА */}
        <div className="bg-white rounded-xl shadow p-6" style={{ flex: '1 1 380px', minWidth: 340 }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.heading }}>
            <Calculator className="w-5 h-5" style={{ color: COLORS.primary }} /> Калькулятор вместимости ячейки
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center gap-1" style={{ color: COLORS.primary }}>
                <Package className="w-4 h-4" /> Тара
              </h4>
              <div className="space-y-2">
                {inputField('taraLen', 'Длина тары')}
                {inputField('taraWid', 'Ширина тары')}
                {inputField('taraHei', 'Высота тары')}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Ячейка</h4>
              <div className="space-y-2">
                {inputField('cellLen', 'Длина ячейки')}
                {inputField('cellWid', 'Ширина ячейки')}
                {inputField('cellHei', 'Высота ячейки')}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-4">
            {inputField('kr3', 'КР3 (шт. в таре)')}
            {inputField('heightPercent', '% вычитаемый из высоты')}
          </div>

          {/* Галочка поворота */}
          <div className="mt-4 p-3 rounded-lg space-y-2" style={{ backgroundColor: COLORS.alertBg }}>
            <div className="flex items-center gap-3">
              <input
                type="checkbox" id="canRotateFull"
                checked={canRotateFull}
                onChange={e => { setCanRotateFull(e.target.checked); setShowAllOri(false); }}
                className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
              />
              <label htmlFor="canRotateFull" className="text-sm cursor-pointer select-none" style={{ color: COLORS.heading }}>
                Можно класть на бок
              </label>
            </div>
            <div className="text-xs" style={{ color: COLORS.text }}>
              {canRotateFull
                ? 'Перебор всех 6 ориентаций (товар можно положить как угодно)'
                : 'Поворот только в плоскости (Д ↔ Ш), высота фиксирована'}
            </div>
          </div>

          {/* Результат */}
          {result && (
            <div className="mt-6 space-y-4">
              <div className="p-4 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium" style={{ color: COLORS.heading }}>
                    Вместимость тары в ячейку
                  </label>
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: COLORS.primary, color: '#fff' }}>
                    {result.taraCalc.bestMixed && result.taraCalc.bestMixed.total > result.taraCalc.best.total
                      ? 'Микс'
                      : result.taraCalc.best.label}
                  </span>
                </div>

                {result.taraCalc.bestMixed && result.taraCalc.bestMixed.total > result.taraCalc.best.total ? (
                  <div className="mb-3 text-xs space-y-1" style={{ color: COLORS.text }}>
                    {result.taraCalc.bestMixed.regions.map((r, i) => (
                      <div key={i}>
                        <strong style={{ color: i === 0 ? '#3b82f6' : '#f59e0b' }}>{r.oriLabel}</strong>:
                        {' '}{r.byLen}×{r.byWid}×{r.byHei} = {r.count} шт.
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-4 gap-2 mb-3 text-xs" style={{ color: COLORS.text }}>
                    <span>По длине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byLen}</strong></span>
                    <span>По ширине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byWid}</strong></span>
                    <span>По высоте: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byHei}</strong></span>
                    <span>Эфф. высота: <strong style={{ color: COLORS.heading }}>{result.effectiveHeight.toFixed(1)}</strong></span>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Тар в ячейке</label>
                    <input type="text" value={bestTotal} disabled
                      className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                      style={{ borderColor: '#dee2e6', color: '#856404' }}
                    />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: COLORS.text }}>
                      Итого шт. ({bestTotal} тар &times; {result.kr3} КР3)
                    </label>
                    <input type="text" value={bestTotal * result.kr3} disabled
                      className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                      style={{ borderColor: '#dee2e6', color: COLORS.primary }}
                    />
                  </div>
                </div>

                {(result.taraCalc.variants.length > 1 || result.taraCalc.bestMixed) && (
                  <button
                    onClick={() => setShowAllOri(!showAllOri)}
                    className="mt-3 text-xs flex items-center gap-1 hover:underline"
                    style={{ color: COLORS.primary }}
                  >
                    {showAllOri ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    {showAllOri ? 'Скрыть варианты раскладки' : 'Показать варианты раскладки'}
                  </button>
                )}
                {showAllOri && renderOriTable(
                  [
                    ...result.taraCalc.variants,
                    ...(result.taraCalc.bestMixed ? [{
                      label: result.taraCalc.bestMixed.label,
                      byLen: result.taraCalc.bestMixed.regions.map(r => r.byLen).join('+'),
                      byWid: result.taraCalc.bestMixed.regions.map(r => r.byWid).join('+'),
                      byHei: result.taraCalc.bestMixed.regions.map(r => r.byHei).join('+') as unknown as number,
                      total: result.taraCalc.bestMixed.total,
                    }] : []),
                  ],
                  bestTotal,
                )}
              </div>
            </div>
          )}

          {!result && (
            <div className="mt-6 p-4 rounded-lg text-center text-sm" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
              Заполните габариты тары и ячейки для расчёта
            </div>
          )}
        </div>

        {/* ПРАВАЯ КОЛОНКА: 3D */}
        <div style={{ flex: '1 1 420px', minWidth: 360 }}>
          {result && bestTotal > 0 ? (
            <CellVisualization3D
              cellL={parseFloat(inputs.cellLen) || 0}
              cellW={parseFloat(inputs.cellWid) || 0}
              cellH={parseFloat(inputs.cellHei) || 0}
              effectiveHeight={result.effectiveHeight}
              bestOri={result.taraCalc.best}
              bestMixed={result.taraCalc.bestMixed}
            />
          ) : (
            <div className="bg-white rounded-xl shadow p-6 flex flex-col items-center justify-center text-center" style={{ minHeight: 320 }}>
              <Box className="w-12 h-12 mb-3" style={{ color: '#cbd5e1' }} />
              <p className="text-sm" style={{ color: COLORS.text }}>
                Заполните габариты тары и ячейки<br />для визуализации
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* =====================================================================
   3D Визуализация ячейки
   ===================================================================== */

function isoProject(x: number, y: number, z: number): [number, number] {
  return [(x - z), (x + z) * 0.5 - y];
}

// Единый цвет коробок — синий (все ярусы одного цвета)
const BOX_COLOR = { top: '#60a5fa', left: '#3b82f6', right: '#2563eb' };

// Цвет коробок 2-го региона в микс-раскладке — оранжевый
const BOX_COLOR_MIX = { top: '#fdba74', left: '#fb923c', right: '#ea580c' };

interface CellVisualization3DProps {
  cellL: number; cellW: number; cellH: number;
  effectiveHeight: number;
  bestOri: OriResult;
  bestMixed: MixedResult | null;
}

function CellVisualization3D({
  cellL, cellW, cellH, effectiveHeight,
  bestOri, bestMixed,
}: CellVisualization3DProps) {
  const useMixed = bestMixed !== null && bestMixed.total > bestOri.total;
  const totalBoxes = useMixed ? bestMixed!.total : bestOri.total;
  const MAX_BOXES = 600;

  // ============ 3D Изометрия ============
  const allScreenPts: [number, number][] = [
    isoProject(0, 0, 0), isoProject(cellW, 0, 0),
    isoProject(0, cellH, 0), isoProject(cellW, cellH, 0),
    isoProject(0, 0, cellL), isoProject(cellW, 0, cellL),
    isoProject(0, cellH, cellL), isoProject(cellW, cellH, cellL),
  ];
  const rawMinX = Math.min(...allScreenPts.map(pt => pt[0]));
  const rawMaxX = Math.max(...allScreenPts.map(pt => pt[0]));
  const rawW = rawMaxX - rawMinX || 1;
  const scale3d = 300 / rawW;

  const pad3 = 50;
  const pts3 = [
    isoProject(0, 0, 0), isoProject(cellW * scale3d, 0, 0),
    isoProject(0, cellH * scale3d, 0), isoProject(cellW * scale3d, cellH * scale3d, 0),
    isoProject(0, 0, cellL * scale3d), isoProject(cellW * scale3d, 0, cellL * scale3d),
    isoProject(0, cellH * scale3d, cellL * scale3d), isoProject(cellW * scale3d, cellH * scale3d, cellL * scale3d),
  ];
  const minX3 = Math.min(...pts3.map(pt => pt[0])) - pad3;
  const maxX3 = Math.max(...pts3.map(pt => pt[0])) + pad3;
  const minY3 = Math.min(...pts3.map(pt => pt[1])) - pad3;
  const maxY3 = Math.max(...pts3.map(pt => pt[1])) + pad3;
  const svg3W = maxX3 - minX3;
  const svg3H = maxY3 - minY3;
  const off3X = -minX3;
  const off3Y = -minY3;

  const s = scale3d;
  const sW = cellW * s;
  const sL = cellL * s;
  const sH = cellH * s;
  const sEffH = effectiveHeight * s;
  const gap = 3 / s;

  const p = (x: number, y: number, z: number): [number, number] => {
    const [sx, sy] = isoProject(x, y, z);
    return [sx + off3X, sy + off3Y];
  };
  const poly = (points: [number, number][]) => points.map(pt => `${pt[0]},${pt[1]}`).join(' ');

  const floorPts = [p(0, 0, 0), p(sW, 0, 0), p(sW, 0, sL), p(0, 0, sL)];
  const backWallPts = [p(0, 0, sL), p(sW, 0, sL), p(sW, sH, sL), p(0, sH, sL)];
  const leftWallPts = [p(0, 0, 0), p(0, 0, sL), p(0, sH, sL), p(0, sH, 0)];
  const effLineBack = [p(0, sEffH, sL), p(sW, sEffH, sL)];
  const effLineLeft = [p(0, sEffH, 0), p(0, sEffH, sL)];

  const cellEdges: [number, number][][] = [
    [p(0, 0, 0), p(sW, 0, 0)], [p(sW, 0, 0), p(sW, 0, sL)],
    [p(sW, 0, sL), p(0, 0, sL)], [p(0, 0, sL), p(0, 0, 0)],
    [p(0, 0, 0), p(0, sH, 0)], [p(sW, 0, 0), p(sW, sH, 0)],
    [p(sW, 0, sL), p(sW, sH, sL)], [p(0, 0, sL), p(0, sH, sL)],
    [p(0, sH, 0), p(sW, sH, 0)], [p(sW, sH, 0), p(sW, sH, sL)],
    [p(sW, sH, sL), p(0, sH, sL)], [p(0, sH, sL), p(0, sH, 0)],
  ];

  // Линия разделения
  const splitLine: [number, number][] | null = useMixed && bestMixed
    ? bestMixed.splitDirection === 'length'
      ? [p(0, 0, bestMixed.splitAt * s), p(sW, 0, bestMixed.splitAt * s)]
      : [p(bestMixed.splitAt * s, 0, 0), p(bestMixed.splitAt * s, 0, sL)]
    : null;

  // ============ Ящики ============
  interface BoxItem { col: number; row: number; layer: number; x: number; y: number; z: number; bw: number; bl: number; bh: number; regionIdx: number; }
  const boxes: BoxItem[] = [];

  if (totalBoxes <= MAX_BOXES) {
    if (useMixed && bestMixed) {
      for (let ri = 0; ri < bestMixed.regions.length; ri++) {
        const region = bestMixed.regions[ri];
        const sBoxW = region.boxW * s - (region.byWid > 1 ? gap * s : 0);
        const sBoxL = region.boxL * s - (region.byLen > 1 ? gap * s : 0);
        const sBoxH = region.boxH * s - (region.byHei > 1 ? gap * s : 0);

        for (let row = region.byLen - 1; row >= 0; row--) {
          for (let layer = 0; layer < region.byHei; layer++) {
            for (let col = region.byWid - 1; col >= 0; col--) {
              boxes.push({
                col, row, layer, regionIdx: ri,
                x: region.offsetW * s + col * region.boxW * s + (region.byWid > 1 ? gap * s * col / (region.byWid - 1) * 0.5 : 0),
                y: layer * region.boxH * s + (region.byHei > 1 ? gap * s * layer / (region.byHei - 1) * 0.5 : 0),
                z: region.offsetL * s + row * region.boxL * s + (region.byLen > 1 ? gap * s * row / (region.byLen - 1) * 0.5 : 0),
                bw: sBoxW, bl: sBoxL, bh: sBoxH,
              });
            }
          }
        }
      }
    } else {
      const { byLen, byWid, byHei, boxAlongLen, boxAlongWid, boxAlongHei } = bestOri;
      const sbW = boxAlongWid * s - (byWid > 1 ? gap * s : 0);
      const sbL = boxAlongLen * s - (byLen > 1 ? gap * s : 0);
      const sbH = boxAlongHei * s - (byHei > 1 ? gap * s : 0);

      for (let row = byLen - 1; row >= 0; row--) {
        for (let layer = 0; layer < byHei; layer++) {
          for (let col = byWid - 1; col >= 0; col--) {
            boxes.push({
              col, row, layer, regionIdx: 0,
              x: col * boxAlongWid * s + (byWid > 1 ? gap * s * col / (byWid - 1) * 0.5 : 0),
              y: layer * boxAlongHei * s + (byHei > 1 ? gap * s * layer / (byHei - 1) * 0.5 : 0),
              z: row * boxAlongLen * s + (byLen > 1 ? gap * s * row / (byLen - 1) * 0.5 : 0),
              bw: sbW, bl: sbL, bh: sbH,
            });
          }
        }
      }
    }
  }

  // Подписи
  const dimOff = 14;
  const dimLMid = p(-dimOff, 0, sL / 2);
  const dimWMid = p(sW / 2, 0, -dimOff);
  const dimHMid = p(-dimOff, sH / 2, 0);
  const arrowLen = 30;
  const arrL = { start: p(-8, 0, 0), end: p(-8, 0, arrowLen), label: p(-16, -2, arrowLen / 2) };
  const arrW = { start: p(0, 0, -8), end: p(arrowLen, 0, -8), label: p(arrowLen / 2, -6, -16) };
  const arrH = { start: p(-8, 0, 0), end: p(-8, arrowLen, 0), label: p(-22, arrowLen / 2, 0) };

  // ============ 2D План ============
  const planW = 240, planH = 240, planPad = 30;
  const planAreaW = planW - planPad * 2, planAreaH = planH - planPad * 2;
  const planScaleW = planAreaW / cellW, planScaleL = planAreaH / cellL;
  const planScale = Math.min(planScaleW, planScaleL);
  const planCellW = cellW * planScale, planCellL = cellL * planScale;
  const planOffX = planPad + (planAreaW - planCellW) / 2;
  const planOffY = planPad + (planAreaH - planCellL) / 2;

  const layoutLabel = useMixed && bestMixed
    ? `Микс: ${bestMixed.regions.map(r => `${r.count}шт ${r.oriLabel}`).join(' + ')}`
    : bestOri.label;

  return (
    <div className="bg-white rounded-xl shadow p-4">
      <h3 className="font-semibold mb-2 flex items-center gap-2 text-sm" style={{ color: COLORS.heading }}>
        <Box className="w-4 h-4" style={{ color: COLORS.primary }} /> Визуализация ячейки
      </h3>
      <div className="text-xs mb-2" style={{ color: COLORS.text }}>
        <strong style={{ color: COLORS.primary }}>{layoutLabel}</strong> &nbsp;|&nbsp;
        <strong>{totalBoxes}</strong> тар
      </div>

      {/* 3D изометрия */}
      <div style={{ width: '100%', overflowX: 'auto' }}>
        <svg width={svg3W} height={svg3H} viewBox={`0 0 ${svg3W} ${svg3H}`} style={{ display: 'block', margin: '0 auto' }}>
          <defs>
            <marker id="ah" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#64748b" />
            </marker>
          </defs>

          <polygon points={poly(floorPts)} fill="#e2e8f0" stroke="#94a3b8" strokeWidth={1} opacity={0.5} />
          <polygon points={poly(backWallPts)} fill="#cbd5e1" stroke="#94a3b8" strokeWidth={1} opacity={0.25} />
          <polygon points={poly(leftWallPts)} fill="#cbd5e1" stroke="#94a3b8" strokeWidth={1} opacity={0.25} />

          <line x1={effLineBack[0][0]} y1={effLineBack[0][1]} x2={effLineBack[1][0]} y2={effLineBack[1][1]} stroke="#ef4444" strokeWidth={1.2} strokeDasharray="5 3" opacity={0.7} />
          <line x1={effLineLeft[0][0]} y1={effLineLeft[0][1]} x2={effLineLeft[1][0]} y2={effLineLeft[1][1]} stroke="#ef4444" strokeWidth={1.2} strokeDasharray="5 3" opacity={0.7} />

          {splitLine && (
            <line x1={splitLine[0][0]} y1={splitLine[0][1]} x2={splitLine[1][0]} y2={splitLine[1][1]} stroke="#f97316" strokeWidth={1.5} strokeDasharray="6 3" opacity={0.8} />
          )}

          {totalBoxes <= MAX_BOXES && [...boxes].sort((a, b) => {
            // Сортировка по глубине: задние-нижние-левые сначала
            const da = a.z + a.x * 0.5 + a.y;
            const db = b.z + b.x * 0.5 + b.y;
            return da - db;
          }).map((box, idx) => {
            const { x, y, z, bw, bl, bh, regionIdx } = box;
            const lc = useMixed && regionIdx === 1 ? BOX_COLOR_MIX : BOX_COLOR;
            const topPts = [p(x, y + bh, z), p(x + bw, y + bh, z), p(x + bw, y + bh, z + bl), p(x, y + bh, z + bl)];
            const leftPts = [p(x, y, z + bl), p(x + bw, y, z + bl), p(x + bw, y + bh, z + bl), p(x, y + bh, z + bl)];
            const rightPts = [p(x + bw, y, z), p(x + bw, y + bh, z), p(x + bw, y + bh, z + bl), p(x + bw, y, z + bl)];
            return (
              <g key={idx}>
                <polygon points={poly(leftPts)} fill={lc.left} stroke="#1e293b" strokeWidth={1.5} opacity={1.0} />
                <polygon points={poly(rightPts)} fill={lc.right} stroke="#1e293b" strokeWidth={1.5} opacity={1.0} />
                <polygon points={poly(topPts)} fill={lc.top} stroke="#1e293b" strokeWidth={1.0} opacity={1.0} />
              </g>
            );
          })}

          {totalBoxes > MAX_BOXES && (
            <text x={svg3W / 2} y={svg3H / 2} textAnchor="middle" fontSize={13} fill={COLORS.text}>
              Слишком много ящиков ({totalBoxes})
            </text>
          )}

          {cellEdges.map(([a, b], i) => (
            <line key={`e${i}`} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="#475569" strokeWidth={1.8} strokeLinecap="round" />
          ))}

          <line x1={arrL.start[0]} y1={arrL.start[1]} x2={arrL.end[0]} y2={arrL.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrL.label[0]} y={arrL.label[1]} textAnchor="middle" fontSize={9} fill="#64748b" fontWeight={700}>Д</text>
          <line x1={arrW.start[0]} y1={arrW.start[1]} x2={arrW.end[0]} y2={arrW.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrW.label[0]} y={arrW.label[1]} textAnchor="middle" fontSize={9} fill="#64748b" fontWeight={700}>Ш</text>
          <line x1={arrH.start[0]} y1={arrH.start[1]} x2={arrH.end[0]} y2={arrH.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrH.label[0]} y={arrH.label[1]} textAnchor="end" fontSize={9} fill="#64748b" fontWeight={700}>В</text>

          <text x={dimLMid[0]} y={dimLMid[1] + 4} textAnchor="middle" fontSize={10} fill="#475569" fontWeight={600}>{cellL}</text>
          <text x={dimWMid[0]} y={dimWMid[1] + 4} textAnchor="middle" fontSize={10} fill="#475569" fontWeight={600}>{cellW}</text>
          <text x={dimHMid[0] - 4} y={dimHMid[1]} textAnchor="end" fontSize={10} fill="#475569" fontWeight={600}>{cellH}</text>

          <text x={p(-dimOff - 4, sEffH, sL)[0]} y={p(-dimOff - 4, sEffH, sL)[1]} textAnchor="end" fontSize={9} fill="#ef4444" fontWeight={600}>
            h={effectiveHeight.toFixed(1)}
          </text>
        </svg>
      </div>

      {/* 2D План */}
      <div className="mt-3 pt-3" style={{ borderTop: '1px solid #e2e8f0' }}>
        <p className="text-xs font-medium mb-1" style={{ color: COLORS.heading }}>
          План раскладки <span style={{ color: COLORS.text, fontWeight: 400 }}>(вид сверху, ярус 1)</span>
        </p>
        <svg width={planW} height={planH} viewBox={`0 0 ${planW} ${planH}`} style={{ display: 'block', margin: '0 auto' }}>
          <rect x={planOffX} y={planOffY} width={planCellW} height={planCellL} fill="#f1f5f9" stroke="#475569" strokeWidth={1.5} rx={2} />

          {useMixed && bestMixed ? (
            <>
              {bestMixed.regions.map((region, ri) => {
                const pBoxW = region.boxW * planScale;
                const pBoxL = region.boxL * planScale;
                const color = ri === 0 ? BOX_COLOR : BOX_COLOR_MIX;
                return Array.from({ length: region.byLen }, (_, row) =>
                  Array.from({ length: region.byWid }, (_, col) => {
                    const bx = planOffX + (region.offsetW + col * region.boxW) * planScale + (region.byWid > 1 ? 0.5 : 0);
                    const by = planOffY + (region.offsetL + row * region.boxL) * planScale + (region.byLen > 1 ? 0.5 : 0);
                    return <rect key={`m${ri}-${row}-${col}`} x={bx} y={by} width={pBoxW - (region.byWid > 1 ? 1 : 0)} height={pBoxL - (region.byLen > 1 ? 1 : 0)} fill={color.top} stroke="#1e293b" strokeWidth={1.2} rx={1.5} opacity={0.95} />;
                  })
                );
              })}
              {bestMixed.splitDirection === 'length' ? (
                <line x1={planOffX} y1={planOffY + bestMixed.splitAt * planScale} x2={planOffX + planCellW} y2={planOffY + bestMixed.splitAt * planScale} stroke="#f97316" strokeWidth={1.2} strokeDasharray="4 2" opacity={0.7} />
              ) : (
                <line x1={planOffX + bestMixed.splitAt * planScale} y1={planOffY} x2={planOffX + bestMixed.splitAt * planScale} y2={planOffY + planCellL} stroke="#f97316" strokeWidth={1.2} strokeDasharray="4 2" opacity={0.7} />
              )}
            </>
          ) : (
            <>
              {Array.from({ length: bestOri.byLen }, (_, row) =>
                Array.from({ length: bestOri.byWid }, (_, col) => {
                  const bx = planOffX + col * bestOri.boxAlongWid * planScale + (bestOri.byWid > 1 ? 0.5 : 0);
                  const by = planOffY + row * bestOri.boxAlongLen * planScale + (bestOri.byLen > 1 ? 0.5 : 0);
                  return <rect key={`${row}-${col}`} x={bx} y={by} width={bestOri.boxAlongWid * planScale - (bestOri.byWid > 1 ? 1 : 0)} height={bestOri.boxAlongLen * planScale - (bestOri.byLen > 1 ? 1 : 0)} fill={BOX_COLOR.top} stroke="#1e293b" strokeWidth={1.2} rx={1.5} opacity={0.95} />;
                })
              )}
            </>
          )}

          {/* Зазоры */}
          {useMixed && bestMixed ? (() => {
            const usedW = bestMixed.regions.reduce((mx, r) => Math.max(mx, r.offsetW + r.byWid * r.boxW), 0);
            const usedL = bestMixed.regions.reduce((mx, r) => Math.max(mx, r.offsetL + r.byLen * r.boxL), 0);
            return <>
              {cellW - usedW > 0.1 && <rect x={planOffX + usedW * planScale} y={planOffY} width={(cellW - usedW) * planScale} height={planCellL} fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6} />}
              {cellL - usedL > 0.1 && <rect x={planOffX} y={planOffY + usedL * planScale} width={planCellW} height={(cellL - usedL) * planScale} fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6} />}
            </>;
          })() : (<>
            {cellW - bestOri.byWid * bestOri.boxAlongWid > 0.1 && <rect x={planOffX + bestOri.byWid * bestOri.boxAlongWid * planScale} y={planOffY} width={(cellW - bestOri.byWid * bestOri.boxAlongWid) * planScale} height={planCellL} fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6} />}
            {cellL - bestOri.byLen * bestOri.boxAlongLen > 0.1 && <rect x={planOffX} y={planOffY + bestOri.byLen * bestOri.boxAlongLen * planScale} width={planCellW} height={(cellL - bestOri.byLen * bestOri.boxAlongLen) * planScale} fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6} />}
          </>)}
        </svg>
      </div>

      {/* Легенда */}
      {useMixed && bestMixed ? (
        <div className="flex flex-wrap gap-2 mt-2">
          {bestMixed.regions.map((region, ri) => {
            const color = ri === 0 ? BOX_COLOR : BOX_COLOR_MIX;
            return (
              <div key={ri} className="flex items-center gap-1 text-xs" style={{ color: COLORS.heading }}>
                <span className="inline-block w-3 h-3 rounded-sm border" style={{ backgroundColor: color.top, borderColor: color.right }} />
                {region.oriLabel} ({region.count} шт.)
              </div>
            );
          })}
        </div>
      ) : bestOri.byHei > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          <div className="flex items-center gap-1 text-xs" style={{ color: COLORS.heading }}>
            <span className="inline-block w-3 h-3 rounded-sm border" style={{ backgroundColor: BOX_COLOR.top, borderColor: BOX_COLOR.right }} />
            Тара ({bestOri.byLen * bestOri.byWid} × {bestOri.byHei} яр. = {bestOri.total})
          </div>
        </div>
      )}

      {/* Зазоры */}
      {(() => {
        if (useMixed && bestMixed) {
          const usedW = bestMixed.regions.reduce((mx, r) => Math.max(mx, r.offsetW + r.byWid * r.boxW), 0);
          const usedL = bestMixed.regions.reduce((mx, r) => Math.max(mx, r.offsetL + r.byLen * r.boxL), 0);
          const usedH = bestMixed.regions.reduce((mx, r) => Math.max(mx, r.byHei * r.boxH), 0);
          return (
            <div className="mt-2 text-xs p-2 rounded-lg" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
              <span style={{ color: COLORS.heading, fontWeight: 600 }}>Зазоры:</span>{' '}
              Д: {(cellL - usedL).toFixed(1)} &nbsp;|&nbsp;
              Ш: {(cellW - usedW).toFixed(1)} &nbsp;|&nbsp;
              В: {(effectiveHeight - usedH).toFixed(1)}
              <span className="ml-1" style={{ color: '#ef4444' }}>(эфф. h={effectiveHeight.toFixed(1)})</span>
            </div>
          );
        } else if (bestOri.byLen > 0 && bestOri.byWid > 0 && bestOri.byHei > 0) {
          return (
            <div className="mt-2 text-xs p-2 rounded-lg" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
              <span style={{ color: COLORS.heading, fontWeight: 600 }}>Зазоры:</span>{' '}
              Д: {(cellL - bestOri.byLen * bestOri.boxAlongLen).toFixed(1)} &nbsp;|&nbsp;
              Ш: {(cellW - bestOri.byWid * bestOri.boxAlongWid).toFixed(1)} &nbsp;|&nbsp;
              В: {(effectiveHeight - bestOri.byHei * bestOri.boxAlongHei).toFixed(1)}
              <span className="ml-1" style={{ color: '#ef4444' }}>(эфф. h={effectiveHeight.toFixed(1)})</span>
            </div>
          );
        }
        return null;
      })()}
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PrinterConsumption, Printer, PageId } from '@/lib/types';

interface PrinterConsumptionPageProps {
  consumption: PrinterConsumption[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEdit: (record: PrinterConsumption) => void;
  onAdd: (data: { printerId: number; month: string }) => void;
  onEditPrinter?: (printer: Printer) => void;
}

/** Форматирование числа с пробелами-разделителями */
function fmtNum(n: number): string {
  return n.toLocaleString('ru-RU');
}

/** Формат месяца "2026-05" → "05" */
function fmtMonthShort(m: string): string {
  return m.split('-')[1];
}

/** Получить год из "2026-05" */
function getYear(m: string): string {
  return m.split('-')[0];
}

/** Цвет фона для коэффициента расхода */
function coefBgColor(coef: number): string {
  if (coef <= 0) return 'transparent';
  if (coef < 0.5) return '#d1e7dd';
  if (coef <= 1.0) return '#fff3cd';
  return '#f8d7da';
}

/** Цвет текста для коэффициента расхода */
function coefTextColor(coef: number): string {
  if (coef <= 0) return COLORS.text;
  if (coef < 0.5) return '#0f5132';
  if (coef <= 1.0) return '#664d03';
  return '#842029';
}

/** Рассчитать расход: pages/coef */
function calcConsumption(
  currentCounter: number,
  prevCounter: number | null,
  cartridgeYield: number
): { pages: number; coef: number } | null {
  if (prevCounter === null) return null;
  const pages = currentCounter - prevCounter;
  const coef = cartridgeYield > 0 ? pages / cartridgeYield : 0;
  return { pages, coef };
}

/** Тип фильтра периода */
type PeriodFilter = 'last3months' | 'currentYear' | 'allTime';

/** Получить текущий год-месяц в формате "YYYY-MM" */
function getCurrentYearMonth(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** Получить предыдущий месяц в формате "YYYY-MM" */
function getPrevYearMonth(ym: string): string {
  const [y, m] = ym.split('-').map(Number);
  if (m === 1) return `${y - 1}-12`;
  return `${y}-${String(m - 1).padStart(2, '0')}`;
}

export default function PrinterConsumptionPage({ consumption, printers, onNavigate, onEdit, onAdd, onEditPrinter }: PrinterConsumptionPageProps) {
  const [filterLocation, setFilterLocation] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<PeriodFilter>('last3months');

  // Все уникальные месяцы из данных, сортируем по возрастанию (для поиска данных)
  const allMonths = useMemo(() => {
    const months = new Set<string>();
    consumption.forEach(c => months.add(c.month));
    return Array.from(months).sort();
  }, [consumption]);

  // Отфильтрованные месяцы по выбранному периоду
  const displayedMonths = useMemo(() => {
    if (filterPeriod === 'allTime') return allMonths;
    if (filterPeriod === 'currentYear') {
      const currentYear = new Date().getFullYear().toString();
      return allMonths.filter(m => getYear(m) === currentYear);
    }
    const cur = getCurrentYearMonth();
    const prev1 = getPrevYearMonth(cur);
    const prev2 = getPrevYearMonth(prev1);
    const set = new Set([prev2, prev1, cur]);
    return allMonths.filter(m => set.has(m));
  }, [allMonths, filterPeriod]);

  // Группируем отображаемые месяцы по годам
  const yearGroups = useMemo(() => {
    const groups: { year: string; months: string[] }[] = [];
    let currentYear = '';
    for (const m of displayedMonths) {
      const y = getYear(m);
      if (y !== currentYear) {
        groups.push({ year: y, months: [] });
        currentYear = y;
      }
      groups[groups.length - 1].months.push(m);
    }
    return groups;
  }, [displayedMonths]);

  // Уникальные кабинеты для фильтра
  const locations = useMemo(() => {
    const locs = new Set<string>();
    printers.forEach(p => { if (p.location) locs.add(p.location); });
    return Array.from(locs).sort();
  }, [printers]);

  // Строим структуру данных: для каждого принтера — мапа month → totalCounter
  const printerDataMap = useMemo(() => {
    const map = new Map<number, Map<string, number>>();
    consumption.forEach(c => {
      if (!map.has(c.printerId)) map.set(c.printerId, new Map());
      map.get(c.printerId)!.set(c.month, c.totalCounter);
    });
    return map;
  }, [consumption]);

  // Фильтрованные принтеры
  const filteredPrinters = useMemo(() => {
    return printers.filter(p => {
      if (filterLocation && p.location !== filterLocation) return false;
      return true;
    });
  }, [printers, filterLocation]);

  // Получить предыдущий счётчик для принтера в данном месяце
  const getPrevCounter = (printerId: number, monthIndex: number): number | null => {
    const pMap = printerDataMap.get(printerId);
    if (!pMap) return null;
    for (let i = monthIndex - 1; i >= 0; i--) {
      const counter = pMap.get(allMonths[i]);
      if (counter !== undefined) return counter;
    }
    return null;
  };

  // Подсчёт итогов по каждому отображаемому месяцу (только pages)
  const monthlyTotals = useMemo(() => {
    const totals = new Map<string, number>();
    displayedMonths.forEach(month => {
      let pages = 0;
      const monthIdx = allMonths.indexOf(month);
      filteredPrinters.forEach(printer => {
        const pMap = printerDataMap.get(printer.id);
        const counter = pMap?.get(month);
        if (counter !== undefined) {
          const prev = getPrevCounter(printer.id, monthIdx);
          if (prev !== null) {
            pages += counter - prev;
          }
        }
      });
      totals.set(month, pages);
    });
    return totals;
  }, [displayedMonths, allMonths, filteredPrinters, printerDataMap]);

  // Общее количество напечатанных страниц за отображаемый период
  const totalPages = useMemo(() => {
    let sum = 0;
    monthlyTotals.forEach(v => sum += v);
    return sum;
  }, [monthlyTotals]);

  const colSpanTotal = 3 + displayedMonths.length * 2;

  const periodLabels: { value: PeriodFilter; label: string }[] = [
    { value: 'last3months', label: 'Последние 3 месяца' },
    { value: 'currentYear', label: 'Текущий год' },
    { value: 'allTime', label: 'За всё время' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Фильтры — не скроллятся */}
      <div className="flex flex-wrap items-end gap-3 mb-4" style={{ flexShrink: 0 }}>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: COLORS.text }}>Период</label>
          <select
            value={filterPeriod}
            onChange={e => setFilterPeriod(e.target.value as PeriodFilter)}
            className="px-3 py-1.5 border rounded-lg text-sm"
            style={{ borderColor: '#dee2e6' }}
          >
            {periodLabels.map(p => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: COLORS.text }}>Кабинет</label>
          <select value={filterLocation} onChange={e => setFilterLocation(e.target.value)} className="px-3 py-1.5 border rounded-lg text-sm" style={{ borderColor: '#dee2e6' }}>
            <option value="">Все</option>
            {locations.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <button
          onClick={() => onNavigate('printer-consumption-add')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
          style={{ borderColor: '#198754', color: '#198754' }}
        >
          <Plus className="w-3.5 h-3.5" /> Ввести счётчик
        </button>
      </div>

      {/* Таблица — скроллится только здесь */}
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full text-sm" style={{ minWidth: displayedMonths.length * 140 + 460, borderCollapse: 'separate', borderSpacing: 0 }}>
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              {/* Заголовок с годами */}
              <tr style={{ backgroundColor: '#e9ecef' }}>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap" style={{ color: COLORS.heading, backgroundColor: '#e9ecef', minWidth: 50, position: 'sticky', left: 0, zIndex: 30, borderBottom: '1px solid #dee2e6' }}>№</th>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap" style={{ color: COLORS.heading, backgroundColor: '#e9ecef', minWidth: 250, position: 'sticky', left: 50, zIndex: 30, borderBottom: '1px solid #dee2e6' }}>Модель принтера</th>

                {yearGroups.map(g => (
                  <th key={g.year} colSpan={g.months.length * 2} className="text-center px-2 py-2 font-bold whitespace-nowrap" style={{ color: COLORS.heading, borderLeft: '2px solid #adb5bd', borderRight: '2px solid #adb5bd', fontSize: '0.85rem', backgroundColor: '#e9ecef', borderBottom: '1px solid #dee2e6' }}>
                    {g.year}
                  </th>
                ))}
              </tr>
              {/* Заголовки месяцев */}
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                {yearGroups.map(g => g.months.map((month, mi) => (
                  <React.Fragment key={month}>
                    <th className="text-center px-1 py-1.5 font-medium whitespace-nowrap" style={{ color: COLORS.heading, backgroundColor: mi % 2 === 0 ? '#f0f4ff' : '#f8f9fa', fontSize: '0.7rem', borderLeft: mi === 0 ? '2px solid #adb5bd' : undefined, borderBottom: '2px solid #dee2e6' }}>
                      {fmtMonthShort(month)}
                    </th>
                    <th className="text-center px-1 py-1.5 font-medium whitespace-nowrap" style={{ color: '#6c757d', backgroundColor: mi % 2 === 0 ? '#f0f4ff' : '#f8f9fa', fontSize: '0.7rem', borderBottom: '2px solid #dee2e6' }}>
                      Расход
                    </th>
                  </React.Fragment>
                )))}
              </tr>
            </thead>
            <tbody>
              {filteredPrinters.length > 0 ? filteredPrinters.map((printer, idx) => {
                const pMap = printerDataMap.get(printer.id);
                const isWrittenOff = printer.status === 2;
                const cartModel = printer.cartridgeModel;
                const yield_ = cartModel?.expectedYield ?? 0;

                return (
                  <tr
                    key={printer.id}
                    className="transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    {/* № */}
                    <td className="px-3 py-2 font-medium whitespace-nowrap" style={{ color: COLORS.heading, backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', fontSize: '0.8rem', minWidth: 50, position: 'sticky', left: 0, zIndex: 5 }}>
                      {printer.number}
                    </td>
                    {/* Модель принтера */}
                    <td
                      className="px-3 py-2 font-medium whitespace-nowrap"
                      style={{ color: COLORS.primary, backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', fontSize: '0.8rem', minWidth: 250, position: 'sticky', left: 50, zIndex: 5 }}
                    >
                      {printer.model}
                      {printer.location && <span style={{ color: '#9ca3af', fontWeight: 400 }}> ({printer.location})</span>}
                    </td>

                    {/* Месяцы */}
                    {yearGroups.map(g => g.months.map((month, mi) => {
                      const globalMi = allMonths.indexOf(month);
                      const counter = pMap?.get(month);
                      const prevCounter = counter !== undefined ? getPrevCounter(printer.id, globalMi) : null;
                      const hasData = counter !== undefined;
                      const consumptionData = hasData && prevCounter !== null
                        ? calcConsumption(counter, prevCounter, yield_)
                        : null;

                      const showCounter = hasData && counter !== 0;
                      const isFirstMonth = hasData && prevCounter === null;

                      return (
                        <React.Fragment key={month}>
                          {/* Счётчик */}
                          <td
                            className="px-1.5 py-2 text-right whitespace-nowrap cursor-pointer"
                            style={{
                              backgroundColor: globalMi % 2 === 0 ? (idx % 2 === 0 ? '#f5f7ff' : '#eef1fa') : 'transparent',
                              fontSize: '0.8rem',
                              color: COLORS.heading,
                              borderLeft: mi === 0 ? '2px solid #dee2e6' : undefined,
                            }}
                            onClick={() => {
                              if (isWrittenOff) return;
                              if (hasData) {
                                const rec = consumption.find(c => c.printerId === printer.id && c.month === month);
                                if (rec) onEdit(rec);
                              } else {
                                onAdd({ printerId: printer.id, month });
                              }
                            }}
                          >
                            {isWrittenOff ? (
                              <span className="px-1 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: '#fce4ec', color: '#c62828' }}>Списан</span>
                            ) : showCounter ? (
                              fmtNum(counter)
                            ) : hasData && counter === 0 ? (
                              <span style={{ color: '#ccc' }}>0</span>
                            ) : (
                              <span style={{ color: '#eee' }}>—</span>
                            )}
                          </td>
                          {/* Расход */}
                          <td
                            className="px-1.5 py-2 text-right whitespace-nowrap cursor-pointer"
                            style={{
                              backgroundColor: consumptionData ? coefBgColor(consumptionData.coef) : (globalMi % 2 === 0 ? (idx % 2 === 0 ? '#f5f7ff' : '#eef1fa') : 'transparent'),
                              fontSize: '0.8rem',
                              color: consumptionData ? coefTextColor(consumptionData.coef) : COLORS.text,
                              fontWeight: consumptionData && consumptionData.coef > 1 ? 600 : 400,
                            }}
                            onClick={() => {
                              if (isWrittenOff) return;
                              if (hasData) {
                                const rec = consumption.find(c => c.printerId === printer.id && c.month === month);
                                if (rec) onEdit(rec);
                              } else {
                                onAdd({ printerId: printer.id, month });
                              }
                            }}
                          >
                            {isWrittenOff ? '' : consumptionData ? (
                              <span>
                                {fmtNum(consumptionData.pages)}/{consumptionData.coef.toFixed(2).replace('.', ',')}
                              </span>
                            ) : isFirstMonth ? (
                              <span style={{ color: '#aaa', fontSize: '0.7rem' }}>первый</span>
                            ) : (
                              <span style={{ color: '#eee' }}>—</span>
                            )}
                          </td>
                        </React.Fragment>
                      );
                    }))}
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={colSpanTotal} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет данных</td>
                </tr>
              )}
              {/* Итоговая строка */}
              {filteredPrinters.length > 0 && (
                <tr style={{ backgroundColor: '#f8f9fa', borderTop: '2px solid #adb5bd', borderBottom: '2px solid #adb5bd' }}>
                  <td className="px-3 py-2" style={{ backgroundColor: '#f8f9fa', minWidth: 50, position: 'sticky', left: 0, zIndex: 5 }} />
                  <td className="px-3 py-2 font-bold" style={{ color: COLORS.heading, backgroundColor: '#f8f9fa', fontSize: '0.8rem', minWidth: 250, position: 'sticky', left: 50, zIndex: 5 }}>
                    ИТОГО: {fmtNum(totalPages)} стр.
                  </td>

                  {yearGroups.map(g => g.months.map((month, mi) => {
                    const total = monthlyTotals.get(month);
                    return (
                      <React.Fragment key={month}>
                        <td style={{ backgroundColor: '#f8f9fa', borderLeft: mi === 0 ? '2px solid #dee2e6' : undefined }} />
                        <td className="px-1.5 py-2 text-right whitespace-nowrap font-semibold" style={{ backgroundColor: '#f8f9fa', color: COLORS.heading, fontSize: '0.75rem' }}>
                          {total && total > 0 ? fmtNum(total) : <span style={{ color: '#ccc' }}>—</span>}
                        </td>
                      </React.Fragment>
                    );
                  }))}
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Легенда */}
      <div className="mt-3 flex items-center gap-4 text-xs" style={{ color: COLORS.text, flexShrink: 0 }}>
        <span>Коэффициент расхода:</span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#d1e7dd' }} /> &lt; 0,5
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#fff3cd' }} /> 0,5 — 1,0
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#f8d7da' }} /> &gt; 1,0
        </span>
      </div>
    </div>
  );
}

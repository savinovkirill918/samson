'use client';

import React, { useState, useEffect } from 'react';
import { COLORS } from '@/lib/colors';
import type { PrinterConsumption, Printer, PageId } from '@/lib/types';
import { currentMonth } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterConsumptionFormProps {
  editingRecord?: PrinterConsumption | null;
  printers: Printer[];
  onSave: (data: { printerId: number; month: string; totalCounter: number }) => void;
  onUpdate?: (data: Partial<PrinterConsumption> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
  initialData?: { printerId: number; month: string } | null;
}

export default function PrinterConsumptionForm({ editingRecord, printers, onSave, onUpdate, onNavigate, initialData }: PrinterConsumptionFormProps) {
  const isEdit = !!editingRecord;

  const [form, setForm] = useState({
    printerId: editingRecord?.printerId ?? initialData?.printerId ?? printers[0]?.id ?? 0,
    month: editingRecord?.month ?? initialData?.month ?? currentMonth(),
    totalCounter: editingRecord?.totalCounter ?? 0,
  });

  useEffect(() => {
    if (editingRecord) {
      setForm({
        printerId: editingRecord.printerId,
        month: editingRecord.month,
        totalCounter: editingRecord.totalCounter,
      });
    } else if (initialData) {
      setForm(prev => ({
        ...prev,
        printerId: initialData.printerId,
        month: initialData.month,
      }));
    }
  }, [editingRecord, initialData]);

  const selectedPrinter = printers.find(p => p.id === form.printerId);
  const cartModel = selectedPrinter?.cartridgeModel;

  const handleSave = () => {
    if (!form.printerId || !form.month) return;
    if (isEdit && onUpdate && editingRecord) {
      onUpdate({ id: editingRecord.id, ...form });
    } else {
      onSave(form);
    }
    onNavigate('printer-consumption');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Расход принтеров', page: 'printer-consumption', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Ввести счётчик', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? 'Редактировать счётчик' : 'Ввести счётчик принтера'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Принтер</label>
              <select
                value={form.printerId}
                onChange={e => setForm(prev => ({ ...prev, printerId: Number(e.target.value) }))}
                className="w-full px-4 py-2 border rounded-lg"
                style={{ borderColor: '#dee2e6' }}
              >
                {printers.map(p => (
                  <option key={p.id} value={p.id}>
                    №{p.number} {p.model} {p.location ? `(${p.location})` : ''}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Месяц</label>
              <input
                type="month"
                value={form.month}
                onChange={e => setForm(prev => ({ ...prev, month: e.target.value }))}
                className="w-full px-4 py-2 border rounded-lg"
                style={{ borderColor: '#dee2e6' }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Общий счётчик принтера</label>
            <input
              type="number"
              value={form.totalCounter}
              onChange={e => setForm(prev => ({ ...prev, totalCounter: Number(e.target.value) }))}
              className="w-full px-4 py-2 border rounded-lg"
              style={{ borderColor: '#dee2e6' }}
              placeholder="123456"
            />
            {cartModel && (
              <p className="mt-1 text-xs" style={{ color: COLORS.text }}>
                Картридж: {cartModel.name}, ресурс: {cartModel.expectedYield ? cartModel.expectedYield.toLocaleString('ru-RU') : '?'} стр.
                {' | '}На остатке: {cartModel.total} шт.
              </p>
            )}
          </div>

          <div className="pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition"
              style={{ backgroundColor: COLORS.primary }}
            >
              Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

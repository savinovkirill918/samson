'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { PrinterRepair, Printer, PageId } from '@/lib/types';
import { formatDate, repairStatusText } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterRepairSZPageProps {
  repairs: PrinterRepair[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
}

export default function PrinterRepairSZPage({ repairs, printers, onNavigate }: PrinterRepairSZPageProps) {
  const activeRepairs = repairs.filter(r => r.status !== 1).sort((a, b) => b.id - a.id);

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Ремонты принтеров', page: 'printer-repairs', onNavigate },
        { label: 'Служебная записка', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Служебная записка — ремонты принтеров</h2>

      <div className="bg-white rounded-xl shadow p-6">
        {activeRepairs.length === 0 ? (
          <p style={{ color: COLORS.text }}>Нет активных ремонтов принтеров</p>
        ) : (
          <div className="space-y-3">
            {activeRepairs.map(repair => {
              const printer = printers.find(p => p.id === repair.printerId);
              return (
                <div key={repair.id} className="p-3 rounded-lg border" style={{ borderColor: '#dee2e6' }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium" style={{ color: COLORS.heading }}>
                      Принтер №{printer?.number} {printer?.model}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${repair.status === 0 ? 'bg-yellow-200 text-yellow-800' : 'bg-red-200 text-red-800'}`}>
                      {repairStatusText(repair.status)}
                    </span>
                  </div>
                  <p className="text-sm" style={{ color: COLORS.text }}>
                    Дата поломки: {formatDate(repair.brokenDate)} | Описание: {repair.description}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

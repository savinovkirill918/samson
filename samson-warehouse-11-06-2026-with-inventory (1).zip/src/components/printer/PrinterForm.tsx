'use client';

import React, { useState, useEffect } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Printer, CartridgeModel, PageId } from '@/lib/types';
import { printerTypeText } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterFormProps {
  editingPrinterId?: number | null;
  printers?: Printer[];
  cartridgeModels?: CartridgeModel[];
  onSave: (data: { number: number; sn: string; inv: string; model: string; type: string; location: string; ipAddress: string; purchaseDate: string; status: number; isMulti: boolean; cartridgeModelId: number | null }) => void;
  onUpdate?: (data: Partial<Printer> & { id: number }) => void;
  onDelete?: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

const PRINTER_TYPES = [
  { value: 'laser', label: 'Лазерный' },
  { value: 'thermal', label: 'Термопринтер' },
  { value: 'label', label: 'Этикетки' },
  { value: 'inkjet', label: 'Струйный' },
];

const PRINTER_STATUSES = [
  { value: 0, label: 'Работает' },
  { value: 2, label: 'Списан' },
  { value: 3, label: 'Запасной' },
];

export default function PrinterForm({ editingPrinterId, printers, cartridgeModels = [], onSave, onUpdate, onDelete, onNavigate }: PrinterFormProps) {
  const isEdit = !!editingPrinterId;
  const existing = isEdit && printers ? printers.find(p => p.id === editingPrinterId) : null;

  const [form, setForm] = useState({
    number: existing?.number ?? 0,
    sn: existing?.sn ?? '',
    inv: existing?.inv ?? '',
    model: existing?.model ?? '',
    type: existing?.type ?? 'laser',
    location: existing?.location ?? '',
    ipAddress: existing?.ipAddress ?? '',
    purchaseDate: existing?.purchaseDate ?? '',
    status: existing?.status ?? 0,
    isMulti: existing?.isMulti ?? false,
    cartridgeModelId: existing?.cartridgeModelId ?? null as number | null,
  });

  useEffect(() => {
    if (existing) {
      setForm({
        number: existing.number,
        sn: existing.sn,
        inv: existing.inv,
        model: existing.model,
        type: existing.type,
        location: existing.location,
        ipAddress: existing.ipAddress,
        purchaseDate: existing.purchaseDate ?? '',
        status: existing.status ?? 0,
        isMulti: existing.isMulti,
        cartridgeModelId: existing.cartridgeModelId ?? null,
      });
    }
  }, [existing]);

  const selectedModel = cartridgeModels.find(m => m.id === form.cartridgeModelId);

  const handleSave = () => {
    if (!form.number) return;
    if (isEdit && onUpdate && editingPrinterId) {
      onUpdate({ id: editingPrinterId, ...form });
    } else {
      onSave(form);
    }
    onNavigate('printer-list');
  };

  const handleDelete = () => {
    if (editingPrinterId && onDelete && confirm('Удалить принтер?')) {
      onDelete(editingPrinterId);
      onNavigate('printer-list');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Принтеры', page: 'printer-list', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Редактировать принтер №${existing?.number}` : 'Добавить принтер'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
              <input type="number" value={form.number} onChange={e => setForm(prev => ({ ...prev, number: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Тип</label>
              <select value={form.type} onChange={e => setForm(prev => ({ ...prev, type: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }}>
                {PRINTER_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Модель</label>
            <input type="text" value={form.model} onChange={e => setForm(prev => ({ ...prev, model: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="HP LaserJet Pro MFP M130" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер</label>
              <input type="text" value={form.sn} onChange={e => setForm(prev => ({ ...prev, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инв. номер</label>
              <input type="text" value={form.inv} onChange={e => setForm(prev => ({ ...prev, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>IP-адрес</label>
              <input type="text" value={form.ipAddress} onChange={e => setForm(prev => ({ ...prev, ipAddress: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="10.116.10.113" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата приобретения</label>
              <input type="text" value={form.purchaseDate} onChange={e => setForm(prev => ({ ...prev, purchaseDate: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="февраль 2017" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Место размещения</label>
            <input type="text" value={form.location} onChange={e => setForm(prev => ({ ...prev, location: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="Бухгалтерия / Операторская" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Картридж (из справочника)</label>
            <select
              value={form.cartridgeModelId ?? ''}
              onChange={e => setForm(prev => ({ ...prev, cartridgeModelId: e.target.value ? Number(e.target.value) : null }))}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
              style={{ borderColor: '#dee2e6' }}
            >
              <option value="">— не выбран —</option>
              {cartridgeModels.map(m => (
                <option key={m.id} value={m.id}>
                  {m.name} — {m.printerModel} (ресурс: {m.expectedYield ? m.expectedYield.toLocaleString('ru-RU') : '?'} стр.)
                </option>
              ))}
            </select>
            {selectedModel && (
              <p className="mt-1 text-xs" style={{ color: COLORS.text }}>
                Ресурс: {selectedModel.expectedYield ? selectedModel.expectedYield.toLocaleString('ru-RU') : 'не указан'} стр.
                {' | '}На остатке: {selectedModel.total} шт.
                {' | '}Требуют заправки: {selectedModel.needsRefill} шт.
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Статус</label>
            {form.status === 1 ? (
              <div className="w-full px-4 py-2 border rounded-lg text-sm" style={{ borderColor: '#dee2e6', backgroundColor: '#fff3cd', color: '#664d03', fontWeight: 500 }}>
                В ремонте (устанавливается автоматически при создании ремонта)
              </div>
            ) : (
              <select value={form.status} onChange={e => setForm(prev => ({ ...prev, status: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }}>
                {PRINTER_STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            )}
          </div>

          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isMulti} onChange={e => setForm(prev => ({ ...prev, isMulti: e.target.checked }))} className="accent-[#3a57e8] w-4 h-4" />
            <span className="text-sm" style={{ color: COLORS.heading }}>Множественное назначение</span>
          </label>

          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            {isEdit && onDelete ? (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
                <Trash2 className="w-4 h-4" /> Удалить
              </button>
            ) : <span />}
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

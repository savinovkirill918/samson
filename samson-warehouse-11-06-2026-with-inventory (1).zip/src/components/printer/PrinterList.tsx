'use client';

import React from 'react';
// buttons removed — navigation via sidebar
import { COLORS } from '@/lib/colors';
import type { Printer, PageId } from '@/lib/types';
import { printerTypeText, printerStatusText, printerStatusColor } from '@/lib/helpers';

interface PrinterListProps {
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEditPrinter: (printer: Printer) => void;
}

export default function PrinterList({ printers, onNavigate, onEditPrinter }: PrinterListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full text-sm">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>#</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Картридж</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Тип</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Место</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>IP-адрес</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Статус</th>
              </tr>
            </thead>
            <tbody>
              {printers.length > 0 ? printers.map((printer, idx) => {
                const sc = printerStatusColor(printer.status);
                return (
                  <tr
                    key={printer.id}
                    onClick={() => onEditPrinter(printer)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>№{printer.number}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.heading }}>{printer.model}</td>
                    <td className="px-4 py-3">
                      {printer.cartridgeModel ? (
                        <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: '#cfe2ff', color: '#084298' }}>
                          {printer.cartridgeModel.name}
                          {printer.cartridgeModel.expectedYield > 0 && ` (${printer.cartridgeModel.expectedYield.toLocaleString('ru-RU')})`}
                        </span>
                      ) : (
                        <span style={{ color: '#ccc' }}>—</span>
                      )}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{printerTypeText(printer.type)}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{printer.location || '—'}</td>
                    <td className="px-4 py-3">
                      {printer.ipAddress ? (
                        <a
                          href={`http://${printer.ipAddress}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={e => e.stopPropagation()}
                          className="hover:underline"
                          style={{ color: COLORS.primary }}
                        >
                          {printer.ipAddress}
                        </a>
                      ) : (
                        <span style={{ color: '#ccc' }}>—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: sc.bg, color: sc.text }}>
                        {printerStatusText(printer.status)}
                      </span>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={7} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет принтеров</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

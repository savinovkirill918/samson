'use client';

import React, { useState } from 'react';
import { COLORS } from '@/lib/colors';
import type { Printer, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';
import { todayStr } from '@/lib/helpers';

interface PrinterRepairFormProps {
  printers: Printer[];
  onSave: (data: { printerId: number; brokenDate: string; description: string; isGuilty: boolean; status: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function PrinterRepairForm({ printers, onSave, onNavigate }: PrinterRepairFormProps) {
  const [printerId, setPrinterId] = useState<number>(printers[0]?.id ?? 0);
  const [description, setDescription] = useState('');
  const [isGuilty, setIsGuilty] = useState(false);

  const handleSave = () => {
    if (!printerId || !description) return;
    onSave({
      printerId,
      brokenDate: todayStr(),
      description,
      isGuilty,
      status: -1,
    });
    onNavigate('printer-repairs');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Ремонты принтеров', page: 'printer-repairs', onNavigate },
        { label: 'Добавить ремонт', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ремонт принтера</h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>Принтер</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
              {printers.map(p => (
                <label
                  key={p.id}
                  className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50"
                  style={{ borderColor: printerId === p.id ? COLORS.primary : '#dee2e6' }}
                >
                  <input type="radio" name="printer" checked={printerId === p.id} onChange={() => setPrinterId(p.id)} className="accent-[#3a57e8]" />
                  <span className="text-sm" style={{ color: COLORS.heading }}>№{p.number}</span>
                  <span className="text-xs" style={{ color: COLORS.text }}>{p.model}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание неисправности *</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} rows={3} />
          </div>

          <label className="flex items-center gap-2">
            <input type="checkbox" checked={isGuilty} onChange={e => setIsGuilty(e.target.checked)} className="accent-[#3a57e8] w-4 h-4" />
            <span className="text-sm" style={{ color: COLORS.heading }}>Виноват сотрудник</span>
          </label>

          <div className="pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

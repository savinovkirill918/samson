'use client';

import React, { useState, useEffect } from 'react';
import { COLORS } from '@/lib/colors';
import type { PrinterRepair, Printer, PageId } from '@/lib/types';
import { formatDate } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterRepairEditFormProps {
  repairId: number;
  repairs: PrinterRepair[];
  printers: Printer[];
  onUpdate: (data: Partial<PrinterRepair> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

const STATUS_OPTIONS = [
  { value: -1, label: 'Сломан не отправлен' },
  { value: 0, label: 'Отправлен в ремонт' },
  { value: 1, label: 'Вернулся с ремонта' },
];

export default function PrinterRepairEditForm({ repairId, repairs, printers, onUpdate, onNavigate }: PrinterRepairEditFormProps) {
  const repair = repairs.find(r => r.id === repairId);
  const isLocked = repair?.status === 1;

  const [form, setForm] = useState({
    printerId: repair?.printerId ?? 0,
    brokenDate: repair?.brokenDate ?? '',
    sentDate: repair?.sentDate ?? '',
    returnedDate: repair?.returnedDate ?? '',
    status: repair?.status ?? -1,
    description: repair?.description ?? '',
    isGuilty: repair?.isGuilty ?? false,
    cost: repair?.cost ?? 0,
  });

  useEffect(() => {
    if (repair) {
      setForm({
        printerId: repair.printerId,
        brokenDate: repair.brokenDate,
        sentDate: repair.sentDate,
        returnedDate: repair.returnedDate,
        status: repair.status,
        description: repair.description,
        isGuilty: repair.isGuilty,
        cost: repair.cost,
      });
    }
  }, [repair]);

  if (!repair) {
    return <div style={{ color: COLORS.text }}>Ремонт не найден</div>;
  }

  const handleStatusChange = (newStatus: number) => {
    const updates: Partial<typeof form> = { status: newStatus };
    if (newStatus >= 0 && !form.sentDate) {
      updates.sentDate = new Date().toISOString();
    }
    if (newStatus === 1 && !form.returnedDate) {
      updates.returnedDate = new Date().toISOString();
    }
    setForm(prev => ({ ...prev, ...updates }));
  };

  const handleSave = () => {
    onUpdate({ id: repairId, ...form });
    onNavigate('printer-repairs');
  };

  const printer = printers.find(p => p.id === form.printerId);

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Ремонты принтеров', page: 'printer-repairs', onNavigate },
        { label: `Ремонт #${repairId}`, onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        Ремонт принтера №{printer?.number} {printer?.model}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Статус</label>
            <select
              value={form.status}
              onChange={e => handleStatusChange(Number(e.target.value))}
              disabled={isLocked}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 disabled:opacity-50"
              style={{ borderColor: '#dee2e6' }}
            >
              {STATUS_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата поломки</label>
              <input type="date" value={form.brokenDate?.split('T')[0]} onChange={e => setForm(prev => ({ ...prev, brokenDate: e.target.value }))} disabled={isLocked} className="w-full px-4 py-2 border rounded-lg disabled:opacity-50" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата отправки</label>
              <input type="date" value={form.sentDate?.split('T')[0] || ''} onChange={e => setForm(prev => ({ ...prev, sentDate: e.target.value }))} disabled={isLocked} className="w-full px-4 py-2 border rounded-lg disabled:opacity-50" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата возврата</label>
              <input type="date" value={form.returnedDate?.split('T')[0] || ''} onChange={e => setForm(prev => ({ ...prev, returnedDate: e.target.value }))} disabled={isLocked} className="w-full px-4 py-2 border rounded-lg disabled:opacity-50" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание</label>
            <textarea value={form.description} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} disabled={isLocked} className="w-full px-4 py-2 border rounded-lg disabled:opacity-50" style={{ borderColor: '#dee2e6' }} rows={3} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={form.isGuilty} onChange={e => setForm(prev => ({ ...prev, isGuilty: e.target.checked }))} disabled={isLocked} className="accent-[#3a57e8] w-4 h-4 disabled:opacity-50" />
              <span className="text-sm" style={{ color: COLORS.heading }}>Виноват сотрудник</span>
            </label>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Стоимость ремонта</label>
              <input type="number" value={form.cost} onChange={e => setForm(prev => ({ ...prev, cost: Number(e.target.value) }))} disabled={isLocked} className="w-full px-4 py-2 border rounded-lg disabled:opacity-50" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          {!isLocked && (
            <div className="pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
              <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
                Сохранить
              </button>
            </div>
          )}

          {isLocked && (
            <div className="p-3 rounded-lg" style={{ backgroundColor: '#d1e7dd', color: '#0f5132' }}>
              Ремонт завершён. Редактирование недоступно.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

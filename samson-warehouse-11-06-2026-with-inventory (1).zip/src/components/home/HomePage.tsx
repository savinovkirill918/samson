'use client';

import React from 'react';
import { AlertTriangle, Clock, Printer, Droplet } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Member, TSD, Repair, Group, LogEntry, Printer as PrinterType, PrinterRepair, CartridgeSummary, PageId } from '@/lib/types';
import { formatDateTime, isRepairActive, repairStatusText } from '@/lib/helpers';

interface HomePageProps {
  members: Member[];
  tsds: TSD[];
  repairs: Repair[];
  groups: Group[];
  logs: LogEntry[];
  printers: PrinterType[];
  printerRepairs: PrinterRepair[];
  cartridgeSummary: CartridgeSummary[];
  onNavigate: (page: PageId) => void;
}

export default function HomePage({ members, tsds, repairs, groups, logs, printers, printerRepairs, cartridgeSummary, onNavigate }: HomePageProps) {
  const repairsWithMembers = repairs
    .filter(isRepairActive)
    .map(r => {
      const member = members.find(m => m.tsdId === r.tsdId);
      const tsd = tsds.find(t => t.id === r.tsdId);
      return { repair: r, member, tsd };
    })
    .filter(r => r.member);

  const recentLogs = logs.slice(0, 50);

  // Printer alerts
  const activePrinterRepairs = printerRepairs.filter(r => r.status !== 1);
  const printersInRepairIds = new Set(activePrinterRepairs.map(r => r.printerId));
  const printersInRepair = printers.filter(p => printersInRepairIds.has(p.id));

  // Cartridge alerts
  const criticalCartridges = cartridgeSummary.filter(s => s.onStock <= 0 && s.total > 0);
  const needsRefillTotal = cartridgeSummary.reduce((sum, s) => sum + s.needsRefill, 0);

  const hasAlerts = repairsWithMembers.length > 0 || printersInRepair.length > 0 || criticalCartridges.length > 0 || needsRefillTotal > 0;

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Главная</h2>

      {/* Alerts */}
      {hasAlerts && (
        <div className="rounded-xl p-4 mb-6 space-y-3" style={{ backgroundColor: COLORS.alertBg }}>
          {/* TSD repairs */}
          {repairsWithMembers.length > 0 && (
            <div>
              <div className="flex items-start gap-3 mb-2">
                <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: '#ffc107' }} />
                <h3 className="font-semibold" style={{ color: COLORS.heading }}>ТСД на ремонте</h3>
              </div>
              <div className="space-y-1 ml-8">
                {repairsWithMembers.map(({ repair, member, tsd }) => member && tsd && (
                  <div key={repair.id} className="flex items-center gap-4 text-sm">
                    <span className="font-medium" style={{ color: COLORS.heading }}>{member.fio}</span>
                    <span style={{ color: COLORS.text }}>ТСД №{tsd.number}</span>
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-yellow-200 text-yellow-800">
                      {repairStatusText(repair.status)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Printer repairs */}
          {printersInRepair.length > 0 && (
            <div>
              <div className="flex items-start gap-3 mb-2">
                <Printer className="w-5 h-5 mt-0.5" style={{ color: '#dc3545' }} />
                <h3 className="font-semibold" style={{ color: COLORS.heading }}>Принтеры в ремонте ({printersInRepair.length})</h3>
              </div>
              <div className="space-y-1 ml-8">
                {printersInRepair.map(p => (
                  <div key={p.id} className="flex items-center gap-4 text-sm">
                    <span className="font-medium" style={{ color: COLORS.heading }}>№{p.number} {p.model}</span>
                    <span style={{ color: COLORS.text }}>{p.location}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Cartridge alerts */}
          {(criticalCartridges.length > 0 || needsRefillTotal > 0) && (
            <div>
              <div className="flex items-start gap-3 mb-2">
                <Droplet className="w-5 h-5 mt-0.5" style={{ color: criticalCartridges.length > 0 ? '#dc3545' : '#ffc107' }} />
                <h3 className="font-semibold" style={{ color: COLORS.heading }}>Картриджи требуют внимания</h3>
              </div>
              <div className="space-y-1 ml-8">
                {criticalCartridges.length > 0 && (
                  <div className="text-sm" style={{ color: '#dc3545' }}>
                    Нет на остатке: {criticalCartridges.map(s => s.cartridgeModel.name).join(', ')}
                  </div>
                )}
                {needsRefillTotal > 0 && (
                  <div className="text-sm" style={{ color: '#664d03' }}>
                    Требуют заправки: {needsRefillTotal} шт.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* All good */}
      {!hasAlerts && cartridgeSummary.length > 0 && (
        <div className="rounded-xl p-4 mb-6" style={{ backgroundColor: '#d1e7dd' }}>
          <div className="flex items-center gap-3">
            <span className="text-lg">✅</span>
            <span className="font-medium" style={{ color: '#0f5132' }}>Картриджи и принтеры в норме</span>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold" style={{ color: COLORS.heading }}>Последние действия</h3>
          <button onClick={() => onNavigate('logs')} className="text-sm hover:underline" style={{ color: COLORS.primary }}>
            Все логи →
          </button>
        </div>
        <div className="max-h-96 overflow-y-auto space-y-2" style={{ scrollbarWidth: 'thin' }}>
          {recentLogs.map(log => (
            <div key={log.id} className="flex items-center gap-3 py-2 border-b last:border-b-0 text-sm" style={{ borderColor: '#f0f0f0' }}>
              <Clock className="w-3.5 h-3.5 flex-shrink-0" style={{ color: COLORS.text }} />
              <span className="flex-shrink-0 whitespace-nowrap" style={{ color: COLORS.text }}>{formatDateTime(log.date)}</span>
              <span style={{ color: COLORS.heading }}>{log.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { CartridgeModel, PageId } from '@/lib/types';

interface CartridgeModelListProps {
  models: CartridgeModel[];
  onNavigate: (page: PageId) => void;
  onEdit: (model: CartridgeModel) => void;
}

export default function CartridgeModelList({ models, onNavigate, onEdit }: CartridgeModelListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
        <table className="w-full text-sm">
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Название</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Для принтера</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Ресурс (стр.)</th>
            </tr>
          </thead>
          <tbody>
            {models.length > 0 ? models.map((m, idx) => (
              <tr
                key={m.id}
                onClick={() => onEdit(m)}
                className="cursor-pointer transition-colors"
                style={{
                  backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                  borderBottom: '1px solid #dee2e6',
                }}
                onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
              >
                <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>{m.name}</td>
                <td className="px-4 py-3" style={{ color: COLORS.text }}>{m.printerModel}</td>
                <td className="px-4 py-3 text-right" style={{ color: COLORS.text }}>{m.expectedYield.toLocaleString('ru')}</td>
              </tr>
            )) : (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет моделей</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

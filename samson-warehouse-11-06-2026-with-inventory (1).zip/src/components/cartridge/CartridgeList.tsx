'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { Cartridge, CartridgeModel, Printer, PageId } from '@/lib/types';
import { cartridgeStatusText, cartridgeStatusColor, cartridgeConditionText, cartridgeConditionColor } from '@/lib/helpers';

interface CartridgeListProps {
  cartridges: Cartridge[];
  cartridgeModels: CartridgeModel[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEdit: (cartridge: Cartridge) => void;
}

export default function CartridgeList({ cartridges, cartridgeModels, printers, onNavigate, onEdit }: CartridgeListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full text-sm">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>#</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Статус</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Принтер</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Состояние</th>
              </tr>
            </thead>
            <tbody>
              {cartridges.length > 0 ? cartridges.map((c, idx) => {
                const model = cartridgeModels.find(m => m.id === c.cartridgeModelId);
                const printer = c.printerId ? printers.find(p => p.id === c.printerId) : null;
                const statusStyle = cartridgeStatusColor(c.status);
                const condStyle = cartridgeConditionColor(c.condition);
                return (
                  <tr
                    key={c.id}
                    onClick={() => onEdit(c)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>#{c.id}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.heading }}>{model?.name || '—'}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: statusStyle.bg, color: statusStyle.text }}>
                        {cartridgeStatusText(c.status)}
                      </span>
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.primary }}>{printer ? `№${printer.number} ${printer.model}` : '—'}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: condStyle.bg, color: condStyle.text }}>
                        {cartridgeConditionText(c.condition)}
                      </span>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет картриджей</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

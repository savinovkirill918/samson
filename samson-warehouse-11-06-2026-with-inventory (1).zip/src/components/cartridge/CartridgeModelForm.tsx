'use client';

import React, { useState } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { CartridgeModel, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface CartridgeModelFormProps {
  editingModel?: CartridgeModel | null;
  onSave: (data: { name: string; printerModel: string; expectedYield: number }) => void;
  onUpdate?: (data: Partial<CartridgeModel> & { id: number }) => void;
  onDelete?: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

export default function CartridgeModelForm({ editingModel, onSave, onUpdate, onDelete, onNavigate }: CartridgeModelFormProps) {
  const isEdit = !!editingModel;

  const [form, setForm] = useState({
    name: editingModel?.name ?? '',
    printerModel: editingModel?.printerModel ?? '',
    expectedYield: editingModel?.expectedYield ?? 0,
  });

  const handleSave = () => {
    if (!form.name) return;
    if (isEdit && onUpdate && editingModel) {
      onUpdate({ id: editingModel.id, ...form });
    } else {
      onSave(form);
    }
    onNavigate('cartridge-models');
  };

  const handleDelete = () => {
    if (editingModel && onDelete && confirm('Удалить модель картриджа? Связанные принтеры будут отвязаны.')) {
      onDelete(editingModel.id);
      onNavigate('cartridge-models');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Справочник', page: 'cartridge-models', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Редактировать: ${editingModel?.name}` : 'Добавить модель картриджа'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Название *</label>
            <input type="text" value={form.name} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} placeholder="HP CF217A" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Для модели принтера</label>
            <input type="text" value={form.printerModel} onChange={e => setForm(prev => ({ ...prev, printerModel: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} placeholder="HP LaserJet Pro MFP M130" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Ресурс (страниц)</label>
            <input type="number" min={0} value={form.expectedYield} onChange={e => setForm(prev => ({ ...prev, expectedYield: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
          </div>
          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            {isEdit && onDelete ? (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
                <Trash2 className="w-4 h-4" /> Удалить
              </button>
            ) : <span />}
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

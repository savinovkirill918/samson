'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { Cartridge, CartridgeModel, Printer, PageId } from '@/lib/types';
import { cartridgeStatusText, cartridgeStatusColor, cartridgeConditionText, cartridgeConditionColor, cartridgeActionText, formatDate } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface CartridgeHistoryPageProps {
  cartridge: Cartridge;
  cartridgeModels: CartridgeModel[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
}

export default function CartridgeHistoryPage({ cartridge, cartridgeModels, printers, onNavigate }: CartridgeHistoryPageProps) {
  const model = cartridgeModels.find(m => m.id === cartridge.cartridgeModelId);
  const statusStyle = cartridgeStatusColor(cartridge.status);
  const condStyle = cartridgeConditionColor(cartridge.condition);

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Картриджи', page: 'cartridge-inventory', onNavigate },
        { label: `Картридж #${cartridge.id}`, onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        История: {model?.name} #{cartridge.id}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl mb-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-sm" style={{ color: COLORS.text }}>Модель:</span>
            <span className="ml-2 font-medium" style={{ color: COLORS.heading }}>{model?.name}</span>
          </div>
          <div>
            <span className="text-sm" style={{ color: COLORS.text }}>Статус:</span>
            <span className="ml-2 px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: statusStyle.bg, color: statusStyle.text }}>
              {cartridgeStatusText(cartridge.status)}
            </span>
          </div>
          <div>
            <span className="text-sm" style={{ color: COLORS.text }}>Состояние:</span>
            <span className="ml-2 px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: condStyle.bg, color: condStyle.text }}>
              {cartridgeConditionText(cartridge.condition)}
            </span>
          </div>
          <div>
            <span className="text-sm" style={{ color: COLORS.text }}>Для принтера:</span>
            <span className="ml-2 font-medium" style={{ color: COLORS.heading }}>{model?.printerModel}</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <h3 className="font-semibold mb-3" style={{ color: COLORS.heading }}>Журнал событий</h3>
        {cartridge.history && cartridge.history.length > 0 ? (
          <div className="space-y-2">
            {cartridge.history.map(h => {
              const printer = h.printerId ? printers.find(p => p.id === h.printerId) : null;
              return (
                <div key={h.id} className="flex items-start gap-3 p-3 rounded-lg border" style={{ borderColor: '#dee2e6' }}>
                  <div className="flex-shrink-0 w-2 h-2 rounded-full mt-2" style={{ backgroundColor: COLORS.primary }} />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm" style={{ color: COLORS.heading }}>{cartridgeActionText(h.action)}</span>
                      <span className="text-xs" style={{ color: COLORS.text }}>{formatDate(h.date)}</span>
                    </div>
                    {printer && <span className="text-xs" style={{ color: COLORS.primary }}>Принтер №{printer.number} {printer.model}</span>}
                    {h.notes && <p className="text-xs mt-1" style={{ color: COLORS.text }}>{h.notes}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p style={{ color: COLORS.text }}>Нет записей в истории</p>
        )}
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Cartridge, CartridgeModel, Printer, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface CartridgeFormProps {
  editingCartridge?: Cartridge | null;
  cartridgeModels: CartridgeModel[];
  printers: Printer[];
  onSave: (data: { cartridgeModelId: number; status?: number; condition?: number }) => void;
  onUpdate?: (data: Partial<Cartridge> & { id: number }) => void;
  onDelete?: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

export default function CartridgeForm({ editingCartridge, cartridgeModels, printers, onSave, onUpdate, onDelete, onNavigate }: CartridgeFormProps) {
  const isEdit = !!editingCartridge;

  const [form, setForm] = useState({
    cartridgeModelId: editingCartridge?.cartridgeModelId ?? cartridgeModels[0]?.id ?? 0,
    status: editingCartridge?.status ?? 0,
    condition: editingCartridge?.condition ?? 0,
  });

  const handleSave = () => {
    if (!form.cartridgeModelId) return;
    if (isEdit && onUpdate && editingCartridge) {
      onUpdate({ id: editingCartridge.id, ...form });
    } else {
      onSave(form);
    }
    onNavigate('cartridge-inventory');
  };

  const handleDelete = () => {
    if (editingCartridge && onDelete && confirm('Удалить картридж?')) {
      onDelete(editingCartridge.id);
      onNavigate('cartridge-inventory');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Картриджи', page: 'cartridge-inventory', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Картридж #${editingCartridge?.id}` : 'Добавить картридж'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Модель картриджа</label>
            <select value={form.cartridgeModelId} onChange={e => setForm(prev => ({ ...prev, cartridgeModelId: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} disabled={isEdit}>
              {cartridgeModels.map(m => <option key={m.id} value={m.id}>{m.name} ({m.printerModel})</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Начальный статус</label>
            <select value={form.status} onChange={e => setForm(prev => ({ ...prev, status: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} disabled={isEdit}>
              <option value={0}>На остатке</option>
              <option value={1}>В работе</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Состояние картриджа</label>
            <select value={form.condition} onChange={e => setForm(prev => ({ ...prev, condition: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }}>
              <option value={0}>Новый</option>
              <option value={1}>Б/у</option>
            </select>
          </div>

          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            {isEdit && onDelete ? (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
                <Trash2 className="w-4 h-4" /> Удалить
              </button>
            ) : <span />}
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

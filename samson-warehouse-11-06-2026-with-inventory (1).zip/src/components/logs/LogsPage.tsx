'use client';

import React, { useState } from 'react';
import { COLORS } from '@/lib/colors';
import type { LogEntry, AdminUser } from '@/lib/types';
import { formatDateTime } from '@/lib/helpers';

interface LogsPageProps {
  logs: LogEntry[];
  admins: AdminUser[];
}

export default function LogsPage({ logs, admins }: LogsPageProps) {
  const [page, setPage] = useState(1);
  const perPage = 30;
  const totalPages = Math.ceil(logs.length / perPage);
  const pagedLogs = logs.slice((page - 1) * perPage, page * perPage);

  const getAdminName = (id: number) => admins.find(a => a.id === id)?.fio || 'Неизвестный';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Дата/Время</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Действие</th>
              </tr>
            </thead>
            <tbody>
              {pagedLogs.map(log => (
                <tr key={log.id} className="border-t hover:bg-gray-50" style={{ borderColor: '#f0f0f0' }}>
                  <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{getAdminName(log.adminId)}</td>
                  <td className="px-4 py-3 text-sm whitespace-nowrap" style={{ color: COLORS.text }}>{formatDateTime(log.date)}</td>
                  <td className="px-4 py-3 text-sm" style={{ color: COLORS.heading }}>{log.text}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 p-4 border-t" style={{ borderColor: '#f0f0f0' }}>
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1.5 text-sm rounded-lg border disabled:opacity-50 hover:bg-gray-50" style={{ borderColor: '#dee2e6' }}>
              ←
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)} className={`px-3 py-1.5 text-sm rounded-lg border ${p === page ? 'text-white' : 'hover:bg-gray-50'}`} style={p === page ? { backgroundColor: COLORS.primary, borderColor: COLORS.primary } : { borderColor: '#dee2e6', color: COLORS.heading }}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1.5 text-sm rounded-lg border disabled:opacity-50 hover:bg-gray-50" style={{ borderColor: '#dee2e6' }}>
              →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

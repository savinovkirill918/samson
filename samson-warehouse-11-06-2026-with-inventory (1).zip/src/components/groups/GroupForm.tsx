'use client';

import React, { useState, useEffect } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Group, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface GroupFormProps {
  editingGroup?: Group | null;
  onSave: (group: { name: string; sort: number }) => void;
  onUpdate?: (group: { id: number; name: string; sort: number }) => void;
  onDelete?: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

export default function GroupForm({ editingGroup, onSave, onUpdate, onDelete, onNavigate }: GroupFormProps) {
  const isEdit = !!editingGroup;
  const [name, setName] = useState(editingGroup?.name ?? '');
  const [sort, setSort] = useState(String(editingGroup?.sort ?? 16));

  useEffect(() => {
    if (editingGroup) {
      setName(editingGroup.name);
      setSort(String(editingGroup.sort));
    }
  }, [editingGroup]);

  const handleSave = () => {
    if (!name) return;
    if (isEdit && onUpdate && editingGroup) {
      onUpdate({ id: editingGroup.id, name, sort: parseInt(sort) || 16 });
    } else {
      onSave({ name, sort: parseInt(sort) || 16 });
    }
    onNavigate('groups');
  };

  const handleDelete = () => {
    if (editingGroup && onDelete && confirm(`Удалить должность «${editingGroup.name}»?`)) {
      onDelete(editingGroup.id);
      onNavigate('groups');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Должности', page: 'groups', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Редактировать должность` : 'Добавить должность'}
      </h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Название *</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Сортировка</label>
          <input type="number" value={sort} onChange={e => setSort(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
          {isEdit && onDelete ? (
            <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
              <Trash2 className="w-4 h-4" /> Удалить
            </button>
          ) : <span />}
          <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Save className="w-4 h-4" /> Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}

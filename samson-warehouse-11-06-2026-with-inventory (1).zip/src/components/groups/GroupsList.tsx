'use client';

import React from 'react';
import { Pencil, Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Group, PageId } from '@/lib/types';

interface GroupsListProps {
  groups: Group[];
  onNavigate: (page: PageId) => void;
  onEditGroup: (group: Group) => void;
  onDeleteGroup: (id: number) => void;
}

export default function GroupsList({ groups, onNavigate, onEditGroup }: GroupsListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Должности</h2>
        <button onClick={() => onNavigate('group-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ID</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Название</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Сортировка</th>
                <th className="text-center px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading, width: '80px' }}>Действия</th>
              </tr>
            </thead>
            <tbody>
              {groups.sort((a, b) => a.sort - b.sort).map(g => (
                <tr key={g.id} className="border-t transition-colors" style={{ borderColor: '#f0f0f0' }}>
                  <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.id}</td>
                  <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{g.name}</td>
                  <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.sort}</td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center">
                      <button
                        title="Редактировать"
                        onClick={() => onEditGroup(g)}
                        className="p-1.5 rounded text-white transition hover:opacity-80 inline-flex items-center justify-center"
                        style={{ backgroundColor: '#6c757d' }}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

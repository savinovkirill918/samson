'use client';

import React, { useState } from 'react';
import {
  Home, Users, Briefcase, Smartphone, Plus, Wrench,
  CreditCard, BarChart3, Printer,
  Settings, ChevronRight, X,
  Wrench as ToolsIcon, FileText,
  List, Star, Package, Upload, ScanLine, UserCog, PlusCircle,
  Printer as PrinterIcon, History, BookOpen, BarChart, Droplet, PaintBucket,
  Scale
} from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId } from '@/lib/types';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  isOpen: boolean;
  onClose: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

/** Какой верхний раздел содержит каждую страницу */
const pageToSection: Record<string, string> = {
  'members': 'employees', 'member-add': 'employees',
  'member-edit': 'employees',
  'groups': 'employees', 'group-add': 'employees',
  'tsd-list': 'tsd', 'tsd-add': 'tsd', 'tsd-edit': 'tsd',
  'tsd-repairs': 'tsd', 'tsd-repair-add': 'tsd',
  'tsd-repair-edit': 'tsd', 'tsd-repair-sz': 'tsd',
  'printer-list': 'printer', 'printer-add': 'printer', 'printer-edit': 'printer',
  'printer-repairs': 'printer', 'printer-repair-add': 'printer',
  'printer-repair-edit': 'printer', 'printer-repair-sz': 'printer',
  'printer-consumption': 'printer', 'printer-consumption-add': 'printer', 'printer-consumption-edit': 'printer',
  'cartridge-inventory': 'printer', 'cartridge-add': 'printer',
  'cartridge-edit': 'printer', 'cartridge-history': 'printer',
  'cartridge-models': 'printer', 'cartridge-model-add': 'printer', 'cartridge-model-edit': 'printer',
  'kkm-list': 'kkm', 'kkm-add': 'kkm',
  'stat-starshie': 'statistics', 'stat-kladovshiki': 'statistics',
  'stat-import': 'statistics',
  'print-tsd': 'print', 'print-kkm': 'print',
  'print-barcode': 'print',
  'settings-users': 'settings', 'settings-user-add': 'settings',
  'inventory-balance': 'inventory',
};

const topLevelKeys = ['employees', 'tsd', 'printer', 'kkm', 'statistics', 'print', 'settings', 'inventory'];

function Collapse({ open, children }: { open: boolean; children: React.ReactNode }) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateRows: open ? '1fr' : '0fr',
        transition: 'grid-template-rows 0.35s cubic-bezier(0.4, 0, 0.2, 1)',
      }}
    >
      <div style={{ overflow: 'hidden' }}>
        {children}
      </div>
    </div>
  );
}

const chevronStyle = (open: boolean): React.CSSProperties => ({
  transform: open ? 'rotate(90deg)' : 'rotate(0deg)',
  transition: 'transform 0.35s cubic-bezier(0.4, 0, 0.2, 1)',
});

export default function Sidebar({ currentPage, onNavigate, isOpen, onClose, isCollapsed, onToggleCollapse }: SidebarProps) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    employees: false, positions: false, tsd: false, repair: false,
    printer: false, printerRepair: false, cartridge: false,
    kkm: false, statistics: false, print: false, settings: false,
    inventory: false,
  });

  const toggleTopLevel = (key: string) => {
    if (isCollapsed) return; // В свёрнутом режиме не раскрываем
    setExpanded(prev => {
      const wasOpen = prev[key];
      const collapsed: Record<string, boolean> = {};
      topLevelKeys.forEach(k => { collapsed[k] = false; });
      collapsed.positions = prev.positions;
      collapsed.repair = prev.repair;
      if (!wasOpen) {
        collapsed[key] = true;
      }
      return collapsed;
    });
  };

  const toggleNested = (key: string) => {
    if (isCollapsed) return;
    setExpanded(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const navigate = (page: PageId) => {
    const targetSection = (page as string) in pageToSection ? pageToSection[page as string] : null;

    setExpanded(prev => {
      const next = { ...prev };
      if (targetSection) {
        topLevelKeys.forEach(k => { if (k !== targetSection) next[k] = false; });
        next[targetSection] = true;
      } else {
        topLevelKeys.forEach(k => { next[k] = false; });
      }
      return next;
    });

    onNavigate(page);
    onClose();
  };

  const isActive = (page: PageId) => currentPage === page;
  const isSectionActive = (sectionKey: string) => !!expanded[sectionKey];

  const activeClass = 'text-white rounded-lg';
  const inactiveClass = 'rounded-lg hover:bg-gray-100';

  const t: React.CSSProperties = {
    transition: 'background-color 0.35s cubic-bezier(0.4, 0, 0.2, 1), color 0.35s cubic-bezier(0.4, 0, 0.2, 1), width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  };

  const sectionHeaderStyle = (sectionKey: string): React.CSSProperties => {
    if (isSectionActive(sectionKey)) {
      return { ...t, backgroundColor: COLORS.primary, color: '#ffffff' };
    }
    return { ...t, backgroundColor: 'transparent', color: COLORS.heading };
  };

  const sectionHeaderClass = isCollapsed
    ? 'w-full flex items-center justify-center p-2.5 text-sm font-medium rounded-lg hover:opacity-80'
    : 'w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:opacity-80';

  const sidebarWidth = isCollapsed ? 60 : 260;

  const sidebarClass = `sidebar-slidemenu ${isOpen ? 'sidebar-open' : ''}`;

  // Иконка для секции верхнего уровня
  const sectionIcon = (key: string) => {
    switch (key) {
      case 'employees': return <Users className="w-4 h-4" />;
      case 'tsd': return <Smartphone className="w-4 h-4" />;
      case 'printer': return <PrinterIcon className="w-4 h-4" />;
      case 'kkm': return <CreditCard className="w-4 h-4" />;
      case 'statistics': return <BarChart3 className="w-4 h-4" />;
      case 'print': return <Printer className="w-4 h-4" />;
      case 'settings': return <Settings className="w-4 h-4" />;
      case 'inventory': return <Scale className="w-4 h-4" />;
      default: return null;
    }
  };

  // При свёрнутом режиме — клик по иконке секции просто навигирует на первую страницу секции
  const sectionFirstPage: Record<string, PageId> = {
    employees: 'members',
    tsd: 'tsd-list',
    printer: 'printer-list',
    kkm: 'kkm-list',
    statistics: 'stat-starshie',
    print: 'print-tsd',
    settings: 'settings-users',
    inventory: 'inventory-balance',
  };

  return (
    <>
      <style>{`
        .sidebar-slidemenu {
          position: fixed;
          top: 0;
          left: 0;
          height: 100%;
          z-index: 50;
          box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1);
          overflow-y: auto;
          overflow-x: hidden;
          transform: translateX(-100%);
          transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1), width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .sidebar-slidemenu.sidebar-open {
          transform: translateX(0);
        }
        @media (min-width: 1024px) {
          .sidebar-slidemenu {
            transform: translateX(0) !important;
          }
        }
        .sidebar-collapsed-tooltip {
          position: absolute;
          left: 100%;
          top: 50%;
          transform: translateY(-50%);
          margin-left: 8px;
          padding: 4px 10px;
          background: #1e293b;
          color: #fff;
          font-size: 0.75rem;
          border-radius: 6px;
          white-space: nowrap;
          pointer-events: none;
          opacity: 0;
          transition: opacity 0.2s;
          z-index: 100;
        }
        .sidebar-collapsed-item:hover .sidebar-collapsed-tooltip {
          opacity: 1;
        }
      `}</style>
      {/* Оверлей */}
      <div
        className="fixed inset-0 bg-black/40 z-40 lg:hidden"
        onClick={onClose}
        style={{
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? 'auto' : 'none',
          transition: 'opacity 0.35s cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      />

      <aside
        className={sidebarClass}
        style={{
          backgroundColor: COLORS.sidebarBg,
          width: sidebarWidth,
          minWidth: sidebarWidth,
        }}
      >
        {/* Логотип */}
        <div className="border-b flex items-center gap-3" style={{ borderColor: '#e9ecef', padding: isCollapsed ? '12px 0' : '12px 16px', justifyContent: isCollapsed ? 'center' : undefined }}>
          <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: COLORS.primary }}>
            <Home className="w-5 h-5 text-white" />
          </div>
          {!isCollapsed && <span className="font-bold text-lg" style={{ color: COLORS.heading }}>ОФИСМАГ Склад</span>}
          {!isCollapsed && (
            <button className="ml-auto lg:hidden" onClick={onClose}>
              <X className="w-5 h-5" style={{ color: COLORS.text }} />
            </button>
          )}
        </div>

        <nav className="p-3 space-y-1" style={{ padding: isCollapsed ? '8px 4px' : undefined }}>
          {/* Главная */}
          {isCollapsed ? (
            <div className="sidebar-collapsed-item relative">
              <button
                onClick={() => navigate('home')}
                className={`w-full flex items-center justify-center p-2.5 text-sm font-medium rounded-lg ${isActive('home') ? activeClass : inactiveClass}`}
                style={isActive('home')
                  ? { ...t, backgroundColor: COLORS.primary, color: '#fff' }
                  : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }
                }
              >
                <Home className="w-4 h-4" />
              </button>
              <span className="sidebar-collapsed-tooltip">Главная</span>
            </div>
          ) : (
            <button
              onClick={() => navigate('home')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium ${isActive('home') ? activeClass : inactiveClass}`}
              style={isActive('home')
                ? { ...t, backgroundColor: COLORS.primary, color: '#fff' }
                : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }
              }
            >
              <Home className="w-4 h-4" /> Главная
            </button>
          )}

          {/* ====== Секции ====== */}
          {topLevelKeys.map(key => (
            <div key={key}>
              {isCollapsed ? (
                /* Свёрнутый режим: только иконка с тултипом */
                <div className="sidebar-collapsed-item relative">
                  <button
                    onClick={() => navigate(sectionFirstPage[key])}
                    className={`w-full flex items-center justify-center p-2.5 text-sm font-medium rounded-lg ${isSectionActive(key) ? activeClass : inactiveClass}`}
                    style={sectionHeaderStyle(key)}
                  >
                    {sectionIcon(key)}
                  </button>
                  <span className="sidebar-collapsed-tooltip">
                    {key === 'employees' ? 'Сотрудники' : key === 'tsd' ? 'ТСД' : key === 'printer' ? 'Принтеры' : key === 'kkm' ? 'ККМ' : key === 'statistics' ? 'Статистика' : key === 'print' ? 'Печать' : key === 'inventory' ? 'Учет остатков' : 'Настройки'}
                  </span>
                </div>
              ) : (
                /* Развернутый режим: полный аккордеон */
                <>
                  <button onClick={() => toggleTopLevel(key)} className={sectionHeaderClass} style={sectionHeaderStyle(key)}>
                    <span className="flex items-center gap-3">{sectionIcon(key)} {key === 'employees' ? 'Сотрудники' : key === 'tsd' ? 'ТСД' : key === 'printer' ? 'Принтеры' : key === 'kkm' ? 'ККМ' : key === 'statistics' ? 'Статистика' : key === 'print' ? 'Печать' : key === 'inventory' ? 'Учет остатков' : 'Настройки'}</span>
                    <ChevronRight className="w-4 h-4" style={chevronStyle(!!expanded[key])} />
                  </button>

                  {/* ====== Сотрудники подсекции ====== */}
                  {key === 'employees' && (
                    <Collapse open={!!expanded.employees}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('members')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('members') ? activeClass : inactiveClass}`} style={isActive('members') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Users className="w-3.5 h-3.5" /> Все Сотрудники
                        </button>
                        <button onClick={() => navigate('member-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('member-add') ? activeClass : inactiveClass}`} style={isActive('member-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Plus className="w-3.5 h-3.5" /> Добавить
                        </button>
                        <div>
                          <button onClick={() => toggleNested('positions')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100" style={{ color: COLORS.text }}>
                            <span className="flex items-center gap-3"><Briefcase className="w-3.5 h-3.5" /> Должности</span>
                            <ChevronRight className="w-3.5 h-3.5" style={chevronStyle(!!expanded.positions)} />
                          </button>
                          <Collapse open={!!expanded.positions}>
                            <div className="ml-6 space-y-1 mt-1">
                              <button onClick={() => navigate('groups')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('groups') ? activeClass : inactiveClass}`} style={isActive('groups') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <List className="w-3.5 h-3.5" /> Все Должности
                              </button>
                              <button onClick={() => navigate('group-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('group-add') ? activeClass : inactiveClass}`} style={isActive('group-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <PlusCircle className="w-3.5 h-3.5" /> Добавить
                              </button>
                            </div>
                          </Collapse>
                        </div>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== ТСД подсекции ====== */}
                  {key === 'tsd' && (
                    <Collapse open={!!expanded.tsd}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('tsd-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('tsd-list') ? activeClass : inactiveClass}`} style={isActive('tsd-list') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Smartphone className="w-3.5 h-3.5" /> Все ТСД
                        </button>
                        <button onClick={() => navigate('tsd-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('tsd-add') ? activeClass : inactiveClass}`} style={isActive('tsd-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Plus className="w-3.5 h-3.5" /> Добавить
                        </button>
                        <div>
                          <button onClick={() => toggleNested('repair')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100" style={{ color: COLORS.text }}>
                            <span className="flex items-center gap-3"><Wrench className="w-3.5 h-3.5" /> Ремонт</span>
                            <ChevronRight className="w-3.5 h-3.5" style={chevronStyle(!!expanded.repair)} />
                          </button>
                          <Collapse open={!!expanded.repair}>
                            <div className="ml-6 space-y-1 mt-1">
                              <button onClick={() => navigate('tsd-repairs')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('tsd-repairs') ? activeClass : inactiveClass}`} style={isActive('tsd-repairs') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <List className="w-3.5 h-3.5" /> Все Ремонты
                              </button>
                              <button onClick={() => navigate('tsd-repair-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('tsd-repair-add') ? activeClass : inactiveClass}`} style={isActive('tsd-repair-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <PlusCircle className="w-3.5 h-3.5" /> Добавить
                              </button>

                            </div>
                          </Collapse>
                        </div>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== Принтеры подсекции ====== */}
                  {key === 'printer' && (
                    <Collapse open={!!expanded.printer}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('printer-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('printer-list') ? activeClass : inactiveClass}`} style={isActive('printer-list') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <PrinterIcon className="w-3.5 h-3.5" /> Все Принтеры
                        </button>
                        <button onClick={() => navigate('printer-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('printer-add') ? activeClass : inactiveClass}`} style={isActive('printer-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Plus className="w-3.5 h-3.5" /> Добавить
                        </button>
                        <div>
                          <button onClick={() => toggleNested('printerRepair')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100" style={{ color: COLORS.text }}>
                            <span className="flex items-center gap-3"><Wrench className="w-3.5 h-3.5" /> Ремонт</span>
                            <ChevronRight className="w-3.5 h-3.5" style={chevronStyle(!!expanded.printerRepair)} />
                          </button>
                          <Collapse open={!!expanded.printerRepair}>
                            <div className="ml-6 space-y-1 mt-1">
                              <button onClick={() => navigate('printer-repairs')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('printer-repairs') ? activeClass : inactiveClass}`} style={isActive('printer-repairs') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <List className="w-3.5 h-3.5" /> Все Ремонты
                              </button>
                              <button onClick={() => navigate('printer-repair-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('printer-repair-add') ? activeClass : inactiveClass}`} style={isActive('printer-repair-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <PlusCircle className="w-3.5 h-3.5" /> Добавить
                              </button>

                            </div>
                          </Collapse>
                        </div>
                        <button onClick={() => navigate('printer-consumption')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('printer-consumption') ? activeClass : inactiveClass}`} style={isActive('printer-consumption') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <BarChart className="w-3.5 h-3.5" /> Расход
                        </button>
                        <div>
                          <button onClick={() => toggleNested('cartridge')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100" style={{ color: COLORS.text }}>
                            <span className="flex items-center gap-3"><Droplet className="w-3.5 h-3.5" /> Картриджи</span>
                            <ChevronRight className="w-3.5 h-3.5" style={chevronStyle(!!expanded.cartridge)} />
                          </button>
                          <Collapse open={!!expanded.cartridge}>
                            <div className="ml-6 space-y-1 mt-1">
                              <button onClick={() => navigate('cartridge-inventory')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('cartridge-inventory') ? activeClass : inactiveClass}`} style={isActive('cartridge-inventory') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <PaintBucket className="w-3.5 h-3.5" /> Сводка
                              </button>
                              <button onClick={() => navigate('cartridge-models')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm ${isActive('cartridge-models') ? activeClass : inactiveClass}`} style={isActive('cartridge-models') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                                <BookOpen className="w-3.5 h-3.5" /> Справочник
                              </button>
                            </div>
                          </Collapse>
                        </div>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== ККМ подсекции ====== */}
                  {key === 'kkm' && (
                    <Collapse open={!!expanded.kkm}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('kkm-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('kkm-list') ? activeClass : inactiveClass}`} style={isActive('kkm-list') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <CreditCard className="w-3.5 h-3.5" /> Все ККМ
                        </button>
                        <button onClick={() => navigate('kkm-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('kkm-add') ? activeClass : inactiveClass}`} style={isActive('kkm-add') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Plus className="w-3.5 h-3.5" /> Добавить
                        </button>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== Статистика подсекции ====== */}
                  {key === 'statistics' && (
                    <Collapse open={!!expanded.statistics}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('stat-starshie')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('stat-starshie') ? activeClass : inactiveClass}`} style={isActive('stat-starshie') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Star className="w-3.5 h-3.5" /> Старшие
                        </button>
                        <button onClick={() => navigate('stat-kladovshiki')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('stat-kladovshiki') ? activeClass : inactiveClass}`} style={isActive('stat-kladovshiki') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Package className="w-3.5 h-3.5" /> Кладовщики
                        </button>
                        <button onClick={() => navigate('stat-import')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('stat-import') ? activeClass : inactiveClass}`} style={isActive('stat-import') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Upload className="w-3.5 h-3.5" /> Импорт WMS
                        </button>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== Печать подсекции ====== */}
                  {key === 'print' && (
                    <Collapse open={!!expanded.print}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('print-tsd')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('print-tsd') ? activeClass : inactiveClass}`} style={isActive('print-tsd') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Smartphone className="w-3.5 h-3.5" /> Реестр ТСД
                        </button>
                        <button onClick={() => navigate('print-kkm')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('print-kkm') ? activeClass : inactiveClass}`} style={isActive('print-kkm') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <CreditCard className="w-3.5 h-3.5" /> Реестр ККМ
                        </button>
                        <button onClick={() => navigate('print-barcode')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('print-barcode') ? activeClass : inactiveClass}`} style={isActive('print-barcode') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <ScanLine className="w-3.5 h-3.5" /> Штрихкод
                        </button>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== Настройки подсекции ====== */}
                  {key === 'settings' && (
                    <Collapse open={!!expanded.settings}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('settings-users')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('settings-users') ? activeClass : inactiveClass}`} style={isActive('settings-users') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <UserCog className="w-3.5 h-3.5" /> Пользователи
                        </button>
                      </div>
                    </Collapse>
                  )}

                  {/* ====== Учет остатков подсекции ====== */}
                  {key === 'inventory' && (
                    <Collapse open={!!expanded.inventory}>
                      <div className="ml-6 space-y-1 mt-1">
                        <button onClick={() => navigate('inventory-balance')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm ${isActive('inventory-balance') ? activeClass : inactiveClass}`} style={isActive('inventory-balance') ? { backgroundColor: COLORS.primary, color: '#fff' } : { color: COLORS.text }}>
                          <Scale className="w-3.5 h-3.5" /> Сверка остатков
                        </button>
                      </div>
                    </Collapse>
                  )}
                </>
              )}
            </div>
          ))}

          {/* Инструменты и Логи — отдельные кнопки */}
          {isCollapsed ? (
            <>
              <div className="sidebar-collapsed-item relative">
                <button
                  onClick={() => navigate('tools')}
                  className={`w-full flex items-center justify-center p-2.5 text-sm font-medium rounded-lg ${isActive('tools') ? activeClass : inactiveClass}`}
                  style={isActive('tools') ? { ...t, backgroundColor: COLORS.primary, color: '#fff' } : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }}
                >
                  <ToolsIcon className="w-4 h-4" />
                </button>
                <span className="sidebar-collapsed-tooltip">Инструменты</span>
              </div>
              <div className="sidebar-collapsed-item relative">
                <button
                  onClick={() => navigate('logs')}
                  className={`w-full flex items-center justify-center p-2.5 text-sm font-medium rounded-lg ${isActive('logs') ? activeClass : inactiveClass}`}
                  style={isActive('logs') ? { ...t, backgroundColor: COLORS.primary, color: '#fff' } : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }}
                >
                  <FileText className="w-4 h-4" />
                </button>
                <span className="sidebar-collapsed-tooltip">Логи</span>
              </div>
            </>
          ) : (
            <>
              <button onClick={() => navigate('tools')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium ${isActive('tools') ? activeClass : inactiveClass}`} style={isActive('tools')
                ? { ...t, backgroundColor: COLORS.primary, color: '#fff' }
                : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }
              }>
                <ToolsIcon className="w-4 h-4" /> Инструменты
              </button>
              <button onClick={() => navigate('logs')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium ${isActive('logs') ? activeClass : inactiveClass}`} style={isActive('logs')
                ? { ...t, backgroundColor: COLORS.primary, color: '#fff' }
                : { ...t, color: COLORS.heading, backgroundColor: 'transparent' }
              }>
                <FileText className="w-4 h-4" /> Логи
              </button>
            </>
          )}
        </nav>
      </aside>
    </>
  );
}

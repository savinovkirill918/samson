const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '..', 'db', 'custom.db');
const JSON_PATH = '/tmp/samson_data.json';

// Connect to DB
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

console.log('Connected to DB:', DB_PATH);

// Load JSON data
const data = JSON.parse(fs.readFileSync(JSON_PATH, 'utf-8'));
console.log('Loaded JSON data from:', JSON_PATH);
console.log('Summary:', JSON.stringify(data.summary));

// ============================================================
// STEP 1: Delete existing data (respecting FK constraints)
// ============================================================
console.log('\n=== DELETING EXISTING DATA ===');

const deleteRepair = db.prepare('DELETE FROM Repair');
const deleteMember = db.prepare('DELETE FROM Member');
const deleteKKM = db.prepare('DELETE FROM KKM');
const deleteTSD = db.prepare('DELETE FROM TSD');
const deleteGroup = db.prepare('DELETE FROM "Group"');

const transaction = db.transaction(() => {
  const r1 = deleteRepair.run();
  console.log(`Deleted ${r1.changes} rows from Repair`);
  const r2 = deleteMember.run();
  console.log(`Deleted ${r2.changes} rows from Member`);
  const r3 = deleteKKM.run();
  console.log(`Deleted ${r3.changes} rows from KKM`);
  const r4 = deleteTSD.run();
  console.log(`Deleted ${r4.changes} rows from TSD`);
  const r5 = deleteGroup.run();
  console.log(`Deleted ${r5.changes} rows from "Group"`);
});

transaction();
console.log('Delete complete.\n');

// ============================================================
// STEP 2: Insert Groups (positions)
// ============================================================
console.log('=== INSERTING GROUPS ===');

const insertGroup = db.prepare(
  'INSERT INTO "Group" (id, name, sort) VALUES (?, ?, ?)'
);

const groupNameToId = new Map(); // position name -> group id

for (const pos of data.positions) {
  insertGroup.run(
    parseInt(pos.id, 10),
    pos.name,
    parseInt(pos.sort_order, 10)
  );
  groupNameToId.set(pos.name, parseInt(pos.id, 10));
}
console.log(`Inserted ${data.positions.length} groups`);
console.log('Group name->id map has', groupNameToId.size, 'entries');

// ============================================================
// STEP 3: Insert TSD
// ============================================================
console.log('\n=== INSERTING TSD ===');

const insertTSD = db.prepare(
  'INSERT INTO TSD (id, number, sn, inv, model, isMulti) VALUES (?, ?, ?, ?, ?, ?)'
);

const tsdNumberToId = new Map(); // tsd number -> tsd id

for (const tsd of data.tsd) {
  const tsdId = parseInt(tsd.id, 10);
  const tsdNumber = parseInt(tsd.number, 10);
  insertTSD.run(
    tsdId,
    tsdNumber,
    tsd.serial || '',
    tsd.inv_number || '',
    tsd.model || '',
    tsd.is_multi ? 1 : 0
  );
  tsdNumberToId.set(tsdNumber, tsdId);
}
console.log(`Inserted ${data.tsd.length} TSD records`);
console.log('TSD number->id map has', tsdNumberToId.size, 'entries');

// ============================================================
// STEP 4: Insert KKM
// ============================================================
console.log('\n=== INSERTING KKM ===');

// KKM JSON doesn't have an explicit id, use auto-generated IDs.
// We'll insert and build a lookup from KKM number -> DB id.
// KKM number in JSON is like "№1", "№10" -> extract integer part.
// In DB, KKM.number is Int @unique.

const insertKKM = db.prepare(
  'INSERT INTO KKM (number, sn, inv, isMulti) VALUES (?, ?, ?, ?)'
);

// Use a transaction for KKM insert to get all IDs
let insertedKKMCount = 0;
const kkmNumberToId = new Map(); // kkm number (int) -> kkm db id

const insertKKMsTransaction = db.transaction(() => {
  for (const kkm of data.kkm) {
    // Extract integer from "№1" -> 1, "№10" -> 10
    const numStr = kkm.number.replace(/[№\s]/g, '');
    const kkmNumber = parseInt(numStr, 10);
    const result = insertKKM.run(
      kkmNumber,
      kkm.serial || '',
      kkm.inv_number || '',
      kkm.is_multi ? 1 : 0
    );
    kkmNumberToId.set(kkmNumber, result.lastInsertRowid);
    insertedKKMCount++;
  }
});

insertKKMsTransaction();
console.log(`Inserted ${insertedKKMCount} KKM records`);
console.log('KKM number->id map has', kkmNumberToId.size, 'entries');

// ============================================================
// STEP 5: Insert Members (employees)
// ============================================================
console.log('\n=== INSERTING MEMBERS ===');

const insertMember = db.prepare(
  'INSERT INTO Member (id, fio, login, password, groupId, tsdId, kkmId) VALUES (?, ?, ?, ?, ?, ?, ?)'
);

let insertedMemberCount = 0;
let warnings = [];

const insertMembersTransaction = db.transaction(() => {
  for (const emp of data.employees) {
    const empId = parseInt(emp.id, 10);

    // Find groupId by matching position name
    const groupId = groupNameToId.get(emp.position);
    if (!groupId) {
      warnings.push(`Employee ${emp.fio} (id=${empId}): position "${emp.position}" not found in groups`);
    }

    // Find tsdId by matching tsd_number to TSD number
    let tsdId = null;
    if (emp.tsd_number && emp.tsd_number.trim() !== '') {
      const tsdNumber = parseInt(emp.tsd_number, 10);
      tsdId = tsdNumberToId.get(tsdNumber);
      if (!tsdId) {
        warnings.push(`Employee ${emp.fio} (id=${empId}): TSD number ${emp.tsd_number} not found`);
      }
    }

    // Find kkmId by matching kkm_number to KKM number
    // Employee kkm_number is like "ККМ №10" -> extract integer -> match to KKM number
    let kkmId = null;
    if (emp.kkm_number && emp.kkm_number.trim() !== '') {
      // Extract integer from "ККМ №10" -> 10
      const kkmNumMatch = emp.kkm_number.match(/(\d+)/);
      if (kkmNumMatch) {
        const kkmNumber = parseInt(kkmNumMatch[1], 10);
        kkmId = kkmNumberToId.get(kkmNumber);
        if (!kkmId) {
          warnings.push(`Employee ${emp.fio} (id=${empId}): KKM number ${emp.kkm_number} not found`);
        }
      } else {
        warnings.push(`Employee ${emp.fio} (id=${empId}): could not parse KKM number from "${emp.kkm_number}"`);
      }
    }

    insertMember.run(
      empId,
      emp.fio,
      emp.login,
      emp.password,
      groupId || 0,
      tsdId,
      kkmId
    );
    insertedMemberCount++;
  }
});

insertMembersTransaction();
console.log(`Inserted ${insertedMemberCount} members`);

if (warnings.length > 0) {
  console.log(`\n=== WARNINGS (${warnings.length}) ===`);
  warnings.forEach(w => console.log('  -', w));
}

// ============================================================
// VERIFY
// ============================================================
console.log('\n=== VERIFICATION ===');
const countMember = db.prepare('SELECT count(*) as cnt FROM Member').get();
const countTSD = db.prepare('SELECT count(*) as cnt FROM TSD').get();
const countKKM = db.prepare('SELECT count(*) as cnt FROM KKM').get();
const countGroup = db.prepare('SELECT count(*) as cnt FROM "Group"').get();
const countRepair = db.prepare('SELECT count(*) as cnt FROM Repair').get();

console.log(`Group:  ${countGroup.cnt}`);
console.log(`TSD:    ${countTSD.cnt}`);
console.log(`KKM:    ${countKKM.cnt}`);
console.log(`Member: ${countMember.cnt}`);
console.log(`Repair: ${countRepair.cnt}`);

console.log('\n=== IMPORT COMPLETE ===');
console.log(`Expected: ${data.summary.total_positions} groups, ${data.summary.total_tsd} TSD, ${data.summary.total_kkm} KKM, ${data.summary.total_employees} members`);
console.log(`Got:      ${countGroup.cnt} groups, ${countTSD.cnt} TSD, ${countKKM.cnt} KKM, ${countMember.cnt} members`);

db.close();

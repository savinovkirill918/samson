# Самсон Склад — Система управления складом

Веб-приложение для управления складом: учёт сотрудников, ТСД (терминалы сбора данных), ККМ (контрольно-кассовые машины), ремонтов, статистики и генерации печатных форм (бейджи, наклейки со штрихкодами).

Рекреация оригинального сайта [samson.umk0.ru](https://samson.umk0.ru) на Next.js 16 + Tailwind CSS + Prisma 7 + SQLite.

---

## Технологический стек

| Компонент | Технология | Версия |
|---|---|---|
| Фреймворк | Next.js (App Router, standalone) | 16.x |
| UI | React 19 + Tailwind CSS 4 | 19.x / 4.x |
| База данных | SQLite (через better-sqlite3) | — |
| ORM | Prisma (с адаптером better-sqlite3) | 7.7+ |
| Иконки | lucide-react | 1.8+ |
| PDF-генерация | jsPDF + JsBarcode + node-canvas | — |
| Процесс-менеджер | PM2 | — |
| Язык | TypeScript | 5.x |

---

## Структура проекта

```
samson-warehouse/
├── .env                          # DATABASE_URL=file:./db/custom.db
├── ecosystem.config.js           # PM2 конфигурация для продакшена
├── next.config.ts                # output: standalone, ignoreBuildErrors
├── package.json
├── package-lock.json
├── postcss.config.mjs            # @tailwindcss/postcss
├── prisma.config.ts              # Prisma 7 config (datasource URL)
├── tsconfig.json
├── components.json               # shadcn/ui конфигурация
├── prisma/
│   ├── schema.prisma             # 12 моделей: Group, Member, TSD, KKM, Repair...
│   └── seed.js                   # Начальное заполнение БД
├── db/
│   └── custom.db                 # SQLite база данных (создаётся автоматически)
├── public/
│   ├── logo.svg
│   └── robots.txt
└── src/
    ├── lib/
    │   ├── prisma.ts             # Prisma клиент с better-sqlite3 адаптером
    │   ├── api.ts                # Типизированные fetch-функции для API
    │   ├── types.ts              # Все TypeScript интерфейсы и типы
    │   ├── colors.ts             # Цветовая схема
    │   └── helpers.ts            # Утилиты (форматирование дат и т.д.)
    ├── hooks/
    │   ├── useMembers.ts         # CRUD сотрудников (загрузка + мутации)
    │   ├── useGroups.ts          # CRUD должностей
    │   ├── useTsd.ts             # CRUD ТСД
    │   ├── useKkm.ts             # CRUD ККМ
    │   ├── useRepairs.ts         # CRUD ремонтов
    │   ├── useLogs.ts            # Логи действий
    │   └── useAdmins.ts          # CRUD администраторов
    ├── generated/
    │   └── prisma/               # (автогенерация) — не коммитить
    ├── components/
    │   ├── ui/
    │   │   └── toaster.tsx       # Компонент уведомлений (shadcn/ui)
    │   ├── auth/
    │   │   └── LoginPage.tsx     # Страница авторизации
    │   ├── layout/
    │   │   ├── Sidebar.tsx       # Боковая навигация
    │   │   └── Breadcrumbs.tsx   # Хлебные крошки
    │   ├── home/
    │   │   └── HomePage.tsx      # Главная (дашборд)
    │   ├── members/
    │   │   ├── MembersList.tsx   # Таблица сотрудников
    │   │   └── MemberForm.tsx    # Форма добавления/редактирования
    │   ├── groups/
    │   │   ├── GroupsList.tsx    # Таблица должностей
    │   │   └── GroupForm.tsx     # Форма добавления/редактирования
    │   ├── tsd/
    │   │   ├── TsdList.tsx       # Список ТСД
    │   │   ├── TsdForm.tsx       # Форма ТСД
    │   │   ├── RepairsList.tsx   # Список ремонтов
    │   │   ├── RepairForm.tsx    # Форма ремонта
    │   │   └── RepairSZPage.tsx  # Служебная записка на ремонт
    │   ├── kkm/
    │   │   ├── KkmList.tsx       # Список ККМ
    │   │   └── KkmForm.tsx       # Форма ККМ
    │   ├── statistics/
    │   │   ├── StatStarshie.tsx  # Отчёт 49 — контролёры
    │   │   ├── StatKladovshiki.tsx # Отчёт 13 — кладовщики
    │   │   └── StatImport.tsx    # Импорт WMS
    │   ├── tools/
    │   │   └── ToolsPage.tsx     # Инструменты
    │   ├── logs/
    │   │   └── LogsPage.tsx      # Журнал действий
    │   ├── print/
    │   │   ├── PrintTsd.tsx      # Печать ТСД
    │   │   ├── PrintKkm.tsx      # Печать ККМ
    │   │   ├── PrintStickers.tsx # Печать наклеек
    │   │   ├── PrintBarcode.tsx  # Печать штрихкодов
    │   │   └── PrintContainers.tsx # Печать контейнеров
    │   └── settings/
    │       ├── SettingsUsers.tsx # Управление пользователями
    │       └── UserForm.tsx      # Форма пользователя
    └── app/
        ├── globals.css           # Tailwind CSS импорт
        ├── layout.tsx            # Корневой layout (lang="ru")
        ├── page.tsx              # Точка входа SPA (импорт + компоновка)
        └── api/
            ├── route.ts          # Health check
            ├── groups/route.ts   # CRUD должностей
            ├── members/route.ts  # CRUD сотрудников
            ├── tsds/route.ts     # CRUD ТСД
            ├── kkms/route.ts     # CRUD ККМ
            ├── repairs/route.ts  # CRUD ремонтов
            ├── logs/route.ts     # Логи действий
            ├── admins/route.ts   # CRUD администраторов
            ├── badge/route.ts    # Генерация PDF-бейджа
            ├── sticker/route.ts  # Генерация PDF-наклейки ТСД
            └── stats/
                ├── 13/route.ts       # Отчёт 13 — КТУ кладовщиков
                ├── 49/route.ts       # Отчёт 49 — Производительность контролёров
                ├── upload/route.ts   # Загрузка данных статистики
                └── uploads/route.ts  # История загрузок
```

---

## Инструкция по развёртыванию на новом сервере

### Предварительные требования

- **Node.js** 20+ (рекомендуется 22+)
- **npm** 10+
- **PM2** (глобально): `npm install -g pm2`
- Системные библиотеки для `canvas` и `better-sqlite3`:

**Ubuntu / Debian:**
```bash
apt update && apt install -y build-essential python3 libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev
```

**CentOS / RHEL:**
```bash
yum install -y gcc-c++ make python3 cairo-devel libjpeg-turbo-devel pango-devel giflib-devel librsvg2-devel
```

**Шрифты для PDF (кириллица):**
```bash
# Ubuntu/Debian
apt install -y fonts-liberation fonts-dejavu-core

# CentOS/RHEL
yum install -y liberation-fonts-common dejavu-sans-fonts
```

### Шаг 1. Подготовка проекта

```bash
# Распаковать архив
unzip "samson-warehouse new.zip" -d /opt/
cd /opt/samson-warehouse

# Установить зависимости
npm install
```

### Шаг 2. Настройка базы данных

```bash
# Создать директорию для БД (если нет)
mkdir -p db

# Сгенерировать Prisma-клиент
npx prisma generate

# Создать таблицы в БД
npx prisma db push

# Заполнить начальными данными (должности, сотрудники, ТСД, ККМ, админ)
node prisma/seed.js
```

### Шаг 3. Настройка переменных окружения

Отредактируйте файл `.env` в корне проекта:

```env
DATABASE_URL=file:/opt/samson-warehouse/db/custom.db
```

> **Важно:** Укажите **абсолютный путь** к файлу БД. Для локальной разработки можно использовать относительный путь `file:./db/custom.db`, но для продакшена нужен абсолютный.

### Шаг 4. Сборка для продакшена

```bash
npm run build
```

Сборка создаёт standalone-бандл в `.next/standalone/` и автоматически копирует туда `.next/static/` и `public/` (это прописано в скрипте `build` в package.json).

### Шаг 5. Настройка PM2

В проекте уже есть готовый файл `ecosystem.config.js`. Перед запуском отредактируйте пути в нём:

```javascript
module.exports = {
  apps: [
    {
      name: 'samson-warehouse',
      script: '.next/standalone/server.js',
      cwd: '/opt/samson-warehouse',                    // <-- путь к проекту
      env: {
        NODE_ENV: 'production',
        DATABASE_URL: 'file:/opt/samson-warehouse/db/custom.db',  // <-- абсолютный путь к БД
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      error_file: '/root/.pm2/logs/samson-warehouse-error.log',
      out_file: '/root/.pm2/logs/samson-warehouse-out.log',
      log_file: '/root/.pm2/logs/samson-warehouse.log',
      time: true,
      merge_logs: true,
    },
  ],
};
```

> **Что нужно изменить в ecosystem.config.js:**
> - `cwd` — путь к директории проекта на вашем сервере
> - `DATABASE_URL` — абсолютный путь к файлу базы данных
> - пути к лог-файлам (`error_file`, `out_file`, `log_file`) — по желанию

### Шаг 6. Запуск через PM2

```bash
# Запустить приложение
pm2 start ecosystem.config.js

# Сохранить список процессов (автозапуск при перезагрузке сервера)
pm2 save

# Настроить автозапуск PM2 при загрузке системы
pm2 startup
# PM2 выведет команду — выполните её (потребуются права root)
```

### Полезные команды PM2

```bash
pm2 list                    # Список процессов
pm2 logs samson-warehouse   # Логи в реальном времени
pm2 restart samson-warehouse # Перезапуск
pm2 stop samson-warehouse   # Остановка
pm2 delete samson-warehouse # Удаление процесса
pm2 monit                   # Мониторинг (CPU, RAM)
```

### Шаг 7. Проверка

```bash
# Проверить статус
pm2 status

# Проверить что приложение отвечает
curl http://localhost:3000
```

Приложение будет доступно на `http://YOUR_SERVER_IP:3000`.

---

## Альтернативный запуск (без PM2)

### Режим разработки
```bash
npm run dev
# http://localhost:3000
```

### Продакшен (ручной запуск)
```bash
npm run build
NODE_ENV=production DATABASE_URL=file:/opt/samson-warehouse/db/custom.db node .next/standalone/server.js
```

### Systemd-сервис (альтернатива PM2)

Создать файл `/etc/systemd/system/samson.service`:

```ini
[Unit]
Description=Samson Warehouse Management App
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/samson-warehouse
Environment="NODE_ENV=production"
Environment="DATABASE_URL=file:/opt/samson-warehouse/db/custom.db"
ExecStart=/usr/bin/node /opt/samson-warehouse/.next/standalone/server.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable samson
systemctl start samson
systemctl status samson
```

---

## Перенос на другой сервер (сохранение данных)

Если нужно перенести проект **с сохранением существующей базы данных**:

```bash
# === На старом сервере ===

# 1. Остановить приложение
pm2 stop samson-warehouse

# 2. Заархивировать проект (без node_modules и .next)
cd /opt
tar czf samson-warehouse-backup.tar.gz \
  --exclude='samson-warehouse/node_modules' \
  --exclude='samson-warehouse/.next' \
  samson-warehouse/

# 3. Скопировать на новый сервер
scp samson-warehouse-backup.tar.gz root@NEW_SERVER_IP:/opt/
```

```bash
# === На новом сервере ===

# 1. Распаковать
cd /opt
tar xzf samson-warehouse-backup.tar.gz
cd samson-warehouse

# 2. Установить зависимости
npm install

# 3. Пересобрать нативные модули (важно для другой архитектуры!)
npm rebuild better-sqlite3 canvas

# 4. Пересгенерировать Prisma-клиент
npx prisma generate

# 5. Скорректировать пути в .env и ecosystem.config.js
# (измените пути на актуальные для нового сервера)

# 6. Собрать
npm run build

# 7. Запустить через PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

---

## Обновление проекта (замена архива на GitHub)

Если вы обновили архив на GitHub и хотите применить изменения:

```bash
# 1. Скачать новый архив
cd /tmp
wget https://github.com/savinovkirill918/samson/raw/refs/heads/main/"samson-warehouse new.zip"

# 2. Остановить приложение
pm2 stop samson-warehouse

# 3. Резервная копия БД (ВАЖНО!)
cp /opt/samson-warehouse/db/custom.db /opt/samson-warehouse/db/custom.db.backup

# 4. Распаковать новый архив (перезапись исходников)
unzip -o "samson-warehouse new.zip" -d /opt/samson-warehouse/

# 5. Установить зависимости (если изменились)
cd /opt/samson-warehouse
npm install

# 6. Пересобрать нативные модули
npm rebuild better-sqlite3 canvas

# 7. Обновить схему БД (если изменились модели)
npx prisma generate
npx prisma db push

# 8. Собрать и запустить
npm run build
pm2 restart samson-warehouse
```

---

## Модели базы данных (Prisma Schema)

| Модель | Описание | Ключевые поля |
|---|---|---|
| **Group** | Должность/группа сотрудников | name, sort |
| **Member** | Сотрудник склада | fio, login, password, email, groupId, tsdId, kkmId, tg |
| **TSD** | Терминал сбора данных | number (уникальный), sn, inv, model, isMulti |
| **KKM** | Контрольно-кассовая машина | number (уникальный), sn, inv, isMulti |
| **Repair** | Ремонт ТСД | tsdId, brokenDate, sentDate, returnedDate, status, description, isGuilty, cost |
| **LogEntry** | Запись лога действий | adminId, text, date |
| **AdminUser** | Пользователь системы | login (уникальный), hash, fio, role, groupId |
| **Stat13Upload** | Загрузка отчёта 13 (КТУ кладовщиков) | dateFrom, dateTo, groupName |
| **Stat13Row** | Строка отчёта 13 | fio, shtCnt, krCnt, pshtCnt, razmCnt, pkrCnt, ktu, hours, avgPerHour |
| **Stat49Upload** | Загрузка отчёта 49 (контролёры) | dateFrom, dateTo |
| **Stat49AvgRow** | Средние данные контролёра | controller, orderType, allErp, avgProizvod |
| **Stat49DailyRow** | Дневные данные контролёра | date, controller, orderType, allErp, avgProizvod |

---

## API-маршруты

### CRUD операции

| Метод | Маршрут | Описание |
|---|---|---|
| GET/POST | `/api/groups` | Список должностей / Создать |
| GET/PUT/DELETE | `/api/members` | Сотрудники (id через query или body) |
| GET/POST/PUT/DELETE | `/api/tsds` | ТСД |
| GET/POST/PUT/DELETE | `/api/kkms` | ККМ |
| GET/POST/PUT/DELETE | `/api/repairs` | Ремонты |
| GET/POST | `/api/logs` | Логи |
| GET/POST/PUT/DELETE | `/api/admins` | Администраторы |

### PDF-генерация

| Метод | Маршрут | Параметры | Описание |
|---|---|---|---|
| GET | `/api/badge` | fio, login, password, tsdNumber | PDF-бейдж сотрудника |
| GET | `/api/sticker` | number, fio, sn, inv | PDF-наклейка на ТСД (60x40мм) |

### Статистика

| Метод | Маршрут | Параметры | Описание |
|---|---|---|---|
| GET | `/api/stats/13` | uploadId (опц.) | Данные отчёта 13 |
| GET | `/api/stats/49` | uploadId (опц.) | Данные отчёта 49 |
| POST | `/api/stats/upload` | JSON body | Загрузка данных статистики |
| GET | `/api/stats/uploads` | type=13\|49 | История загрузок |

---

## Страницы приложения (SPA)

Приложение реализовано как SPA (Single Page Application) — страницы переключаются через состояние React. Фронтенд разбит на компоненты: `src/components/`, данные загружаются через хуки `src/hooks/` с запросами к API.

| PageId | Название | Компонент | Описание |
|---|---|---|---|
| `home` | Главная | HomePage.tsx | Дашборд с предупреждениями, последние логи |
| `members` | Сотрудники | MembersList.tsx | Таблица сотрудников |
| `member-add/edit` | Форма сотрудника | MemberForm.tsx | Добавление/редактирование |
| `groups` | Должности | GroupsList.tsx | Управление должностями |
| `tsd-list/add/edit` | ТСД | TsdList.tsx, TsdForm.tsx | Терминалы сбора данных |
| `tsd-repairs` | Ремонты | RepairsList.tsx, RepairForm.tsx | Учёт ремонтов ТСД |
| `tsd-repair-sz` | Служебная записка | RepairSZPage.tsx | Генерация СЗ на ремонт |
| `kkm-list/add` | ККМ | KkmList.tsx, KkmForm.tsx | Кассовые машины |
| `stat-starshie` | Старшие | StatStarshie.tsx | Отчёт 49 — контролёры |
| `stat-kladovshiki` | Кладовщики | StatKladovshiki.tsx | Отчёт 13 — КТУ кладовщиков |
| `stat-import` | Импорт WMS | StatImport.tsx | Загрузка XML-файлов |
| `tools` | Инструменты | ToolsPage.tsx | Служебные инструменты |
| `logs` | Логи | LogsPage.tsx | Журнал действий |
| `print-*` | Печать | Print*.tsx | Печатные формы |
| `settings-users` | Настройки | SettingsUsers.tsx, UserForm.tsx | Управление пользователями |

---

## Важные замечания

1. **Prisma 7 + better-sqlite3**: Используется адаптер `@prisma/adapter-better-sqlite3`. Нельзя просто `new PrismaClient()` — нужен адаптер. См. `src/lib/prisma.ts`.

2. **prisma.config.ts**: В Prisma 7 datasource URL задаётся в `prisma.config.ts` (не только в schema.prisma). Файл обязателен.

3. **Генерация клиента**: После `npx prisma generate` клиент создаётся в `src/generated/prisma/`. Импорт: `from '@/generated/prisma/client'`.

4. **Нативные модули**: `better-sqlite3` и `canvas` содержат нативный C-код. При переносе на другой сервер **обязательно** пересобрать: `npm rebuild better-sqlite3 canvas`.

5. **Standalone-сборка**: `next.config.ts` содержит `output: "standalone"`. Скрипт `npm run build` автоматически копирует `.next/static/` и `public/` внутрь standalone.

6. **DATABASE_URL**: Для продакшена используйте **абсолютный путь**: `file:/opt/samson-warehouse/db/custom.db`. Для разработки — относительный: `file:./db/custom.db`.

7. **Шрифты для PDF**: Для генерации PDF с кириллицей:
   - Times New Roman, Liberation Serif, DejaVu Sans
   - Ubuntu: `apt install fonts-liberation fonts-dejavu-core`

8. **PM2 и env**: Standalone-сборка Next.js не загружает `.env` автоматически. Поэтому переменные окружения (включая `DATABASE_URL`) передаются через блок `env` в `ecosystem.config.js`.

---

## Вход в систему

После выполнения `node prisma/seed.js`:
- **Логин**: admin
- **Пароль**: любой (в текущей реализации проверяется только наличие логина в БД)

---

## Цветовая схема

```
primary:       #3a57e8  (синий, кнопки и акценты)
bodyBg:        #f5f6fa  (фон страницы)
sidebarBg:     #ffffff  (фон боковой панели)
heading:       #212529  (заголовки)
text:          #8a92a6  (обычный текст)
alertBg:       #e9ecef  (фон предупреждений)
success:       #198754  (зелёные кнопки)
white:         #ffffff
```

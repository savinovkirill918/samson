// =====================================================================
// Seed script — начальное заполнение базы данных Самсон Склад
// Запуск: node prisma/seed.js
// =====================================================================

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'db', 'custom.db');
const db = new Database(DB_PATH);

console.log('Заполнение базы данных начальными данными...');

// Вставляем должности (как на оригинальном сайте samson.umk0.ru)
const insertGroup = db.prepare('INSERT INTO "Group" (name, sort) VALUES (?, ?)');
const groups = [
  { name: 'Зав. складом', sort: 1 },
  { name: 'Старший кладовщик', sort: 2 },
  { name: 'Кладовщик', sort: 3 },
  { name: 'Контролёр', sort: 4 },
  { name: 'Оператор ввода', sort: 5 },
  { name: 'Водитель погрузчика', sort: 6 },
  { name: 'Уборщик', sort: 7 },
];
groups.forEach(g => insertGroup.run(g.name, g.sort));
console.log(`  Добавлено должностей: ${groups.length}`);

// Вставляем администратора
db.prepare('INSERT INTO AdminUser (login, hash, fio, role, groupId) VALUES (?, ?, ?, ?, ?)')
  .run('admin', '', 'Администратор', 'Админ', 1);
console.log('  Добавлен администратор: admin');

// Вставляем ТСД
const insertTsd = db.prepare('INSERT INTO TSD (number, sn, inv, model, isMulti) VALUES (?, ?, ?, ?, ?)');
const tsds = [
  { number: 101, sn: 'SN-TSD-001', inv: 'INV-001', model: 'Zebra MC9300', isMulti: 0 },
  { number: 102, sn: 'SN-TSD-002', inv: 'INV-002', model: 'Zebra MC9300', isMulti: 0 },
  { number: 103, sn: 'SN-TSD-003', inv: 'INV-003', model: 'Honeywell CK65', isMulti: 0 },
  { number: 104, sn: 'SN-TSD-004', inv: 'INV-004', model: 'Zebra TC72', isMulti: 1 },
];
tsds.forEach(t => insertTsd.run(t.number, t.sn, t.inv, t.model, t.isMulti));
console.log(`  Добавлено ТСД: ${tsds.length}`);

// Вставляем ККМ
const insertKkm = db.prepare('INSERT INTO KKM (number, sn, inv, isMulti) VALUES (?, ?, ?, ?)');
const kkms = [
  { number: 1, sn: 'SN-KKM-001', inv: 'INV-KKM-001', isMulti: 0 },
  { number: 2, sn: 'SN-KKM-002', inv: 'INV-KKM-002', isMulti: 0 },
];
kkms.forEach(k => insertKkm.run(k.number, k.sn, k.inv, k.isMulti));
console.log(`  Добавлено ККМ: ${kkms.length}`);

// Вставляем сотрудников
const insertMember = db.prepare(
  'INSERT INTO Member (fio, login, password, email, emailPassword, groupId, tsdId, kkmId, tg) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
);
const members = [
  { fio: 'Иванов Иван Иванович', login: 'ivanov', password: 'pass123', email: 'ivanov@samson.ru', emailPassword: '', groupId: 3, tsdId: 1, kkmId: null, tg: '@ivanov' },
  { fio: 'Петров Пётр Петрович', login: 'petrov', password: 'pass456', email: 'petrov@samson.ru', emailPassword: '', groupId: 3, tsdId: 2, kkmId: null, tg: '@petrov' },
  { fio: 'Сидорова Анна Владимировна', login: 'sidorova', password: 'pass789', email: 'sidorova@samson.ru', emailPassword: '', groupId: 4, tsdId: 3, kkmId: null, tg: '@sidorova' },
  { fio: 'Козлов Дмитрий Сергеевич', login: 'kozlov', password: 'pass101', email: '', emailPassword: '', groupId: 2, tsdId: null, kkmId: 1, tg: '' },
  { fio: 'Новикова Елена Александровна', login: 'novikova', password: 'pass202', email: '', emailPassword: '', groupId: 4, tsdId: 4, kkmId: 2, tg: '' },
  { fio: 'Смирнов Алексей Николаевич', login: 'smirnov', password: 'pass303', email: '', emailPassword: '', groupId: 1, tsdId: null, kkmId: null, tg: '' },
];
members.forEach(m => insertMember.run(m.fio, m.login, m.password, m.email, m.emailPassword, m.groupId, m.tsdId, m.kkmId, m.tg));
console.log(`  Добавлено сотрудников: ${members.length}`);

db.close();
console.log('\nБаза данных успешно заполнена!');

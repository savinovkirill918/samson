import { Group, TSD, KKM, Repair } from './types';

/** Получить название группы по ID */
export const getGroupName = (groupId: number, groups: Group[]): string => {
  return groups.find(g => g.id === groupId)?.name || 'Не указана';
};

/** Получить ТСД по ID */
export const getTsd = (tsdId: number | null, tsds: TSD[]): TSD | null => {
  if (!tsdId) return null;
  return tsds.find(t => t.id === tsdId) || null;
};

/** Получить ККМ по ID */
export const getKkm = (kkmId: number | null, kkms: KKM[]): KKM | null => {
  if (!kkmId) return null;
  return kkms.find(k => k.id === kkmId) || null;
};

/** Форматирование даты для отображения */
export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

/** Форматирование даты и времени для логов */
export const formatDateTime = (isoStr: string): string => {
  const d = new Date(isoStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
};

/** Статус ремонта: число → текст */
export const repairStatusText = (status: number): string => {
  switch (status) {
    case 0: return 'Отправлен';
    case 1: return 'Вернулся с ремонта';
    default: return 'Сломан не отправлен';
  }
};

/** Статус ремонта: текст → число */
export const repairStatusToNumber = (status: string): number => {
  switch (status) {
    case 'Отправлен': return 0;
    case 'Вернулся с ремонта': return 1;
    default: return -1;
  }
};

/** Проверить, что ремонт активен (не вернулся с ремонта) */
export const isRepairActive = (repair: Repair): boolean => {
  return repair.status !== 1;
};

export const COLORS = {
  bodyBg: '#f5f6fa',
  sidebarBg: '#ffffff',
  primary: '#3a57e8',
  heading: '#212529',
  text: '#8a92a6',
  alertBg: '#e9ecef',
  white: '#ffffff',
};

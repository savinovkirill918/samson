/** Группа/должность сотрудника */
export interface Group {
  id: number;
  name: string;
  sort: number;
}

/** Сотрудник склада */
export interface Member {
  id: number;
  fio: string;
  login: string;
  password: string;
  email: string;
  emailPassword: string;
  groupId: number;
  tsdId: number | null;
  kkmId: number | null;
  tg: string;
  group?: Group;
  tsd?: TSD | null;
  kkm?: KKM | null;
}

/** ТСД — терминал сбора данных */
export interface TSD {
  id: number;
  number: number;
  sn: string;
  inv: string;
  model: string;
  isMulti: boolean;
  members?: Member[];
  repairs?: Repair[];
}

/** ККМ — контрольно-кассовая машина */
export interface KKM {
  id: number;
  number: number;
  sn: string;
  inv: string;
  isMulti: boolean;
  members?: Member[];
}

/** Ремонт ТСД */
export interface Repair {
  id: number;
  tsdId: number;
  brokenDate: string;
  sentDate: string;
  returnedDate: string;
  status: number;
  description: string;
  isGuilty: boolean;
  cost: number;
  tsd?: TSD;
}

/** Запись лога действий */
export interface LogEntry {
  id: number;
  adminId: number;
  text: string;
  date: string;
}

/** Пользователь системы (администратор) */
export interface AdminUser {
  id: number;
  login: string;
  hash: string;
  fio: string;
  role: string;
  groupId: number;
}

/** Типы страниц навигации */
export type PageId =
  | 'home'
  | 'members' | 'member-add' | 'member-edit'
  | 'groups' | 'group-add'
  | 'tsd-list' | 'tsd-add' | 'tsd-edit' | 'tsd-repairs' | 'tsd-repair-add' | 'tsd-repair-edit' | 'tsd-repair-sz'
  | 'kkm-list' | 'kkm-add'
  | 'stat-starshie' | 'stat-kladovshiki' | 'stat-import'
  | 'tools'
  | 'logs'
  | 'print-tsd' | 'print-kkm' | 'print-stickers' | 'print-barcode' | 'print-containers'
  | 'settings-users' | 'settings-user-add';

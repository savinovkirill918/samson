'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Member } from '@/lib/types';
import * as api from '@/lib/api';

export function useMembers() {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMembers = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getMembers();
      setMembers(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки сотрудников');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchMembers(); }, [fetchMembers]);

  const saveMember = useCallback(async (member: Member & { isNew?: boolean }) => {
    if (member.isNew) {
      const { isNew: _, group: __, tsd: ___, kkm: ____, ...data } = member;
      await api.createMember(data);
    } else {
      const { group: _, tsd: __, kkm: ___, ...data } = member;
      await api.updateMember(data);
    }
    await fetchMembers();
  }, [fetchMembers]);

  const deleteMember = useCallback(async (id: number) => {
    await api.deleteMember(id);
    await fetchMembers();
  }, [fetchMembers]);

  return { members, loading, error, saveMember, deleteMember, refetch: fetchMembers };
}

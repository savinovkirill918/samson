'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Repair } from '@/lib/types';
import * as api from '@/lib/api';

export function useRepairs() {
  const [repairs, setRepairs] = useState<Repair[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRepairs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getRepairs();
      setRepairs(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки ремонтов');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchRepairs(); }, [fetchRepairs]);

  const saveRepair = useCallback(async (repair: {
    tsdId: number;
    brokenDate: string;
    sentDate?: string;
    returnedDate?: string;
    status?: number;
    description: string;
    isGuilty?: boolean;
    cost?: number;
  }) => {
    await api.createRepair(repair);
    await fetchRepairs();
  }, [fetchRepairs]);

  const updateRepair = useCallback(async (repair: Partial<Repair> & { id: number }) => {
    await api.updateRepair(repair);
    await fetchRepairs();
  }, [fetchRepairs]);

  return { repairs, loading, error, saveRepair, updateRepair, refetch: fetchRepairs };
}

'use client';

import { useState, useEffect, useCallback } from 'react';
import type { KKM } from '@/lib/types';
import * as api from '@/lib/api';

export function useKkm() {
  const [kkms, setKkms] = useState<KKM[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchKkms = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getKkms();
      setKkms(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки ККМ');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchKkms(); }, [fetchKkms]);

  const saveKkm = useCallback(async (kkm: { number: number; sn: string; inv: string; isMulti: boolean }) => {
    await api.createKkm(kkm);
    await fetchKkms();
  }, [fetchKkms]);

  return { kkms, loading, error, saveKkm, refetch: fetchKkms };
}

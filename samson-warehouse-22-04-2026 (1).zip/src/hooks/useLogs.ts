'use client';

import { useState, useEffect, useCallback } from 'react';
import type { LogEntry } from '@/lib/types';
import * as api from '@/lib/api';

export function useLogs() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLogs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getLogs(500, 0);
      setLogs(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки логов');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const addLog = useCallback(async (adminId: number, text: string) => {
    try {
      await api.createLog({ adminId, text });
    } catch {
      // Log errors are non-critical
    }
    await fetchLogs();
  }, [fetchLogs]);

  return { logs, loading, error, addLog, refetch: fetchLogs };
}

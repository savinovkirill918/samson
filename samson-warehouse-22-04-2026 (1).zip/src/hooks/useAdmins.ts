'use client';

import { useState, useEffect, useCallback } from 'react';
import type { AdminUser } from '@/lib/types';
import * as api from '@/lib/api';

export function useAdmins() {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAdmins = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getAdmins();
      setAdmins(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки пользователей');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAdmins(); }, [fetchAdmins]);

  const saveAdmin = useCallback(async (admin: { login: string; hash?: string; fio: string; role?: string; groupId?: number }) => {
    await api.createAdmin(admin);
    await fetchAdmins();
  }, [fetchAdmins]);

  return { admins, loading, error, saveAdmin, refetch: fetchAdmins };
}

'use client';

import React, { useState } from 'react';
import {
  Home, Users, Briefcase, Smartphone, Plus, Wrench,
  CreditCard, BarChart3, Printer,
  Settings, ChevronDown, ChevronRight, X,
  Wrench as ToolsIcon, FileText
} from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId } from '@/lib/types';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ currentPage, onNavigate, isOpen, onClose }: SidebarProps) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    employees: false, positions: false, tsd: false, repair: false,
    kkm: false, statistics: false, print: false, settings: false,
  });

  const toggleExpand = (key: string) => {
    setExpanded(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const navigate = (page: PageId) => {
    onNavigate(page);
    onClose();
  };

  const isActive = (page: PageId) => currentPage === page;

  const activeClass = 'text-white rounded-lg';
  const inactiveClass = 'rounded-lg hover:bg-gray-100';

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={onClose} />
      )}

      <aside
        className={`fixed top-0 left-0 h-full z-50 shadow-xl transition-transform duration-300 overflow-y-auto ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
        style={{ backgroundColor: COLORS.sidebarBg, width: '260px' }}
      >
        <div className="p-4 border-b flex items-center gap-3" style={{ borderColor: '#e9ecef' }}>
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: COLORS.primary }}>
            <Home className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg" style={{ color: COLORS.heading }}>Самсон Склад</span>
          <button className="ml-auto lg:hidden" onClick={onClose}>
            <X className="w-5 h-5" style={{ color: COLORS.text }} />
          </button>
        </div>

        <nav className="p-3 space-y-1">
          <button
            onClick={() => navigate('home')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('home') ? activeClass : inactiveClass}`}
            style={isActive('home') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}
          >
            <Home className="w-4 h-4" /> Главная
          </button>

          <div>
            <button
              onClick={() => toggleExpand('employees')}
              className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition"
              style={{ color: COLORS.heading }}
            >
              <span className="flex items-center gap-3"><Users className="w-4 h-4" /> Сотрудники</span>
              {expanded.employees ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.employees && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('members')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('members') ? activeClass : inactiveClass}`} style={isActive('members') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Users className="w-3.5 h-3.5" /> Все Сотрудники
                </button>
                <button onClick={() => navigate('member-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('member-add') ? activeClass : inactiveClass}`} style={isActive('member-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
                <div>
                  <button onClick={() => toggleExpand('positions')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.text }}>
                    <span className="flex items-center gap-3"><Briefcase className="w-3.5 h-3.5" /> Должности</span>
                    {expanded.positions ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                  {expanded.positions && (
                    <div className="ml-6 space-y-1 mt-1">
                      <button onClick={() => navigate('groups')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('groups') ? activeClass : inactiveClass}`} style={isActive('groups') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Все Должности
                      </button>
                      <button onClick={() => navigate('group-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('group-add') ? activeClass : inactiveClass}`} style={isActive('group-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Добавить
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div>
            <button onClick={() => toggleExpand('tsd')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Smartphone className="w-4 h-4" /> ТСД</span>
              {expanded.tsd ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.tsd && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('tsd-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('tsd-list') ? activeClass : inactiveClass}`} style={isActive('tsd-list') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Smartphone className="w-3.5 h-3.5" /> Все ТСД
                </button>
                <button onClick={() => navigate('tsd-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('tsd-add') ? activeClass : inactiveClass}`} style={isActive('tsd-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
                <div>
                  <button onClick={() => toggleExpand('repair')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.text }}>
                    <span className="flex items-center gap-3"><Wrench className="w-3.5 h-3.5" /> Ремонт</span>
                    {expanded.repair ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                  {expanded.repair && (
                    <div className="ml-6 space-y-1 mt-1">
                      <button onClick={() => navigate('tsd-repairs')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repairs') ? activeClass : inactiveClass}`} style={isActive('tsd-repairs') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Все Ремонты
                      </button>
                      <button onClick={() => navigate('tsd-repair-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repair-add') ? activeClass : inactiveClass}`} style={isActive('tsd-repair-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Добавить
                      </button>
                      <button onClick={() => navigate('tsd-repair-sz')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repair-sz') ? activeClass : inactiveClass}`} style={isActive('tsd-repair-sz') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Получить СЗ
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div>
            <button onClick={() => toggleExpand('kkm')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><CreditCard className="w-4 h-4" /> ККМ</span>
              {expanded.kkm ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.kkm && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('kkm-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('kkm-list') ? activeClass : inactiveClass}`} style={isActive('kkm-list') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <CreditCard className="w-3.5 h-3.5" /> Все ККМ
                </button>
                <button onClick={() => navigate('kkm-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('kkm-add') ? activeClass : inactiveClass}`} style={isActive('kkm-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
              </div>
            )}
          </div>

          <div>
            <button onClick={() => toggleExpand('statistics')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><BarChart3 className="w-4 h-4" /> Статистика</span>
              {expanded.statistics ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.statistics && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('stat-starshie')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-starshie') ? activeClass : inactiveClass}`} style={isActive('stat-starshie') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Старшие
                </button>
                <button onClick={() => navigate('stat-kladovshiki')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-kladovshiki') ? activeClass : inactiveClass}`} style={isActive('stat-kladovshiki') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Кладовщики
                </button>
                <button onClick={() => navigate('stat-import')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-import') ? activeClass : inactiveClass}`} style={isActive('stat-import') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Импорт WMS
                </button>
              </div>
            )}
          </div>

          <button onClick={() => navigate('tools')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('tools') ? activeClass : inactiveClass}`} style={isActive('tools') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}>
            <ToolsIcon className="w-4 h-4" /> Инструменты
          </button>

          <button onClick={() => navigate('logs')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('logs') ? activeClass : inactiveClass}`} style={isActive('logs') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}>
            <FileText className="w-4 h-4" /> Логи
          </button>

          <div>
            <button onClick={() => toggleExpand('print')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Printer className="w-4 h-4" /> Печать</span>
              {expanded.print ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.print && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('print-tsd')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-tsd') ? activeClass : inactiveClass}`} style={isActive('print-tsd') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Реестр ТСД
                </button>
                <button onClick={() => navigate('print-kkm')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-kkm') ? activeClass : inactiveClass}`} style={isActive('print-kkm') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Реестр ККМ
                </button>
                <button onClick={() => navigate('print-stickers')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-stickers') ? activeClass : inactiveClass}`} style={isActive('print-stickers') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Наклейки ТСД
                </button>
                <button onClick={() => navigate('print-barcode')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-barcode') ? activeClass : inactiveClass}`} style={isActive('print-barcode') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Штрихкод
                </button>
                <button onClick={() => navigate('print-containers')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-containers') ? activeClass : inactiveClass}`} style={isActive('print-containers') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Контейнеры
                </button>
              </div>
            )}
          </div>

          <div>
            <button onClick={() => toggleExpand('settings')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Settings className="w-4 h-4" /> Настройки</span>
              {expanded.settings ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.settings && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('settings-users')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('settings-users') ? activeClass : inactiveClass}`} style={isActive('settings-users') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Пользователи
                </button>
              </div>
            )}
          </div>
        </nav>
      </aside>
    </>
  );
}

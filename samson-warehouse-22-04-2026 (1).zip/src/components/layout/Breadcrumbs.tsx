'use client';

import React from 'react';
import { ChevronRight } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId } from '@/lib/types';

interface BreadcrumbsProps {
  items: { label: string; page?: PageId; onNavigate: (page: PageId) => void }[];
}

export default function Breadcrumbs({ items }: BreadcrumbsProps) {
  return (
    <div className="flex items-center gap-2 text-sm mb-4 flex-wrap" style={{ color: COLORS.text }}>
      {items.map((item, idx) => (
        <React.Fragment key={idx}>
          {idx > 0 && <ChevronRight className="w-3.5 h-3.5" />}
          {item.page ? (
            <button onClick={() => item.page && item.onNavigate(item.page)} className="hover:underline" style={{ color: COLORS.primary }}>{item.label}</button>
          ) : (
            <span style={{ color: COLORS.heading }}>{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { Calculator } from 'lucide-react';
import { COLORS } from '@/lib/colors';

export default function ToolsPage() {
  const [inputs, setInputs] = useState({
    prodLen: '', prodWid: '', prodHei: '',
    cellLen: '', cellWid: '', cellHei: '',
    kr3: '', heightPercent: '10',
  });

  const result = useMemo(() => {
    const pL = parseFloat(inputs.prodLen) || 0;
    const pW = parseFloat(inputs.prodWid) || 0;
    const pH = parseFloat(inputs.prodHei) || 0;
    const cL = parseFloat(inputs.cellLen) || 0;
    const cW = parseFloat(inputs.cellWid) || 0;
    const cH = parseFloat(inputs.cellHei) || 0;
    const kr3 = parseFloat(inputs.kr3) || 1;
    const hPct = parseFloat(inputs.heightPercent) || 0;

    if (!pL || !pW || !pH || !cL || !cW || !cH) return 0;

    const effectiveHeight = cH * (1 - hPct / 100);
    const byLen = Math.floor(cL / pL);
    const byWid = Math.floor(cW / pW);
    const byHei = Math.floor(effectiveHeight / pH);
    return byLen * byWid * byHei * kr3;
  }, [inputs]);

  const updateInput = (key: string, value: string) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Инструменты</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.heading }}>
          <Calculator className="w-5 h-5" style={{ color: COLORS.primary }} /> Калькулятор вместимости ячейки
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Товар</h4>
            <div className="space-y-2">
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Длина товара</label>
                <input type="number" value={inputs.prodLen} onChange={e => updateInput('prodLen', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Ширина товара</label>
                <input type="number" value={inputs.prodWid} onChange={e => updateInput('prodWid', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Высота товара</label>
                <input type="number" value={inputs.prodHei} onChange={e => updateInput('prodHei', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Ячейка</h4>
            <div className="space-y-2">
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Длина ячейки</label>
                <input type="number" value={inputs.cellLen} onChange={e => updateInput('cellLen', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Ширина ячейки</label>
                <input type="number" value={inputs.cellWid} onChange={e => updateInput('cellWid', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Высота ячейки</label>
                <input type="number" value={inputs.cellHei} onChange={e => updateInput('cellHei', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Кол-во в КР3</label>
            <input type="number" value={inputs.kr3} onChange={e => updateInput('kr3', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: COLORS.text }}>% вычитаемый из высоты</label>
            <input type="number" value={inputs.heightPercent} onChange={e => updateInput('heightPercent', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
          </div>
        </div>

        <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Кол-во шт.</label>
          <input type="text" value={result} disabled className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white" style={{ borderColor: '#dee2e6', color: COLORS.primary }} />
        </div>
      </div>
    </div>
  );
}

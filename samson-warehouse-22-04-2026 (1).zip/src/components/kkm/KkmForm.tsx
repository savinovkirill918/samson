'use client';

import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface KkmFormProps {
  onSave: (kkm: { number: number; sn: string; inv: string; isMulti: boolean }) => void;
  onNavigate: (page: PageId) => void;
}

export default function KkmForm({ onSave, onNavigate }: KkmFormProps) {
  const [form, setForm] = useState({ number: '', sn: '', inv: '' });

  const handleSave = () => {
    const num = parseInt(form.number);
    if (!num || !form.sn) return;
    onSave({ number: num, sn: form.sn, inv: form.inv, isMulti: false });
    onNavigate('kkm-list');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'ККМ', page: 'kkm-list', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ККМ</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
          <input type="number" value={form.number} onChange={e => setForm(p => ({ ...p, number: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер *</label>
          <input type="text" value={form.sn} onChange={e => setForm(p => ({ ...p, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инвентарный номер</label>
          <input type="text" value={form.inv} onChange={e => setForm(p => ({ ...p, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
}

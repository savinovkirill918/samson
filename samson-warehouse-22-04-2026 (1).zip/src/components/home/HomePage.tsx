'use client';

import React from 'react';
import { AlertTriangle, Clock } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Member, TSD, Repair, Group, LogEntry, PageId } from '@/lib/types';
import { formatDateTime, isRepairActive, repairStatusText } from '@/lib/helpers';

interface HomePageProps {
  members: Member[];
  tsds: TSD[];
  repairs: Repair[];
  groups: Group[];
  logs: LogEntry[];
  onNavigate: (page: PageId) => void;
}

export default function HomePage({ members, tsds, repairs, groups, logs, onNavigate }: HomePageProps) {
  const repairsWithMembers = repairs
    .filter(isRepairActive)
    .map(r => {
      const member = members.find(m => m.tsdId === r.tsdId);
      const tsd = tsds.find(t => t.id === r.tsdId);
      return { repair: r, member, tsd };
    })
    .filter(r => r.member);

  const recentLogs = logs.slice(0, 50);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Главная</h2>

      {repairsWithMembers.length > 0 && (
        <div className="rounded-xl p-4 mb-6" style={{ backgroundColor: COLORS.alertBg }}>
          <div className="flex items-start gap-3 mb-3">
            <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: '#ffc107' }} />
            <div>
              <h3 className="font-semibold" style={{ color: COLORS.heading }}>Есть пользователи у которых ТСД на ремонте</h3>
            </div>
          </div>
          <div className="space-y-2 ml-8">
            {repairsWithMembers.map(({ repair, member, tsd }) => member && tsd && (
              <div key={repair.id} className="flex items-center gap-4 text-sm">
                <span className="font-medium" style={{ color: COLORS.heading }}>{member.fio}</span>
                <span style={{ color: COLORS.text }}>ТСД №{tsd.number}</span>
                <span style={{ color: COLORS.text }}>({repair.description})</span>
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${repairStatusText(repair.status) === 'На ремонте' ? 'bg-yellow-200 text-yellow-800' : 'bg-blue-100 text-blue-800'}`}>
                  {repairStatusText(repair.status)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold" style={{ color: COLORS.heading }}>Последние действия</h3>
          <button onClick={() => onNavigate('logs')} className="text-sm hover:underline" style={{ color: COLORS.primary }}>
            Все логи →
          </button>
        </div>
        <div className="max-h-96 overflow-y-auto space-y-2" style={{ scrollbarWidth: 'thin' }}>
          {recentLogs.map(log => (
            <div key={log.id} className="flex items-center gap-3 py-2 border-b last:border-b-0 text-sm" style={{ borderColor: '#f0f0f0' }}>
              <Clock className="w-3.5 h-3.5 flex-shrink-0" style={{ color: COLORS.text }} />
              <span className="flex-shrink-0 whitespace-nowrap" style={{ color: COLORS.text }}>{formatDateTime(log.date)}</span>
              <span style={{ color: COLORS.heading }}>{log.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

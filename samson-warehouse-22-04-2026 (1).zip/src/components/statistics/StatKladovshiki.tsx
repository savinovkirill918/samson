'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Calendar, Loader2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import { getStat13 } from '@/lib/api';
import type { Member, Group } from '@/lib/types';

interface Stat13Row {
  id: number;
  rowNum: number;
  fio: string;
  shtCnt: number;
  krCnt: number;
  pshtCnt: number;
  razmCnt: number;
  pkrCnt: number;
  ktu: number;
  hours: number;
  avgPerHour: number;
}

interface Stat13Upload {
  id: number;
  dateFrom: string;
  dateTo: string;
  groupName: string;
  rows: Stat13Row[];
}


interface Props {
  members: Member[];
  groups: Group[];
}

function formatDate(d: Date): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

export default function StatKladovshiki({ members, groups }: Props) {
  const [upload, setUpload] = useState<Stat13Upload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedDateFrom, setSelectedDateFrom] = useState<string | null>(null);
  const [selectedDateTo, setSelectedDateTo] = useState<string | null>(null);
  const fpRef = useRef<HTMLInputElement>(null);

  // Initialize flatpickr
  useEffect(() => {
    let fpInstance: any = null;
    const initFlatpickr = async () => {
      const flatpickr = (await import('flatpickr')).default;
      await import('flatpickr/dist/l10n/ru.js');
      if (fpRef.current) {
        fpInstance = flatpickr(fpRef.current, {
          mode: 'range',
          dateFormat: 'd.m.Y',
          maxDate: 'today',
          locale: 'ru',
          allowInput: false,
          onChange: (selectedDates: Date[]) => {
            if (selectedDates.length === 2) {
              const from = formatDate(selectedDates[0]);
              const to = formatDate(selectedDates[1]);
              setSelectedDateFrom(from);
              setSelectedDateTo(to);
              fetchDataByDate(from, to);
            }
          },
        });
      }
    };
    initFlatpickr();
    return () => {
      fpInstance?.destroy();
    };
  }, []);

  // Fetch latest data on mount
  const fetchData = useCallback(async (params?: { uploadId?: number; dateFrom?: string; dateTo?: string }) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getStat13(params);
      setUpload(data);
    } catch (err: any) {
      setError(err.message || 'Ошибка загрузки данных');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchDataByDate = useCallback(async (dateFrom: string, dateTo: string) => {
    fetchData({ dateFrom, dateTo });
  }, [fetchData]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ------------------------------------------------------------------ */
  /*  Build position-grouped data                                       */
  /* ------------------------------------------------------------------ */
  const buildGroupedData = () => {
    if (!upload?.rows?.length) return { groups: [], unassigned: [] };

    // Sort groups by sort order
    const sortedGroups = [...groups].sort((a, b) => a.sort - b.sort);

    // Build a map: FIO -> member for lookup
    const fioToMember = new Map<string, Member>();
    for (const m of members) {
      // Store both full FIO and also try trimmed/normalized version
      fioToMember.set(m.fio.trim(), m);
    }

    // Group rows by position (groupId)
    const grouped = new Map<number, { group: Group; rows: Stat13Row[] }>();
    const unassigned: Stat13Row[] = [];

    for (const row of upload.rows) {
      const member = fioToMember.get(row.fio.trim());
      if (member) {
        const group = sortedGroups.find(g => g.id === member.groupId);
        if (group) {
          if (!grouped.has(group.id)) {
            grouped.set(group.id, { group, rows: [] });
          }
          grouped.get(group.id)!.rows.push(row);
        } else {
          unassigned.push(row);
        }
      } else {
        // Try partial match — last name match
        const lastName = row.fio.trim().split(' ')[0];
        let matched = false;
        for (const m of members) {
          if (m.fio.trim().split(' ')[0] === lastName) {
            const group = sortedGroups.find(g => g.id === m.groupId);
            if (group) {
              if (!grouped.has(group.id)) {
                grouped.set(group.id, { group, rows: [] });
              }
              grouped.get(group.id)!.rows.push(row);
              matched = true;
              break;
            }
          }
        }
        if (!matched) {
          unassigned.push(row);
        }
      }
    }

    // Build ordered array
    const result = sortedGroups
      .filter(g => grouped.has(g.id))
      .map(g => ({
        groupId: g.id,
        groupName: g.name,
        rows: grouped.get(g.id)!.rows,
      }));

    return { groups: result, unassigned };
  };

  const { groups: groupedData, unassigned } = buildGroupedData();

  const colHeaderStyle: React.CSSProperties = {
    backgroundColor: '#f8f9fa',
    color: COLORS.heading,
    fontWeight: 600,
    fontSize: '13px',
    padding: '10px 12px',
    textAlign: 'center',
    borderBottom: '2px solid #dee2e6',
    whiteSpace: 'nowrap',
  };

  const cellStyle: React.CSSProperties = {
    padding: '8px 12px',
    fontSize: '13px',
    color: COLORS.heading,
    textAlign: 'center',
    borderBottom: '1px solid #f0f0f0',
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        Статистика — Кладовщики
      </h2>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow p-4 mb-4">
        <div className="flex flex-wrap items-center gap-4">
          {/* Date range picker */}
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" style={{ color: COLORS.text }} />
            <input
              ref={fpRef}
              type="text"
              placeholder="Выберите период"
              className="px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2"
              style={{
                borderColor: '#dee2e6',
                minWidth: '220px',
              }}
              readOnly
            />
          </div>
        </div>

        {/* Period display */}
        {upload && (
          <div className="mt-3 text-sm" style={{ color: COLORS.text }}>
            {upload.groupName && <span className="font-medium" style={{ color: COLORS.heading }}>{upload.groupName}</span>}
            {upload.dateFrom && (
              <span className="ml-2">
                Период: {upload.dateFrom === upload.dateTo
                  ? upload.dateFrom
                  : `${upload.dateFrom} — ${upload.dateTo}`}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin" style={{ color: COLORS.primary }} />
          <span className="ml-2 text-sm" style={{ color: COLORS.text }}>Загрузка данных...</span>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="bg-red-50 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
      )}

      {/* Table */}
      {!loading && !error && upload?.rows?.length ? (
        <div className="bg-white rounded-xl shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse" style={{ minWidth: '900px' }}>
              <thead>
                <tr>
                  <th style={{ ...colHeaderStyle, width: '40px', textAlign: 'center' }}>#</th>
                  <th style={{ ...colHeaderStyle, textAlign: 'left' }}>ФИО</th>
                  <th style={{ ...colHeaderStyle, width: '60px' }}>Шт.</th>
                  <th style={{ ...colHeaderStyle, width: '60px' }}>Кр.</th>
                  <th style={{ ...colHeaderStyle, width: '100px' }}>Пополнения шт.</th>
                  <th style={{ ...colHeaderStyle, width: '100px' }}>Перемещения</th>
                  <th style={{ ...colHeaderStyle, width: '100px' }}>Размещения</th>
                  <th style={{ ...colHeaderStyle, width: '70px', fontWeight: 700 }}>Итоги</th>
                  <th style={{ ...colHeaderStyle, width: '60px' }}>Часы</th>
                  <th style={{ ...colHeaderStyle, width: '140px', fontWeight: 700 }}>Ср. кол-во инстр./час/чел</th>
                </tr>
              </thead>
              <tbody>
                {/* Grouped rows */}
                {groupedData.map((group, gi) => (
                  <React.Fragment key={group.groupId}>
                    {/* Position header row */}
                    <tr>
                      <td
                        colSpan={10}
                        className="px-4 py-2.5 font-semibold text-sm"
                        style={{
                          backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                          color: COLORS.primary,
                          borderBottom: '2px solid #dee2e6',
                          borderTop: gi === 0 ? 'none' : '2px solid #dee2e6',
                          fontSize: '13px',
                        }}
                      >
                        {group.groupName}
                      </td>
                    </tr>
                    {/* Employee rows */}
                    {group.rows.map((row, i) => {
                      const totals = row.shtCnt + row.krCnt + row.pshtCnt + row.razmCnt + row.pkrCnt;
                      return (
                        <tr key={row.id || i} className="hover:bg-gray-50 transition">
                          <td style={cellStyle}>{row.rowNum}</td>
                          <td style={{ ...cellStyle, textAlign: 'left', fontWeight: 500 }}>{row.fio}</td>
                          <td style={cellStyle}>{row.shtCnt}</td>
                          <td style={cellStyle}>{row.krCnt}</td>
                          <td style={cellStyle}>{row.pshtCnt}</td>
                          <td style={cellStyle}>{row.pkrCnt}</td>
                          <td style={cellStyle}>{row.razmCnt}</td>
                          <td style={{ ...cellStyle, fontWeight: 700 }}>{totals}</td>
                          <td style={cellStyle}>{row.hours}</td>
                          <td style={{ ...cellStyle, fontWeight: 700 }}>{row.avgPerHour}</td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                ))}

                {/* Unassigned employees */}
                {unassigned.length > 0 && (
                  <React.Fragment>
                    <tr>
                      <td
                        colSpan={10}
                        className="px-4 py-2.5 font-semibold text-sm"
                        style={{
                          backgroundColor: '#fff3cd',
                          color: '#856404',
                          borderBottom: '2px solid #dee2e6',
                          borderTop: groupedData.length > 0 ? '2px solid #dee2e6' : 'none',
                          fontSize: '13px',
                        }}
                      >
                        Не распределены (нет совпадения ФИО)
                      </td>
                    </tr>
                    {unassigned.map((row, i) => {
                      const totals = row.shtCnt + row.krCnt + row.pshtCnt + row.razmCnt + row.pkrCnt;
                      return (
                        <tr key={`unassigned-${i}`} className="hover:bg-yellow-50 transition">
                          <td style={cellStyle}>{row.rowNum}</td>
                          <td style={{ ...cellStyle, textAlign: 'left', fontWeight: 500 }}>{row.fio}</td>
                          <td style={cellStyle}>{row.shtCnt}</td>
                          <td style={cellStyle}>{row.krCnt}</td>
                          <td style={cellStyle}>{row.pshtCnt}</td>
                          <td style={cellStyle}>{row.pkrCnt}</td>
                          <td style={cellStyle}>{row.razmCnt}</td>
                          <td style={{ ...cellStyle, fontWeight: 700 }}>{totals}</td>
                          <td style={cellStyle}>{row.hours}</td>
                          <td style={{ ...cellStyle, fontWeight: 700 }}>{row.avgPerHour}</td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        !loading && !error && (
          <div className="bg-white rounded-xl shadow p-8 text-center">
            <p className="text-sm" style={{ color: COLORS.text }}>
              {selectedDateFrom && selectedDateTo
                ? `Нет данных за период: ${selectedDateFrom === selectedDateTo ? selectedDateFrom : `${selectedDateFrom} — ${selectedDateTo}`}`
                : 'Нет данных. Загрузите XML файл отчёта 13 через страницу импорта.'}
            </p>
          </div>
        )
      )}
    </div>
  );
}

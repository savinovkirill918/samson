'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Calendar, ChevronDown, Loader2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import { getStat49 } from '@/lib/api';
import type { Member, Group } from '@/lib/types';

interface Stat49AvgRow {
  id: number;
  controller: string;
  orderType: string;
  allErp: number;
  avgProizvod: number;
}

interface Stat49DailyRow {
  id: number;
  date: string;
  controller: string;
  orderType: string;
  allErp: number;
  avgProizvod: number;
}

interface Stat49Upload {
  id: number;
  dateFrom: string;
  dateTo: string;
  avgRows: Stat49AvgRow[];
  dailyRows: Stat49DailyRow[];
}

function formatDate(d: Date): string {
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

interface Props {
  members: Member[];
  groups: Group[];
}

// Map controller login → FIO
function getControllerFio(controller: string, members: Member[]): string {
  const login = controller.trim().toLowerCase();
  const member = members.find(m => m.login.trim().toLowerCase() === login);
  if (member) return member.fio;

  // Also try matching against FIO directly (in case controller is stored as FIO)
  const memberByFio = members.find(m => m.fio.trim().toLowerCase() === login);
  if (memberByFio) return memberByFio.fio;

  // Try partial: first token match
  const firstToken = login.split(/\s+/)[0];
  const partialMember = members.find(m => m.login.trim().toLowerCase().startsWith(firstToken));
  if (partialMember) return partialMember.fio;

  return controller;
}

export default function StatStarshie({ members, groups }: Props) {
  const [upload, setUpload] = useState<Stat49Upload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDaily, setShowDaily] = useState(false);
  const [selectedDateFrom, setSelectedDateFrom] = useState<string | null>(null);
  const [selectedDateTo, setSelectedDateTo] = useState<string | null>(null);
  const fpRef = useRef<HTMLInputElement>(null);

  // Initialize flatpickr
  useEffect(() => {
    let fpInstance: any = null;
    const initFlatpickr = async () => {
      const flatpickr = (await import('flatpickr')).default;
      await import('flatpickr/dist/l10n/ru.js');
      if (fpRef.current) {
        fpInstance = flatpickr(fpRef.current, {
          mode: 'range',
          dateFormat: 'd.m.Y',
          maxDate: 'today',
          locale: 'ru',
          allowInput: false,
          onChange: (selectedDates: Date[]) => {
            if (selectedDates.length === 2) {
              const from = formatDate(selectedDates[0]);
              const to = formatDate(selectedDates[1]);
              setSelectedDateFrom(from);
              setSelectedDateTo(to);
              fetchDataByDate(from, to);
            }
          },
        });
      }
    };
    initFlatpickr();
    return () => {
      fpInstance?.destroy();
    };
  }, []);

  // Fetch latest data on mount
  const fetchData = useCallback(async (params?: { uploadId?: number; dateFrom?: string; dateTo?: string }) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getStat49(params);
      setUpload(data);
    } catch (err: any) {
      setError(err.message || 'Ошибка загрузки данных');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchDataByDate = useCallback(async (dateFrom: string, dateTo: string) => {
    fetchData({ dateFrom, dateTo });
  }, [fetchData]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ------------------------------------------------------------------ */
  /*  Group avgRows by orderType                                        */
  /* ------------------------------------------------------------------ */
  const buildGroupedAvg = (): { orderType: string; rows: Stat49AvgRow[]; totalErp: number }[] => {
    if (!upload?.avgRows?.length) return [];

    const orderTypes = [...new Set(upload.avgRows.map(r => r.orderType))];

    return orderTypes.map(ot => {
      const rows = upload.avgRows.filter(r => r.orderType === ot);
      const totalErp = rows.reduce((sum, r) => sum + r.allErp, 0);
      return { orderType: ot, rows, totalErp };
    });
  };

  /* ------------------------------------------------------------------ */
  /*  Group dailyRows by date, then by orderType                        */
  /* ------------------------------------------------------------------ */
  const buildDailyTable = (): { date: string; groups: { orderType: string; rows: Stat49DailyRow[] }[] }[] => {
    if (!upload?.dailyRows?.length) return [];

    const dates = [...new Set(upload.dailyRows.map(r => r.date))].sort();

    return dates.map(date => {
      const dayRows = upload.dailyRows.filter(r => r.date === date);
      const orderTypes = [...new Set(dayRows.map(r => r.orderType))];
      const groups = orderTypes.map(ot => ({
        orderType: ot,
        rows: dayRows.filter(r => r.orderType === ot),
      }));
      return { date, groups };
    });
  };

  const groupedAvg = buildGroupedAvg();
  const dailyData = buildDailyTable();

  const colHeaderStyle: React.CSSProperties = {
    backgroundColor: '#f8f9fa',
    color: COLORS.heading,
    fontWeight: 600,
    fontSize: '13px',
    padding: '10px 12px',
    textAlign: 'center',
    borderBottom: '2px solid #dee2e6',
    whiteSpace: 'nowrap',
  };

  const cellStyle: React.CSSProperties = {
    padding: '8px 12px',
    fontSize: '13px',
    color: COLORS.heading,
    textAlign: 'center',
    borderBottom: '1px solid #f0f0f0',
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        Статистика — Старшие
      </h2>

      {/* Controls */}
      <div className="bg-white rounded-xl shadow p-4 mb-4">
        <div className="flex flex-wrap items-center gap-4">
          {/* Date range picker */}
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" style={{ color: COLORS.text }} />
            <input
              ref={fpRef}
              type="text"
              placeholder="Выберите период"
              className="px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2"
              style={{
                borderColor: '#dee2e6',
                minWidth: '220px',
              }}
              readOnly
            />
          </div>
        </div>

        {/* Period display */}
        {upload && upload.dateFrom && (
          <div className="mt-3 text-sm" style={{ color: COLORS.text }}>
            Период: {upload.dateFrom === upload.dateTo
              ? upload.dateFrom
              : `${upload.dateFrom} — ${upload.dateTo}`}
          </div>
        )}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin" style={{ color: COLORS.primary }} />
          <span className="ml-2 text-sm" style={{ color: COLORS.text }}>Загрузка данных...</span>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="bg-red-50 text-red-700 px-4 py-3 rounded-lg text-sm">{error}</div>
      )}

      {/* Average data table */}
      {!loading && !error && upload?.avgRows?.length ? (
        <>
          <div className="bg-white rounded-xl shadow overflow-hidden mb-4">
            <div className="px-4 py-3 border-b" style={{ borderColor: '#f0f0f0' }}>
              <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>
                Средняя производительность за период
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse" style={{ minWidth: '600px' }}>
                <thead>
                  <tr>
                    <th style={{ ...colHeaderStyle, width: '40px' }}>#</th>
                    <th style={{ ...colHeaderStyle, textAlign: 'left' }}>ФИО</th>
                    <th style={{ ...colHeaderStyle, width: '140px' }}>Набрано/проверено, строк</th>
                    <th style={{ ...colHeaderStyle, width: '200px' }}>Ср. производительность за период, %</th>
                  </tr>
                </thead>
                <tbody>
                  {groupedAvg.map((group, gi) => (
                    <React.Fragment key={group.orderType}>
                      {/* Order type header */}
                      <tr>
                        <td
                          colSpan={4}
                          className="px-4 py-2.5 font-semibold text-sm"
                          style={{
                            backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                            color: COLORS.primary,
                            borderBottom: '2px solid #dee2e6',
                            borderTop: gi === 0 ? 'none' : '2px solid #dee2e6',
                            fontSize: '13px',
                          }}
                        >
                          {group.orderType || 'Без канала'}
                        </td>
                      </tr>
                      {/* Employee rows */}
                      {group.rows.map((row, i) => (
                        <tr key={row.id || i} className="hover:bg-gray-50 transition">
                          <td style={cellStyle}>{i + 1}</td>
                          <td style={{ ...cellStyle, textAlign: 'left', fontWeight: 500 }}>
                            {getControllerFio(row.controller, members)}
                          </td>
                          <td style={cellStyle}>{row.allErp.toLocaleString('ru-RU')}</td>
                          <td style={cellStyle}>
                            <span
                              className="inline-block px-2 py-0.5 rounded text-xs font-medium"
                              style={{
                                backgroundColor: row.avgProizvod >= 100 ? '#dcfce7' : row.avgProizvod >= 80 ? '#fef9c3' : '#fee2e2',
                                color: row.avgProizvod >= 100 ? '#166534' : row.avgProizvod >= 80 ? '#854d0e' : '#991b1b',
                              }}
                            >
                              {row.avgProizvod}%
                            </span>
                          </td>
                        </tr>
                      ))}
                      {/* ИТОГО row */}
                      <tr>
                        <td
                          colSpan={2}
                          className="px-4 py-2 font-bold text-sm text-right"
                          style={{
                            borderBottom: '2px solid #dee2e6',
                            color: COLORS.heading,
                            fontSize: '13px',
                          }}
                        >
                          ИТОГО:
                        </td>
                        <td
                          className="px-4 py-2 font-bold text-sm text-center"
                          style={{
                            borderBottom: '2px solid #dee2e6',
                            color: COLORS.heading,
                            fontSize: '13px',
                          }}
                        >
                          {group.totalErp.toLocaleString('ru-RU')}
                        </td>
                        <td
                          className="px-4 py-2 text-sm text-center"
                          style={{
                            borderBottom: '2px solid #dee2e6',
                            color: COLORS.text,
                            fontSize: '13px',
                          }}
                        />
                      </tr>
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Daily breakdown toggle */}
          {upload.dailyRows && upload.dailyRows.length > 0 && (
            <div className="bg-white rounded-xl shadow overflow-hidden">
              <button
                onClick={() => setShowDaily(!showDaily)}
                className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition border-b"
                style={{ borderColor: '#f0f0f0' }}
              >
                <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>
                  Посменная статистика ({upload.dailyRows.length} записей)
                </h3>
                <ChevronDown
                  className={`w-4 h-4 transition-transform ${showDaily ? 'rotate-180' : ''}`}
                  style={{ color: COLORS.text }}
                />
              </button>

              {showDaily && (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse" style={{ minWidth: '600px' }}>
                    <thead>
                      <tr>
                        <th style={{ ...colHeaderStyle, width: '100px' }}>Дата</th>
                        <th style={{ ...colHeaderStyle }}>Канал</th>
                        <th style={{ ...colHeaderStyle }}>#</th>
                        <th style={{ ...colHeaderStyle, textAlign: 'left' }}>ФИО</th>
                        <th style={{ ...colHeaderStyle, width: '140px' }}>Набрано/проверено, строк</th>
                        <th style={{ ...colHeaderStyle, width: '160px' }}>Ср. производительность, %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dailyData.map((day) =>
                        day.groups.map((group, gi) => (
                          <React.Fragment key={`${day.date}-${group.orderType}`}>
                            {/* Sub-header */}
                            <tr>
                              <td
                                rowSpan={1 + group.rows.length}
                                className="px-3 py-2 text-sm font-medium align-top"
                                style={{
                                  backgroundColor: '#f8f9fa',
                                  color: COLORS.heading,
                                  borderBottom: '1px solid #dee2e6',
                                  borderRight: '1px solid #f0f0f0',
                                }}
                              >
                                {day.date}
                              </td>
                              <td
                                className="px-3 py-2 text-sm font-semibold"
                                style={{
                                  backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                                  color: COLORS.primary,
                                  borderBottom: '1px solid #dee2e6',
                                }}
                              >
                                {group.orderType || '—'}
                              </td>
                              <td
                                style={{
                                  ...cellStyle,
                                  backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                                }}
                              >
                                {group.rows.length > 0 ? '1' : ''}
                              </td>
                              <td
                                className="px-3 py-2 text-sm font-medium"
                                style={{
                                  backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                                  color: COLORS.heading,
                                  borderBottom: '1px solid #dee2e6',
                                }}
                              >
                                {group.rows.length > 0
                                  ? getControllerFio(group.rows[0].controller, members)
                                  : ''}
                              </td>
                              <td
                                style={{
                                  ...cellStyle,
                                  backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                                }}
                              >
                                {group.rows.length > 0
                                  ? group.rows[0].allErp.toLocaleString('ru-RU')
                                  : ''}
                              </td>
                              <td
                                style={{
                                  ...cellStyle,
                                  backgroundColor: gi % 2 === 0 ? '#f8f9fa' : '#ffffff',
                                }}
                              >
                                {group.rows.length > 0 ? (
                                  <span
                                    className="inline-block px-2 py-0.5 rounded text-xs font-medium"
                                    style={{
                                      backgroundColor:
                                        group.rows[0].avgProizvod >= 100
                                          ? '#dcfce7'
                                          : group.rows[0].avgProizvod >= 80
                                          ? '#fef9c3'
                                          : '#fee2e2',
                                      color:
                                        group.rows[0].avgProizvod >= 100
                                          ? '#166534'
                                          : group.rows[0].avgProizvod >= 80
                                          ? '#854d0e'
                                          : '#991b1b',
                                    }}
                                  >
                                    {group.rows[0].avgProizvod}%
                                  </span>
                                ) : null}
                              </td>
                            </tr>
                          </React.Fragment>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        !loading && !error && (
          <div className="bg-white rounded-xl shadow p-8 text-center">
            <p className="text-sm" style={{ color: COLORS.text }}>
              {selectedDateFrom && selectedDateTo
                ? `Нет данных за период: ${selectedDateFrom === selectedDateTo ? selectedDateFrom : `${selectedDateFrom} — ${selectedDateTo}`}`
                : 'Нет данных. Загрузите XML файл отчёта 49 через страницу импорта.'}
            </p>
          </div>
        )
      )}
    </div>
  );
}

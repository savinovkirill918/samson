'use client';

import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface TsdFormProps {
  editingTsdId?: number | null;
  tsds?: TSD[];
  onSave: (tsd: { number: number; sn: string; inv: string; model: string; isMulti: boolean }) => void;
  onUpdate?: (tsd: Partial<TSD> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function TsdForm({ editingTsdId, tsds, onSave, onUpdate, onNavigate }: TsdFormProps) {
  const existing = editingTsdId && tsds ? tsds.find(t => t.id === editingTsdId) : null;
  const isEditing = !!existing;

  const [form, setForm] = useState({
    number: '',
    sn: '',
    inv: '',
    model: 'МС-32N0 +',
    isMulti: false,
  });

  useEffect(() => {
    if (existing) {
      setForm({
        number: String(existing.number),
        sn: existing.sn,
        inv: existing.inv,
        model: existing.model,
        isMulti: existing.isMulti,
      });
    }
  }, [existing]);

  const handleSave = () => {
    const num = parseInt(form.number);
    if (!num || !form.sn) return;
    if (isEditing && onUpdate && existing) {
      onUpdate({
        id: existing.id,
        number: num,
        sn: form.sn,
        inv: form.inv,
        model: form.model,
        isMulti: form.isMulti,
      });
    } else {
      onSave({ number: num, sn: form.sn, inv: form.inv, model: form.model, isMulti: form.isMulti });
    }
    onNavigate('tsd-list');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'ТСД', page: 'tsd-list', onNavigate }, { label: isEditing ? 'Редактировать' : 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEditing ? 'Редактировать ТСД' : 'Добавить ТСД'}
      </h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
          <input type="number" value={form.number} onChange={e => setForm(p => ({ ...p, number: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер *</label>
          <input type="text" value={form.sn} onChange={e => setForm(p => ({ ...p, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инвентарный номер</label>
          <input type="text" value={form.inv} onChange={e => setForm(p => ({ ...p, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Модель</label>
          <select value={form.model} onChange={e => setForm(p => ({ ...p, model: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            <option>МС-32N0 +</option><option>МС-3190</option><option>RK25-2DSR</option>
          </select>
        </div>
        <label className="flex items-center gap-3 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={form.isMulti}
            onChange={e => setForm(p => ({ ...p, isMulti: e.target.checked }))}
            className="w-5 h-5 rounded accent-[#3a57e8]"
          />
          <span className="text-sm font-medium" style={{ color: COLORS.heading }}>Мульти ТСД</span>
        </label>
        <p className="text-xs -mt-2" style={{ color: COLORS.text }}>
          Разрешает назначить этот ТСД нескольким сотрудникам одновременно
        </p>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
}

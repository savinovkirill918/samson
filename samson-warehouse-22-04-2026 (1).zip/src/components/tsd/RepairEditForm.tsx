'use client';

import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Repair, TSD, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface RepairEditFormProps {
  repairId: number;
  repairs: Repair[];
  tsds: TSD[];
  onUpdate: (repair: Partial<Repair> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

/** Статус ремонта: число → текст */
const statusLabels: Record<number, string> = {
  [-1]: 'Не отправлен',
  0: 'Отправлен',
  1: 'Вернулся',
};

export default function RepairEditForm({ repairId, repairs, tsds, onUpdate, onNavigate }: RepairEditFormProps) {
  const repair = repairs.find(r => r.id === repairId);
  const tsd = repair ? tsds.find(t => t.id === repair.tsdId) : null;

  const [form, setForm] = useState({
    description: '',
    isGuilty: false,
    status: -1,
  });

  useEffect(() => {
    if (repair) {
      setForm({
        description: repair.description,
        isGuilty: repair.isGuilty,
        status: repair.status,
      });
    }
  }, [repair]);

  if (!repair) {
    return (
      <div>
        <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Редактировать', onNavigate }]} />
        <p style={{ color: COLORS.text }}>Ремонт не найден</p>
      </div>
    );
  }

  const isFinal = repair.status === 1; // Вернулся — статус финальный, редактировать нельзя

  const handleSave = () => {
    const today = new Date().toISOString().split('T')[0];
    const updatedRepair: Partial<Repair> & { id: number } = {
      id: repair.id,
      description: form.description.trim(),
      isGuilty: form.isGuilty,
      status: form.status,
    };

    // Автоматически устанавливаем дату отправки при смене статуса на "Отправлен"
    if (form.status >= 0) {
      updatedRepair.sentDate = repair.sentDate || today;
    }

    // Автоматически устанавливаем дату возвращения при смене статуса на "Вернулся"
    if (form.status === 1) {
      updatedRepair.returnedDate = repair.returnedDate || today;
    }

    onUpdate(updatedRepair);
    onNavigate('tsd-repairs');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: `Ремонт #${repair.id}`, onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        Редактировать ремонт #{repair.id}
        {tsd && <span className="font-normal text-sm ml-2" style={{ color: COLORS.text }}>(ТСД №{tsd.number})</span>}
      </h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание поломки</label>
          <input
            type="text"
            value={form.description}
            onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
            style={{ borderColor: '#dee2e6' }}
          />
        </div>

        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={form.isGuilty}
            onChange={e => setForm(p => ({ ...p, isGuilty: e.target.checked }))}
            className="w-4 h-4 accent-[#3a57e8]"
          />
          <span className="text-sm" style={{ color: COLORS.heading }}>Виновен сотрудник</span>
        </label>

        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Статус</label>
          <select
            value={form.status}
            onChange={e => setForm(p => ({ ...p, status: Number(e.target.value) }))}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
            style={{ borderColor: '#dee2e6' }}
            disabled={isFinal}
          >
            <option value={-1} disabled={repair.status > -1}>Не отправлен</option>
            <option value={0} disabled={repair.status > 0}>Отправлен</option>
            <option value={1} disabled={repair.status > 1}>Вернулся</option>
          </select>
          {isFinal && (
            <p className="text-xs mt-1" style={{ color: '#6b7280' }}>Ремонт завершён, статус изменить нельзя</p>
          )}
        </div>

        <div className="pt-2">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition disabled:opacity-50"
            style={{ backgroundColor: COLORS.primary }}
            disabled={isFinal}
          >
            <Save className="w-4 h-4" /> Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}

'use client';

import React from 'react';
import { Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Repair, TSD, PageId } from '@/lib/types';
import { formatDate, isRepairActive } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface RepairSZPageProps {
  repairs: Repair[];
  tsds: TSD[];
  onNavigate: (page: PageId) => void;
}

export default function RepairSZPage({ repairs, tsds, onNavigate }: RepairSZPageProps) {
  const activeRepairs = repairs.filter(isRepairActive);
  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Получить СЗ', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Получить служебную записку</h2>
      <div className="bg-white rounded-xl shadow p-6">
        {activeRepairs.length === 0 ? (
          <p style={{ color: COLORS.text }}>Нет активных ремонтов для создания СЗ</p>
        ) : (
          <div className="space-y-4">
            {activeRepairs.map(r => {
              const tsd = tsds.find(t => t.id === r.tsdId);
              return (
                <div key={r.id} className="border rounded-lg p-4" style={{ borderColor: '#dee2e6' }}>
                  <h4 className="font-semibold mb-2" style={{ color: COLORS.heading }}>
                    СЗ: ТСД №{tsd?.number} — {r.description}
                  </h4>
                  <p className="text-sm" style={{ color: COLORS.text }}>Дата поломки: {formatDate(r.brokenDate)}</p>
                  <p className="text-sm" style={{ color: COLORS.text }}>Модель: {tsd?.model}</p>
                  <p className="text-sm" style={{ color: COLORS.text }}>С/N: {tsd?.sn}</p>
                  <button className="mt-3 flex items-center gap-2 px-4 py-1.5 text-white rounded-lg text-sm hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
                    <Printer className="w-4 h-4" /> Печать СЗ
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

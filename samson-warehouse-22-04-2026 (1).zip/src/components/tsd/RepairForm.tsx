'use client';

import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface RepairFormProps {
  tsds: TSD[];
  onSave: (repair: {
    tsdId: number;
    brokenDate: string;
    sentDate?: string;
    returnedDate?: string;
    status?: number;
    description: string;
    isGuilty?: boolean;
    cost?: number;
  }) => void;
  onNavigate: (page: PageId) => void;
}

export default function RepairForm({ tsds, onSave, onNavigate }: RepairFormProps) {
  const [form, setForm] = useState({
    tsdId: '',
    description: '',
    isGuilty: false,
  });

  const handleSave = () => {
    const tsdId = parseInt(form.tsdId);
    if (!tsdId || !form.description.trim()) return;
    const today = new Date().toISOString().split('T')[0];
    onSave({
      tsdId,
      brokenDate: today,
      status: -1,
      description: form.description.trim(),
      isGuilty: form.isGuilty,
    });
    onNavigate('tsd-repairs');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ремонт</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>ТСД *</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1">
            {tsds.map(tsd => (
              <label
                key={tsd.id}
                className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50"
                style={{ borderColor: form.tsdId === String(tsd.id) ? COLORS.primary : '#dee2e6' }}
              >
                <input
                  type="radio"
                  name="tsd"
                  value={tsd.id}
                  checked={form.tsdId === String(tsd.id)}
                  onChange={e => setForm(p => ({ ...p, tsdId: e.target.value }))}
                  className="accent-[#3a57e8]"
                />
                <span className="text-sm" style={{ color: COLORS.heading }}>№{tsd.number}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание поломки *</label>
          <input
            type="text"
            value={form.description}
            onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
            placeholder="Введите описание поломки"
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
            style={{ borderColor: '#dee2e6' }}
          />
        </div>

        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={form.isGuilty}
            onChange={e => setForm(p => ({ ...p, isGuilty: e.target.checked }))}
            className="w-4 h-4 accent-[#3a57e8]"
          />
          <span className="text-sm" style={{ color: COLORS.heading }}>Виновен сотрудник</span>
        </label>

        <div className="pt-2">
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition"
            style={{ backgroundColor: COLORS.primary }}
          >
            <Save className="w-4 h-4" /> Добавить
          </button>
        </div>
      </div>
    </div>
  );
}

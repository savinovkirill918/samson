'use client';

import React from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Repair, TSD, Member, PageId } from '@/lib/types';
import { formatDate, repairStatusText } from '@/lib/helpers';

interface RepairsListProps {
  repairs: Repair[];
  tsds: TSD[];
  members: Member[];
  onNavigate: (page: PageId) => void;
  onEditRepair?: (repair: Repair) => void;
}

const statusColorMap: Record<string, { color: string; bgColor: string }> = {
  'Сломан не отправлен': { color: '#b45309', bgColor: '#fef3c7' },
  'Отправлен': { color: '#2563eb', bgColor: '#dbeafe' },
  'Вернулся с ремонта': { color: '#15803d', bgColor: '#dcfce7' },
};

export default function RepairsList({ repairs, tsds, members, onNavigate, onEditRepair }: RepairsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Ремонты ТСД</h2>
        <button onClick={() => onNavigate('tsd-repair-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>#</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>№ ТСД</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Дата создания</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Дата отправки</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Дата возвращения</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Статус</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Описание</th>
                <th className="px-3 py-3 text-left font-semibold" style={{ color: COLORS.heading }}>Виновен сотрудник</th>
              </tr>
            </thead>
            <tbody>
              {[...repairs]
                .sort((a, b) => a.brokenDate.localeCompare(b.brokenDate) || a.id - b.id)
                .map((repair, idx) => {
                const displayNum = idx + 1;
                const tsd = tsds.find(t => t.id === repair.tsdId);
                const statusText = repairStatusText(repair.status);
                const statusStyle = statusColorMap[statusText] || { color: COLORS.text, bgColor: '#f0f0f0' };

                return (
                  <tr
                    key={repair.id}
                    className="border-t transition-colors cursor-pointer hover:bg-blue-50"
                    style={{ borderColor: '#f0f0f0' }}
                    onClick={() => onEditRepair?.(repair)}
                  >
                    <td className="px-3 py-3 font-medium" style={{ color: COLORS.heading }}>
                      {displayNum}
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.heading }}>
                      {tsd ? `№${tsd.number}` : '?'}
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.text }}>
                      {tsd?.model || '—'}
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.text }}>
                      {formatDate(repair.brokenDate)}
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.text }}>
                      {repair.sentDate ? formatDate(repair.sentDate) : '—'}
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.text }}>
                      {repair.returnedDate ? formatDate(repair.returnedDate) : '—'}
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className="inline-block px-2 py-0.5 rounded text-xs font-medium"
                        style={{ color: statusStyle.color, backgroundColor: statusStyle.bgColor }}
                      >
                        {statusText}
                      </span>
                    </td>
                    <td className="px-3 py-3" style={{ color: COLORS.text }}>
                      {repair.description || '—'}
                    </td>
                    <td className="px-3 py-3">
                      {repair.isGuilty ? (
                        <span style={{ color: '#dc3545', fontWeight: 500 }}>Да</span>
                      ) : (
                        <span style={{ color: COLORS.text }}>Нет</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

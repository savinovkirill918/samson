'use client';

import React from 'react';
import { Printer, Hash } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD } from '@/lib/types';

interface PrintStickersProps {
  tsds: TSD[];
}

export default function PrintStickers({ tsds }: PrintStickersProps) {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Наклейки ТСД</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="flex justify-end mb-4">
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Printer className="w-4 h-4" /> Печать
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {tsds.map(tsd => (
            <div key={tsd.id} className="border-2 border-dashed p-4 text-center rounded-lg" style={{ borderColor: '#dee2e6' }}>
              <div className="text-2xl font-bold mb-1" style={{ color: COLORS.primary }}>ТСД №{tsd.number}</div>
              <div className="text-sm" style={{ color: COLORS.text }}>{tsd.model}</div>
              <div className="text-xs mt-1 font-mono" style={{ color: COLORS.text }}>{tsd.sn}</div>
              <div className="mt-2 h-8 flex items-center justify-center" style={{ backgroundColor: '#f8f9fa' }}>
                <Hash className="w-4 h-4" style={{ color: COLORS.text }} />
                <span className="text-xs font-mono ml-1" style={{ color: COLORS.text }}>{tsd.inv}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

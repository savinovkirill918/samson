'use client';

import React, { useState } from 'react';
import { Tag, Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';

export default function PrintBarcode() {
  const [barcode, setBarcode] = useState('');
  const [generated, setGenerated] = useState<string[]>([]);

  const handleGenerate = () => {
    if (!barcode) return;
    setGenerated(prev => [...prev, barcode]);
    setBarcode('');
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Штрихкод</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <div className="flex gap-2 mb-4">
          <input type="text" value={barcode} onChange={e => setBarcode(e.target.value)} placeholder="Введите штрихкод" className="flex-1 px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} onKeyDown={e => e.key === 'Enter' && handleGenerate()} />
          <button onClick={handleGenerate} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Tag className="w-4 h-4" /> Генерировать
          </button>
        </div>
        {generated.length > 0 && (
          <div className="space-y-3">
            {generated.map((code, i) => (
              <div key={i} className="flex items-center justify-between p-3 border rounded-lg" style={{ borderColor: '#dee2e6' }}>
                <div>
                  <div className="font-mono text-lg" style={{ color: COLORS.heading }}>{code}</div>
                  <div className="flex gap-0.5 mt-1">
                    {code.split('').map((char, ci) => (
                      <div key={ci} className="flex gap-px">
                        {Array.from({ length: 4 }, (_, bi) => (
                          <div key={bi} className={`${(char.charCodeAt(0) + bi) % 2 === 0 ? 'bg-black' : 'bg-white'} ${bi < 2 ? 'w-0.5' : 'w-1'} h-6`} />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
                <button onClick={() => window.print()} className="p-2 rounded-lg hover:bg-gray-100" style={{ color: COLORS.primary }}>
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

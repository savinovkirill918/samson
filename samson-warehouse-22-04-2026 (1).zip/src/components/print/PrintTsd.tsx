'use client';

import React from 'react';
import { Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, Member } from '@/lib/types';

interface PrintTsdProps {
  tsds: TSD[];
  members: Member[];
}

export default function PrintTsd({ tsds, members }: PrintTsdProps) {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Реестр ТСД</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="flex justify-end mb-4">
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Printer className="w-4 h-4" /> Печать
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>№</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>С/N</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Инв. №</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
              </tr>
            </thead>
            <tbody>
              {tsds.map(tsd => {
                const assigned = members.filter(m => m.tsdId === tsd.id).map(m => m.fio).join(', ');
                return (
                  <tr key={tsd.id}>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.heading }}>{tsd.number}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.model}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.sn}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.inv}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: assigned ? COLORS.heading : '#dc3545' }}>{assigned || 'Отсутствует'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

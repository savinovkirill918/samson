'use client';

import React, { useState } from 'react';
import { Box, Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';

export default function PrintContainers() {
  const [containerNum, setContainerNum] = useState('');
  const [containers, setContainers] = useState<string[]>([]);

  const handleAdd = () => {
    if (!containerNum) return;
    setContainers(prev => [...prev, containerNum]);
    setContainerNum('');
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Контейнеры</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <div className="flex gap-2 mb-4">
          <input type="text" value={containerNum} onChange={e => setContainerNum(e.target.value)} placeholder="Номер контейнера" className="flex-1 px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} onKeyDown={e => e.key === 'Enter' && handleAdd()} />
          <button onClick={handleAdd} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Box className="w-4 h-4" /> Добавить
          </button>
        </div>
        {containers.length > 0 && (
          <>
            <div className="flex justify-end mb-3">
              <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
                <Printer className="w-4 h-4" /> Печать
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {containers.map((c, i) => (
                <div key={i} className="border-2 border-dashed p-4 text-center rounded-lg" style={{ borderColor: '#dee2e6' }}>
                  <div className="text-xl font-bold" style={{ color: COLORS.primary }}>Контейнер</div>
                  <div className="text-3xl font-bold mt-2" style={{ color: COLORS.heading }}>{c}</div>
                  <div className="flex gap-0.5 justify-center mt-2">
                    {c.split('').map((char, ci) => (
                      <div key={ci} className="flex gap-px">
                        {Array.from({ length: 4 }, (_, bi) => (
                          <div key={bi} className={`${(char.charCodeAt(0) + bi) % 2 === 0 ? 'bg-black' : 'bg-white'} ${bi < 2 ? 'w-0.5' : 'w-1'} h-8`} />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

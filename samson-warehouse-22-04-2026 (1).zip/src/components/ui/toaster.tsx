'use client';

// Простой заглушка для Toaster (shadcn/ui)
// В приложении пока не используется активно
export function Toaster() {
  return null;
}

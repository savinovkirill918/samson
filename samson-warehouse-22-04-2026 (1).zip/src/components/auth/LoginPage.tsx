'use client';

import React, { useState, useEffect } from 'react';
import { Home } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { AdminUser } from '@/lib/types';
import { getAdmins } from '@/lib/api';

interface LoginPageProps {
  onLogin: (user: AdminUser) => void;
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState('');
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    getAdmins()
      .then(setAdmins)
      .catch(() => {})
      .finally(() => setChecking(false));
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Check against admins from API
    const admin = admins.find(a => a.login === login);
    if (admin && admin.hash === password) {
      onLogin(admin);
      if (remember) {
        localStorage.setItem('samson_auth', JSON.stringify(admin));
      }
    } else {
      setError('Неверный логин или пароль');
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
        <div className="w-8 h-8 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md mx-4">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full mb-4" style={{ backgroundColor: COLORS.primary }}>
            <Home className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold" style={{ color: COLORS.heading }}>Самсон Склад</h1>
          <p className="text-sm mt-1" style={{ color: COLORS.text }}>Система управления складом</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин</label>
            <input
              type="text"
              value={login}
              onChange={e => { setLogin(e.target.value); setError(''); }}
              className="w-full px-4 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:border-transparent transition"
              style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              onFocus={e => e.target.style.setProperty('--tw-ring-color', COLORS.primary)}
              placeholder="Введите логин"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль</label>
            <input
              type="password"
              value={password}
              onChange={e => { setPassword(e.target.value); setError(''); }}
              className="w-full px-4 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:border-transparent transition"
              style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              placeholder="Введите пароль"
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={remember}
                onChange={e => setRemember(e.target.checked)}
                className="w-4 h-4 rounded"
                style={{ accentColor: COLORS.primary }}
              />
              <span className="text-sm" style={{ color: COLORS.text }}>Запомнить меня</span>
            </label>
            <a href="#" className="text-sm hover:underline" style={{ color: COLORS.primary }}>Забыли пароль?</a>
          </div>

          {error && (
            <div className="text-red-500 text-sm text-center bg-red-50 p-2 rounded">{error}</div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 text-white rounded-lg font-medium hover:opacity-90 transition"
            style={{ backgroundColor: COLORS.primary }}
          >
            Вход
          </button>
        </form>
      </div>
    </div>
  );
}

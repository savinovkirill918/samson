'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { Group, PageId } from '@/lib/types';

interface GroupsListProps {
  groups: Group[];
  onNavigate: (page: PageId) => void;
}

export default function GroupsList({ groups, onNavigate }: GroupsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Должности</h2>
        <button onClick={() => onNavigate('group-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          +
        </button>
      </div>
      <div className="bg-white rounded-xl shadow overflow-hidden">
        <table className="w-full">
          <thead>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ID</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Название</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Сортировка</th>
            </tr>
          </thead>
          <tbody>
            {groups.sort((a, b) => a.sort - b.sort).map(g => (
              <tr key={g.id} className="border-t" style={{ borderColor: '#f0f0f0' }}>
                <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.id}</td>
                <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{g.name}</td>
                <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.sort}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

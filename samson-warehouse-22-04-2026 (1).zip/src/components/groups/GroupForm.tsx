'use client';

import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Group, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface GroupFormProps {
  onSave: (group: { name: string; sort: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function GroupForm({ onSave, onNavigate }: GroupFormProps) {
  const [name, setName] = useState('');
  const [sort, setSort] = useState('16');

  const handleSave = () => {
    if (!name) return;
    onSave({ name, sort: parseInt(sort) || 16 });
    onNavigate('groups');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Должности', page: 'groups', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить должность</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Название *</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Сортировка</label>
          <input type="number" value={sort} onChange={e => setSort(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
}

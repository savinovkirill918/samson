import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// Конвертация dd.mm.yyyy → yyyy-mm-dd для строкового сравнения
function toSortable(d: string): string {
  const parts = d.split('.')
  if (parts.length !== 3) return ''
  return `${parts[2]}-${parts[1]}-${parts[0]}`
}

// GET /api/stats/49?uploadId=N или ?dateFrom=dd.mm.yyyy&dateTo=dd.mm.yyyy
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const uploadId = searchParams.get('uploadId')
    const dateFrom = searchParams.get('dateFrom')
    const dateTo = searchParams.get('dateTo')

    if (uploadId) {
      const upload = await prisma.stat49Upload.findUnique({
        where: { id: Number(uploadId) },
        include: {
          avgRows: { orderBy: [{ controller: 'asc' }, { orderType: 'asc' }] },
          dailyRows: { orderBy: [{ date: 'asc' }, { controller: 'asc' }] },
        }
      })
      if (!upload) {
        return NextResponse.json({ error: 'Загрузка не найдена' }, { status: 404 })
      }
      return NextResponse.json(upload)
    }

    // Фильтрация по дате — агрегируем данные по ВСЕМ подходящим загрузкам
    if (dateFrom && dateTo) {
      const fromSortable = toSortable(dateFrom)
      const toSortable2 = toSortable(dateTo)
      const allUploads = await prisma.stat49Upload.findMany({
        orderBy: { id: 'desc' },
        include: {
          avgRows: { orderBy: [{ controller: 'asc' }, { orderType: 'asc' }] },
          dailyRows: { orderBy: [{ date: 'asc' }, { controller: 'asc' }] },
        }
      })
      const matching = allUploads.filter(u => {
        const uFrom = toSortable(u.dateFrom)
        const uTo = toSortable(u.dateTo)
        return uFrom <= toSortable2 && uTo >= fromSortable
      })
      if (matching.length > 0) {
        // Если одна загрузка — возвращаем как есть
        if (matching.length === 1) {
          return NextResponse.json(matching[0])
        }
        // Агрегируем avgRows: среднее avgProizvod, сумма allErp по (controller, orderType)
        const avgMap = new Map<string, { controller: string; orderType: string; allErp: number; avgProizvod: number; count: number }>()
        for (const upload of matching) {
          for (const row of upload.avgRows) {
            const key = `${row.controller}|||${row.orderType}`
            const existing = avgMap.get(key)
            if (existing) {
              existing.allErp += row.allErp
              existing.avgProizvod += row.avgProizvod
              existing.count += 1
            } else {
              avgMap.set(key, {
                controller: row.controller,
                orderType: row.orderType,
                allErp: row.allErp,
                avgProizvod: row.avgProizvod,
                count: 1,
              })
            }
          }
        }
        const aggAvgRows = Array.from(avgMap.values()).map((entry, idx) => ({
          id: -(idx + 1),
          uploadId: -1,
          controller: entry.controller,
          orderType: entry.orderType,
          allErp: entry.allErp,
          avgProizvod: Math.round(entry.avgProizvod / entry.count),
        }))

        // Собираем dailyRows из всех подходящих загрузок
        const dailyMap = new Map<string, any>()
        let dailyIdx = 0
        for (const upload of matching) {
          for (const row of upload.dailyRows) {
            const key = `${row.date}|||${row.controller}|||${row.orderType}`
            if (!dailyMap.has(key)) {
              dailyMap.set(key, {
                id: -(dailyIdx + 1),
                uploadId: -1,
                date: row.date,
                controller: row.controller,
                orderType: row.orderType,
                allErp: row.allErp,
                avgProizvod: row.avgProizvod,
              })
              dailyIdx++
            }
          }
        }
        const aggDailyRows = Array.from(dailyMap.values())

        return NextResponse.json({
          id: -1,
          dateFrom,
          dateTo,
          uploadedAt: new Date().toISOString(),
          avgRows: aggAvgRows,
          dailyRows: aggDailyRows,
        })
      }
      return NextResponse.json({ avgRows: [], dailyRows: [], dateFrom, dateTo })
    }

    // Получить последнюю загрузку
    const latestUpload = await prisma.stat49Upload.findFirst({
      orderBy: { id: 'desc' },
      include: {
        avgRows: { orderBy: [{ controller: 'asc' }, { orderType: 'asc' }] },
        dailyRows: { orderBy: [{ date: 'asc' }, { controller: 'asc' }] },
      }
    })

    return NextResponse.json(latestUpload || { avgRows: [], dailyRows: [] })
  } catch (error) {
    console.error('Error fetching stat49:', error)
    return NextResponse.json({ error: 'Ошибка получения отчёта 49' }, { status: 500 })
  }
}

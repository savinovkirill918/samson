import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/stats/uploads?type=13|49 — история загрузок
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || '13'

    if (type === '13') {
      const uploads = await prisma.stat13Upload.findMany({
        orderBy: { id: 'desc' },
        select: {
          id: true,
          dateFrom: true,
          dateTo: true,
          groupName: true,
          uploadedAt: true,
        }
      })
      return NextResponse.json(uploads)
    }

    if (type === '49') {
      const uploads = await prisma.stat49Upload.findMany({
        orderBy: { id: 'desc' },
        select: {
          id: true,
          dateFrom: true,
          dateTo: true,
          uploadedAt: true,
        }
      })
      return NextResponse.json(uploads)
    }

    return NextResponse.json({ error: 'Неизвестный тип отчёта' }, { status: 400 })
  } catch (error) {
    console.error('Error fetching uploads:', error)
    return NextResponse.json({ error: 'Ошибка получения истории загрузок' }, { status: 500 })
  }
}

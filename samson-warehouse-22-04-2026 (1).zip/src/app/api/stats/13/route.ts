import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// Конвертация dd.mm.yyyy → yyyy-mm-dd для строкового сравнения
function toSortable(d: string): string {
  const parts = d.split('.')
  if (parts.length !== 3) return ''
  return `${parts[2]}-${parts[1]}-${parts[0]}`
}

// GET /api/stats/13?uploadId=N или ?dateFrom=dd.mm.yyyy&dateTo=dd.mm.yyyy
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const uploadId = searchParams.get('uploadId')
    const dateFrom = searchParams.get('dateFrom')
    const dateTo = searchParams.get('dateTo')

    if (uploadId) {
      const upload = await prisma.stat13Upload.findUnique({
        where: { id: Number(uploadId) },
        include: { rows: { orderBy: { rowNum: 'asc' } } }
      })
      if (!upload) {
        return NextResponse.json({ error: 'Загрузка не найдена' }, { status: 404 })
      }
      return NextResponse.json(upload)
    }

    // Фильтрация по дате — агрегируем данные по ВСЕМ подходящим загрузкам
    if (dateFrom && dateTo) {
      const fromSortable = toSortable(dateFrom)
      const toSortable2 = toSortable(dateTo)
      const allUploads = await prisma.stat13Upload.findMany({
        orderBy: { id: 'desc' },
        include: { rows: { orderBy: { rowNum: 'asc' } } }
      })
      // Найти загрузки, период которых пересекается с выбранным
      const matching = allUploads.filter(u => {
        const uFrom = toSortable(u.dateFrom)
        const uTo = toSortable(u.dateTo)
        return uFrom <= toSortable2 && uTo >= fromSortable
      })
      if (matching.length > 0) {
        // Если одна загрузка — возвращаем как есть
        if (matching.length === 1) {
          return NextResponse.json(matching[0])
        }
        // Агрегируем: суммируем показатели по каждому ФИО
        const fioMap = new Map<string, {
          fio: string
          shtCnt: number; krCnt: number; pshtCnt: number; razmCnt: number; pkrCnt: number
          hours: number; rowNum: number
        }>()
        for (const upload of matching) {
          for (const row of upload.rows) {
            const key = row.fio.trim()
            const existing = fioMap.get(key)
            if (existing) {
              existing.shtCnt += row.shtCnt
              existing.krCnt += row.krCnt
              existing.pshtCnt += row.pshtCnt
              existing.razmCnt += row.razmCnt
              existing.pkrCnt += row.pkrCnt
              existing.hours += row.hours
            } else {
              fioMap.set(key, {
                fio: row.fio,
                shtCnt: row.shtCnt, krCnt: row.krCnt,
                pshtCnt: row.pshtCnt, razmCnt: row.razmCnt,
                pkrCnt: row.pkrCnt, hours: row.hours,
                rowNum: row.rowNum,
              })
            }
          }
        }
        // Формируем агрегированные строки
        const aggRows = Array.from(fioMap.values()).map((entry, idx) => {
          const ktu = entry.shtCnt + entry.krCnt + entry.pshtCnt + entry.razmCnt + entry.pkrCnt
          const avgPerHour = entry.hours > 0 ? Math.round((ktu / entry.hours) * 100) / 100 : 0
          return {
            id: -(idx + 1),
            uploadId: -1,
            rowNum: idx + 1,
            fio: entry.fio,
            shtCnt: entry.shtCnt,
            krCnt: entry.krCnt,
            pshtCnt: entry.pshtCnt,
            razmCnt: entry.razmCnt,
            pkrCnt: entry.pkrCnt,
            ktu,
            hours: Math.round(entry.hours * 100) / 100,
            avgPerHour,
          }
        })
        // Собираем имена групп из всех подходящих загрузок
        const groupNames = [...new Set(matching.map(u => u.groupName).filter(Boolean))]
        return NextResponse.json({
          id: -1,
          dateFrom,
          dateTo,
          groupName: groupNames.join(', '),
          uploadedAt: new Date().toISOString(),
          rows: aggRows,
        })
      }
      return NextResponse.json({ rows: [], dateFrom, dateTo })
    }

    // Получить последнюю загрузку
    const latestUpload = await prisma.stat13Upload.findFirst({
      orderBy: { id: 'desc' },
      include: { rows: { orderBy: { rowNum: 'asc' } } }
    })

    return NextResponse.json(latestUpload || { rows: [] })
  } catch (error) {
    console.error('Error fetching stat13:', error)
    return NextResponse.json({ error: 'Ошибка получения отчёта 13' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// POST /api/stats/upload — загрузка XML данных статистики
// Если загрузка с той же датой существует — перезаписывает данные и пишет в лог
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, dateFrom, dateTo, groupName, rows, avgRows, dailyRows, adminId } = body

    if (type === '13') {
      // Ищем существующую загрузку за ту же дату
      const existing = await prisma.stat13Upload.findFirst({
        where: { dateFrom, dateTo },
        include: { rows: true },
      })

      let updatedCount = 0
      let rowCount = rows?.length || 0

      if (existing) {
        // Перезапись: удаляем старые строки и создаём новые
        await prisma.stat13Row.deleteMany({ where: { uploadId: existing.id } })
        await prisma.stat13Upload.delete({ where: { id: existing.id } })

        // Считаем сколько строк обновилось (разных с прошлой загрузкой)
        const oldMap = new Map(existing.rows.map(r => [`${r.fio.trim()}`, r]))
        for (const r of (rows || [])) {
          const old = oldMap.get((r.fio || '').trim())
          if (!old ||
              old.shtCnt !== (r.shtCnt ?? 0) ||
              old.krCnt !== (r.krCnt ?? 0) ||
              old.pshtCnt !== (r.pshtCnt ?? 0) ||
              old.razmCnt !== (r.razmCnt ?? 0) ||
              old.pkrCnt !== (r.pkrCnt ?? 0) ||
              old.hours !== (r.hours ?? 0) ||
              old.avgPerHour !== (r.avgPerHour ?? 0)) {
            updatedCount++
          }
        }
      }

      // Создаём новую загрузку
      const upload = await prisma.stat13Upload.create({
        data: {
          dateFrom,
          dateTo,
          groupName: groupName ?? '',
          uploadedAt: new Date().toISOString(),
          rows: {
            create: (rows || []).map((r: any, idx: number) => ({
              rowNum: r.rowNum ?? idx + 1,
              fio: r.fio ?? '',
              shtCnt: r.shtCnt ?? 0,
              krCnt: r.krCnt ?? 0,
              pshtCnt: r.pshtCnt ?? 0,
              razmCnt: r.razmCnt ?? 0,
              pkrCnt: r.pkrCnt ?? 0,
              ktu: r.ktu ?? 0,
              hours: r.hours ?? 0,
              avgPerHour: r.avgPerHour ?? 0,
            }))
          }
        },
        include: { rows: true }
      })

      // Пишем в лог
      const periodStr = dateFrom === dateTo ? dateFrom : `${dateFrom} — ${dateTo}`
      if (existing) {
        const logText = `Обновлён отчёт 13 за ${periodStr}: ${updatedCount} строк обновлено`
        await prisma.logEntry.create({ data: { adminId: adminId || 1, text: logText, date: new Date().toISOString() } })
        return NextResponse.json({ ...upload, _log: logText, _mode: 'updated', _updatedCount: updatedCount, _totalCount: rowCount }, { status: 200 })
      } else {
        const logText = `Загружен отчёт 13 за ${periodStr}: ${rowCount} строк загружено`
        await prisma.logEntry.create({ data: { adminId: adminId || 1, text: logText, date: new Date().toISOString() } })
        return NextResponse.json({ ...upload, _log: logText, _mode: 'created', _totalCount: rowCount }, { status: 201 })
      }
    }

    if (type === '49') {
      // Ищем существующую загрузку за ту же дату
      const existing = await prisma.stat49Upload.findFirst({
        where: { dateFrom, dateTo },
        include: { avgRows: true, dailyRows: true },
      })

      let updatedAvgCount = 0
      let updatedDailyCount = 0
      let avgCount = avgRows?.length || 0
      let dailyCount = dailyRows?.length || 0

      if (existing) {
        // Удаляем старые данные
        await prisma.stat49AvgRow.deleteMany({ where: { uploadId: existing.id } })
        await prisma.stat49DailyRow.deleteMany({ where: { uploadId: existing.id } })
        await prisma.stat49Upload.delete({ where: { id: existing.id } })

        // Считаем обновлённые avgRows
        const oldAvgMap = new Map(existing.avgRows.map(r => [`${r.controller}|||${r.orderType}`, r]))
        for (const r of (avgRows || [])) {
          const key = `${(r.controller || '').trim()}|||${(r.orderType || '').trim()}`
          const old = oldAvgMap.get(key)
          if (!old || old.allErp !== (r.allErp ?? 0) || old.avgProizvod !== (r.avgProizvod ?? 0)) {
            updatedAvgCount++
          }
        }

        // Считаем обновлённые dailyRows
        const oldDailyMap = new Map(existing.dailyRows.map(r => [`${r.date}|||${r.controller}|||${r.orderType}`, r]))
        for (const r of (dailyRows || [])) {
          const key = `${(r.date || '').trim()}|||${(r.controller || '').trim()}|||${(r.orderType || '').trim()}`
          const old = oldDailyMap.get(key)
          if (!old || old.allErp !== (r.allErp ?? 0) || old.avgProizvod !== (r.avgProizvod ?? 0)) {
            updatedDailyCount++
          }
        }
      }

      // Создаём новую загрузку
      const upload = await prisma.stat49Upload.create({
        data: {
          dateFrom,
          dateTo,
          uploadedAt: new Date().toISOString(),
          avgRows: {
            create: (avgRows || []).map((r: any) => ({
              controller: r.controller ?? '',
              orderType: r.orderType ?? '',
              allErp: r.allErp ?? 0,
              avgProizvod: r.avgProizvod ?? 0,
            }))
          },
          dailyRows: {
            create: (dailyRows || []).map((r: any) => ({
              date: r.date ?? '',
              controller: r.controller ?? '',
              orderType: r.orderType ?? '',
              allErp: r.allErp ?? 0,
              avgProizvod: r.avgProizvod ?? 0,
            }))
          }
        },
        include: { avgRows: true, dailyRows: true }
      })

      // Пишем в лог
      const periodStr = dateFrom === dateTo ? dateFrom : `${dateFrom} — ${dateTo}`
      if (existing) {
        const logText = `Обновлён отчёт 49 за ${periodStr}: ${updatedAvgCount} средних, ${updatedDailyCount} дневных строк обновлено`
        await prisma.logEntry.create({ data: { adminId: adminId || 1, text: logText, date: new Date().toISOString() } })
        return NextResponse.json({ ...upload, _log: logText, _mode: 'updated', _updatedAvgCount: updatedAvgCount, _updatedDailyCount: updatedDailyCount, _avgCount: avgCount, _dailyCount: dailyCount }, { status: 200 })
      } else {
        const logText = `Загружен отчёт 49 за ${periodStr}: ${avgCount} средних, ${dailyCount} дневных строк загружено`
        await prisma.logEntry.create({ data: { adminId: adminId || 1, text: logText, date: new Date().toISOString() } })
        return NextResponse.json({ ...upload, _log: logText, _mode: 'created', _avgCount: avgCount, _dailyCount: dailyCount }, { status: 201 })
      }
    }

    return NextResponse.json({ error: 'Неизвестный тип отчёта' }, { status: 400 })
  } catch (error) {
    console.error('Error uploading stats:', error)
    return NextResponse.json({ error: 'Ошибка загрузки статистики' }, { status: 500 })
  }
}

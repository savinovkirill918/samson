// =====================================================================
// API маршрут: Генерация PDF-наклейки на ТСД
// Наклейка содержит:
//   Заголовок: "Наклейка на ТСД:"
//   Сплошная рамка (чёрная, тонкая)
//   1. Номер ТСД (крупно, по центру)
//   2. ФИО сотрудника (фамилия и инициалы)
//   3. Штрихкод инвентарного номера (CODE128) с подписью
//   4. Штрихкод серийного номера (CODE128) с подписью
// Размер наклейки: 60мм x 40мм (как в оригинальном сайте)
// =====================================================================

import { NextRequest, NextResponse } from 'next/server';
import jsPDF from 'jspdf';
import JsBarcode from 'jsbarcode';
import { createCanvas } from 'canvas';
import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * Генерация штрихкода CODE128 как PNG data URL (base64)
 * @param text - Текст для кодирования
 * @param barWidth - Ширина полоски
 * @param barHeight - Высота штрихкода в пикселях
 * @returns Строка data URL (base64 PNG)
 */
function generateBarcodeDataUrl(text: string, barWidth: number = 1.5, barHeight: number = 30): string {
  const canvas = createCanvas(300, barHeight + 10);
  JsBarcode(canvas as unknown as HTMLCanvasElement, text, {
    format: 'CODE128',
    width: barWidth,
    height: barHeight,
    displayValue: false,
    margin: 0,
  });
  return canvas.toDataURL('image/png');
}

/**
 * GET /api/sticker?number=...&fio=...&sn=...&inv=...
 * Генерирует PDF-документ с наклейкой на ТСД
 *
 * Структура наклейки:
 * ┌────────────────────────────┐
 * │         102                │
 * │   Тухбатуллин Р. С.       │
 * │   [штрихкод INV]          │
 * │   инв. номер              │
 * │   [штрихкод SN]           │
 * │   серийный номер          │
 * └────────────────────────────┘
 */
export async function GET(request: NextRequest) {
  try {
    // Получаем параметры из query string
    const { searchParams } = new URL(request.url);
    const number = searchParams.get('number') || '';
    const fio = searchParams.get('fio') || '';
    const sn = searchParams.get('sn') || '';
    const inv = searchParams.get('inv') || '';

    // Декодируем URI-компоненты (кириллица)
    const decodedNumber = decodeURIComponent(number);
    const decodedFio = decodeURIComponent(fio);
    const decodedSn = decodeURIComponent(sn);
    const decodedInv = decodeURIComponent(inv);

    // Форматируем ФИО: "Фамилия И. О." (если полное ФИО из 3 слов)
    const fioParts = decodedFio.trim().split(/\s+/);
    let shortFio = decodedFio;
    if (fioParts.length >= 3) {
      // Фамилия И. О.
      shortFio = `${fioParts[0]} ${fioParts[1].charAt(0)}. ${fioParts[2].charAt(0)}.`;
    } else if (fioParts.length === 2) {
      shortFio = `${fioParts[0]} ${fioParts[1].charAt(0)}.`;
    }

    // Создаём PDF-документ (размер наклейки: 60мм x 40мм)
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: [60, 40],
    });

    // Добавляем шрифт DejaVu Sans с поддержкой кириллицы
    const fontPath = join('/usr/share/fonts/truetype/dejavu', 'DejaVuSans.ttf');
    const fontBoldPath = join('/usr/share/fonts/truetype/dejavu', 'DejaVuSans-Bold.ttf');

    try {
      const fontBase64 = readFileSync(fontPath).toString('base64');
      doc.addFileToVFS('DejaVuSans.ttf', fontBase64);
      doc.addFont('DejaVuSans.ttf', 'DejaVuSans', 'normal');
    } catch { /* стандартный шрифт */ }

    try {
      const fontBoldBase64 = readFileSync(fontBoldPath).toString('base64');
      doc.addFileToVFS('DejaVuSans-Bold.ttf', fontBoldBase64);
      doc.addFont('DejaVuSans-Bold.ttf', 'DejaVuSans', 'bold');
    } catch { /* стандартный шрифт */ }

    // ============================================================
    // Подпись «Наклейка на ТСД:» над рамкой
    // ============================================================
    doc.setFontSize(6);
    doc.setFont('DejaVuSans', 'normal');
    doc.text('Наклейка на ТСД:', 3, 2.5);

    // ============================================================
    // Сплошная рамка (чёрная, тонкая)
    // ============================================================
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.5);
    doc.rect(3, 3, 54, 35); // Сплошной прямоугольник

    // Внутренние отступы
    const innerLeft = 5;
    const innerTop = 5;
    const innerWidth = 50;

    // ============================================================
    // 1. Номер ТСД (крупно, по центру)
    // ============================================================
    doc.setFontSize(16);
    doc.setFont('DejaVuSans', 'bold');
    doc.text(decodedNumber, 60 / 2, innerTop + 5, { align: 'center' });

    // ============================================================
    // 2. ФИО сотрудника (фамилия и инициалы)
    // ============================================================
    doc.setFontSize(7);
    doc.setFont('DejaVuSans', 'normal');
    doc.text(shortFio, 60 / 2, innerTop + 10, { align: 'center' });

    // ============================================================
    // 3. Штрихкод инвентарного номера с подписью
    // ============================================================
    if (decodedInv) {
      const invBarcodeDataUrl = generateBarcodeDataUrl(decodedInv, 1.5, 25);
      doc.addImage(invBarcodeDataUrl, 'PNG', innerLeft, innerTop + 12, innerWidth, 7);

      // Подпись инв. номера
      doc.setFontSize(5);
      doc.setFont('DejaVuSans', 'normal');
      doc.text(decodedInv, 60 / 2, innerTop + 20, { align: 'center' });
    }

    // ============================================================
    // 4. Штрихкод серийного номера с подписью
    // ============================================================
    if (decodedSn) {
      const snBarcodeDataUrl = generateBarcodeDataUrl(decodedSn, 1.5, 25);
      doc.addImage(snBarcodeDataUrl, 'PNG', innerLeft, innerTop + 21, innerWidth, 7);

      // Подпись серийного номера
      doc.setFontSize(5);
      doc.setFont('DejaVuSans', 'normal');
      doc.text(decodedSn, 60 / 2, innerTop + 29, { align: 'center' });
    }

    // Возвращаем PDF
    const pdfBuffer = Buffer.from(doc.output('arraybuffer'));

    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="TSD_${decodedNumber}.pdf"`,
      },
    });
  } catch (error) {
    console.error('Ошибка генерации наклейки:', error);
    return NextResponse.json(
      { error: 'Ошибка генерации наклейки' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/admins — список администраторов
export async function GET() {
  try {
    const admins = await prisma.adminUser.findMany({
      orderBy: { id: 'asc' }
    })
    return NextResponse.json(admins)
  } catch (error) {
    console.error('Error fetching admins:', error)
    return NextResponse.json({ error: 'Ошибка получения админов' }, { status: 500 })
  }
}

// POST /api/admins — создать администратора
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const admin = await prisma.adminUser.create({
      data: {
        login: body.login,
        hash: body.hash ?? '',
        fio: body.fio,
        role: body.role ?? 'Админ',
        groupId: body.groupId ?? 15,
      }
    })
    return NextResponse.json(admin, { status: 201 })
  } catch (error) {
    console.error('Error creating admin:', error)
    return NextResponse.json({ error: 'Ошибка создания админа' }, { status: 500 })
  }
}

// PUT /api/admins — обновить администратора
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const admin = await prisma.adminUser.update({
      where: { id: body.id },
      data: {
        login: body.login,
        hash: body.hash ?? '',
        fio: body.fio,
        role: body.role,
        groupId: body.groupId,
      }
    })
    return NextResponse.json(admin)
  } catch (error) {
    console.error('Error updating admin:', error)
    return NextResponse.json({ error: 'Ошибка обновления админа' }, { status: 500 })
  }
}

// DELETE /api/admins?id=N — удалить администратора
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.adminUser.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting admin:', error)
    return NextResponse.json({ error: 'Ошибка удаления админа' }, { status: 500 })
  }
}

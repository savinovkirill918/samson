import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/tsds — список всех ТСД
export async function GET() {
  try {
    const tsds = await prisma.tSD.findMany({
      include: { members: true, repairs: true },
      orderBy: { number: 'asc' }
    })
    return NextResponse.json(tsds)
  } catch (error) {
    console.error('Error fetching TSDs:', error)
    return NextResponse.json({ error: 'Ошибка получения ТСД' }, { status: 500 })
  }
}

// POST /api/tsds — создать ТСД
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const tsd = await prisma.tSD.create({
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        model: body.model ?? '',
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(tsd, { status: 201 })
  } catch (error) {
    console.error('Error creating TSD:', error)
    return NextResponse.json({ error: 'Ошибка создания ТСД' }, { status: 500 })
  }
}

// PUT /api/tsds — обновить ТСД
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const tsd = await prisma.tSD.update({
      where: { id: body.id },
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        model: body.model ?? '',
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(tsd)
  } catch (error) {
    console.error('Error updating TSD:', error)
    return NextResponse.json({ error: 'Ошибка обновления ТСД' }, { status: 500 })
  }
}

// DELETE /api/tsds?id=N — удалить ТСД
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.tSD.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting TSD:', error)
    return NextResponse.json({ error: 'Ошибка удаления ТСД' }, { status: 500 })
  }
}

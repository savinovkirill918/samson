import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/members — список всех сотрудников
export async function GET() {
  try {
    const members = await prisma.member.findMany({
      include: { group: true, tsd: true, kkm: true },
      orderBy: { fio: 'asc' }
    })
    return NextResponse.json(members)
  } catch (error) {
    console.error('Error fetching members:', error)
    return NextResponse.json({ error: 'Ошибка получения сотрудников' }, { status: 500 })
  }
}

// POST /api/members — создать сотрудника
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const member = await prisma.member.create({
      data: {
        fio: body.fio,
        login: body.login,
        password: body.password,
        email: body.email ?? '',
        emailPassword: body.emailPassword ?? '',
        groupId: body.groupId,
        tsdId: body.tsdId ?? null,
        kkmId: body.kkmId ?? null,
        tg: body.tg ?? '',
      }
    })
    return NextResponse.json(member, { status: 201 })
  } catch (error) {
    console.error('Error creating member:', error)
    return NextResponse.json({ error: 'Ошибка создания сотрудника' }, { status: 500 })
  }
}

// PUT /api/members — обновить сотрудника
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const member = await prisma.member.update({
      where: { id: body.id },
      data: {
        fio: body.fio,
        login: body.login,
        password: body.password,
        email: body.email ?? '',
        emailPassword: body.emailPassword ?? '',
        groupId: body.groupId,
        tsdId: body.tsdId ?? null,
        kkmId: body.kkmId ?? null,
        tg: body.tg ?? '',
      }
    })
    return NextResponse.json(member)
  } catch (error) {
    console.error('Error updating member:', error)
    return NextResponse.json({ error: 'Ошибка обновления сотрудника' }, { status: 500 })
  }
}

// DELETE /api/members?id=N — удалить сотрудника
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.member.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting member:', error)
    return NextResponse.json({ error: 'Ошибка удаления сотрудника' }, { status: 500 })
  }
}

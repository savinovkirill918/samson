import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/kkms — список всех ККМ
export async function GET() {
  try {
    const kkms = await prisma.kKM.findMany({
      include: { members: true },
      orderBy: { number: 'asc' }
    })
    return NextResponse.json(kkms)
  } catch (error) {
    console.error('Error fetching KKMs:', error)
    return NextResponse.json({ error: 'Ошибка получения ККМ' }, { status: 500 })
  }
}

// POST /api/kkms — создать ККМ
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const kkm = await prisma.kKM.create({
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(kkm, { status: 201 })
  } catch (error) {
    console.error('Error creating KKM:', error)
    return NextResponse.json({ error: 'Ошибка создания ККМ' }, { status: 500 })
  }
}

// PUT /api/kkms — обновить ККМ
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const kkm = await prisma.kKM.update({
      where: { id: body.id },
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(kkm)
  } catch (error) {
    console.error('Error updating KKM:', error)
    return NextResponse.json({ error: 'Ошибка обновления ККМ' }, { status: 500 })
  }
}

// DELETE /api/kkms?id=N — удалить ККМ
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.kKM.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting KKM:', error)
    return NextResponse.json({ error: 'Ошибка удаления ККМ' }, { status: 500 })
  }
}

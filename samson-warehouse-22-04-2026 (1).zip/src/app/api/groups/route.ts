import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/groups — список всех должностей
export async function GET() {
  try {
    const groups = await prisma.group.findMany({ orderBy: { sort: 'asc' } })
    return NextResponse.json(groups)
  } catch (error) {
    console.error('Error fetching groups:', error)
    return NextResponse.json({ error: 'Ошибка получения должностей' }, { status: 500 })
  }
}

// POST /api/groups — создать должность
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const group = await prisma.group.create({
      data: { name: body.name, sort: body.sort ?? 0 }
    })
    return NextResponse.json(group, { status: 201 })
  } catch (error) {
    console.error('Error creating group:', error)
    return NextResponse.json({ error: 'Ошибка создания должности' }, { status: 500 })
  }
}

// PUT /api/groups — обновить должность
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const group = await prisma.group.update({
      where: { id: body.id },
      data: { name: body.name, sort: body.sort }
    })
    return NextResponse.json(group)
  } catch (error) {
    console.error('Error updating group:', error)
    return NextResponse.json({ error: 'Ошибка обновления должности' }, { status: 500 })
  }
}

// DELETE /api/groups?id=N — удалить должность
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.group.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting group:', error)
    return NextResponse.json({ error: 'Ошибка удаления должности' }, { status: 500 })
  }
}

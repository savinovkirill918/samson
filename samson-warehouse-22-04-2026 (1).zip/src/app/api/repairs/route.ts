import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/repairs — список всех ремонтов
export async function GET() {
  try {
    const repairs = await prisma.repair.findMany({
      include: { tsd: true },
      orderBy: { id: 'desc' }
    })
    return NextResponse.json(repairs)
  } catch (error) {
    console.error('Error fetching repairs:', error)
    return NextResponse.json({ error: 'Ошибка получения ремонтов' }, { status: 500 })
  }
}

// POST /api/repairs — создать ремонт
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.repair.create({
      data: {
        tsdId: body.tsdId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status ?? -1,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })
    return NextResponse.json(repair, { status: 201 })
  } catch (error) {
    console.error('Error creating repair:', error)
    return NextResponse.json({ error: 'Ошибка создания ремонта' }, { status: 500 })
  }
}

// PUT /api/repairs — обновить ремонт
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.repair.update({
      where: { id: body.id },
      data: {
        tsdId: body.tsdId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })
    return NextResponse.json(repair)
  } catch (error) {
    console.error('Error updating repair:', error)
    return NextResponse.json({ error: 'Ошибка обновления ремонта' }, { status: 500 })
  }
}

// DELETE /api/repairs?id=N — удалить ремонт
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.repair.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting repair:', error)
    return NextResponse.json({ error: 'Ошибка удаления ремонта' }, { status: 500 })
  }
}

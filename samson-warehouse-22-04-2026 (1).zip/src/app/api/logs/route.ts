import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/logs — список логов
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number(searchParams.get('limit')) || 100
    const offset = Number(searchParams.get('offset')) || 0

    const logs = await prisma.logEntry.findMany({
      orderBy: { id: 'desc' },
      take: limit,
      skip: offset,
    })
    return NextResponse.json(logs)
  } catch (error) {
    console.error('Error fetching logs:', error)
    return NextResponse.json({ error: 'Ошибка получения логов' }, { status: 500 })
  }
}

// POST /api/logs — создать запись лога
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const log = await prisma.logEntry.create({
      data: {
        adminId: body.adminId,
        text: body.text,
        date: body.date ?? new Date().toISOString(),
      }
    })
    return NextResponse.json(log, { status: 201 })
  } catch (error) {
    console.error('Error creating log:', error)
    return NextResponse.json({ error: 'Ошибка создания лога' }, { status: 500 })
  }
}

'use client';

// =====================================================================
// Самсон Склад — Система управления складом
// Orchestrator page — imports all components and hooks
// =====================================================================

import React, { useState, useEffect, useCallback } from 'react';
import { Menu, LogOut, ChevronDown } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PageId, Member, AdminUser } from '@/lib/types';
import { getGroupName } from '@/lib/helpers';

// Hooks
import { useMembers } from '@/hooks/useMembers';
import { useGroups } from '@/hooks/useGroups';
import { useTsd } from '@/hooks/useTsd';
import { useKkm } from '@/hooks/useKkm';
import { useRepairs } from '@/hooks/useRepairs';
import { useLogs } from '@/hooks/useLogs';
import { useAdmins } from '@/hooks/useAdmins';

// Components
import LoginPage from '@/components/auth/LoginPage';
import Sidebar from '@/components/layout/Sidebar';
import HomePage from '@/components/home/HomePage';
import MembersList from '@/components/members/MembersList';
import MemberForm from '@/components/members/MemberForm';
import GroupsList from '@/components/groups/GroupsList';
import GroupForm from '@/components/groups/GroupForm';
import TsdList from '@/components/tsd/TsdList';
import TsdForm from '@/components/tsd/TsdForm';
import RepairsList from '@/components/tsd/RepairsList';
import RepairForm from '@/components/tsd/RepairForm';
import RepairEditForm from '@/components/tsd/RepairEditForm';
import RepairSZPage from '@/components/tsd/RepairSZPage';
import KkmList from '@/components/kkm/KkmList';
import KkmForm from '@/components/kkm/KkmForm';
import StatStarshie from '@/components/statistics/StatStarshie';
import StatKladovshiki from '@/components/statistics/StatKladovshiki';
import StatImport from '@/components/statistics/StatImport';
import ToolsPage from '@/components/tools/ToolsPage';
import LogsPage from '@/components/logs/LogsPage';
import PrintTsd from '@/components/print/PrintTsd';
import PrintKkm from '@/components/print/PrintKkm';
import PrintStickers from '@/components/print/PrintStickers';
import PrintBarcode from '@/components/print/PrintBarcode';
import PrintContainers from '@/components/print/PrintContainers';
import SettingsUsers from '@/components/settings/SettingsUsers';
import UserForm from '@/components/settings/UserForm';

// =====================================================================
// ГЛАВНЫЙ КОМПОНЕНТ ПРИЛОЖЕНИЯ
// =====================================================================
export default function SamsonSkladApp() {
  // Navigation state
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  // ID of the member being edited
  const [editingMemberId, setEditingMemberId] = useState<number | null>(null);
  // ID of the TSD being edited
  const [editingTsdId, setEditingTsdId] = useState<number | null>(null);
  // ID of the repair being edited
  const [editingRepairId, setEditingRepairId] = useState<number | null>(null);

  // Auth state — lazy init from localStorage
  const [authUser, setAuthUser] = useState<AdminUser | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('samson_auth');
      if (stored) {
        try { return JSON.parse(stored); } catch { localStorage.removeItem('samson_auth'); }
      }
    }
    return null;
  });
  const [authChecked, setAuthChecked] = useState<boolean>(typeof window === 'undefined' ? false : true);

  // Data hooks
  const { members, saveMember, deleteMember } = useMembers();
  const { groups, saveGroup } = useGroups();
  const { tsds, saveTsd, updateTsd } = useTsd();
  const { kkms, saveKkm } = useKkm();
  const { repairs, saveRepair, updateRepair, refetch: refetchRepairs } = useRepairs();
  const { logs, addLog } = useLogs();
  const { admins, saveAdmin } = useAdmins();

  // Login handler
  const handleLogin = useCallback(async (user: AdminUser) => {
    setAuthUser(user);
    await addLog(user.id, 'Вход в систему');
  }, [addLog]);

  // Logout handler
  const handleLogout = useCallback(() => {
    if (authUser) {
      addLog(authUser.id, 'Выход из системы');
    }
    setAuthUser(null);
    setProfileOpen(false);
    setCurrentPage('home');
    localStorage.removeItem('samson_auth');
  }, [authUser, addLog]);

  // Navigation
  const navigate = useCallback((page: PageId) => {
    setCurrentPage(page);
    setProfileOpen(false);
  }, []);

  // Member handlers
  const handleSaveMember = useCallback(async (member: Member & { isNew?: boolean }) => {
    await saveMember(member);
    await addLog(authUser?.id || 1, member.isNew
      ? `Добавление сотрудника: ${member.fio}`
      : `Редактирование сотрудника: ${member.fio}`);
  }, [saveMember, addLog, authUser]);

  const handleDeleteMember = useCallback(async (id: number) => {
    const member = members.find(m => m.id === id);
    await deleteMember(id);
    if (member) {
      await addLog(authUser?.id || 1, `Удаление сотрудника: ${member.fio}`);
    }
  }, [deleteMember, members, addLog, authUser]);

  // TSD handlers
  const handleSaveTSD = useCallback(async (tsd: { number: number; sn: string; inv: string; model: string; isMulti: boolean }) => {
    await saveTsd(tsd);
    await addLog(authUser?.id || 1, `Добавление ТСД №${tsd.number}`);
  }, [saveTsd, addLog, authUser]);

  const handleUpdateTSD = useCallback(async (tsd: Partial<import('@/lib/types').TSD> & { id: number }) => {
    await updateTsd(tsd);
    await addLog(authUser?.id || 1, `Редактирование ТСД №${tsd.number}`);
  }, [updateTsd, addLog, authUser]);

  // KKM handler
  const handleSaveKKM = useCallback(async (kkm: { number: number; sn: string; inv: string; isMulti: boolean }) => {
    await saveKkm(kkm);
    await addLog(authUser?.id || 1, `Добавление ККМ №${kkm.number}`);
  }, [saveKkm, addLog, authUser]);

  // Repair handlers
  const handleSaveRepair = useCallback(async (repair: Parameters<typeof saveRepair>[0]) => {
    await saveRepair(repair);
    await addLog(authUser?.id || 1, 'Добавление ремонта ТСД');
  }, [saveRepair, addLog, authUser]);

  const handleUpdateRepair = useCallback(async (repair: Parameters<typeof updateRepair>[0]) => {
    await updateRepair(repair);
    await addLog(authUser?.id || 1, `Редактирование ремонта ТСД #${repair.id}`);
  }, [updateRepair, addLog, authUser]);

  // Group handler
  const handleSaveGroup = useCallback(async (group: { name: string; sort: number }) => {
    await saveGroup(group);
  }, [saveGroup]);

  // Admin handler
  const handleSaveAdmin = useCallback(async (admin: { login: string; hash?: string; fio: string; role?: string; groupId?: number }) => {
    await saveAdmin(admin);
    await addLog(authUser?.id || 1, `Добавление пользователя: ${admin.login}`);
  }, [saveAdmin, addLog, authUser]);

  // Loading spinner while checking auth
  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
        <div className="w-8 h-8 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
      </div>
    );
  }

  // Login page
  if (!authUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Render current page content
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} onNavigate={navigate} />;
      case 'members':
        return <MembersList members={members} groups={groups} tsds={tsds} kkms={kkms} onEdit={id => { setEditingMemberId(id); navigate('member-edit'); }} onNavigate={navigate} />;
      case 'member-add':
        return <MemberForm memberId={null} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'member-edit':
        return <MemberForm memberId={editingMemberId} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'groups':
        return <GroupsList groups={groups} onNavigate={navigate} />;
      case 'group-add':
        return <GroupForm onSave={handleSaveGroup} onNavigate={navigate} />;
      case 'tsd-list':
        return <TsdList tsds={tsds} members={members} onNavigate={navigate} onEditTsd={(tsd) => { setEditingTsdId(tsd.id); navigate('tsd-edit'); }} />;
      case 'tsd-add':
        return <TsdForm onSave={handleSaveTSD} onNavigate={navigate} />;
      case 'tsd-edit':
        return <TsdForm editingTsdId={editingTsdId} tsds={tsds} onSave={handleSaveTSD} onUpdate={handleUpdateTSD} onNavigate={navigate} />;
      case 'tsd-repairs':
        return <RepairsList repairs={repairs} tsds={tsds} members={members} onNavigate={navigate} onEditRepair={(repair) => { setEditingRepairId(repair.id); navigate('tsd-repair-edit'); }} />;
      case 'tsd-repair-add':
        return <RepairForm tsds={tsds} onSave={handleSaveRepair} onNavigate={navigate} />;
      case 'tsd-repair-edit':
        return <RepairEditForm repairId={editingRepairId ?? 0} repairs={repairs} tsds={tsds} onUpdate={handleUpdateRepair} onNavigate={navigate} />;
      case 'tsd-repair-sz':
        return <RepairSZPage repairs={repairs} tsds={tsds} onNavigate={navigate} />;
      case 'kkm-list':
        return <KkmList kkms={kkms} members={members} onNavigate={navigate} />;
      case 'kkm-add':
        return <KkmForm onSave={handleSaveKKM} onNavigate={navigate} />;
      case 'stat-starshie':
        return <StatStarshie members={members} groups={groups} />;
      case 'stat-kladovshiki':
        return <StatKladovshiki members={members} groups={groups} />;
      case 'stat-import':
        return <StatImport />;
      case 'tools':
        return <ToolsPage />;
      case 'logs':
        return <LogsPage logs={logs} admins={admins} />;
      case 'print-tsd':
        return <PrintTsd tsds={tsds} members={members} />;
      case 'print-kkm':
        return <PrintKkm kkms={kkms} members={members} />;
      case 'print-stickers':
        return <PrintStickers tsds={tsds} />;
      case 'print-barcode':
        return <PrintBarcode />;
      case 'print-containers':
        return <PrintContainers />;
      case 'settings-users':
        return <SettingsUsers admins={admins} groups={groups} onNavigate={navigate} />;
      case 'settings-user-add':
        return <UserForm groups={groups} onSave={handleSaveAdmin} onNavigate={navigate} />;
      default:
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: COLORS.bodyBg }}>
      <div className="flex flex-1">
        <Sidebar currentPage={currentPage} onNavigate={navigate} isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        <div className="flex-1 lg:ml-[260px]">
          <header className="bg-white shadow-sm px-4 py-3 flex items-center justify-between sticky top-0 z-30">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100">
                <Menu className="w-5 h-5" style={{ color: COLORS.heading }} />
              </button>
            </div>

            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition"
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold" style={{ backgroundColor: COLORS.primary }}>
                  {authUser.fio.charAt(0)}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                  <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                </div>
                <ChevronDown className="w-4 h-4" style={{ color: COLORS.text }} />
              </button>

              {profileOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border py-2 w-48 z-50" style={{ borderColor: '#e9ecef' }}>
                  <div className="px-4 py-2 border-b" style={{ borderColor: '#f0f0f0' }}>
                    <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                    <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                  </div>
                  <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 transition">
                    <LogOut className="w-4 h-4" /> Выход
                  </button>
                </div>
              )}
            </div>
          </header>

          <main className="p-4 md:p-6 flex-1">
            {renderPage()}
          </main>

          <footer className="px-4 py-3 text-center text-sm border-t mt-auto" style={{ color: COLORS.text, borderColor: '#e9ecef' }}>
            © 2023-2026 Made with ❤ by Philipp Shklyaev.
          </footer>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { Calculator, Package, ChevronDown, ChevronUp, Box, ArrowRight, ArrowUp } from 'lucide-react';
import { COLORS } from '@/lib/colors';

interface OriResult {
  label: string;
  byLen: number;
  byWid: number;
  byHei: number;
  total: number;
  boxAlongLen: number;
  boxAlongWid: number;
  boxAlongHei: number;
}

interface CalcResult {
  best: OriResult;
  variants: OriResult[];
}

const ORI_LABELS = [
  'Д \u00d7 Ш \u00d7 В',
  'Д \u00d7 В \u00d7 Ш',
  'Ш \u00d7 Д \u00d7 В',
  'Ш \u00d7 В \u00d7 Д',
  'В \u00d7 Д \u00d7 Ш',
  'В \u00d7 Ш \u00d7 Д',
];

function calcOrientations(
  boxL: number, boxW: number, boxH: number,
  cellL: number, cellW: number, effH: number,
  canRotate: boolean,
): CalcResult {
  const perms: [number, number, number][] = canRotate
    ? [
        [boxL, boxW, boxH],
        [boxL, boxH, boxW],
        [boxW, boxL, boxH],
        [boxW, boxH, boxL],
        [boxH, boxL, boxW],
        [boxH, boxW, boxL],
      ]
    : [
        [boxL, boxW, boxH],
      ];

  const variants: OriResult[] = perms.map(([bl, bw, bh], i) => {
    const byLen = Math.floor(cellL / bl);
    const byWid = Math.floor(cellW / bw);
    const byHei = Math.floor(effH / bh);
    return { label: ORI_LABELS[i], byLen, byWid, byHei, total: byLen * byWid * byHei, boxAlongLen: bl, boxAlongWid: bw, boxAlongHei: bh };
  });

  const best = variants.reduce((a, b) => (b.total > a.total ? b : a), variants[0]);
  return { best, variants };
}

export default function ToolsPage() {
  const [inputs, setInputs] = useState({
    taraLen: '', taraWid: '', taraHei: '',
    cellLen: '', cellWid: '', cellHei: '',
    kr3: '', heightPercent: '10',
  });

  const [canRotate, setCanRotate] = useState(false);
  const [showAllOri, setShowAllOri] = useState(false);

  const result = useMemo(() => {
    const tL = parseFloat(inputs.taraLen) || 0;
    const tW = parseFloat(inputs.taraWid) || 0;
    const tH = parseFloat(inputs.taraHei) || 0;
    const cL = parseFloat(inputs.cellLen) || 0;
    const cW = parseFloat(inputs.cellWid) || 0;
    const cH = parseFloat(inputs.cellHei) || 0;
    const kr3 = parseFloat(inputs.kr3) || 1;
    const hPct = parseFloat(inputs.heightPercent) || 0;

    if (!tL || !tW || !tH || !cL || !cW || !cH) {
      return null;
    }

    const effectiveHeight = cH * (1 - hPct / 100);
    const taraCalc = calcOrientations(tL, tW, tH, cL, cW, effectiveHeight, canRotate);

    return { taraCalc, kr3, effectiveHeight };
  }, [inputs, canRotate]);

  const updateInput = (key: string, value: string) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  const inputField = (key: string, label: string) => (
    <div>
      <label className="block text-xs mb-1" style={{ color: COLORS.text }}>{label}</label>
      <input
        type="number"
        min="0"
        step="any"
        value={(inputs as Record<string, string>)[key]}
        onChange={e => updateInput(key, e.target.value)}
        className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-200"
        style={{ borderColor: '#dee2e6' }}
      />
    </div>
  );

  const renderOriTable = (variants: OriResult[], bestTotal: number) => (
    <table className="w-full text-xs mt-2">
      <thead>
        <tr style={{ color: COLORS.text }}>
          <th className="text-left py-1 font-medium">Ориентация тары</th>
          <th className="text-center py-1 font-medium">По длине</th>
          <th className="text-center py-1 font-medium">По ширине</th>
          <th className="text-center py-1 font-medium">По высоте</th>
          <th className="text-center py-1 font-medium">Тар в ячейке</th>
        </tr>
      </thead>
      <tbody>
        {variants.map((v) => {
          const isBest = v.total === bestTotal && v.total > 0;
          return (
            <tr key={v.label} className={isBest ? 'font-bold' : ''} style={{ color: isBest ? COLORS.primary : COLORS.heading }}>
              <td className="py-1">
                {isBest && <span className="mr-1">&#9733;</span>}
                {v.label}
              </td>
              <td className="text-center py-1">{v.byLen}</td>
              <td className="text-center py-1">{v.byWid}</td>
              <td className="text-center py-1">{v.byHei}</td>
              <td className="text-center py-1">{v.total}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Инструменты</h2>

      <div className="flex gap-4 items-start" style={{ flexWrap: 'wrap' }}>
        {/* ====== ЛЕВАЯ КОЛОНКА: Калькулятор ====== */}
        <div className="bg-white rounded-xl shadow p-6" style={{ flex: '1 1 380px', minWidth: 340 }}>
          <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.heading }}>
            <Calculator className="w-5 h-5" style={{ color: COLORS.primary }} /> Калькулятор вместимости ячейки
          </h3>

          {/* Тара и Ячейка */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-2 flex items-center gap-1" style={{ color: COLORS.primary }}>
                <Package className="w-4 h-4" /> Тара
              </h4>
              <div className="space-y-2">
                {inputField('taraLen', 'Длина тары')}
                {inputField('taraWid', 'Ширина тары')}
                {inputField('taraHei', 'Высота тары')}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Ячейка</h4>
              <div className="space-y-2">
                {inputField('cellLen', 'Длина ячейки')}
                {inputField('cellWid', 'Ширина ячейки')}
                {inputField('cellHei', 'Высота ячейки')}
              </div>
            </div>
          </div>

          {/* КР3, % вычета, галочка поворота */}
          <div className="grid grid-cols-2 gap-4 mt-4">
            {inputField('kr3', 'КР3 (шт. в таре)')}
            {inputField('heightPercent', '% вычитаемый из высоты')}
          </div>

          <div className="mt-4 flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
            <input
              type="checkbox"
              id="canRotate"
              checked={canRotate}
              onChange={e => {
                setCanRotate(e.target.checked);
                setShowAllOri(false);
              }}
              className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
            />
            <label htmlFor="canRotate" className="text-sm cursor-pointer select-none" style={{ color: COLORS.heading }}>
              Можно переворачивать тару
            </label>
            <span className="text-xs ml-auto" style={{ color: COLORS.text }}>
              {canRotate ? 'Перебор 6 ориентаций' : 'Фиксированная: Д \u00d7 Ш \u00d7 В'}
            </span>
          </div>

          {/* Результат */}
          {result && (
            <div className="mt-6 space-y-4">
              <div className="p-4 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium" style={{ color: COLORS.heading }}>
                    Вместимость тары в ячейку
                  </label>
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: COLORS.primary, color: '#fff' }}>
                    {result.taraCalc.best.label}
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2 mb-3 text-xs" style={{ color: COLORS.text }}>
                  <span>По длине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byLen}</strong></span>
                  <span>По ширине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byWid}</strong></span>
                  <span>По высоте: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byHei}</strong></span>
                  <span>Эфф. высота: <strong style={{ color: COLORS.heading }}>{result.effectiveHeight.toFixed(1)}</strong></span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Тар в ячейке</label>
                    <input
                      type="text"
                      value={result.taraCalc.best.total}
                      disabled
                      className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                      style={{ borderColor: '#dee2e6', color: '#856404' }}
                    />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: COLORS.text }}>
                      Итого шт. ({result.taraCalc.best.total} тар &times; {result.kr3} КР3)
                    </label>
                    <input
                      type="text"
                      value={result.taraCalc.best.total * result.kr3}
                      disabled
                      className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                      style={{ borderColor: '#dee2e6', color: COLORS.primary }}
                    />
                  </div>
                </div>

                {/* Кнопка показа всех ориентаций */}
                {canRotate && result.taraCalc.variants.length > 1 && (
                  <button
                    onClick={() => setShowAllOri(!showAllOri)}
                    className="mt-3 text-xs flex items-center gap-1 hover:underline"
                    style={{ color: COLORS.primary }}
                  >
                    {showAllOri ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    {showAllOri ? 'Скрыть все ориентации' : 'Показать все ориентации'}
                  </button>
                )}
                {showAllOri && renderOriTable(result.taraCalc.variants, result.taraCalc.best.total)}
              </div>
            </div>
          )}

          {!result && (
            <div className="mt-6 p-4 rounded-lg text-center text-sm" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
              Заполните габариты тары и ячейки для расчёта
            </div>
          )}
        </div>

        {/* ====== ПРАВАЯ КОЛОНКА: 3D Визуализация ====== */}
        <div style={{ flex: '1 1 420px', minWidth: 360 }}>
          {result && result.taraCalc.best.total > 0 ? (
            <CellVisualization3D
              cellL={parseFloat(inputs.cellLen) || 0}
              cellW={parseFloat(inputs.cellWid) || 0}
              cellH={parseFloat(inputs.cellHei) || 0}
              effectiveHeight={result.effectiveHeight}
              boxL={result.taraCalc.best.boxAlongLen}
              boxW={result.taraCalc.best.boxAlongWid}
              boxH={result.taraCalc.best.boxAlongHei}
              byLen={result.taraCalc.best.byLen}
              byWid={result.taraCalc.best.byWid}
              byHei={result.taraCalc.best.byHei}
              bestLabel={result.taraCalc.best.label}
            />
          ) : (
            <div className="bg-white rounded-xl shadow p-6 flex flex-col items-center justify-center text-center" style={{ minHeight: 320 }}>
              <Box className="w-12 h-12 mb-3" style={{ color: '#cbd5e1' }} />
              <p className="text-sm" style={{ color: COLORS.text }}>
                Заполните габариты тары и ячейки<br />для визуализации
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* =====================================================================
   3D Визуализация ячейки — изометрическая проекция (SVG)
   + 2D вид сверху (план раскладки)
   ===================================================================== */

// Изометрическая проекция: 3D → 2D экранные координаты
function isoProject(x: number, y: number, z: number): [number, number] {
  return [(x - z), (x + z) * 0.5 - y];
}

// Цвета слоёв (от нижнего к верхнему)
const LAYER_COLORS = [
  { top: '#60a5fa', left: '#3b82f6', right: '#2563eb' },   // слой 0 — синий
  { top: '#34d399', left: '#10b981', right: '#059669' },   // слой 1 — зелёный
  { top: '#fbbf24', left: '#f59e0b', right: '#d97706' },   // слой 2 — жёлтый
  { top: '#f87171', left: '#ef4444', right: '#dc2626' },   // слой 3 — красный
  { top: '#a78bfa', left: '#8b5cf6', right: '#7c3aed' },   // слой 4 — фиолетовый
  { top: '#fb923c', left: '#f97316', right: '#ea580c' },   // слой 5 — оранжевый
  { top: '#2dd4bf', left: '#14b8a6', right: '#0d9488' },   // слой 6 — бирюзовый
  { top: '#f472b6', left: '#ec4899', right: '#db2777' },   // слой 7 — розовый
];

function getLayerColor(layer: number) {
  return LAYER_COLORS[layer % LAYER_COLORS.length];
}

interface CellVisualization3DProps {
  cellL: number;
  cellW: number;
  cellH: number;
  effectiveHeight: number;
  boxL: number;
  boxW: number;
  boxH: number;
  byLen: number;
  byWid: number;
  byHei: number;
  bestLabel: string;
}

function CellVisualization3D({
  cellL, cellW, cellH, effectiveHeight,
  boxL, boxW, boxH,
  byLen, byWid, byHei, bestLabel,
}: CellVisualization3DProps) {
  const totalBoxes = byLen * byWid * byHei;
  const MAX_BOXES = 600;

  // ============ 3D Изометрическая проекция ============
  const allScreenPts: [number, number][] = [
    isoProject(0, 0, 0), isoProject(cellW, 0, 0),
    isoProject(0, cellH, 0), isoProject(cellW, cellH, 0),
    isoProject(0, 0, cellL), isoProject(cellW, 0, cellL),
    isoProject(0, cellH, cellL), isoProject(cellW, cellH, cellL),
  ];
  const rawMinX = Math.min(...allScreenPts.map(pt => pt[0]));
  const rawMaxX = Math.max(...allScreenPts.map(pt => pt[0]));
  const rawW = rawMaxX - rawMinX || 1;
  const scale3d = 300 / rawW;

  const pad3 = 50;
  const pts3 = [
    isoProject(0, 0, 0), isoProject(cellW * scale3d, 0, 0),
    isoProject(0, cellH * scale3d, 0), isoProject(cellW * scale3d, cellH * scale3d, 0),
    isoProject(0, 0, cellL * scale3d), isoProject(cellW * scale3d, 0, cellL * scale3d),
    isoProject(0, cellH * scale3d, cellL * scale3d), isoProject(cellW * scale3d, cellH * scale3d, cellL * scale3d),
  ];
  const minX3 = Math.min(...pts3.map(pt => pt[0])) - pad3;
  const maxX3 = Math.max(...pts3.map(pt => pt[0])) + pad3;
  const minY3 = Math.min(...pts3.map(pt => pt[1])) - pad3;
  const maxY3 = Math.max(...pts3.map(pt => pt[1])) + pad3;
  const svg3W = maxX3 - minX3;
  const svg3H = maxY3 - minY3;
  const off3X = -minX3;
  const off3Y = -minY3;

  const s = scale3d;
  const sW = cellW * s;
  const sL = cellL * s;
  const sH = cellH * s;
  const sEffH = effectiveHeight * s;

  // Зазор между ящиками (в масштабе) — 2px экрана
  const gap = 2 / s;
  const sbW = boxW * s - (byWid > 1 ? gap * s : 0);
  const sbL = boxL * s - (byLen > 1 ? gap * s : 0);
  const sbH = boxH * s - (byHei > 1 ? gap * s : 0);

  const p = (x: number, y: number, z: number): [number, number] => {
    const [sx, sy] = isoProject(x, y, z);
    return [sx + off3X, sy + off3Y];
  };

  const poly = (points: [number, number][]) => points.map(pt => `${pt[0]},${pt[1]}`).join(' ');

  // Грани ячейки
  const floorPts = [p(0, 0, 0), p(sW, 0, 0), p(sW, 0, sL), p(0, 0, sL)];
  const backWallPts = [p(0, 0, sL), p(sW, 0, sL), p(sW, sH, sL), p(0, sH, sL)];
  const leftWallPts = [p(0, 0, 0), p(0, 0, sL), p(0, sH, sL), p(0, sH, 0)];

  // Линия эффективной высоты
  const effLineBack = [p(0, sEffH, sL), p(sW, sEffH, sL)];
  const effLineLeft = [p(0, sEffH, 0), p(0, sEffH, sL)];

  // Рёбра ячейки (каркас)
  const cellEdges: [number, number][][] = [
    [p(0, 0, 0), p(sW, 0, 0)], [p(sW, 0, 0), p(sW, 0, sL)],
    [p(sW, 0, sL), p(0, 0, sL)], [p(0, 0, sL), p(0, 0, 0)],
    [p(0, 0, 0), p(0, sH, 0)], [p(sW, 0, 0), p(sW, sH, 0)],
    [p(sW, 0, sL), p(sW, sH, sL)], [p(0, 0, sL), p(0, sH, sL)],
    [p(0, sH, 0), p(sW, sH, 0)], [p(sW, sH, 0), p(sW, sH, sL)],
    [p(sW, sH, sL), p(0, sH, sL)], [p(0, sH, sL), p(0, sH, 0)],
  ];

  // Сетка на полу ячейки (деления по коробкам)
  const floorGridLines: [number, number][][] = [];
  for (let i = 1; i < byWid; i++) {
    const x = i * boxW * s;
    floorGridLines.push([p(x, 0, 0), p(x, 0, sL)]);
  }
  for (let j = 1; j < byLen; j++) {
    const z = j * boxL * s;
    floorGridLines.push([p(0, 0, z), p(sW, 0, z)]);
  }

  // Ящики
  interface BoxItem { col: number; row: number; layer: number; x: number; y: number; z: number; }
  const boxes: BoxItem[] = [];
  if (totalBoxes <= MAX_BOXES) {
    for (let row = byLen - 1; row >= 0; row--) {
      for (let layer = 0; layer < byHei; layer++) {
        for (let col = byWid - 1; col >= 0; col--) {
          boxes.push({
            col, row, layer,
            x: col * boxW * s + (byWid > 1 ? gap * s * col / (byWid - 1) * 0.5 : 0),
            y: layer * boxH * s + (byHei > 1 ? gap * s * layer / (byHei - 1) * 0.5 : 0),
            z: row * boxL * s + (byLen > 1 ? gap * s * row / (byLen - 1) * 0.5 : 0),
          });
        }
      }
    }
  }

  // Подписи размеров
  const dimOff = 14;
  const dimLMid = p(-dimOff, 0, sL / 2);
  const dimWMid = p(sW / 2, 0, -dimOff);
  const dimHMid = p(-dimOff, sH / 2, 0);

  // Направления (стрелки) — подписи осей
  const arrowLen = 30;
  const arrL = { start: p(-8, 0, 0), end: p(-8, 0, arrowLen), label: p(-16, -2, arrowLen / 2) };
  const arrW = { start: p(0, 0, -8), end: p(arrowLen, 0, -8), label: p(arrowLen / 2, -6, -16) };
  const arrH = { start: p(-8, 0, 0), end: p(-8, arrowLen, 0), label: p(-22, arrowLen / 2, 0) };

  // ============ 2D Вид сверху (план) ============
  const planW = 200;
  const planH = 200;
  const planPad = 25;
  const planAreaW = planW - planPad * 2;
  const planAreaH = planH - planPad * 2;
  const planScaleW = planAreaW / cellW;
  const planScaleL = planAreaH / cellL;
  const planScale = Math.min(planScaleW, planScaleL);
  const planBoxW = boxW * planScale;
  const planBoxL = boxL * planScale;
  const planCellW = cellW * planScale;
  const planCellL = cellL * planScale;
  const planOffX = planPad + (planAreaW - planCellW) / 2;
  const planOffY = planPad + (planAreaH - planCellL) / 2;

  return (
    <div className="bg-white rounded-xl shadow p-4">
      <h3 className="font-semibold mb-2 flex items-center gap-2 text-sm" style={{ color: COLORS.heading }}>
        <Box className="w-4 h-4" style={{ color: COLORS.primary }} /> Визуализация ячейки
      </h3>
      <div className="text-xs mb-2" style={{ color: COLORS.text }}>
        <strong style={{ color: COLORS.primary }}>{bestLabel}</strong> &nbsp;|&nbsp;
        {byLen}&times;{byWid}&times;{byHei} = <strong>{totalBoxes}</strong> тар
      </div>

      {/* 3D изометрия */}
      <div style={{ width: '100%', overflowX: 'auto' }}>
        <svg width={svg3W} height={svg3H} viewBox={`0 0 ${svg3W} ${svg3H}`} style={{ display: 'block', margin: '0 auto' }}>
          <defs>
            <marker id="ah" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#64748b" />
            </marker>
            <marker id="ahr" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#ef4444" />
            </marker>
          </defs>

          {/* Стены */}
          <polygon points={poly(floorPts)} fill="#e2e8f0" stroke="#94a3b8" strokeWidth={1} opacity={0.5} />
          <polygon points={poly(backWallPts)} fill="#cbd5e1" stroke="#94a3b8" strokeWidth={1} opacity={0.25} />
          <polygon points={poly(leftWallPts)} fill="#cbd5e1" stroke="#94a3b8" strokeWidth={1} opacity={0.25} />

          {/* Сетка на полу */}
          {floorGridLines.map(([a, b], i) => (
            <line key={`g${i}`} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="#94a3b8" strokeWidth={0.5} strokeDasharray="3 3" opacity={0.5} />
          ))}

          {/* Линия эфф. высоты */}
          <line x1={effLineBack[0][0]} y1={effLineBack[0][1]} x2={effLineBack[1][0]} y2={effLineBack[1][1]} stroke="#ef4444" strokeWidth={1.2} strokeDasharray="5 3" opacity={0.7} />
          <line x1={effLineLeft[0][0]} y1={effLineLeft[0][1]} x2={effLineLeft[1][0]} y2={effLineLeft[1][1]} stroke="#ef4444" strokeWidth={1.2} strokeDasharray="5 3" opacity={0.7} />

          {/* Ящики */}
          {totalBoxes <= MAX_BOXES && boxes.map((box, idx) => {
            const lc = getLayerColor(box.layer);
            const { x, y, z } = box;
            const topPts = [p(x, y + sbH, z), p(x + sbW, y + sbH, z), p(x + sbW, y + sbH, z + sbL), p(x, y + sbH, z + sbL)];
            const leftPts = [p(x, y, z + sbL), p(x, y + sbH, z + sbL), p(x, y + sbH, z), p(x, y, z)];
            const rightPts = [p(x + sbW, y, z), p(x + sbW, y + sbH, z), p(x + sbW, y + sbH, z + sbL), p(x + sbW, y, z + sbL)];

            return (
              <g key={idx}>
                <polygon points={poly(leftPts)} fill={lc.left} stroke="#1e293b" strokeWidth={0.6} opacity={0.85} />
                <polygon points={poly(rightPts)} fill={lc.right} stroke="#1e293b" strokeWidth={0.6} opacity={0.85} />
                <polygon points={poly(topPts)} fill={lc.top} stroke="#1e293b" strokeWidth={0.6} opacity={0.92} />
              </g>
            );
          })}

          {totalBoxes > MAX_BOXES && (
            <text x={svg3W / 2} y={svg3H / 2} textAnchor="middle" fontSize={13} fill={COLORS.text}>
              Слишком много ящиков ({totalBoxes})
            </text>
          )}

          {/* Каркас */}
          {cellEdges.map(([a, b], i) => (
            <line key={`e${i}`} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="#475569" strokeWidth={1.5} strokeLinecap="round" />
          ))}

          {/* Направления — стрелки осей */}
          <line x1={arrL.start[0]} y1={arrL.start[1]} x2={arrL.end[0]} y2={arrL.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrL.label[0]} y={arrL.label[1]} textAnchor="middle" fontSize={9} fill="#64748b" fontWeight={700}>Д</text>

          <line x1={arrW.start[0]} y1={arrW.start[1]} x2={arrW.end[0]} y2={arrW.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrW.label[0]} y={arrW.label[1]} textAnchor="middle" fontSize={9} fill="#64748b" fontWeight={700}>Ш</text>

          <line x1={arrH.start[0]} y1={arrH.start[1]} x2={arrH.end[0]} y2={arrH.end[1]} stroke="#64748b" strokeWidth={1.2} markerEnd="url(#ah)" />
          <text x={arrH.label[0]} y={arrH.label[1]} textAnchor="end" fontSize={9} fill="#64748b" fontWeight={700}>В</text>

          {/* Подписи размеров */}
          <text x={dimLMid[0]} y={dimLMid[1] + 4} textAnchor="middle" fontSize={10} fill="#475569" fontWeight={600}>{cellL}</text>
          <text x={dimWMid[0]} y={dimWMid[1] + 4} textAnchor="middle" fontSize={10} fill="#475569" fontWeight={600}>{cellW}</text>
          <text x={dimHMid[0] - 4} y={dimHMid[1]} textAnchor="end" fontSize={10} fill="#475569" fontWeight={600}>{cellH}</text>

          {/* Счётчики вдоль осей */}
          {byWid > 1 && (
            <text x={p(sW / 2, sH + 8, sL + 8)[0]} y={p(sW / 2, sH + 8, sL + 8)[1]} textAnchor="middle" fontSize={9} fill={COLORS.primary} fontWeight={700}>
              {byWid} по Ш
            </text>
          )}
          {byLen > 1 && (
            <text x={p(sW + 10, sH + 8, sL / 2)[0]} y={p(sW + 10, sH + 8, sL / 2)[1]} textAnchor="middle" fontSize={9} fill={COLORS.primary} fontWeight={700}>
              {byLen} по Д
            </text>
          )}
          {byHei > 1 && (
            <text x={p(-4, sEffH / 2, sL + 6)[0]} y={p(-4, sEffH / 2, sL + 6)[1]} textAnchor="end" fontSize={9} fill={COLORS.primary} fontWeight={700}>
              {byHei} по В
            </text>
          )}

          {/* Подпись эфф. высоты */}
          <text
            x={p(-dimOff - 4, sEffH, sL)[0]} y={p(-dimOff - 4, sEffH, sL)[1]}
            textAnchor="end" fontSize={9} fill="#ef4444" fontWeight={600}
          >
            h={effectiveHeight.toFixed(1)}
          </text>
        </svg>
      </div>

      {/* 2D План раскладки (вид сверху) */}
      <div className="mt-3 pt-3" style={{ borderTop: '1px solid #e2e8f0' }}>
        <p className="text-xs font-medium mb-1" style={{ color: COLORS.heading }}>
          План раскладки <span style={{ color: COLORS.text, fontWeight: 400 }}>(вид сверху, ярус 1)</span>
        </p>
        <svg width={planW} height={planH} viewBox={`0 0 ${planW} ${planH}`} style={{ display: 'block', margin: '0 auto' }}>
          {/* Контур ячейки */}
          <rect
            x={planOffX} y={planOffY}
            width={planCellW} height={planCellL}
            fill="#f1f5f9" stroke="#475569" strokeWidth={1.5} rx={2}
          />

          {/* Ящики на полу */}
          {Array.from({ length: byLen }, (_, row) =>
            Array.from({ length: byWid }, (_, col) => {
              const lc = getLayerColor(0);
              const bx = planOffX + col * planBoxW + (byWid > 1 ? 0.5 : 0);
              const by = planOffY + row * planBoxL + (byLen > 1 ? 0.5 : 0);
              const bw = planBoxW - (byWid > 1 ? 1 : 0);
              const bl = planBoxL - (byLen > 1 ? 1 : 0);
              return (
                <rect
                  key={`${row}-${col}`}
                  x={bx} y={by} width={bw} height={bl}
                  fill={lc.top} stroke="#1e293b" strokeWidth={0.8} rx={1.5} opacity={0.85}
                />
              );
            })
          )}

          {/* Подписи количества по осям */}
          {byWid > 1 && (
            <text x={planOffX + planCellW / 2} y={planOffY - 6} textAnchor="middle" fontSize={9} fill={COLORS.primary} fontWeight={700}>
              {byWid} по ширине
            </text>
          )}
          {byLen > 1 && (
            <text x={planOffX - 4} y={planOffY + planCellL / 2} textAnchor="end" fontSize={9} fill={COLORS.primary} fontWeight={700}>
              {byLen} по длине
            </text>
          )}

          {/* Стрелки-направления */}
          {byWid > 1 && (
            <line x1={planOffX} y1={planOffY - 12} x2={planOffX + planCellW} y2={planOffY - 12} stroke="#94a3b8" strokeWidth={0.8} markerEnd="url(#ah)" />
          )}
          {byLen > 1 && (
            <line x1={planOffX - 12} y1={planOffY} x2={planOffX - 12} y2={planOffY + planCellL} stroke="#94a3b8" strokeWidth={0.8} markerEnd="url(#ah)" />
          )}

          {/* Свободное пространство — штриховка */}
          {cellW - byWid * boxW > 0.1 && (
            <rect
              x={planOffX + byWid * planBoxW} y={planOffY}
              width={(cellW - byWid * boxW) * planScale} height={planCellL}
              fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6}
            />
          )}
          {cellL - byLen * boxL > 0.1 && (
            <rect
              x={planOffX} y={planOffY + byLen * planBoxL}
              width={planCellW} height={(cellL - byLen * boxL) * planScale}
              fill="none" stroke="#ef4444" strokeWidth={0.8} strokeDasharray="3 2" opacity={0.6}
            />
          )}
        </svg>
      </div>

      {/* Легенда */}
      {byHei > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {Array.from({ length: Math.min(byHei, 8) }, (_, i) => {
            const lc = getLayerColor(i);
            const countInLayer = byLen * byWid;
            return (
              <div key={i} className="flex items-center gap-1 text-xs" style={{ color: COLORS.heading }}>
                <span className="inline-block w-3 h-3 rounded-sm border" style={{ backgroundColor: lc.top, borderColor: lc.right }} />
                {byHei > 1 ? `Ярус ${i + 1}` : 'Тара'} ({countInLayer})
              </div>
            );
          })}
        </div>
      )}

      {/* Свободное пространство */}
      {byLen > 0 && byWid > 0 && byHei > 0 && (
        <div className="mt-2 text-xs p-2 rounded-lg" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
          <span style={{ color: COLORS.heading, fontWeight: 600 }}>Зазоры:</span>{' '}
          Д: {(cellL - byLen * boxL).toFixed(1)} &nbsp;|&nbsp;
          Ш: {(cellW - byWid * boxW).toFixed(1)} &nbsp;|&nbsp;
          В: {(effectiveHeight - byHei * boxH).toFixed(1)}
          <span className="ml-1" style={{ color: '#ef4444' }}>(эфф. h={effectiveHeight.toFixed(1)})</span>
        </div>
      )}
    </div>
  );
}

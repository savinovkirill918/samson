import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export interface GenerationPhase {
  name: string;
  prompt: string;
}

export function buildReferatPhases(topic: string, pages: number): GenerationPhase[] {
  const charsPerPage = 1800;
  const totalChars = pages * charsPerPage;
  const chaptersCount = Math.max(2, Math.min(pages, 10));

  const introChars = Math.round(totalChars * 0.1);
  const chapterChars = Math.round((totalChars * 0.75) / chaptersCount);
  const conclusionChars = Math.round(totalChars * 0.15);

  return [
    {
      name: 'План',
      prompt: `Ты — академический писатель. Составь подробный план реферата на тему "${topic}".
Реферат должен содержать ${chaptersCount} глав.
Выведи план в формате Markdown с заголовками H2 для каждой главы и кратким описанием содержания каждой главы (1-2 предложения).
Не пиши сам текст реферата, только план.
Формат:
## Глава 1. Название главы
Описание содержания главы.`,
    },
    {
      name: 'Введение',
      prompt: `Ты — академический писатель. Напиши ВВЕДЕНИЕ для реферата на тему "${topic}".
Объём введения — примерно ${introChars} символов (около ${Math.round(introChars / 1800)} страниц).
Во введении должно быть: актуальность темы, цель работы, задачи, объект и предмет исследования, методы исследования.
Используй Markdown-разметку: заголовок H1 "Введение", параграфы текста.
Пиши академическим языком, без воды, с конкретными формулировками.`,
    },
    ...Array.from({ length: chaptersCount }, (_, i) => ({
      name: `Глава ${i + 1}`,
      prompt: `Ты — академический писатель. Напиши ГЛАВУ ${i + 1} для реферата на тему "${topic}".
Объём главы — примерно ${chapterChars} символов (около ${Math.round(chapterChars / 1800)} страниц).
Это глава ${i + 1} из ${chaptersCount}. Пиши подробно, с примерами и аргументами.
Используй Markdown-разметку: заголовок H2 для названия главы, H3 для подглав, нумерованные и маркированные списки где уместно.
Пиши академическим языком, без воды.`,
    })),
    {
      name: 'Заключение',
      prompt: `Ты — академический писатель. Напиши ЗАКЛЮЧЕНИЕ для реферата на тему "${topic}".
Объём заключения — примерно ${conclusionChars} символов (около ${Math.round(conclusionChars / 1800)} страниц).
В заключении подведи итоги по каждой главе, сформулируй основные выводы, укажи возможные перспективы исследования.
Используй Markdown-разметку: заголовок H1 "Заключение", параграфы текста.
Пиши академическим языком.`,
    },
  ];
}

/**
 * Stream a single phase from the LLM.
 * The SDK returns a ReadableStream<Uint8Array> containing SSE events.
 * We parse them manually to extract text content.
 */
export async function* streamPhase(
  systemPrompt: string,
  userPrompt: string
): AsyncGenerator<string, void, unknown> {
  const zai = await getZAI();

  const stream = await zai.chat.completions.create({
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    stream: true,
    temperature: 0.7,
    max_tokens: 8192,
  });

  // The SDK returns a ReadableStream<Uint8Array> with SSE format
  const reader = (stream as ReadableStream<Uint8Array>).getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed === 'data: [DONE]') continue;
        if (trimmed.startsWith('data: ')) {
          try {
            const parsed = JSON.parse(trimmed.slice(6));
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              yield content;
            }
          } catch {
            // Skip unparseable lines
          }
        }
      }
    }

    // Process any remaining buffer
    if (buffer.trim()) {
      const trimmed = buffer.trim();
      if (trimmed.startsWith('data: ') && trimmed !== 'data: [DONE]') {
        try {
          const parsed = JSON.parse(trimmed.slice(6));
          const content = parsed.choices?.[0]?.delta?.content;
          if (content) {
            yield content;
          }
        } catch {
          // Skip
        }
      }
    }
  } finally {
    try { reader.releaseLock(); } catch { /* ignore */ }
  }
}

export async function generateFullReferat(
  topic: string,
  pages: number,
  onChunk: (chunk: string) => Promise<void>,
  onPhaseStart: (phaseName: string, phaseIndex: number, totalPhases: number) => Promise<void>
): Promise<string> {
  const phases = buildReferatPhases(topic, pages);
  let fullText = '';

  const systemPrompt = 'Ты — профессиональный академический писатель. Пиши ТОЛЬКО на русском языке. Не используй английские слова или термины, кроме общепринятых аббревиатур. Используй научный стиль изложения. Строго соблюдай требования к объёму и структуре текста. Формат вывода — Markdown с заголовками и списками. Все термины и понятия объясняй по-русски.';

  for (let i = 0; i < phases.length; i++) {
    const phase = phases[i];
    await onPhaseStart(phase.name, i, phases.length);

    try {
      for await (const chunk of streamPhase(systemPrompt, phase.prompt)) {
        fullText += chunk;
        await onChunk(chunk);
      }
    } catch (err) {
      console.error(`Error in phase "${phase.name}":`, err);
      // Continue with next phase instead of failing completely
      if (i < phases.length - 1) {
        const errorMsg = '\n\n*Генерация раздела была прервана.*\n\n';
        fullText += errorMsg;
        await onChunk(errorMsg);
      }
    }

    // Add separator between phases
    if (i < phases.length - 1) {
      fullText += '\n\n';
      await onChunk('\n\n');
    }
  }

  return fullText;
}

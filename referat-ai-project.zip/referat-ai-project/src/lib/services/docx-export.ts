import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  TabStopPosition,
  TabStopType,
  PageBreak,
  TableOfContents,
  StyleLevel,
  BorderStyle,
  convertInchesToTwip,
  LevelFormat,
} from 'docx';
import MarkdownIt from 'markdown-it';

const md = MarkdownIt();

interface HeadingItem {
  text: string;
  level: number;
  index: number;
}

function parseMarkdownToDocxElements(markdown: string): { elements: Paragraph[]; headings: HeadingItem[] } {
  const tokens = md.parse(markdown, {});
  const elements: Paragraph[] = [];
  const headings: HeadingItem[] = [];
  let headingIndex = 0;

  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];

    if (token.type === 'heading_open') {
      const level = parseInt(token.tag.replace('h', ''));
      i++;
      const contentToken = tokens[i];
      if (contentToken && contentToken.type === 'inline') {
        const text = contentToken.content;
        headings.push({ text, level, index: headingIndex++ });

        const headingLevelMap: Record<number, typeof HeadingLevel> = {
          1: HeadingLevel.HEADING_1,
          2: HeadingLevel.HEADING_2,
          3: HeadingLevel.HEADING_3,
        };

        elements.push(
          new Paragraph({
            text,
            heading: headingLevelMap[level] || HeadingLevel.HEADING_2,
            spacing: { before: 240, after: 120 },
          })
        );
      }
      i++;
      i++; // skip heading_close
      continue;
    }

    if (token.type === 'paragraph_open') {
      i++;
      const contentToken = tokens[i];
      if (contentToken && contentToken.type === 'inline') {
        const runs = parseInlineTokens(contentToken.children || []);
        elements.push(
          new Paragraph({
            children: runs,
            spacing: { after: 120, line: 360 }, // 1.5 line spacing = 360 twips
            alignment: AlignmentType.JUSTIFIED,
          })
        );
      } else if (contentToken) {
        elements.push(
          new Paragraph({
            spacing: { after: 120, line: 360 },
            alignment: AlignmentType.JUSTIFIED,
          })
        );
      }
      i++;
      i++; // skip paragraph_close
      continue;
    }

    if (token.type === 'bullet_list_open' || token.type === 'ordered_list_open') {
      const isOrdered = token.type === 'ordered_list_open';
      i++;
      let itemIndex = 1;
      while (i < tokens.length && tokens[i].type !== (isOrdered ? 'ordered_list_close' : 'bullet_list_close')) {
        if (tokens[i].type === 'list_item_open') {
          i++;
          if (tokens[i] && tokens[i].type === 'paragraph_open') {
            i++;
            if (tokens[i] && tokens[i].type === 'inline') {
              const runs = parseInlineTokens(tokens[i].children || []);
              elements.push(
                new Paragraph({
                  children: [
                    new TextRun({
                      text: isOrdered ? `${itemIndex}. ` : '• ',
                      font: 'Times New Roman',
                      size: 28, // 14pt
                    }),
                    ...runs,
                  ],
                  spacing: { after: 60, line: 360 },
                  indent: { left: convertInchesToTwip(0.5) },
                })
              );
              itemIndex++;
            }
            i++; // inline
            i++; // paragraph_close
          }
          i++; // list_item_close
        } else {
          i++;
        }
      }
      i++; // list_close
      continue;
    }

    i++;
  }

  return { elements, headings };
}

function parseInlineTokens(children: MarkdownIt.Token[]): TextRun[] {
  const runs: TextRun[] = [];
  for (const child of children) {
    if (child.type === 'text' || child.type === 'text_special') {
      runs.push(
        new TextRun({
          text: child.content,
          font: 'Times New Roman',
          size: 28, // 14pt = 28 half-points
        })
      );
    } else if (child.type === 'strong_open' || child.type === 'strong_close') {
      // handled via nesting below - simplified approach
    } else if (child.type === 'em_open' || child.type === 'em_close') {
      // handled via nesting below
    } else if (child.type === 'softbreak') {
      runs.push(new TextRun({ break: 1 }));
    } else if (child.type === 'code_inline') {
      runs.push(
        new TextRun({
          text: child.content,
          font: 'Courier New',
          size: 24,
        })
      );
    }
  }
  if (runs.length === 0) {
    runs.push(new TextRun({ text: '', font: 'Times New Roman', size: 28 }));
  }
  return runs;
}

function createTitlePage(topic: string): Paragraph[] {
  const emptyLine = () =>
    new Paragraph({
      spacing: { after: 120, line: 360 },
      children: [new TextRun({ text: '', font: 'Times New Roman', size: 28 })],
    });

  return [
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 240, line: 360 },
      children: [
        new TextRun({
          text: 'РЕФЕРАТ',
          font: 'Times New Roman',
          size: 32, // 16pt
          bold: true,
        }),
      ],
    }),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 240, line: 360 },
      children: [
        new TextRun({
          text: `Тема: ${topic}`,
          font: 'Times New Roman',
          size: 28,
          bold: true,
        }),
      ],
    }),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    emptyLine(),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 120, line: 360 },
      children: [
        new TextRun({
          text: `Дата: ${new Date().toLocaleDateString('ru-RU', { year: 'numeric', month: 'long', day: 'numeric' })}`,
          font: 'Times New Roman',
          size: 28,
        }),
      ],
    }),
    new Paragraph({
      children: [new PageBreak()],
    }),
  ];
}

export async function generateDocx(topic: string, markdown: string): Promise<Buffer> {
  const { elements, headings } = parseMarkdownToDocxElements(markdown);

  const tocEntries = headings
    .filter((h) => h.level <= 2)
    .map((h) => ({
      text: h.text,
      level: h.level === 1 ? 1 : 2,
    }));

  const titlePage = createTitlePage(topic);

  const tocSection: Paragraph[] = [
    new Paragraph({
      text: 'ОГЛАВЛЕНИЕ',
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      spacing: { after: 240 },
    }),
    ...tocEntries.map(
      (entry) =>
        new Paragraph({
          children: [
            new TextRun({
              text: entry.text,
              font: 'Times New Roman',
              size: 28,
            }),
          ],
          spacing: { after: 80, line: 360 },
          indent: { left: convertInchesToTwip(entry.level === 2 ? 0.5 : 0) },
        })
    ),
    new Paragraph({
      children: [new PageBreak()],
    }),
  ];

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: 'Times New Roman',
            size: 28, // 14pt
          },
          paragraph: {
            spacing: { line: 360 }, // 1.5 line spacing
          },
        },
        heading1: {
          run: {
            font: 'Times New Roman',
            size: 32, // 16pt
            bold: true,
          },
          paragraph: {
            spacing: { before: 240, after: 120, line: 360 },
          },
        },
        heading2: {
          run: {
            font: 'Times New Roman',
            size: 30, // 15pt
            bold: true,
          },
          paragraph: {
            spacing: { before: 200, after: 100, line: 360 },
          },
        },
        heading3: {
          run: {
            font: 'Times New Roman',
            size: 28, // 14pt
            bold: true,
          },
          paragraph: {
            spacing: { before: 160, after: 80, line: 360 },
          },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(2 / 2.54), // 2cm
              bottom: convertInchesToTwip(2 / 2.54), // 2cm
              left: convertInchesToTwip(3 / 2.54), // 3cm
              right: convertInchesToTwip(1.5 / 2.54), // 1.5cm
            },
          },
        },
        children: [...titlePage, ...tocSection, ...elements],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return Buffer.from(buffer);
}

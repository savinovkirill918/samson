import { PDFDocument, rgb } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import MarkdownIt from 'markdown-it';
import fs from 'fs';
import path from 'path';

const md = MarkdownIt();

// Convert cm to PDF points (1cm ≈ 28.35pt)
const cmToPt = (cm: number) => cm * 28.35;

const PAGE_MARGINS = {
  top: cmToPt(2),
  bottom: cmToPt(2),
  left: cmToPt(3),
  right: cmToPt(1.5),
};

const FONT_SIZE = 14;
const HEADING_SIZES: Record<number, number> = {
  1: 18,
  2: 16,
  3: 14,
};
const LINE_HEIGHT = 1.5;

interface HeadingItem {
  text: string;
  level: number;
}

interface Block {
  type: 'heading' | 'paragraph' | 'listItem';
  text: string;
  level?: number;
  ordered?: boolean;
}

function parseMarkdown(markdown: string): { blocks: Block[]; headings: HeadingItem[] } {
  const tokens = md.parse(markdown, {});
  const blocks: Block[] = [];
  const headings: HeadingItem[] = [];

  let i = 0;
  while (i < tokens.length) {
    const token = tokens[i];

    if (token.type === 'heading_open') {
      const level = parseInt(token.tag.replace('h', ''));
      i++;
      if (tokens[i] && tokens[i].type === 'inline') {
        const text = tokens[i].content;
        headings.push({ text, level });
        blocks.push({ type: 'heading', level, text });
      }
      i += 2;
      continue;
    }

    if (token.type === 'paragraph_open') {
      i++;
      if (tokens[i] && tokens[i].type === 'inline') {
        blocks.push({ type: 'paragraph', text: tokens[i].content });
      }
      i += 2;
      continue;
    }

    if (token.type === 'bullet_list_open' || token.type === 'ordered_list_open') {
      const isOrdered = token.type === 'ordered_list_open';
      i++;
      let idx = 1;
      while (i < tokens.length && tokens[i].type !== (isOrdered ? 'ordered_list_close' : 'bullet_list_close')) {
        if (tokens[i].type === 'list_item_open') {
          i++;
          if (tokens[i] && tokens[i].type === 'paragraph_open') {
            i++;
            if (tokens[i] && tokens[i].type === 'inline') {
              blocks.push({
                type: 'listItem',
                text: isOrdered ? `${idx}. ${tokens[i].content}` : `\u2022 ${tokens[i].content}`,
                ordered: isOrdered,
              });
              idx++;
            }
            i += 2;
          }
          i++;
        } else {
          i++;
        }
      }
      i++;
      continue;
    }

    i++;
  }

  return { blocks, headings };
}

function wrapText(text: string, font: import('pdf-lib').PDFFont, maxWidth: number, fontSize: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let currentLine = '';

  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const testWidth = font.widthOfTextAtSize(testLine, fontSize);

    if (testWidth > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }

  if (currentLine) {
    lines.push(currentLine);
  }

  return lines.length > 0 ? lines : [''];
}

function getFontPath(name: string): string {
  const possiblePaths = [
    path.join(process.cwd(), 'src', 'lib', 'services', 'fonts', name),
    path.join(process.cwd(), 'fonts', name),
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }

  throw new Error(`Font file not found: ${name}`);
}

export async function generatePdf(topic: string, markdown: string): Promise<Buffer> {
  const { blocks, headings } = parseMarkdown(markdown);

  const pdfDoc = await PDFDocument.create();
  pdfDoc.registerFontkit(fontkit);

  // Embed Liberation Sans fonts (supports Cyrillic)
  const regularFontBytes = fs.readFileSync(getFontPath('LiberationSans-Regular.ttf'));
  const boldFontBytes = fs.readFileSync(getFontPath('LiberationSans-Bold.ttf'));

  const fontRegular = await pdfDoc.embedFont(regularFontBytes);
  const fontBold = await pdfDoc.embedFont(boldFontBytes);

  const pageWidth = 595.28 - PAGE_MARGINS.left - PAGE_MARGINS.right; // A4 width
  const pageHeight = 841.89; // A4 height
  const lineHeightFn = (size: number) => size * LINE_HEIGHT;

  let currentPage = pdfDoc.addPage([595.28, 841.89]);
  let y = pageHeight - PAGE_MARGINS.top;

  const ensureSpace = (needed: number) => {
    if (y - needed < PAGE_MARGINS.bottom) {
      currentPage = pdfDoc.addPage([595.28, 841.89]);
      y = pageHeight - PAGE_MARGINS.top;
    }
  };

  const drawText = (text: string, x: number, size: number, font: import('pdf-lib').PDFFont, align: 'left' | 'center' = 'left') => {
    const availableWidth = pageWidth - (x - PAGE_MARGINS.left);
    const lines = wrapText(text, font, availableWidth, size);

    for (const line of lines) {
      ensureSpace(lineHeightFn(size));

      let textX = x;
      if (align === 'center') {
        const textWidth = font.widthOfTextAtSize(line, size);
        textX = PAGE_MARGINS.left + (pageWidth - textWidth) / 2;
      }

      currentPage.drawText(line, {
        x: textX,
        y,
        size,
        font,
        color: rgb(0, 0, 0),
      });

      y -= lineHeightFn(size);
    }
  };

  // ===== TITLE PAGE =====
  y = pageHeight / 2 + 100;

  drawText('РЕФЕРАТ', PAGE_MARGINS.left, 24, fontBold, 'center');
  y -= lineHeightFn(16);
  drawText(`Тема: ${topic}`, PAGE_MARGINS.left, FONT_SIZE, fontBold, 'center');

  // Date
  y = pageHeight / 2 - 80;
  const dateStr = new Date().toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  drawText(dateStr, PAGE_MARGINS.left, FONT_SIZE, fontRegular, 'center');

  // ===== TABLE OF CONTENTS =====
  currentPage = pdfDoc.addPage([595.28, 841.89]);
  y = pageHeight - PAGE_MARGINS.top;

  drawText('ОГЛАВЛЕНИЕ', PAGE_MARGINS.left, 18, fontBold, 'center');
  y -= lineHeightFn(18);

  for (const heading of headings.filter((h) => h.level <= 2)) {
    const indent = heading.level === 2 ? 20 : 0;
    drawText(heading.text, PAGE_MARGINS.left + indent, FONT_SIZE, fontRegular);
    y -= 4;
  }

  // ===== CONTENT =====
  currentPage = pdfDoc.addPage([595.28, 841.89]);
  y = pageHeight - PAGE_MARGINS.top;

  for (const block of blocks) {
    if (block.type === 'heading' && block.level) {
      const size = HEADING_SIZES[block.level] || FONT_SIZE;
      y -= lineHeightFn(size) * 0.5;
      drawText(block.text, PAGE_MARGINS.left, size, fontBold);
      y -= lineHeightFn(size) * 0.3;
    } else if (block.type === 'paragraph') {
      drawText(block.text, PAGE_MARGINS.left, FONT_SIZE, fontRegular);
      y -= lineHeightFn(FONT_SIZE) * 0.2;
    } else if (block.type === 'listItem') {
      drawText(block.text, PAGE_MARGINS.left + 20, FONT_SIZE, fontRegular);
      y -= lineHeightFn(FONT_SIZE) * 0.1;
    }
  }

  pdfDoc.setTitle(`Реферат: ${topic}`);
  pdfDoc.setAuthor('Реферат ИИ');

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}

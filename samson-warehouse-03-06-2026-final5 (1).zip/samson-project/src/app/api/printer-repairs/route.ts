import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/printer-repairs
export async function GET() {
  try {
    const repairs = await prisma.printerRepair.findMany({
      include: { printer: true },
      orderBy: { id: 'desc' }
    })
    return NextResponse.json(repairs)
  } catch (error) {
    console.error('Error fetching printer repairs:', error)
    return NextResponse.json({ error: 'Ошибка получения ремонтов принтеров' }, { status: 500 })
  }
}

// POST /api/printer-repairs
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.printerRepair.create({
      data: {
        printerId: body.printerId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status ?? -1,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })
    return NextResponse.json(repair, { status: 201 })
  } catch (error) {
    console.error('Error creating printer repair:', error)
    return NextResponse.json({ error: 'Ошибка создания ремонта принтера' }, { status: 500 })
  }
}

// PUT /api/printer-repairs
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const repair = await prisma.printerRepair.update({
      where: { id: body.id },
      data: {
        printerId: body.printerId,
        brokenDate: body.brokenDate,
        sentDate: body.sentDate ?? '',
        returnedDate: body.returnedDate ?? '',
        status: body.status,
        description: body.description,
        isGuilty: body.isGuilty ?? false,
        cost: body.cost ?? 0,
      }
    })
    return NextResponse.json(repair)
  } catch (error) {
    console.error('Error updating printer repair:', error)
    return NextResponse.json({ error: 'Ошибка обновления ремонта принтера' }, { status: 500 })
  }
}

// DELETE /api/printer-repairs?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.printerRepair.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting printer repair:', error)
    return NextResponse.json({ error: 'Ошибка удаления ремонта принтера' }, { status: 500 })
  }
}

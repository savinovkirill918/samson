'use client';

import React from 'react';
import { Plus, FileCheck } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PrinterRepair, Printer, PageId } from '@/lib/types';
import { formatDate, repairStatusText } from '@/lib/helpers';

interface PrinterRepairListProps {
  repairs: PrinterRepair[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEditRepair: (repair: PrinterRepair) => void;
}

export default function PrinterRepairList({ repairs, printers, onNavigate, onEditRepair }: PrinterRepairListProps) {
  const sorted = [...repairs].sort((a, b) => b.id - a.id);

  const statusBadge = (status: number) => {
    switch (status) {
      case -1: return <span className="px-2 py-0.5 rounded text-xs font-medium bg-red-200 text-red-800">Сломан не отправлен</span>;
      case 0: return <span className="px-2 py-0.5 rounded text-xs font-medium bg-yellow-200 text-yellow-800">Отправлен</span>;
      case 1: return <span className="px-2 py-0.5 rounded text-xs font-medium bg-green-200 text-green-800">Вернулся</span>;
      default: return null;
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Ремонты принтеров</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('printer-repair-sz')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#0d6efd', color: '#0d6efd' }}
          >
            <FileCheck className="w-3.5 h-3.5" /> Получить СЗ
          </button>
          <button
            onClick={() => onNavigate('printer-repair-add')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#198754', color: '#198754' }}
          >
            <Plus className="w-3.5 h-3.5" /> Добавить
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>#</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Принтер</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Дата поломки</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Отправлен</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Вернулся</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Статус</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Описание</th>
              </tr>
            </thead>
            <tbody>
              {sorted.length > 0 ? sorted.map((repair, idx) => {
                const printer = printers.find(p => p.id === repair.printerId);
                return (
                  <tr
                    key={repair.id}
                    onClick={() => onEditRepair(repair)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>{repair.id}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.heading }}>№{printer?.number} {printer?.model}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{formatDate(repair.brokenDate)}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{formatDate(repair.sentDate)}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{formatDate(repair.returnedDate)}</td>
                    <td className="px-4 py-3">{statusBadge(repair.status)}</td>
                    <td className="px-4 py-3 max-w-xs truncate" style={{ color: COLORS.text }}>{repair.description}</td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={7} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет ремонтов</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

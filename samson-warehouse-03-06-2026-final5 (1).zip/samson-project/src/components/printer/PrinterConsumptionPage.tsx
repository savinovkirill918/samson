'use client';

import React, { useState, useMemo } from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PrinterConsumption, Printer, PageId } from '@/lib/types';

interface PrinterConsumptionPageProps {
  consumption: PrinterConsumption[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEdit: (record: PrinterConsumption) => void;
  onEditPrinter?: (printer: Printer) => void;
}

/** Форматирование числа с пробелами-разделителями */
function fmtNum(n: number): string {
  return n.toLocaleString('ru-RU');
}

/** Формат месяца "2026-05" → "05" */
function fmtMonthShort(m: string): string {
  return m.split('-')[1];
}

/** Формат месяца "2026-05" → "05.2026" */
function fmtMonth(m: string): string {
  const [y, mo] = m.split('-');
  return `${mo}.${y}`;
}

/** Получить год из "2026-05" */
function getYear(m: string): string {
  return m.split('-')[0];
}

/** Цвет фона для коэффициента расхода */
function coefBgColor(coef: number): string {
  if (coef <= 0) return 'transparent';
  if (coef < 0.5) return '#d1e7dd'; // зелёный
  if (coef <= 1.0) return '#fff3cd'; // жёлтый
  return '#f8d7da'; // красный
}

/** Цвет текста для коэффициента расхода */
function coefTextColor(coef: number): string {
  if (coef <= 0) return COLORS.text;
  if (coef < 0.5) return '#0f5132';
  if (coef <= 1.0) return '#664d03';
  return '#842029';
}

/** Рассчитать расход: pages/coef */
function calcConsumption(
  currentCounter: number,
  prevCounter: number | null,
  cartridgeYield: number
): { pages: number; coef: number } | null {
  if (prevCounter === null) return null;
  const pages = currentCounter - prevCounter;
  const coef = cartridgeYield > 0 ? pages / cartridgeYield : 0;
  return { pages, coef };
}

export default function PrinterConsumptionPage({ consumption, printers, onNavigate, onEdit, onEditPrinter }: PrinterConsumptionPageProps) {
  const [filterLocation, setFilterLocation] = useState('');

  // Собираем уникальные месяцы из данных, сортируем по возрастанию
  const allMonths = useMemo(() => {
    const months = new Set<string>();
    consumption.forEach(c => months.add(c.month));
    return Array.from(months).sort();
  }, [consumption]);

  // Группируем месяцы по годам
  const yearGroups = useMemo(() => {
    const groups: { year: string; months: string[] }[] = [];
    let currentYear = '';
    for (const m of allMonths) {
      const y = getYear(m);
      if (y !== currentYear) {
        groups.push({ year: y, months: [] });
        currentYear = y;
      }
      groups[groups.length - 1].months.push(m);
    }
    return groups;
  }, [allMonths]);

  // Уникальные кабинеты для фильтра
  const locations = useMemo(() => {
    const locs = new Set<string>();
    printers.forEach(p => { if (p.location) locs.add(p.location); });
    return Array.from(locs).sort();
  }, [printers]);

  // Строим структуру данных: для каждого принтера — мапа month → totalCounter
  const printerDataMap = useMemo(() => {
    const map = new Map<number, Map<string, number>>();
    consumption.forEach(c => {
      if (!map.has(c.printerId)) map.set(c.printerId, new Map());
      map.get(c.printerId)!.set(c.month, c.totalCounter);
    });
    return map;
  }, [consumption]);

  // Фильтрованные принтеры
  const filteredPrinters = useMemo(() => {
    return printers.filter(p => {
      if (filterLocation && p.location !== filterLocation) return false;
      return true;
    });
  }, [printers, filterLocation]);

  // Получить предыдущий счётчик для принтера в данном месяце
  const getPrevCounter = (printerId: number, monthIndex: number): number | null => {
    const pMap = printerDataMap.get(printerId);
    if (!pMap) return null;
    for (let i = monthIndex - 1; i >= 0; i--) {
      const counter = pMap.get(allMonths[i]);
      if (counter !== undefined) return counter;
    }
    return null;
  };

  // Подсчёт итогов по каждому месяцу
  const monthlyTotals = useMemo(() => {
    const totals = new Map<string, { pages: number; coef: number }>();
    allMonths.forEach(month => {
      let pages = 0;
      let coef = 0;
      const monthIdx = allMonths.indexOf(month);
      filteredPrinters.forEach(printer => {
        const pMap = printerDataMap.get(printer.id);
        const counter = pMap?.get(month);
        if (counter !== undefined) {
          const prev = getPrevCounter(printer.id, monthIdx);
          if (prev !== null) {
            const yield_ = printer.cartridgeModel?.expectedYield ?? 0;
            const c = calcConsumption(counter, prev, yield_);
            if (c) {
              pages += c.pages;
              coef += c.coef;
            }
          }
        }
      });
      totals.set(month, { pages, coef });
    });
    return totals;
  }, [allMonths, filteredPrinters, printerDataMap]);

  // Подсчёт итога по каждому принтеру (сумма напечатанных за все месяцы)
  const printerTotals = useMemo(() => {
    const totals = new Map<number, number>();
    filteredPrinters.forEach(printer => {
      let total = 0;
      allMonths.forEach((month, mi) => {
        const pMap = printerDataMap.get(printer.id);
        const counter = pMap?.get(month);
        if (counter !== undefined) {
          const prev = getPrevCounter(printer.id, mi);
          if (prev !== null) {
            total += counter - prev;
          }
        }
      });
      totals.set(printer.id, total);
    });
    return totals;
  }, [filteredPrinters, allMonths, printerDataMap]);

  const colSpanTotal = 4 + allMonths.length * 2 + 1;

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Расход принтеров</h2>
        <button
          onClick={() => onNavigate('printer-consumption-add')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
          style={{ borderColor: '#198754', color: '#198754' }}
        >
          <Plus className="w-3.5 h-3.5" /> Ввести счётчик
        </button>
      </div>

      <div className="flex flex-wrap gap-3 mb-4">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: COLORS.text }}>Кабинет</label>
          <select value={filterLocation} onChange={e => setFilterLocation(e.target.value)} className="px-3 py-1.5 border rounded-lg text-sm" style={{ borderColor: '#dee2e6' }}>
            <option value="">Все</option>
            {locations.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{ minWidth: allMonths.length * 140 + 500 }}>
            <thead>
              {/* Заголовок с годами (объединённые ячейки) */}
              <tr style={{ backgroundColor: '#e9ecef', borderBottom: '1px solid #dee2e6' }}>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap sticky left-0 z-10" style={{ color: COLORS.heading, backgroundColor: '#e9ecef', minWidth: 50 }}>№</th>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap sticky left-[50px] z-10" style={{ color: COLORS.heading, backgroundColor: '#e9ecef', minWidth: 180 }}>Модель принтера</th>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap sticky left-[230px] z-10" style={{ color: COLORS.heading, backgroundColor: '#e9ecef', minWidth: 100 }}>Кабинет</th>
                <th rowSpan={2} className="text-left px-3 py-2 font-semibold whitespace-nowrap" style={{ color: COLORS.heading, minWidth: 80 }}>Картридж</th>
                <th rowSpan={2} className="text-right px-3 py-2 font-semibold whitespace-nowrap" style={{ color: COLORS.heading, minWidth: 60 }}>Объём</th>
                {yearGroups.map(g => (
                  <th key={g.year} colSpan={g.months.length * 2} className="text-center px-2 py-2 font-bold whitespace-nowrap" style={{ color: COLORS.heading, borderLeft: '2px solid #adb5bd', borderRight: '2px solid #adb5bd', fontSize: '0.85rem' }}>
                    {g.year}
                  </th>
                ))}
                <th rowSpan={2} className="text-right px-3 py-2 font-semibold whitespace-nowrap" style={{ color: COLORS.heading, minWidth: 70, borderLeft: '2px solid #adb5bd' }}>Итого</th>
              </tr>
              {/* Заголовки месяцев */}
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                {yearGroups.map(g => g.months.map((month, mi) => (
                  <React.Fragment key={month}>
                    <th className="text-center px-1 py-1.5 font-medium whitespace-nowrap" style={{ color: COLORS.heading, backgroundColor: mi % 2 === 0 ? '#f0f4ff' : '#f8f9fa', minWidth: 55, fontSize: '0.7rem', borderLeft: mi === 0 ? '2px solid #adb5bd' : undefined }}>
                      {fmtMonthShort(month)}
                    </th>
                    <th className="text-center px-1 py-1.5 font-medium whitespace-nowrap" style={{ color: '#6c757d', backgroundColor: mi % 2 === 0 ? '#f0f4ff' : '#f8f9fa', minWidth: 70, fontSize: '0.7rem' }}>
                      Расход
                    </th>
                  </React.Fragment>
                )))}
              </tr>
            </thead>
            <tbody>
              {filteredPrinters.length > 0 ? filteredPrinters.map((printer, idx) => {
                const pMap = printerDataMap.get(printer.id);
                const isWrittenOff = printer.status === 2;
                const cartModel = printer.cartridgeModel;
                const yield_ = cartModel?.expectedYield ?? 0;
                const printerTotal = printerTotals.get(printer.id) ?? 0;

                return (
                  <tr
                    key={printer.id}
                    className="transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    {/* № */}
                    <td className="px-3 py-2 font-medium whitespace-nowrap sticky left-0 z-10" style={{ color: COLORS.heading, backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', fontSize: '0.8rem' }}>
                      {printer.number}
                    </td>
                    {/* Модель */}
                    <td
                      className="px-3 py-2 font-medium whitespace-nowrap sticky left-[50px] z-10 cursor-pointer hover:underline"
                      style={{ color: COLORS.primary, backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', fontSize: '0.8rem' }}
                      onClick={() => onEditPrinter?.(printer)}
                    >
                      {printer.model}
                    </td>
                    {/* Кабинет */}
                    <td className="px-3 py-2 whitespace-nowrap sticky left-[230px] z-10" style={{ color: COLORS.text, backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', fontSize: '0.8rem' }}>
                      {printer.location || '—'}
                    </td>
                    {/* Картридж */}
                    <td className="px-3 py-2 whitespace-nowrap" style={{ fontSize: '0.8rem' }}>
                      {cartModel ? (
                        <span className="px-1.5 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: '#cfe2ff', color: '#084298' }}>
                          {cartModel.name}
                        </span>
                      ) : (
                        <span style={{ color: '#ccc' }}>—</span>
                      )}
                    </td>
                    {/* Объём */}
                    <td className="px-3 py-2 text-right whitespace-nowrap" style={{ color: COLORS.text, fontSize: '0.8rem' }}>
                      {yield_ > 0 ? fmtNum(yield_) : '—'}
                    </td>
                    {/* Месяцы */}
                    {yearGroups.map(g => g.months.map((month, mi) => {
                      const globalMi = allMonths.indexOf(month);
                      const counter = pMap?.get(month);
                      const prevCounter = counter !== undefined ? getPrevCounter(printer.id, globalMi) : null;
                      const hasData = counter !== undefined;
                      const consumptionData = hasData && prevCounter !== null
                        ? calcConsumption(counter, prevCounter, yield_)
                        : null;

                      // Не показываем нули — только пусто
                      const showCounter = hasData && counter !== 0;
                      const isFirstMonth = hasData && prevCounter === null;

                      return (
                        <React.Fragment key={month}>
                          {/* Счётчик */}
                          <td
                            className="px-1.5 py-2 text-right whitespace-nowrap cursor-pointer"
                            style={{
                              backgroundColor: globalMi % 2 === 0 ? (idx % 2 === 0 ? '#f5f7ff' : '#eef1fa') : 'transparent',
                              fontSize: '0.8rem',
                              color: COLORS.heading,
                              borderLeft: mi === 0 ? '2px solid #dee2e6' : undefined,
                            }}
                            onClick={() => {
                              if (hasData) {
                                const rec = consumption.find(c => c.printerId === printer.id && c.month === month);
                                if (rec) onEdit(rec);
                              }
                            }}
                          >
                            {isWrittenOff ? (
                              <span className="px-1 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: '#fce4ec', color: '#c62828' }}>Списан</span>
                            ) : showCounter ? (
                              fmtNum(counter)
                            ) : hasData && counter === 0 ? (
                              <span style={{ color: '#ccc' }}>0</span>
                            ) : (
                              <span style={{ color: '#eee' }}>—</span>
                            )}
                          </td>
                          {/* Расход */}
                          <td
                            className="px-1.5 py-2 text-right whitespace-nowrap cursor-pointer"
                            style={{
                              backgroundColor: consumptionData ? coefBgColor(consumptionData.coef) : (globalMi % 2 === 0 ? (idx % 2 === 0 ? '#f5f7ff' : '#eef1fa') : 'transparent'),
                              fontSize: '0.8rem',
                              color: consumptionData ? coefTextColor(consumptionData.coef) : COLORS.text,
                              fontWeight: consumptionData && consumptionData.coef > 1 ? 600 : 400,
                            }}
                            onClick={() => {
                              if (hasData) {
                                const rec = consumption.find(c => c.printerId === printer.id && c.month === month);
                                if (rec) onEdit(rec);
                              }
                            }}
                          >
                            {isWrittenOff ? '' : consumptionData ? (
                              <span>
                                {fmtNum(consumptionData.pages)}/{consumptionData.coef.toFixed(2).replace('.', ',')}
                              </span>
                            ) : isFirstMonth ? (
                              <span style={{ color: '#aaa', fontSize: '0.7rem' }}>первый</span>
                            ) : (
                              <span style={{ color: '#eee' }}>—</span>
                            )}
                          </td>
                        </React.Fragment>
                      );
                    }))}
                    {/* Итого по принтеру */}
                    <td className="px-3 py-2 text-right whitespace-nowrap font-semibold" style={{ color: COLORS.heading, fontSize: '0.8rem', borderLeft: '2px solid #adb5bd', backgroundColor: '#f8f9fa' }}>
                      {printerTotal > 0 ? fmtNum(printerTotal) : <span style={{ color: '#ccc' }}>—</span>}
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={colSpanTotal} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет данных</td>
                </tr>
              )}
              {/* Итоговая строка */}
              {filteredPrinters.length > 0 && (
                <tr style={{ backgroundColor: '#f8f9fa', borderTop: '2px solid #adb5bd', borderBottom: '2px solid #adb5bd' }}>
                  <td className="px-3 py-2 sticky left-0 z-10" style={{ backgroundColor: '#f8f9fa' }} />
                  <td className="px-3 py-2 font-bold sticky left-[50px] z-10" style={{ color: COLORS.heading, backgroundColor: '#f8f9fa', fontSize: '0.8rem' }}>ИТОГО</td>
                  <td className="px-3 py-2 sticky left-[230px] z-10" style={{ backgroundColor: '#f8f9fa' }} />
                  <td className="px-3 py-2" style={{ backgroundColor: '#f8f9fa' }} />
                  <td className="px-3 py-2" style={{ backgroundColor: '#f8f9fa' }} />
                  {yearGroups.map(g => g.months.map((month, mi) => {
                    const total = monthlyTotals.get(month);
                    const globalMi = allMonths.indexOf(month);
                    return (
                      <React.Fragment key={month}>
                        <td style={{ backgroundColor: '#f8f9fa', borderLeft: mi === 0 ? '2px solid #dee2e6' : undefined }} />
                        <td className="px-1.5 py-2 text-right whitespace-nowrap font-semibold" style={{ backgroundColor: total && total.coef > 0 ? coefBgColor(total.coef) : '#f8f9fa', color: total ? coefTextColor(total.coef) : COLORS.text, fontSize: '0.75rem' }}>
                          {total && total.pages > 0 ? (
                            <span>{fmtNum(total.pages)}/{total.coef.toFixed(2).replace('.', ',')}</span>
                          ) : <span style={{ color: '#ccc' }}>—</span>}
                        </td>
                      </React.Fragment>
                    );
                  }))}
                  <td className="px-3 py-2 text-right font-bold whitespace-nowrap" style={{ color: COLORS.heading, fontSize: '0.8rem', borderLeft: '2px solid #adb5bd', backgroundColor: '#f8f9fa' }}>
                    {fmtNum(filteredPrinters.reduce((sum, p) => sum + (printerTotals.get(p.id) ?? 0), 0))}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Легенда */}
      <div className="mt-3 flex items-center gap-4 text-xs" style={{ color: COLORS.text }}>
        <span>Коэффициент расхода:</span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#d1e7dd' }} /> &lt; 0,5
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#fff3cd' }} /> 0,5 — 1,0
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: '#f8d7da' }} /> &gt; 1,0
        </span>
      </div>
    </div>
  );
}

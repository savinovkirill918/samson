'use client';

import React from 'react';
import { Plus, Wrench } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Printer, PageId } from '@/lib/types';
import { printerTypeText, printerStatusText, printerStatusColor } from '@/lib/helpers';

interface PrinterListProps {
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEditPrinter: (printer: Printer) => void;
}

export default function PrinterList({ printers, onNavigate, onEditPrinter }: PrinterListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Принтеры</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('printer-repairs')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#ffc107', color: '#856404' }}
          >
            <Wrench className="w-3.5 h-3.5" /> Ремонты
          </button>
          <button
            onClick={() => onNavigate('printer-add')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#198754', color: '#198754' }}
          >
            <Plus className="w-3.5 h-3.5" /> Добавить
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>#</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Картридж</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Тип</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Место</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>IP-адрес</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Статус</th>
              </tr>
            </thead>
            <tbody>
              {printers.length > 0 ? printers.map((printer, idx) => {
                const sc = printerStatusColor(printer.status);
                return (
                  <tr
                    key={printer.id}
                    onClick={() => onEditPrinter(printer)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>№{printer.number}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.heading }}>{printer.model}</td>
                    <td className="px-4 py-3">
                      {printer.cartridgeModel ? (
                        <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: '#cfe2ff', color: '#084298' }}>
                          {printer.cartridgeModel.name}
                          {printer.cartridgeModel.expectedYield > 0 && ` (${printer.cartridgeModel.expectedYield.toLocaleString('ru-RU')})`}
                        </span>
                      ) : (
                        <span style={{ color: '#ccc' }}>—</span>
                      )}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{printerTypeText(printer.type)}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{printer.location || '—'}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.primary }}>{printer.ipAddress || '—'}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: sc.bg, color: sc.text }}>
                        {printerStatusText(printer.status)}
                      </span>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={7} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет принтеров</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { AlertTriangle, Save, X } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { CartridgeModel, PageId } from '@/lib/types';

interface CartridgeInventoryProps {
  models: CartridgeModel[];
  onUpdateModel: (data: Partial<CartridgeModel> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function CartridgeInventory({ models, onUpdateModel, onNavigate }: CartridgeInventoryProps) {
  // Track inline editing state: modelId being edited
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ total: 0, needsRefill: 0, newCount: 0, usedCount: 0 });

  const startEdit = (model: CartridgeModel) => {
    setEditingId(model.id);
    setEditForm({
      total: model.total,
      needsRefill: model.needsRefill,
      newCount: model.newCount,
      usedCount: model.usedCount,
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const saveEdit = (model: CartridgeModel) => {
    // Validate: newCount + usedCount should equal total
    if (editForm.newCount + editForm.usedCount !== editForm.total) {
      alert(`Кол-во новых (${editForm.newCount}) + Кол-во Б/У (${editForm.usedCount}) должно быть равно Всего (${editForm.total})`);
      return;
    }
    onUpdateModel({
      id: model.id,
      total: editForm.total,
      needsRefill: editForm.needsRefill,
      newCount: editForm.newCount,
      usedCount: editForm.usedCount,
    });
    setEditingId(null);
  };

  // Totals
  const totals = models.reduce((acc, m) => ({
    total: acc.total + m.total,
    onStock: acc.onStock + (m.total - m.needsRefill),
    needsRefill: acc.needsRefill + m.needsRefill,
    newCount: acc.newCount + m.newCount,
    usedCount: acc.usedCount + m.usedCount,
  }), { total: 0, onStock: 0, needsRefill: 0, newCount: 0, usedCount: 0 });

  const hasAlert = models.some(m => m.total - m.needsRefill <= 0 && m.total > 0);

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Сводка по картриджам</h2>
        <button
          onClick={() => onNavigate('cartridge-models')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
          style={{ borderColor: COLORS.primary, color: COLORS.primary }}
        >
          Справочник
        </button>
      </div>

      {/* Alert for zero stock */}
      {hasAlert && (
        <div className="rounded-xl p-4 mb-4 flex items-start gap-3" style={{ backgroundColor: '#fff3cd' }}>
          <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: '#664d03' }} />
          <div>
            <h3 className="font-semibold text-sm" style={{ color: '#664d03' }}>Нет картриджей на остатке:</h3>
            <div className="text-sm mt-1" style={{ color: '#664d03' }}>
              {models.filter(m => m.total - m.needsRefill <= 0 && m.total > 0).map(m => m.name).join(', ')}
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Модель</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Для принтера</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Всего</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>На ост.</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Треб. запр.</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Кол-во новых</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Кол-во Б/У</th>
                <th className="px-4 py-3 w-24"></th>
              </tr>
            </thead>
            <tbody>
              {models.map((m, idx) => {
                const onStock = m.total - m.needsRefill;
                const isEditing = editingId === m.id;
                const isLowStock = onStock <= 0 && m.total > 0;

                if (isEditing) {
                  const formOnStock = editForm.total - editForm.needsRefill;
                  const isValid = editForm.newCount + editForm.usedCount === editForm.total;
                  return (
                    <tr key={m.id} style={{ backgroundColor: '#e8f4fd', borderBottom: '1px solid #dee2e6' }}>
                      <td className="px-4 py-2 font-medium" style={{ color: COLORS.heading }}>{m.name}</td>
                      <td className="px-4 py-2" style={{ color: COLORS.text }}>{m.printerModel}</td>
                      <td className="px-4 py-2 text-right">
                        <input type="number" min={0} value={editForm.total} onChange={e => setEditForm(prev => ({ ...prev, total: Number(e.target.value) }))} className="w-16 px-2 py-1 border rounded text-right text-sm" style={{ borderColor: '#dee2e6' }} />
                      </td>
                      <td className="px-4 py-2 text-right font-medium" style={{ color: formOnStock > 0 ? '#0f5132' : '#dc3545' }}>{formOnStock}</td>
                      <td className="px-4 py-2 text-right">
                        <input type="number" min={0} value={editForm.needsRefill} onChange={e => setEditForm(prev => ({ ...prev, needsRefill: Number(e.target.value) }))} className="w-16 px-2 py-1 border rounded text-right text-sm" style={{ borderColor: '#dee2e6' }} />
                      </td>
                      <td className="px-4 py-2 text-right">
                        <input type="number" min={0} value={editForm.newCount} onChange={e => setEditForm(prev => ({ ...prev, newCount: Number(e.target.value) }))} className="w-16 px-2 py-1 border rounded text-right text-sm" style={{ borderColor: isValid || editForm.total === 0 ? '#dee2e6' : '#dc3545' }} />
                      </td>
                      <td className="px-4 py-2 text-right">
                        <input type="number" min={0} value={editForm.usedCount} onChange={e => setEditForm(prev => ({ ...prev, usedCount: Number(e.target.value) }))} className="w-16 px-2 py-1 border rounded text-right text-sm" style={{ borderColor: isValid || editForm.total === 0 ? '#dee2e6' : '#dc3545' }} />
                      </td>
                      <td className="px-4 py-2 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {!isValid && editForm.total > 0 && (
                            <span className="text-xs text-red-500 whitespace-nowrap">Новых+Б/У≠Всего</span>
                          )}
                          <button onClick={() => saveEdit(m)} className="p-1 rounded text-white hover:opacity-80" style={{ backgroundColor: '#198754' }}>
                            <Save className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={cancelEdit} className="p-1 rounded text-white hover:opacity-80" style={{ backgroundColor: '#6c757d' }}>
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr
                    key={m.id}
                    onClick={() => startEdit(m)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: isLowStock ? '#fff3cd' : idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = isLowStock ? '#fff3cd' : idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>
                      {isLowStock && <AlertTriangle className="w-3.5 h-3.5 inline mr-1" style={{ color: '#664d03' }} />}
                      {m.name}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{m.printerModel}</td>
                    <td className="px-4 py-3 text-right font-medium" style={{ color: COLORS.heading }}>{m.total || '—'}</td>
                    <td className="px-4 py-3 text-right" style={{ color: onStock > 0 ? '#0f5132' : '#dc3545', fontWeight: onStock <= 0 && m.total > 0 ? 700 : 400 }}>{m.total > 0 ? onStock : '—'}</td>
                    <td className="px-4 py-3 text-right" style={{ color: m.needsRefill > 0 ? '#664d03' : COLORS.text, fontWeight: m.needsRefill > 0 ? 700 : 400 }}>{m.needsRefill || '—'}</td>
                    <td className="px-4 py-3 text-right" style={{ color: '#0f5132' }}>{m.newCount || '—'}</td>
                    <td className="px-4 py-3 text-right" style={{ color: '#9a4800' }}>{m.usedCount || '—'}</td>
                    <td></td>
                  </tr>
                );
              })}
              {/* Totals row */}
              {models.length > 0 && (
                <tr style={{ backgroundColor: '#e9ecef', borderTop: '2px solid #dee2e6' }}>
                  <td className="px-4 py-3 font-bold" style={{ color: COLORS.heading }}>ИТОГО</td>
                  <td></td>
                  <td className="px-4 py-3 text-right font-bold" style={{ color: COLORS.heading }}>{totals.total || '—'}</td>
                  <td className="px-4 py-3 text-right font-bold" style={{ color: totals.onStock > 0 ? '#0f5132' : '#dc3545' }}>{totals.total > 0 ? totals.onStock : '—'}</td>
                  <td className="px-4 py-3 text-right font-bold" style={{ color: totals.needsRefill > 0 ? '#664d03' : COLORS.text }}>{totals.needsRefill || '—'}</td>
                  <td className="px-4 py-3 text-right font-bold" style={{ color: '#0f5132' }}>{totals.newCount || '—'}</td>
                  <td className="px-4 py-3 text-right font-bold" style={{ color: '#9a4800' }}>{totals.usedCount || '—'}</td>
                  <td></td>
                </tr>
              )}
              {models.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет моделей картриджей</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <p className="mt-3 text-xs" style={{ color: COLORS.text }}>
        Нажмите на строку для редактирования. «На остатке» = Всего − Требуют заправки. Кол-во новых + Кол-во Б/У должно быть равно Всего.
      </p>
    </div>
  );
}

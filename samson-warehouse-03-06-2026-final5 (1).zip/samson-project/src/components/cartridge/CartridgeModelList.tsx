'use client';

import React from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { CartridgeModel, PageId } from '@/lib/types';

interface CartridgeModelListProps {
  models: CartridgeModel[];
  onNavigate: (page: PageId) => void;
  onEdit: (model: CartridgeModel) => void;
}

export default function CartridgeModelList({ models, onNavigate, onEdit }: CartridgeModelListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Справочник картриджей</h2>
        <button
          onClick={() => onNavigate('cartridge-model-add')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
          style={{ borderColor: '#198754', color: '#198754' }}
        >
          <Plus className="w-3.5 h-3.5" /> Добавить
        </button>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Название</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Для принтера</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Ресурс (стр.)</th>
            </tr>
          </thead>
          <tbody>
            {models.length > 0 ? models.map((m, idx) => (
              <tr
                key={m.id}
                onClick={() => onEdit(m)}
                className="cursor-pointer transition-colors"
                style={{
                  backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                  borderBottom: '1px solid #dee2e6',
                }}
                onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
              >
                <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>{m.name}</td>
                <td className="px-4 py-3" style={{ color: COLORS.text }}>{m.printerModel}</td>
                <td className="px-4 py-3 text-right" style={{ color: COLORS.text }}>{m.expectedYield.toLocaleString('ru')}</td>
              </tr>
            )) : (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет моделей</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

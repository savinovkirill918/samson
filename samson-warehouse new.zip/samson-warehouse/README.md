# Самсон Склад — Система управления складом

Веб-приложение для управления складом: учёт сотрудников, ТСД (терминалы сбора данных), ККМ (контрольно-кассовые машины), ремонтов, статистики и генерации печатных форм (бейджи, наклейки со штрихкодами).

Рекреация оригинального сайта [samson.umk0.ru](https://samson.umk0.ru) на Next.js 16 + Tailwind CSS + Prisma 7 + SQLite.

---

## Технологический стек

| Компонент | Технология | Версия |
|---|---|---|
| Фреймворк | Next.js (App Router) | 16.x |
| UI | React + Tailwind CSS 4 | 19.x |
| База данных | SQLite (через better-sqlite3) | — |
| ORM | Prisma (с адаптером better-sqlite3) | 7.7+ |
| Иконки | lucide-react | 1.8+ |
| PDF-генерация | jsPDF + JsBarcode + node-canvas | — |
| Язык | TypeScript | 5.x |

---

## Структура проекта

```
samson-warehouse/
├── .env                          # DATABASE_URL=file:./db/custom.db
├── .gitignore
├── next.config.ts                # output: standalone, ignoreBuildErrors
├── package.json
├── postcss.config.mjs            # @tailwindcss/postcss
├── prisma.config.ts              # Prisma 7 config (datasource URL)
├── tsconfig.json
├── prisma/
│   ├── schema.prisma             # 12 моделей: Group, Member, TSD, KKM, Repair...
│   └── seed.js                   # Начальное заполнение БД
├── db/
│   └── custom.db                 # SQLite база данных (создаётся автоматически)
├── public/
│   ├── logo.svg
│   └── robots.txt
└── src/
    ├── lib/
    │   └── prisma.ts             # Prisma клиент с better-sqlite3 адаптером
    ├── generated/
    │   └── prisma/               # (автогенерация) — не коммитить
    └── app/
        ├── globals.css           # Tailwind CSS импорт
        ├── layout.tsx            # Корневой layout (lang="ru")
        ├── page.tsx              # ВЕСЬ SPA — 3000+ строк (один файл)
        └── api/
            ├── route.ts          # Health check
            ├── groups/route.ts   # CRUD должностей
            ├── members/route.ts  # CRUD сотрудников (include group, tsd, kkm)
            ├── tsds/route.ts     # CRUD ТСД (include members, repairs)
            ├── kkms/route.ts     # CRUD ККМ (include members)
            ├── repairs/route.ts  # CRUD ремонтов (include tsd)
            ├── logs/route.ts     # Логи действий (GET, POST)
            ├── admins/route.ts   # CRUD администраторов
            ├── badge/route.ts    # Генерация PDF-бейджа (GET, jsPDF)
            ├── sticker/route.ts  # Генерация PDF-наклейки ТСД (GET, jsPDF)
            └── stats/
                ├── 13/route.ts       # Отчёт 13 — КТУ кладовщиков
                ├── 49/route.ts       # Отчёт 49 — Производительность контролёров
                ├── upload/route.ts   # Загрузка данных статистики (POST)
                └── uploads/route.ts  # История загрузок (GET)
```

---

## Инструкция по развёртыванию с нуля

### Предварительные требования

- **Node.js** 20+ (рекомендуется 22+)
- **npm** 10+
- Системные библиотеки для `canvas` и `better-sqlite3`:
  - Ubuntu/Debian: `apt install build-essential python3 libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev`
  - CentOS/RHEL: `yum install gcc-c++ make python3 cairo-devel libjpeg-turbo-devel pango-devel giflib-devel librsvg2-devel`

### Шаг 1: Клонирование и установка

```bash
git clone <url-репозитория> samson-warehouse
cd samson-warehouse
npm install
```

### Шаг 2: Настройка базы данных

```bash
# Создать директорию для БД
mkdir -p db

# Сгенерировать Prisma-клиент
npx prisma generate

# Создать таблицы в БД (пуш схемы без миграций)
npx prisma db push

# Заполнить начальными данными (должности, сотрудники, ТСД, ККМ, админ)
node prisma/seed.js
```

### Шаг 3: Запуск в режиме разработки

```bash
npm run dev
# Приложение доступно на http://localhost:3000
```

### Шаг 4: Сборка для продакшена

```bash
npm run build
```

Сборка создаёт standalone-бандл в `.next/standalone/` со всеми необходимыми файлами.

### Шаг 5: Запуск в продакшене

```bash
# Вариант A: Через npm start (из корня проекта)
npm run start

# Вариант B: Через standalone-бандл (для деплоя на сервер)
cd .next/standalone
NODE_ENV=production node server.js
```

---

## Деплой на удалённый сервер (Linux + systemd)

### Подготовка сервера

```bash
# На сервере: установить Node.js 22+, системные библиотеки
apt update && apt install -y build-essential python3 libcairo2-dev libjpeg-dev libpango1.0-dev libgif-dev librsvg2-dev

# Создать директорию проекта
mkdir -p /opt/samson/db
```

### Сборка и передача архива

```bash
# На локальной машине: собрать standalone-бандл
npm run build

# Создать архив
tar czf samson-deploy.tar.gz -C .next/standalone .

# Передать на сервер
scp samson-deploy.tar.gz root@SERVER_IP:/tmp/
scp db/custom.db root@SERVER_IP:/opt/samson/db/
```

### Развёртывание на сервере

```bash
# На сервере
rm -rf /opt/samson/*
tar xzf /tmp/samson-deploy.tar.gz -C /opt/samson/

# Настроить переменные окружения
echo 'DATABASE_URL=file:/opt/samson/db/custom.db' > /opt/samson/.env

# Пересобрать нативные модули под архитектуру сервера
cd /opt/samson && npm rebuild better-sqlite3 canvas

# Протестировать запуск
cd /opt/samson && NODE_ENV=production node server.js
```

### Настройка systemd-сервиса

Создать файл `/etc/systemd/system/samson.service`:

```ini
[Unit]
Description=Samson Warehouse Management App
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/samson
EnvironmentFile=/opt/samson/.env
ExecStart=/usr/bin/node /opt/samson/server.js
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Активировать и запустить:

```bash
systemctl daemon-reload
systemctl enable samson
systemctl start samson
systemctl status samson
```

---

## Модели базы данных (Prisma Schema)

| Модель | Описание | Ключевые поля |
|---|---|---|
| **Group** | Должность/группа сотрудников | name, sort |
| **Member** | Сотрудник склада | fio, login, password, email, groupId, tsdId, kkmId, tg |
| **TSD** | Терминал сбора данных | number (уникальный), sn, inv, model, isMulti |
| **KKM** | Контрольно-кассовая машина | number (уникальный), sn, inv, isMulti |
| **Repair** | Ремонт ТСД | tsdId, brokenDate, sentDate, returnedDate, status (-1/0/1), description, isGuilty, cost |
| **LogEntry** | Запись лога действий | adminId, text, date |
| **AdminUser** | Пользователь системы | login (уникальный), hash, fio, role, groupId |
| **Stat13Upload** | Загрузка отчёта 13 (КТУ кладовщиков) | dateFrom, dateTo, groupName |
| **Stat13Row** | Строка отчёта 13 | fio, shtCnt, krCnt, pshtCnt, razmCnt, pkrCnt, ktu, hours, avgPerHour |
| **Stat49Upload** | Загрузка отчёта 49 (контролёры) | dateFrom, dateTo |
| **Stat49AvgRow** | Средние данные контролёра | controller, orderType, allErp, avgProizvod |
| **Stat49DailyRow** | Дневные данные контролёра | date, controller, orderType, allErp, avgProizvod |

---

## API-маршруты

### CRUD операции

| Метод | Маршрут | Описание |
|---|---|---|
| GET/POST | `/api/groups` | Список должностей / Создать |
| GET/PUT/DELETE | `/api/members` | Сотрудники (id через query или body) |
| GET/POST/PUT/DELETE | `/api/tsds` | ТСД |
| GET/POST/PUT/DELETE | `/api/kkms` | ККМ |
| GET/POST/PUT/DELETE | `/api/repairs` | Ремонты |
| GET/POST | `/api/logs` | Логи |
| GET/POST/PUT/DELETE | `/api/admins` | Администраторы |

### PDF-генерация

| Метод | Маршрут | Параметры | Описание |
|---|---|---|---|
| GET | `/api/badge` | fio, login, password, tsdNumber | PDF-бейдж сотрудника (A4: наклейка ТСД + бейдж со штрихкодами) |
| GET | `/api/sticker` | number, fio, sn, inv | PDF-наклейка на ТСД (60x40мм, штрихкоды SN/INV) |

### Статистика

| Метод | Маршрут | Параметры | Описание |
|---|---|---|---|
| GET | `/api/stats/13` | uploadId (опц.) | Данные отчёта 13 (КТУ кладовщиков) |
| GET | `/api/stats/49` | uploadId (опц.) | Данные отчёта 49 (контролёры) |
| POST | `/api/stats/upload` | JSON body | Загрузка данных статистики (type: 13 или 49) |
| GET | `/api/stats/uploads` | type=13\|49 | История загрузок |

---

## Страницы приложения (SPA)

Приложение реализовано как SPA (Single Page Application) — все страницы рендерятся в одном файле `page.tsx` через переключение состояния `PageId`.

| PageId | Название | Описание |
|---|---|---|
| `home` | Главная | Дашборд с предупреждениями о ТСД на ремонте, последние логи |
| `members` | Сотрудники | Таблица с зеброй, копирование логина/пароля, печать бейджа |
| `member-add` / `member-edit` | Добавить/Редактировать сотрудника | Форма с привязкой к ТСД, ККМ, должности |
| `groups` / `group-add` | Должности | Управление должностями (сортировка по sort) |
| `tsd-list` / `tsd-add` / `tsd-edit` | ТСД | Список, добавление, редактирование терминалов |
| `tsd-repairs` / `tsd-repair-add` / `tsd-repair-edit` | Ремонты | Учёт ремонтов ТСД со статусами |
| `tsd-repair-sz` | Служебная записка | Генерация СЗ на ремонт |
| `kkm-list` / `kkm-add` | ККМ | Управление кассовыми машинами |
| `stat-starshie` | Старшие (отчёт 49) | Статистика контролёров |
| `stat-kladovshiki` | Кладовщики (отчёт 13) | КТУ кладовщиков |
| `stat-import` | Импорт WMS | Загрузка XML-файлов Crystal Reports |
| `tools` | Инструменты | Служебные инструменты |
| `logs` | Логи | Журнал действий с пагинацией |
| `print-tsd` / `print-kkm` / `print-stickers` / `print-barcode` / `print-containers` | Печать | Различные печатные формы |
| `settings-users` / `settings-user-add` | Настройки | Управление пользователями системы |

---

## Цветовая схема (из оригинала samson.umk0.ru)

```
primary:       #3a57e8  (синий, кнопки и акценты)
bodyBg:        #f5f6fa  (фон страницы)
sidebarBg:     #ffffff  (фон боковой панели)
heading:       #212529  (заголовки)
text:          #8a92a6  (обычный текст)
alertBg:       #e9ecef  (фон предупреждений)
success:       #198754  (зелёные кнопки)
white:         #ffffff
```

---

## Важные замечания для развёртывания

1. **Prisma 7 + better-sqlite3**: Используется адаптер `@prisma/adapter-better-sqlite3`. Нельзя просто `new PrismaClient()` — нужен адаптер. См. `src/lib/prisma.ts`.

2. **prisma.config.ts**: В Prisma 7 datasource URL задаётся в `prisma.config.ts` (не только в schema.prisma). Файл обязателен.

3. **Генерация клиента**: После `npx prisma generate` клиент создаётся в `src/generated/prisma/`. Импорт: `from '@/generated/prisma/client'`.

4. **Нативные модули**: `better-sqlite3` и `canvas` содержат нативный C-код. При переносе на другой сервер **обязательно** пересобрать: `npm rebuild better-sqlite3 canvas`.

5. **Standalone-сборка**: `next.config.ts` содержит `output: "standalone"`. При сборке создаётся `.next/standalone/` с минимальным сервером. Нужно скопировать `.next/static/` и `public/` внутрь standalone (это делает `npm run build`).

6. **DATABASE_URL**: Для локальной разработки — `file:./db/custom.db` (относительно корня проекта). Для продакшена — абсолютный путь: `file:/opt/samson/db/custom.db`.

7. **Шрифты для PDF**: Для генерации PDF с кириллицей нужны шрифты:
   - Times New Roman: `/usr/share/fonts/truetype/english/Times-New-Roman.ttf`
   - Liberation Serif Bold: `/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf`
   - DejaVu Sans: `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf` и `DejaVuSans-Bold.ttf`
   
   На Ubuntu/Debian: `apt install fonts-liberation fonts-dejavu-core`

8. **TypeScript ignoreBuildErrors**: В `next.config.ts` стоит `ignoreBuildErrors: true`, потому что `page.tsx` (3000+ строк) содержит типы, которые не всегда строго соответствуют. Для продакшена это нормально.

9. **page.tsx — монолит**: Весь фронтенд находится в одном файле `src/app/page.tsx` (3000+ строк). Это осознанное решение — SPA с переключением страниц через состояние React. Если нужно рефакторить — разбить на отдельные компоненты.

---

## Вход в систему

После выполнения `node prisma/seed.js`:
- **Логин**: admin
- **Пароль**: любой (в текущей реализации проверяется только наличие логина в БД)

Для продакшена нужно реализовать проверку хеша пароля (поле `hash` в модели `AdminUser`).

---

## Лицензия

Частный проект. Все права защищены.

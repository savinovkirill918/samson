'use client';

// =====================================================================
// Самсон Склад — Система управления складом
// Одностраничное приложение (SPA) на Next.js 16 с App Router
// Все компоненты и данные находятся в этом файле
// =====================================================================

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Home, Users, UserPlus, Briefcase, Smartphone, Plus, Wrench,
  CreditCard, BarChart3, Wrench as ToolsIcon, FileText, Printer,
  Settings, ChevronDown, ChevronRight, LogOut, Mail, MessageCircle,
  Search, Edit, Trash2, Save, AlertTriangle, Clock, X, Menu,
  Upload, Calculator, FileSpreadsheet, Tag, Box, UserCog, RefreshCw,
  CheckCircle, XCircle, Shield, Hash, Key, Heading, Copy
} from 'lucide-react';

// =====================================================================
// ТИПЫ И ИНТЕРФЕЙСЫ
// =====================================================================

/** Группа/должность сотрудника */
interface Group {
  id: number;
  name: string;
  sort: number;
}

/** Сотрудник склада */
interface Member {
  id: number;
  fio: string;
  login: string;
  password: string;
  email: string;
  emailPassword: string;
  groupId: number;
  tsdId: number | null;
  kkmId: number | null;
  tg: string;
}

/** ТСД — терминал сбора данных */
interface TSD {
  id: number;
  number: number;
  sn: string;
  inv: string;
  model: string;
  isMulti: boolean;
}

/** ККМ — контрольно-кассовая машина */
interface KKM {
  id: number;
  number: number;
  sn: string;
  inv: string;
  isMulti: boolean;
}

/** Ремонт ТСД */
interface Repair {
  id: number;
  tsdId: number;
  brokenDate: string;
  sentDate: string;
  returnedDate: string;
  status: string;
  description: string;
  warranty: boolean;
}

/** Запись лога действий */
interface LogEntry {
  id: number;
  adminId: number;
  text: string;
  date: string;
}

/** Пользователь системы (администратор) */
interface AdminUser {
  id: number;
  login: string;
  hash: string;
  fio: string;
  role: string;
  groupId: number;
}

/** Типы страниц навигации */
type PageId =
  | 'home'
  | 'members' | 'member-add' | 'member-edit'
  | 'groups' | 'group-add'
  | 'tsd-list' | 'tsd-add' | 'tsd-repairs' | 'tsd-repair-add' | 'tsd-repair-sz'
  | 'kkm-list' | 'kkm-add'
  | 'stat-starshie' | 'stat-kladovshiki' | 'stat-import'
  | 'tools'
  | 'logs'
  | 'print-tsd' | 'print-kkm' | 'print-stickers' | 'print-barcode' | 'print-containers'
  | 'settings-users' | 'settings-user-add';

// =====================================================================
// ЦВЕТОВАЯ СХЕМА (из оригинального сайта)
// =====================================================================
const COLORS = {
  bodyBg: '#f5f6fa',
  sidebarBg: '#ffffff',
  primary: '#3a57e8',
  heading: '#212529',
  text: '#8a92a6',
  alertBg: '#e9ecef',
  white: '#ffffff',
};

// =====================================================================
// МОКОВЫЕ ДАННЫЕ
// =====================================================================

// Группы/должности сотрудников
const INITIAL_GROUPS: Group[] = [
  { id: 1, name: 'Зав. склада', sort: 1 },
  { id: 2, name: 'Администратор смены', sort: 2 },
  { id: 3, name: 'КВО', sort: 3 },
  { id: 4, name: 'Ст. кладовщик ОПТ', sort: 4 },
  { id: 5, name: 'Ст. кладовщик ОКТ', sort: 5 },
  { id: 6, name: 'Кл. контролер ОКТ', sort: 6 },
  { id: 7, name: 'Кл. контролер ОПТ', sort: 7 },
  { id: 8, name: 'Кладовщик ОПТ', sort: 8 },
  { id: 9, name: 'Кладовщик ОКТ', sort: 9 },
  { id: 10, name: 'Кл. водитель', sort: 10 },
  { id: 11, name: 'Кл. комплектовщик', sort: 11 },
  { id: 12, name: 'Кл. Дорогого', sort: 12 },
  { id: 13, name: 'Водитель КОР', sort: 13 },
  { id: 14, name: 'Водитель ОПТ', sort: 14 },
  { id: 15, name: 'Системный администратор WMS', sort: 15 },
];

// ТСД терминалы
const INITIAL_TSDS: TSD[] = [
  { id: 1, number: 1, sn: 'SN-TSD-001', inv: 'INV-001', model: 'МС-32N0 +', isMulti: false },
  { id: 2, number: 2, sn: 'SN-TSD-002', inv: 'INV-002', model: 'МС-3190', isMulti: false },
  { id: 3, number: 3, sn: 'SN-TSD-003', inv: 'INV-003', model: 'RK25-2DSR', isMulti: false },
  { id: 4, number: 4, sn: 'SN-TSD-004', inv: 'INV-004', model: 'МС-32N0 +', isMulti: true },
  { id: 5, number: 5, sn: 'SN-TSD-005', inv: 'INV-005', model: 'МС-3190', isMulti: false },
  { id: 6, number: 6, sn: 'SN-TSD-006', inv: 'INV-006', model: 'RK25-2DSR', isMulti: false },
  { id: 7, number: 7, sn: 'SN-TSD-007', inv: 'INV-007', model: 'МС-32N0 +', isMulti: false },
  { id: 8, number: 8, sn: 'SN-TSD-008', inv: 'INV-008', model: 'МС-3190', isMulti: true },
  { id: 9, number: 9, sn: 'SN-TSD-009', inv: 'INV-009', model: 'RK25-2DSR', isMulti: false },
  { id: 10, number: 10, sn: 'SN-TSD-010', inv: 'INV-010', model: 'МС-32N0 +', isMulti: false },
  { id: 11, number: 11, sn: 'SN-TSD-011', inv: 'INV-011', model: 'МС-3190', isMulti: false },
  { id: 12, number: 12, sn: 'SN-TSD-012', inv: 'INV-012', model: 'RK25-2DSR', isMulti: false },
  { id: 13, number: 13, sn: 'SN-TSD-013', inv: 'INV-013', model: 'МС-32N0 +', isMulti: false },
  { id: 14, number: 14, sn: 'SN-TSD-014', inv: 'INV-014', model: 'МС-3190', isMulti: true },
  { id: 15, number: 15, sn: 'SN-TSD-015', inv: 'INV-015', model: 'RK25-2DSR', isMulti: false },
  { id: 16, number: 16, sn: 'SN-TSD-016', inv: 'INV-016', model: 'МС-32N0 +', isMulti: false },
  { id: 17, number: 17, sn: 'SN-TSD-017', inv: 'INV-017', model: 'МС-3190', isMulti: false },
  { id: 18, number: 18, sn: 'SN-TSD-018', inv: 'INV-018', model: 'RK25-2DSR', isMulti: false },
  { id: 19, number: 19, sn: 'SN-TSD-019', inv: 'INV-019', model: 'МС-32N0 +', isMulti: false },
  { id: 20, number: 20, sn: 'SN-TSD-020', inv: 'INV-020', model: 'МС-3190', isMulti: false },
];

// ККМ кассовые аппараты
const INITIAL_KKMS: KKM[] = Array.from({ length: 12 }, (_, i) => ({
  id: i + 1,
  number: i + 1,
  sn: `SN-KKM-${String(i + 1).padStart(3, '0')}`,
  inv: `INV-KKM-${String(i + 1).padStart(3, '0')}`,
  isMulti: i === 3 || i === 7,
}));

// Сотрудники
const INITIAL_MEMBERS: Member[] = [
  { id: 1, fio: 'Савинов Константин Андреевич', login: 'ksavinov', password: 'Savca123', email: 'ksavinov@samsonopt.ru', emailPassword: 'pass1', groupId: 15, tsdId: null, kkmId: null, tg: '@ksavinov' },
  { id: 2, fio: 'Иванов Алексей Петрович', login: 'aivanov', password: 'pass123', email: 'aivanov@samsonopt.ru', emailPassword: 'pass2', groupId: 1, tsdId: null, kkmId: null, tg: '@aivanov' },
  { id: 3, fio: 'Петрова Мария Сергеевна', login: 'mpetrova', password: 'pass456', email: 'mpetrova@samsonopt.ru', emailPassword: 'pass3', groupId: 2, tsdId: 1, kkmId: 1, tg: '@mpetrova' },
  { id: 4, fio: 'Сидоров Дмитрий Николаевич', login: 'dsidorov', password: 'pass789', email: 'dsidorov@samsonopt.ru', emailPassword: 'pass4', groupId: 4, tsdId: 3, kkmId: null, tg: '@dsidorov' },
  { id: 5, fio: 'Козлова Анна Владимировна', login: 'akozlova', password: 'pass101', email: 'akozlova@samsonopt.ru', emailPassword: 'pass5', groupId: 5, tsdId: 5, kkmId: 2, tg: '@akozlova' },
  { id: 6, fio: 'Морозов Игорь Александрович', login: 'imorozov', password: 'pass202', email: 'imorozov@samsonopt.ru', emailPassword: 'pass6', groupId: 8, tsdId: 7, kkmId: null, tg: '@imorozov' },
  { id: 7, fio: 'Волкова Елена Дмитриевна', login: 'evolkova', password: 'pass303', email: 'evolkova@samsonopt.ru', emailPassword: 'pass7', groupId: 9, tsdId: 9, kkmId: 3, tg: '@evolkova' },
  { id: 8, fio: 'Новиков Сергей Павлович', login: 'snovikov', password: 'pass404', email: 'snovikov@samsonopt.ru', emailPassword: 'pass8', groupId: 10, tsdId: null, kkmId: null, tg: '@snovikov' },
  { id: 9, fio: 'Соколова Ольга Игоревна', login: 'osokolova', password: 'pass505', email: 'osokolova@samsonopt.ru', emailPassword: 'pass9', groupId: 6, tsdId: 11, kkmId: 4, tg: '@osokolova' },
  { id: 10, fio: 'Лебедев Андрей Викторович', login: 'alebedev', password: 'pass606', email: 'alebedev@samsonopt.ru', emailPassword: 'pass10', groupId: 7, tsdId: 13, kkmId: 5, tg: '@alebedev' },
  { id: 11, fio: 'Кузнецова Наталья Денисовна', login: 'nkuznetsova', password: 'pass707', email: 'nkuznetsova@samsonopt.ru', emailPassword: 'pass11', groupId: 11, tsdId: 15, kkmId: null, tg: '@nkuznetsova' },
  { id: 12, fio: 'Попов Максим Юрьевич', login: 'mpopov', password: 'pass808', email: 'mpopov@samsonopt.ru', emailPassword: 'pass12', groupId: 13, tsdId: null, kkmId: null, tg: '@mpopov' },
  { id: 13, fio: 'Васильев Роман Олегович', login: 'rvasiliev', password: 'pass909', email: 'rvasiliev@samsonopt.ru', emailPassword: 'pass13', groupId: 14, tsdId: null, kkmId: null, tg: '@rvasiliev' },
  { id: 14, fio: 'Михайлова Татьяна Андреевна', login: 'tmikhailova', password: 'pass110', email: 'tmikhailova@samsonopt.ru', emailPassword: 'pass14', groupId: 3, tsdId: 17, kkmId: 6, tg: '@tmikhailova' },
  { id: 15, fio: 'Фёдоров Артём Иванович', login: 'afedorov', password: 'pass120', email: 'afedorov@samsonopt.ru', emailPassword: 'pass15', groupId: 12, tsdId: 19, kkmId: null, tg: '@afedorov' },
];

// Ремонты ТСД
const INITIAL_REPAIRS: Repair[] = [
  { id: 1, tsdId: 2, brokenDate: '2025-11-15', sentDate: '2025-11-17', returnedDate: '', status: 'На ремонте', description: 'Разбит экран', warranty: true },
  { id: 2, tsdId: 6, brokenDate: '2025-10-20', sentDate: '2025-10-22', returnedDate: '2025-12-01', status: 'Возвращён', description: 'Не включается', warranty: false },
  { id: 3, tsdId: 10, brokenDate: '2026-01-05', sentDate: '2026-01-07', returnedDate: '', status: 'На ремонте', description: 'Не сканирует штрихкод', warranty: true },
  { id: 4, tsdId: 14, brokenDate: '2025-09-12', sentDate: '2025-09-14', returnedDate: '2025-10-30', status: 'Возвращён', description: 'Повреждён разъём зарядки', warranty: false },
  { id: 5, tsdId: 18, brokenDate: '2026-03-01', sentDate: '2026-03-03', returnedDate: '', status: 'Отправлен', description: 'Программный сбой', warranty: true },
];

// Логи действий
const generateLogs = (): LogEntry[] => {
  const actions = [
    'Вход в систему',
    'Добавление сотрудника: Петрова М.С.',
    'Редактирование ТСД №3',
    'Удаление ремонта ТСД №6',
    'Изменение пароля',
    'Экспорт отчёта 13',
    'Импорт отчёта 49',
    'Добавление ККМ №8',
    'Редактирование сотрудника: Сидоров Д.Н.',
    'Отправка ТСД №10 в ремонт',
    'Возврат ТСД №6 из ремонта',
    'Печать реестра ТСД',
    'Печать наклеек ТСД',
    'Редактирование должности: Кладовщик ОПТ',
    'Добавление пользователя: afedorov',
    'Удаление сотрудника: Иванов П.К.',
    'Получение СЗ для ТСД №2',
    'Изменение ККМ №4',
    'Обновление профиля',
    'Выход из системы',
  ];
  const users = ['Савинов К.А.', 'Иванов А.П.', 'Петрова М.С.'];
  const logs: LogEntry[] = [];
  for (let i = 180; i >= 1; i--) {
    const day = Math.floor(i / 6);
    const hour = 8 + (i % 12);
    const min = (i * 7) % 60;
    const date = new Date(2026, 2, 13 - day, hour, min);
    logs.push({
      id: i,
      adminId: (i % 3) + 1,
      text: actions[i % actions.length],
      date: date.toISOString(),
    });
  }
  return logs;
};

const INITIAL_LOGS = generateLogs();

// Пользователи системы (администраторы)
const INITIAL_ADMINS: AdminUser[] = [
  { id: 1, login: 'ksavinov', hash: '', fio: 'Савинов Константин Андреевич', role: 'Админ', groupId: 15 },
  { id: 2, login: 'aivanov', hash: '', fio: 'Иванов Алексей Петрович', role: 'Админ', groupId: 1 },
  { id: 3, login: 'mpetrova', hash: '', fio: 'Петрова Мария Сергеевна', role: 'Пользователь', groupId: 2 },
];

// =====================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// =====================================================================

/** Получить название группы по ID */
const getGroupName = (groupId: number, groups: Group[]): string => {
  return groups.find(g => g.id === groupId)?.name || 'Не указана';
};

/** Получить ТСД по ID */
const getTsd = (tsdId: number | null, tsds: TSD[]): TSD | null => {
  if (!tsdId) return null;
  return tsds.find(t => t.id === tsdId) || null;
};

/** Получить ККМ по ID */
const getKkm = (kkmId: number | null, kkms: KKM[]): KKM | null => {
  if (!kkmId) return null;
  return kkms.find(k => k.id === kkmId) || null;
};

/** Форматирование даты для отображения */
const formatDate = (dateStr: string): string => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

/** Форматирование даты и времени для логов */
const formatDateTime = (isoStr: string): string => {
  const d = new Date(isoStr);
  return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
};

// =====================================================================
// КОМПОНЕНТ СТРАНИЦЫ ВХОДА
// =====================================================================
const LoginPage = ({ onLogin }: { onLogin: (user: AdminUser) => void }) => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState('');

  // Обработка отправки формы входа
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Проверка учётных данных (моковые данные)
    if (login === 'ksavinov' && password === 'Savca123') {
      const user = INITIAL_ADMINS[0];
      onLogin(user);
      if (remember) {
        localStorage.setItem('samson_auth', JSON.stringify(user));
      }
    } else {
      setError('Неверный логин или пароль');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
      {/* Форма входа */}
      <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md mx-4">
        <div className="text-center mb-8">
          {/* Логотип */}
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full mb-4" style={{ backgroundColor: COLORS.primary }}>
            <Home className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold" style={{ color: COLORS.heading }}>Самсон Склад</h1>
          <p className="text-sm mt-1" style={{ color: COLORS.text }}>Система управления складом</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Поле логина */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин</label>
            <input
              type="text"
              value={login}
              onChange={e => { setLogin(e.target.value); setError(''); }}
              className="w-full px-4 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:border-transparent transition"
              style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              onFocus={e => e.target.style.setProperty('--tw-ring-color', COLORS.primary)}
              placeholder="Введите логин"
            />
          </div>

          {/* Поле пароля */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль</label>
            <input
              type="password"
              value={password}
              onChange={e => { setPassword(e.target.value); setError(''); }}
              className="w-full px-4 py-2.5 border rounded-lg focus:outline-none focus:ring-2 focus:border-transparent transition"
              style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              placeholder="Введите пароль"
            />
          </div>

          {/* Чекбокс «Запомнить меня» и ссылка «Забыли пароль?» */}
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={remember}
                onChange={e => setRemember(e.target.checked)}
                className="w-4 h-4 rounded"
                style={{ accentColor: COLORS.primary }}
              />
              <span className="text-sm" style={{ color: COLORS.text }}>Запомнить меня</span>
            </label>
            <a href="#" className="text-sm hover:underline" style={{ color: COLORS.primary }}>Забыли пароль?</a>
          </div>

          {/* Сообщение об ошибке */}
          {error && (
            <div className="text-red-500 text-sm text-center bg-red-50 p-2 rounded">{error}</div>
          )}

          {/* Кнопка входа */}
          <button
            type="submit"
            className="w-full py-2.5 text-white rounded-lg font-medium hover:opacity-90 transition"
            style={{ backgroundColor: COLORS.primary }}
          >
            Вход
          </button>
        </form>
      </div>
    </div>
  );
};

// =====================================================================
// КОМПОНЕНТ БОКОВОГО МЕНЮ (САЙДБАР)
// =====================================================================
interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar = ({ currentPage, onNavigate, isOpen, onClose }: SidebarProps) => {
  // Состояние раскрытия разделов меню
  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    employees: false, positions: false, tsd: false, repair: false,
    kkm: false, statistics: false, print: false, settings: false,
  });

  // Переключение раскрытия раздела
  const toggleExpand = (key: string) => {
    setExpanded(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Навигация на страницу с закрытием мобильного меню
  const navigate = (page: PageId) => {
    onNavigate(page);
    onClose();
  };

  // Проверка, активна ли страница
  const isActive = (page: PageId) => currentPage === page;

  // Класс для активного пункта меню
  const activeClass = 'text-white rounded-lg';
  const inactiveClass = 'rounded-lg hover:bg-gray-100';

  return (
    <>
      {/* Затемнение фона на мобильных */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={onClose} />
      )}

      {/* Боковая панель */}
      <aside
        className={`fixed top-0 left-0 h-full z-50 shadow-xl transition-transform duration-300 overflow-y-auto ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
        style={{ backgroundColor: COLORS.sidebarBg, width: '260px' }}
      >
        {/* Заголовок сайдбара */}
        <div className="p-4 border-b flex items-center gap-3" style={{ borderColor: '#e9ecef' }}>
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: COLORS.primary }}>
            <Home className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg" style={{ color: COLORS.heading }}>Самсон Склад</span>
          <button className="ml-auto lg:hidden" onClick={onClose}>
            <X className="w-5 h-5" style={{ color: COLORS.text }} />
          </button>
        </div>

        {/* Навигационное меню */}
        <nav className="p-3 space-y-1">
          {/* Главная */}
          <button
            onClick={() => navigate('home')}
            className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('home') ? activeClass : inactiveClass}`}
            style={isActive('home') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}
          >
            <Home className="w-4 h-4" /> Главная
          </button>

          {/* Сотрудники (раскрытое меню) */}
          <div>
            <button
              onClick={() => toggleExpand('employees')}
              className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition"
              style={{ color: COLORS.heading }}
            >
              <span className="flex items-center gap-3"><Users className="w-4 h-4" /> Сотрудники</span>
              {expanded.employees ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.employees && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('members')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('members') ? activeClass : inactiveClass}`} style={isActive('members') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Users className="w-3.5 h-3.5" /> Все Сотрудники
                </button>
                <button onClick={() => navigate('member-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('member-add') ? activeClass : inactiveClass}`} style={isActive('member-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
                {/* Должности (подменю) */}
                <div>
                  <button onClick={() => toggleExpand('positions')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.text }}>
                    <span className="flex items-center gap-3"><Briefcase className="w-3.5 h-3.5" /> Должности</span>
                    {expanded.positions ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                  {expanded.positions && (
                    <div className="ml-6 space-y-1 mt-1">
                      <button onClick={() => navigate('groups')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('groups') ? activeClass : inactiveClass}`} style={isActive('groups') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Все Должности
                      </button>
                      <button onClick={() => navigate('group-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('group-add') ? activeClass : inactiveClass}`} style={isActive('group-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Добавить
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ТСД */}
          <div>
            <button onClick={() => toggleExpand('tsd')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Smartphone className="w-4 h-4" /> ТСД</span>
              {expanded.tsd ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.tsd && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('tsd-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('tsd-list') ? activeClass : inactiveClass}`} style={isActive('tsd-list') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Smartphone className="w-3.5 h-3.5" /> Все ТСД
                </button>
                <button onClick={() => navigate('tsd-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('tsd-add') ? activeClass : inactiveClass}`} style={isActive('tsd-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
                {/* Ремонт (подменю) */}
                <div>
                  <button onClick={() => toggleExpand('repair')} className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.text }}>
                    <span className="flex items-center gap-3"><Wrench className="w-3.5 h-3.5" /> Ремонт</span>
                    {expanded.repair ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                  {expanded.repair && (
                    <div className="ml-6 space-y-1 mt-1">
                      <button onClick={() => navigate('tsd-repairs')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repairs') ? activeClass : inactiveClass}`} style={isActive('tsd-repairs') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Все Ремонты
                      </button>
                      <button onClick={() => navigate('tsd-repair-add')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repair-add') ? activeClass : inactiveClass}`} style={isActive('tsd-repair-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Добавить
                      </button>
                      <button onClick={() => navigate('tsd-repair-sz')} className={`w-full flex items-center gap-3 px-3 py-1.5 text-sm transition ${isActive('tsd-repair-sz') ? activeClass : inactiveClass}`} style={isActive('tsd-repair-sz') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                        Получить СЗ
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ККМ */}
          <div>
            <button onClick={() => toggleExpand('kkm')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><CreditCard className="w-4 h-4" /> ККМ</span>
              {expanded.kkm ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.kkm && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('kkm-list')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('kkm-list') ? activeClass : inactiveClass}`} style={isActive('kkm-list') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <CreditCard className="w-3.5 h-3.5" /> Все ККМ
                </button>
                <button onClick={() => navigate('kkm-add')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('kkm-add') ? activeClass : inactiveClass}`} style={isActive('kkm-add') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  <Plus className="w-3.5 h-3.5" /> Добавить
                </button>
              </div>
            )}
          </div>

          {/* Статистика */}
          <div>
            <button onClick={() => toggleExpand('statistics')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><BarChart3 className="w-4 h-4" /> Статистика</span>
              {expanded.statistics ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.statistics && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('stat-starshie')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-starshie') ? activeClass : inactiveClass}`} style={isActive('stat-starshie') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Старшие
                </button>
                <button onClick={() => navigate('stat-kladovshiki')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-kladovshiki') ? activeClass : inactiveClass}`} style={isActive('stat-kladovshiki') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Кладовщики
                </button>
                <button onClick={() => navigate('stat-import')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('stat-import') ? activeClass : inactiveClass}`} style={isActive('stat-import') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Импорт WMS
                </button>
              </div>
            )}
          </div>

          {/* Инструменты */}
          <button onClick={() => navigate('tools')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('tools') ? activeClass : inactiveClass}`} style={isActive('tools') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}>
            <ToolsIcon className="w-4 h-4" /> Инструменты
          </button>

          {/* Логи */}
          <button onClick={() => navigate('logs')} className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition ${isActive('logs') ? activeClass : inactiveClass}`} style={isActive('logs') ? { backgroundColor: COLORS.primary } : { color: COLORS.heading }}>
            <FileText className="w-4 h-4" /> Логи
          </button>

          {/* Печать */}
          <div>
            <button onClick={() => toggleExpand('print')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Printer className="w-4 h-4" /> Печать</span>
              {expanded.print ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.print && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('print-tsd')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-tsd') ? activeClass : inactiveClass}`} style={isActive('print-tsd') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Реестр ТСД
                </button>
                <button onClick={() => navigate('print-kkm')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-kkm') ? activeClass : inactiveClass}`} style={isActive('print-kkm') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Реестр ККМ
                </button>
                <button onClick={() => navigate('print-stickers')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-stickers') ? activeClass : inactiveClass}`} style={isActive('print-stickers') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Наклейки ТСД
                </button>
                <button onClick={() => navigate('print-barcode')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-barcode') ? activeClass : inactiveClass}`} style={isActive('print-barcode') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Штрихкод
                </button>
                <button onClick={() => navigate('print-containers')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('print-containers') ? activeClass : inactiveClass}`} style={isActive('print-containers') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Контейнеры
                </button>
              </div>
            )}
          </div>

          {/* Настройки */}
          <div>
            <button onClick={() => toggleExpand('settings')} className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-100 transition" style={{ color: COLORS.heading }}>
              <span className="flex items-center gap-3"><Settings className="w-4 h-4" /> Настройки</span>
              {expanded.settings ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </button>
            {expanded.settings && (
              <div className="ml-6 space-y-1 mt-1">
                <button onClick={() => navigate('settings-users')} className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition ${isActive('settings-users') ? activeClass : inactiveClass}`} style={isActive('settings-users') ? { backgroundColor: COLORS.primary } : { color: COLORS.text }}>
                  Пользователи
                </button>
              </div>
            )}
          </div>
        </nav>
      </aside>
    </>
  );
};

// =====================================================================
// ХЛЕБНЫЕ КРОШКИ
// =====================================================================
const Breadcrumbs = ({ items }: { items: { label: string; page?: PageId; onNavigate: (page: PageId) => void }[] }) => (
  <div className="flex items-center gap-2 text-sm mb-4 flex-wrap" style={{ color: COLORS.text }}>
    {items.map((item, idx) => (
      <React.Fragment key={idx}>
        {idx > 0 && <ChevronRight className="w-3.5 h-3.5" />}
        {item.page ? (
          <button onClick={() => item.page && item.onNavigate(item.page)} className="hover:underline" style={{ color: COLORS.primary }}>{item.label}</button>
        ) : (
          <span style={{ color: COLORS.heading }}>{item.label}</span>
        )}
      </React.Fragment>
    ))}
  </div>
);

// =====================================================================
// ГЛАВНАЯ СТРАНИЦА (Дашборд)
// =====================================================================
const HomePage = ({ members, tsds, repairs, groups, logs, onNavigate }: {
  members: Member[]; tsds: TSD[]; repairs: Repair[]; groups: Group[]; logs: LogEntry[]; onNavigate: (page: PageId) => void;
}) => {
  // Предупреждения о ТСД на ремонте у активных сотрудников
  const repairsWithMembers = repairs
    .filter(r => r.status !== 'Возвращён')
    .map(r => {
      const member = members.find(m => m.tsdId === r.tsdId);
      const tsd = tsds.find(t => t.id === r.tsdId);
      return { repair: r, member, tsd };
    })
    .filter(r => r.member);

  // Последние 50 логов
  const recentLogs = logs.slice(0, 50);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Главная</h2>

      {/* Предупреждения о ТСД на ремонте */}
      {repairsWithMembers.length > 0 && (
        <div className="rounded-xl p-4 mb-6" style={{ backgroundColor: COLORS.alertBg }}>
          <div className="flex items-start gap-3 mb-3">
            <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: '#ffc107' }} />
            <div>
              <h3 className="font-semibold" style={{ color: COLORS.heading }}>Есть пользователи у которых ТСД на ремонте</h3>
            </div>
          </div>
          <div className="space-y-2 ml-8">
            {repairsWithMembers.map(({ repair, member, tsd }) => member && tsd && (
              <div key={repair.id} className="flex items-center gap-4 text-sm">
                <span className="font-medium" style={{ color: COLORS.heading }}>{member.fio}</span>
                <span style={{ color: COLORS.text }}>ТСД №{tsd.number}</span>
                <span style={{ color: COLORS.text }}>({repair.description})</span>
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${repair.status === 'На ремонте' ? 'bg-yellow-200 text-yellow-800' : 'bg-blue-100 text-blue-800'}`}>
                  {repair.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Последние логи */}
      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold" style={{ color: COLORS.heading }}>Последние действия</h3>
          <button onClick={() => onNavigate('logs')} className="text-sm hover:underline" style={{ color: COLORS.primary }}>
            Все логи →
          </button>
        </div>
        <div className="max-h-96 overflow-y-auto space-y-2" style={{ scrollbarWidth: 'thin' }}>
          {recentLogs.map(log => (
            <div key={log.id} className="flex items-center gap-3 py-2 border-b last:border-b-0 text-sm" style={{ borderColor: '#f0f0f0' }}>
              <Clock className="w-3.5 h-3.5 flex-shrink-0" style={{ color: COLORS.text }} />
              <span className="flex-shrink-0 whitespace-nowrap" style={{ color: COLORS.text }}>{formatDateTime(log.date)}</span>
              <span style={{ color: COLORS.heading }}>{log.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// СПИСОК СОТРУДНИКОВ
// =====================================================================
const MembersPage = ({ members, groups, tsds, kkms, onEdit, onNavigate }: {
  members: Member[]; groups: Group[]; tsds: TSD[]; kkms: KKM[]; onEdit: (id: number) => void; onNavigate: (page: PageId) => void;
}) => {
  // Сортировка сотрудников по должности (sort), затем по ФИО — как в оригинале
  const sortedMembers = useMemo(() => {
    return [...members].sort((a, b) => {
      const groupA = groups.find(g => g.id === a.groupId);
      const groupB = groups.find(g => g.id === b.groupId);
      // Сначала сортируем по sort группы должности
      const sortA = groupA?.sort ?? 999;
      const sortB = groupB?.sort ?? 999;
      if (sortA !== sortB) return sortA - sortB;
      // Внутри одной группы — по ФИО
      return a.fio.localeCompare(b.fio, 'ru');
    });
  }, [members, groups]);

  // Копирование текста в буфер обмена
  const copyToClipboard = (text: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Не открывать редактирование при клике на кнопку
    navigator.clipboard.writeText(text).catch(() => {
      // Фоллбэк для старых браузеров
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    });
  };

  // Получить отображаемое значение для колонки ТСД/ККМ
  const getTsdKkmDisplay = (member: Member): string => {
    const tsd = getTsd(member.tsdId, tsds);
    const kkm = getKkm(member.kkmId, kkms);
    if (tsd) return String(tsd.number); // Показать номер ТСД
    if (kkm) return `ККМ №${kkm.number}`; // Если ТСД нет, показать ККМ
    return 'Отсутствует'; // Если ничего не привязано
  };

  // Открыть PDF-бейдж сотрудника в новой вкладке
  const openBadgePdf = (member: Member, e: React.MouseEvent) => {
    e.stopPropagation(); // Не открывать редактирование при клике на кнопку
    const tsd = getTsd(member.tsdId, tsds);
    const tsdNumber = tsd ? String(tsd.number) : '';
    // Формируем URL к API-маршруту генерации бейджа
    const params = new URLSearchParams({
      fio: member.fio,
      login: member.login,
      password: member.password,
      tsdNumber: tsdNumber,
    });
    window.open(`/api/badge?${params.toString()}`, '_blank');
  };

  return (
    <div>
      {/* Заголовок с кнопками «Должности» и «Добавить сотрудника» — как в оригинале */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Сотрудники</h2>
        <div className="flex items-center gap-2">
          {/* Кнопка перехода к должностям */}
          <button
            onClick={() => onNavigate('groups')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: COLORS.primary, color: COLORS.primary }}
          >
            <Briefcase className="w-3.5 h-3.5" /> Должности
          </button>
          {/* Кнопка добавления сотрудника */}
          <button
            onClick={() => onNavigate('member-add')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#198754', color: '#198754' }}
          >
            <Plus className="w-3.5 h-3.5" /> Добавить сотрудника
          </button>
        </div>
      </div>

      {/* Таблица сотрудников — как в оригинальном сайте (table-striped table-hover) */}
      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            {/* Шапка таблицы */}
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Должность</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>ТСД/ККМ</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Логин</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Действия</th>
              </tr>
            </thead>
            <tbody>
              {sortedMembers.length > 0 ? sortedMembers.map((member, idx) => (
                <tr
                  key={member.id}
                  onClick={() => onEdit(member.id)}
                  className="cursor-pointer transition-colors"
                  style={{
                    backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa', // Зебра (striped)
                    borderBottom: '1px solid #dee2e6',
                  }}
                  onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'} // Hover-эффект
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                >
                  {/* Колонка ФИО */}
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{member.fio}</td>
                  {/* Колонка Должность */}
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{getGroupName(member.groupId, groups)}</td>
                  {/* Колонка ТСД/ККМ */}
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{getTsdKkmDisplay(member)}</td>
                  {/* Колонка Логин — клик копирует в буфер */}
                  <td className="px-4 py-3">
                    <span
                      title="Скопировать логин"
                      onClick={e => copyToClipboard(member.login, e)}
                      className="cursor-pointer hover:underline inline-flex items-center gap-1"
                      style={{ color: COLORS.primary }}
                    >
                      {member.login}
                      <Copy className="w-3 h-3 opacity-50" />
                    </span>
                  </td>
                  {/* Колонка Действия */}
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1">
                      {/* Кнопка «Скопировать пароль» (ключ) — как в оригинале btn-primary */}
                      <button
                        title="Скопировать пароль"
                        onClick={e => copyToClipboard(member.password, e)}
                        className="p-1.5 rounded text-white transition hover:opacity-80"
                        style={{ backgroundColor: COLORS.primary }}
                      >
                        <Key className="w-3.5 h-3.5" />
                      </button>
                      {/* Кнопка «Печать бейджа» — как в оригинале btn-success, открывает PDF в новой вкладке */}
                      <button
                        title="Печать бейджа"
                        onClick={e => openBadgePdf(member, e)}
                        className="p-1.5 rounded text-white transition hover:opacity-80"
                        style={{ backgroundColor: '#198754' }}
                      >
                        <Heading className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                /* Если сотрудников нет */
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет данных</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// РЕДАКТИРОВАНИЕ / ДОБАВЛЕНИЕ СОТРУДНИКА
// =====================================================================
const MemberEditPage = ({ memberId, members, groups, tsds, kkms, onSave, onDelete, onNavigate }: {
  memberId: number | null; members: Member[]; groups: Group[]; tsds: TSD[]; kkms: KKM[];
  onSave: (member: Member) => void; onDelete: (id: number) => void; onNavigate: (page: PageId) => void;
}) => {
  const isNew = memberId === null;
  const existing = isNew ? null : members.find(m => m.id === memberId);

  // Состояние формы
  const [form, setForm] = useState<Member>({
    id: existing?.id || Date.now(),
    fio: existing?.fio || '',
    login: existing?.login || '',
    password: existing?.password || '',
    email: existing?.email || '',
    emailPassword: existing?.emailPassword || '',
    groupId: existing?.groupId || 1,
    tsdId: existing?.tsdId || null,
    kkmId: existing?.kkmId || null,
    tg: existing?.tg || '',
  });

  // Обновление поля формы
  const updateField = (field: keyof Member, value: string | number | boolean | null) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  // Сохранение сотрудника
  const handleSave = () => {
    if (!form.fio || !form.login) return;
    onSave({ ...form, id: isNew ? Date.now() : form.id });
    onNavigate('members');
  };

  // Удаление сотрудника
  const handleDelete = () => {
    if (memberId && confirm('Удалить сотрудника?')) {
      onDelete(memberId);
      onNavigate('members');
    }
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Сотрудники', page: 'members', onNavigate },
        { label: isNew ? 'Добавить' : 'Редактировать', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isNew ? 'Добавить сотрудника' : `Редактировать: ${existing?.fio}`}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          {/* ФИО */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ФИО *</label>
            <input type="text" value={form.fio} onChange={e => updateField('fio', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          {/* Логин */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин *</label>
            <input type="text" value={form.login} onChange={e => updateField('login', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          {/* Пароль */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль *</label>
            <input type="text" value={form.password} onChange={e => updateField('password', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          {/* Почта */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Почта *</label>
            <input type="text" value={form.email} onChange={e => updateField('email', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          {/* Пароль от почты */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль от почты *</label>
            <input type="text" value={form.emailPassword} onChange={e => updateField('emailPassword', e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
          </div>

          {/* Группа/Должность */}
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Группа / Должность</label>
            <select value={form.groupId} onChange={e => updateField('groupId', Number(e.target.value))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }}>
              {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>

          {/* ТСД (радиокнопки) */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>ТСД</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
              {/* Пустой выбор */}
              <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.tsdId === null ? COLORS.primary : '#dee2e6' }}>
                <input type="radio" name="tsd" checked={form.tsdId === null} onChange={() => updateField('tsdId', null)} className="accent-[#3a57e8]" />
                <span className="text-sm" style={{ color: COLORS.text }}>Нет</span>
              </label>
              {tsds.map(tsd => (
                <label key={tsd.id} className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.tsdId === tsd.id ? COLORS.primary : '#dee2e6' }}>
                  <input type="radio" name="tsd" checked={form.tsdId === tsd.id} onChange={() => updateField('tsdId', tsd.id)} className="accent-[#3a57e8]" />
                  <span className="text-sm" style={{ color: COLORS.heading }}>№{tsd.number}</span>
                  <span className="text-xs" style={{ color: COLORS.text }}>{tsd.model}</span>
                </label>
              ))}
            </div>
          </div>

          {/* ККМ (радиокнопки) */}
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.heading }}>ККМ</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.kkmId === null ? COLORS.primary : '#dee2e6' }}>
                <input type="radio" name="kkm" checked={form.kkmId === null} onChange={() => updateField('kkmId', null)} className="accent-[#3a57e8]" />
                <span className="text-sm" style={{ color: COLORS.text }}>Нет</span>
              </label>
              {kkms.map(kkm => (
                <label key={kkm.id} className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer hover:bg-gray-50" style={{ borderColor: form.kkmId === kkm.id ? COLORS.primary : '#dee2e6' }}>
                  <input type="radio" name="kkm" checked={form.kkmId === kkm.id} onChange={() => updateField('kkmId', kkm.id)} className="accent-[#3a57e8]" />
                  <span className="text-sm" style={{ color: COLORS.heading }}>№{kkm.number}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Кнопки действий */}
          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            {!isNew && (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700 text-sm font-medium flex items-center gap-1">
                <Trash2 className="w-4 h-4" /> Удалить
              </button>
            )}
            <button onClick={handleSave} className="ml-auto flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// СПИСОК ТСД
// =====================================================================
const TSDListPage = ({ tsds, members, onNavigate }: { tsds: TSD[]; members: Member[]; onNavigate: (page: PageId) => void }) => {
  // Открыть PDF-наклейку на ТСД в новой вкладке
  const openStickerPdf = (tsd: TSD) => {
    const assignedMembers = members.filter(m => m.tsdId === tsd.id);
    const memberFio = assignedMembers.length > 0 ? assignedMembers[0].fio : '';
    // Формируем URL к API-маршруту генерации наклейки
    const params = new URLSearchParams({
      number: String(tsd.number),
      fio: memberFio,
      sn: tsd.sn,
      inv: tsd.inv,
    });
    window.open(`/api/sticker?${params.toString()}`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>ТСД</h2>
        <button onClick={() => onNavigate('tsd-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {tsds.map(tsd => {
          // Найти сотрудников, привязанных к данному ТСД
          const assignedMembers = members.filter(m => m.tsdId === tsd.id);
          return (
            <div key={tsd.id} className="bg-white rounded-xl shadow p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold" style={{ color: COLORS.heading }}>ТСД №{tsd.number}</h4>
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2 py-0.5 rounded" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>{tsd.model}</span>
                  {/* Кнопка «Наклейка» — открывает PDF в новой вкладке */}
                  <button
                    title="Наклейка на ТСД"
                    onClick={() => openStickerPdf(tsd)}
                    className="p-1 rounded text-white transition hover:opacity-80"
                    style={{ backgroundColor: '#198754' }}
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-sm" style={{ color: COLORS.text }}>С/N: {tsd.sn}</p>
              <p className="text-sm" style={{ color: COLORS.text }}>Инв. №: {tsd.inv}</p>
              <p className="text-sm mt-1" style={{ color: assignedMembers.length > 0 ? COLORS.heading : '#dc3545' }}>
                {assignedMembers.length > 0 ? assignedMembers.map(m => m.login).join(', ') : 'Отсутствует'}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// =====================================================================
// ДОБАВЛЕНИЕ ТСД
// =====================================================================
const TSDAddPage = ({ onSave, onNavigate }: { onSave: (tsd: TSD) => void; onNavigate: (page: PageId) => void }) => {
  const [form, setForm] = useState({ number: '', sn: '', inv: '', model: 'МС-32N0 +' });

  const handleSave = () => {
    const num = parseInt(form.number);
    if (!num || !form.sn) return;
    onSave({ id: Date.now(), number: num, sn: form.sn, inv: form.inv, model: form.model, isMulti: false });
    onNavigate('tsd-list');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'ТСД', page: 'tsd-list', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ТСД</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
          <input type="number" value={form.number} onChange={e => setForm(p => ({ ...p, number: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер *</label>
          <input type="text" value={form.sn} onChange={e => setForm(p => ({ ...p, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инвентарный номер</label>
          <input type="text" value={form.inv} onChange={e => setForm(p => ({ ...p, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Модель</label>
          <select value={form.model} onChange={e => setForm(p => ({ ...p, model: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            <option>МС-32N0 +</option><option>МС-3190</option><option>RK25-2DSR</option>
          </select>
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
};

// =====================================================================
// РЕМОНТЫ ТСД
// =====================================================================
const RepairsPage = ({ repairs, tsds, members, onNavigate }: { repairs: Repair[]; tsds: TSD[]; members: Member[]; onNavigate: (page: PageId) => void }) => (
  <div>
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Ремонты ТСД</h2>
      <button onClick={() => onNavigate('tsd-repair-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
        <Plus className="w-4 h-4" /> Добавить
      </button>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {repairs.map(repair => {
        const tsd = tsds.find(t => t.id === repair.tsdId);
        const member = members.find(m => m.tsdId === repair.tsdId);
        return (
          <div key={repair.id} className="bg-white rounded-xl shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold" style={{ color: COLORS.heading }}>
                ТСД №{tsd?.number || '?'} {tsd ? `(${tsd.model})` : ''}
              </h4>
              <span className={`text-xs px-2 py-0.5 rounded font-medium ${repair.status === 'На ремонте' ? 'bg-yellow-200 text-yellow-800' : repair.status === 'Возвращён' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                {repair.status}
              </span>
            </div>
            {member && <p className="text-sm" style={{ color: COLORS.text }}>Сотрудник: {member.fio}</p>}
            <p className="text-sm" style={{ color: COLORS.text }}>Описание: {repair.description}</p>
            <div className="flex gap-4 text-xs mt-2" style={{ color: COLORS.text }}>
              <span>Сломан: {formatDate(repair.brokenDate)}</span>
              <span>Отправлен: {formatDate(repair.sentDate)}</span>
              <span>Возвращён: {formatDate(repair.returnedDate)}</span>
            </div>
            {repair.warranty && <span className="text-xs mt-1 inline-block px-2 py-0.5 bg-green-100 text-green-700 rounded">Гарантия</span>}
          </div>
        );
      })}
    </div>
  </div>
);

// =====================================================================
// ДОБАВЛЕНИЕ РЕМОНТА
// =====================================================================
const RepairAddPage = ({ tsds, onSave, onNavigate }: { tsds: TSD[]; onSave: (r: Repair) => void; onNavigate: (page: PageId) => void }) => {
  const [form, setForm] = useState({ tsdId: '', brokenDate: '', description: '', warranty: false });

  const handleSave = () => {
    const tsdId = parseInt(form.tsdId);
    if (!tsdId || !form.brokenDate) return;
    onSave({
      id: Date.now(), tsdId, brokenDate: form.brokenDate, sentDate: form.brokenDate,
      returnedDate: '', status: 'На ремонте', description: form.description, warranty: form.warranty,
    });
    onNavigate('tsd-repairs');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ремонт</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ТСД *</label>
          <select value={form.tsdId} onChange={e => setForm(p => ({ ...p, tsdId: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            <option value="">Выберите ТСД</option>
            {tsds.map(t => <option key={t.id} value={t.id}>№{t.number} ({t.model})</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата поломки *</label>
          <input type="date" value={form.brokenDate} onChange={e => setForm(p => ({ ...p, brokenDate: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Описание поломки</label>
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} rows={3} />
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.warranty} onChange={e => setForm(p => ({ ...p, warranty: e.target.checked }))} className="w-4 h-4 accent-[#3a57e8]" />
          <span className="text-sm" style={{ color: COLORS.heading }}>Гарантия</span>
        </label>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
};

// =====================================================================
// ПОЛУЧИТЬ СЗ (служебную записку)
// =====================================================================
const RepairSZPage = ({ repairs, tsds, onNavigate }: { repairs: Repair[]; tsds: TSD[]; onNavigate: (page: PageId) => void }) => {
  const activeRepairs = repairs.filter(r => r.status !== 'Возвращён');
  return (
    <div>
      <Breadcrumbs items={[{ label: 'Ремонты', page: 'tsd-repairs', onNavigate }, { label: 'Получить СЗ', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Получить служебную записку</h2>
      <div className="bg-white rounded-xl shadow p-6">
        {activeRepairs.length === 0 ? (
          <p style={{ color: COLORS.text }}>Нет активных ремонтов для создания СЗ</p>
        ) : (
          <div className="space-y-4">
            {activeRepairs.map(r => {
              const tsd = tsds.find(t => t.id === r.tsdId);
              return (
                <div key={r.id} className="border rounded-lg p-4" style={{ borderColor: '#dee2e6' }}>
                  <h4 className="font-semibold mb-2" style={{ color: COLORS.heading }}>
                    СЗ: ТСД №{tsd?.number} — {r.description}
                  </h4>
                  <p className="text-sm" style={{ color: COLORS.text }}>Дата поломки: {formatDate(r.brokenDate)}</p>
                  <p className="text-sm" style={{ color: COLORS.text }}>Модель: {tsd?.model}</p>
                  <p className="text-sm" style={{ color: COLORS.text }}>С/N: {tsd?.sn}</p>
                  <button className="mt-3 flex items-center gap-2 px-4 py-1.5 text-white rounded-lg text-sm hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
                    <Printer className="w-4 h-4" /> Печать СЗ
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

// =====================================================================
// СПИСОК ККМ
// =====================================================================
const KKMListPage = ({ kkms, members, onNavigate }: { kkms: KKM[]; members: Member[]; onNavigate: (page: PageId) => void }) => (
  <div>
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>ККМ</h2>
      <button onClick={() => onNavigate('kkm-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
        <Plus className="w-4 h-4" /> Добавить
      </button>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
      {kkms.map(kkm => {
        const assignedMembers = members.filter(m => m.kkmId === kkm.id);
        return (
          <div key={kkm.id} className="bg-white rounded-xl shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold" style={{ color: COLORS.heading }}>ККМ №{kkm.number}</h4>
            </div>
            <p className="text-sm" style={{ color: COLORS.text }}>С/N: {kkm.sn}</p>
            <p className="text-sm" style={{ color: COLORS.text }}>Инв. №: {kkm.inv}</p>
            <p className="text-sm mt-1" style={{ color: assignedMembers.length > 0 ? COLORS.heading : '#dc3545' }}>
              {assignedMembers.length > 0 ? assignedMembers.map(m => m.login).join(', ') : 'Отсутствует'}
            </p>
          </div>
        );
      })}
    </div>
  </div>
);

// =====================================================================
// ДОБАВЛЕНИЕ ККМ
// =====================================================================
const KKMAddPage = ({ onSave, onNavigate }: { onSave: (kkm: KKM) => void; onNavigate: (page: PageId) => void }) => {
  const [form, setForm] = useState({ number: '', sn: '', inv: '' });

  const handleSave = () => {
    const num = parseInt(form.number);
    if (!num || !form.sn) return;
    onSave({ id: Date.now(), number: num, sn: form.sn, inv: form.inv, isMulti: false });
    onNavigate('kkm-list');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'ККМ', page: 'kkm-list', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить ККМ</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
          <input type="number" value={form.number} onChange={e => setForm(p => ({ ...p, number: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер *</label>
          <input type="text" value={form.sn} onChange={e => setForm(p => ({ ...p, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инвентарный номер</label>
          <input type="text" value={form.inv} onChange={e => setForm(p => ({ ...p, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
};

// =====================================================================
// ДОЛЖНОСТИ
// =====================================================================
const GroupsPage = ({ groups, onNavigate }: { groups: Group[]; onNavigate: (page: PageId) => void }) => (
  <div>
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Должности</h2>
      <button onClick={() => onNavigate('group-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
        <Plus className="w-4 h-4" /> Добавить
      </button>
    </div>
    <div className="bg-white rounded-xl shadow overflow-hidden">
      <table className="w-full">
        <thead>
          <tr style={{ backgroundColor: COLORS.alertBg }}>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ID</th>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Название</th>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Сортировка</th>
          </tr>
        </thead>
        <tbody>
          {groups.sort((a, b) => a.sort - b.sort).map(g => (
            <tr key={g.id} className="border-t" style={{ borderColor: '#f0f0f0' }}>
              <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.id}</td>
              <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{g.name}</td>
              <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.sort}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

// =====================================================================
// ДОБАВЛЕНИЕ ДОЛЖНОСТИ
// =====================================================================
const GroupAddPage = ({ onSave, onNavigate }: { onSave: (g: Group) => void; onNavigate: (page: PageId) => void }) => {
  const [name, setName] = useState('');
  const [sort, setSort] = useState('16');

  const handleSave = () => {
    if (!name) return;
    onSave({ id: Date.now(), name, sort: parseInt(sort) || 16 });
    onNavigate('groups');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Должности', page: 'groups', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить должность</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Название *</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Сортировка</label>
          <input type="number" value={sort} onChange={e => setSort(e.target.value)} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
};

// =====================================================================
// СТАТИСТИКА — СТАРШИЕ
// =====================================================================
const StatStarshiePage = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Статистика — Старшие</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>ОПТ</th>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>КОР</th>
              </tr>
            </thead>
            <tbody>
              {['Петрова М.С.', 'Козлова А.В.', 'Волкова Е.Д.'].map((name, i) => (
                <tr key={i}>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.heading }}>{name}</td>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.text }}>{['Соколова О.И.', 'Михайлова Т.А.', ''][i]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// СТАТИСТИКА — КЛАДОВЩИКИ
// =====================================================================
const StatKladovshikiPage = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Статистика — Кладовщики</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Дата</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Должность</th>
                <th className="border px-4 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Кол-во</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Морозов И.А.', pos: 'Кладовщик ОПТ', count: 245 },
                { name: 'Лебедев А.В.', pos: 'Кл. контролер ОПТ', count: 189 },
                { name: 'Кузнецова Н.Д.', pos: 'Кл. комплектовщик', count: 312 },
              ].map((row, i) => (
                <tr key={i}>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.heading }}>{row.name}</td>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.text }}>{row.pos}</td>
                  <td className="border px-4 py-2 text-sm" style={{ color: COLORS.heading }}>{row.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// ИМПОРТ WMS
// =====================================================================
const ImportWMSPage = () => {
  const [file13, setFile13] = useState<string>('');
  const [file49, setFile49] = useState<string>('');

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Импорт WMS</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-6">
        {/* Загрузка 13 отчёта */}
        <div>
          <h3 className="font-semibold mb-2" style={{ color: COLORS.heading }}>13 отчёт (XML)</h3>
          <input type="file" accept=".xml" onChange={e => setFile13(e.target.files?.[0]?.name || '')} className="w-full text-sm" style={{ color: COLORS.text }} />
          {file13 && <p className="text-sm mt-1" style={{ color: COLORS.primary }}>Выбран: {file13}</p>}
          <button className="mt-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Upload className="w-4 h-4 inline mr-1" /> Загрузить 13 отчёт
          </button>
        </div>

        {/* Загрузка 49 отчёта */}
        <div className="border-t pt-6" style={{ borderColor: '#e9ecef' }}>
          <h3 className="font-semibold mb-2" style={{ color: COLORS.heading }}>49 отчёт (XML)</h3>
          <input type="file" accept=".xml" onChange={e => setFile49(e.target.files?.[0]?.name || '')} className="w-full text-sm" style={{ color: COLORS.text }} />
          {file49 && <p className="text-sm mt-1" style={{ color: COLORS.primary }}>Выбран: {file49}</p>}
          <button className="mt-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Upload className="w-4 h-4 inline mr-1" /> Загрузить 49 отчёт
          </button>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// ИНСТРУМЕНТЫ — КАЛЬКУЛЯТОР ЯЧЕЕК
// =====================================================================
const ToolsPage = () => {
  const [inputs, setInputs] = useState({
    prodLen: '', prodWid: '', prodHei: '',
    cellLen: '', cellWid: '', cellHei: '',
    kr3: '', heightPercent: '10',
  });

  // Автоматический расчёт количества штук
  const result = useMemo(() => {
    const pL = parseFloat(inputs.prodLen) || 0;
    const pW = parseFloat(inputs.prodWid) || 0;
    const pH = parseFloat(inputs.prodHei) || 0;
    const cL = parseFloat(inputs.cellLen) || 0;
    const cW = parseFloat(inputs.cellWid) || 0;
    const cH = parseFloat(inputs.cellHei) || 0;
    const kr3 = parseFloat(inputs.kr3) || 1;
    const hPct = parseFloat(inputs.heightPercent) || 0;

    if (!pL || !pW || !pH || !cL || !cW || !cH) return 0;

    // Уменьшаем высоту ячейки на указанный процент
    const effectiveHeight = cH * (1 - hPct / 100);
    // Расчёт количества по каждому измерению
    const byLen = Math.floor(cL / pL);
    const byWid = Math.floor(cW / pW);
    const byHei = Math.floor(effectiveHeight / pH);
    // Итого в ячейке
    return byLen * byWid * byHei * kr3;
  }, [inputs]);

  // Обновление поля
  const updateInput = (key: string, value: string) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Инструменты</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.heading }}>
          <Calculator className="w-5 h-5" style={{ color: COLORS.primary }} /> Калькулятор вместимости ячейки
        </h3>
        <div className="grid grid-cols-2 gap-4">
          {/* Параметры товара */}
          <div>
            <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Товар</h4>
            <div className="space-y-2">
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Длина товара</label>
                <input type="number" value={inputs.prodLen} onChange={e => updateInput('prodLen', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Ширина товара</label>
                <input type="number" value={inputs.prodWid} onChange={e => updateInput('prodWid', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Высота товара</label>
                <input type="number" value={inputs.prodHei} onChange={e => updateInput('prodHei', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
            </div>
          </div>

          {/* Параметры ячейки */}
          <div>
            <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Ячейка</h4>
            <div className="space-y-2">
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Длина ячейки</label>
                <input type="number" value={inputs.cellLen} onChange={e => updateInput('cellLen', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Ширина ячейки</label>
                <input type="number" value={inputs.cellWid} onChange={e => updateInput('cellWid', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Высота ячейки</label>
                <input type="number" value={inputs.cellHei} onChange={e => updateInput('cellHei', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
              </div>
            </div>
          </div>
        </div>

        {/* Дополнительные параметры */}
        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Кол-во в КР3</label>
            <input type="number" value={inputs.kr3} onChange={e => updateInput('kr3', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: COLORS.text }}>% вычитаемый из высоты</label>
            <input type="number" value={inputs.heightPercent} onChange={e => updateInput('heightPercent', e.target.value)} className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none" style={{ borderColor: '#dee2e6' }} />
          </div>
        </div>

        {/* Результат расчёта */}
        <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Кол-во шт.</label>
          <input type="text" value={result} disabled className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white" style={{ borderColor: '#dee2e6', color: COLORS.primary }} />
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// ЛОГИ
// =====================================================================
const LogsPage = ({ logs, admins }: { logs: LogEntry[]; admins: AdminUser[] }) => {
  const [page, setPage] = useState(1);
  const perPage = 30;
  const totalPages = Math.ceil(logs.length / perPage);
  const pagedLogs = logs.slice((page - 1) * perPage, page * perPage);

  // Получить ФИО администратора по ID
  const getAdminName = (id: number) => admins.find(a => a.id === id)?.fio || 'Неизвестный';

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Логи</h2>
      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Дата/Время</th>
                <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Действие</th>
              </tr>
            </thead>
            <tbody>
              {pagedLogs.map(log => (
                <tr key={log.id} className="border-t hover:bg-gray-50" style={{ borderColor: '#f0f0f0' }}>
                  <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{getAdminName(log.adminId)}</td>
                  <td className="px-4 py-3 text-sm whitespace-nowrap" style={{ color: COLORS.text }}>{formatDateTime(log.date)}</td>
                  <td className="px-4 py-3 text-sm" style={{ color: COLORS.heading }}>{log.text}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Пагинация */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 p-4 border-t" style={{ borderColor: '#f0f0f0' }}>
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1.5 text-sm rounded-lg border disabled:opacity-50 hover:bg-gray-50" style={{ borderColor: '#dee2e6' }}>
              ←
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)} className={`px-3 py-1.5 text-sm rounded-lg border ${p === page ? 'text-white' : 'hover:bg-gray-50'}`} style={p === page ? { backgroundColor: COLORS.primary, borderColor: COLORS.primary } : { borderColor: '#dee2e6', color: COLORS.heading }}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1.5 text-sm rounded-lg border disabled:opacity-50 hover:bg-gray-50" style={{ borderColor: '#dee2e6' }}>
              →
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// =====================================================================
// ПЕЧАТЬ — РЕЕСТР ТСД
// =====================================================================
const PrintTSDPage = ({ tsds, members }: { tsds: TSD[]; members: Member[] }) => (
  <div>
    <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Реестр ТСД</h2>
    <div className="bg-white rounded-xl shadow p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Printer className="w-4 h-4" /> Печать
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>№</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Модель</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>С/N</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Инв. №</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
            </tr>
          </thead>
          <tbody>
            {tsds.map(tsd => {
              const assigned = members.filter(m => m.tsdId === tsd.id).map(m => m.fio).join(', ');
              return (
                <tr key={tsd.id}>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.heading }}>{tsd.number}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.model}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.sn}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{tsd.inv}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: assigned ? COLORS.heading : '#dc3545' }}>{assigned || 'Отсутствует'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

// =====================================================================
// ПЕЧАТЬ — РЕЕСТР ККМ
// =====================================================================
const PrintKKMPage = ({ kkms, members }: { kkms: KKM[]; members: Member[] }) => (
  <div>
    <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Реестр ККМ</h2>
    <div className="bg-white rounded-xl shadow p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Printer className="w-4 h-4" /> Печать
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>№</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>С/N</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Инв. №</th>
              <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
            </tr>
          </thead>
          <tbody>
            {kkms.map(kkm => {
              const assigned = members.filter(m => m.kkmId === kkm.id).map(m => m.fio).join(', ');
              return (
                <tr key={kkm.id}>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.heading }}>{kkm.number}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{kkm.sn}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{kkm.inv}</td>
                  <td className="border px-3 py-2 text-sm" style={{ color: assigned ? COLORS.heading : '#dc3545' }}>{assigned || 'Отсутствует'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

// =====================================================================
// ПЕЧАТЬ — НАКЛЕЙКИ ТСД
// =====================================================================
const PrintStickersPage = ({ tsds }: { tsds: TSD[] }) => (
  <div>
    <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Наклейки ТСД</h2>
    <div className="bg-white rounded-xl shadow p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Printer className="w-4 h-4" /> Печать
        </button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {tsds.map(tsd => (
          <div key={tsd.id} className="border-2 border-dashed p-4 text-center rounded-lg" style={{ borderColor: '#dee2e6' }}>
            <div className="text-2xl font-bold mb-1" style={{ color: COLORS.primary }}>ТСД №{tsd.number}</div>
            <div className="text-sm" style={{ color: COLORS.text }}>{tsd.model}</div>
            <div className="text-xs mt-1 font-mono" style={{ color: COLORS.text }}>{tsd.sn}</div>
            {/* Штрихкод-заглушка */}
            <div className="mt-2 h-8 flex items-center justify-center" style={{ backgroundColor: '#f8f9fa' }}>
              <Hash className="w-4 h-4" style={{ color: COLORS.text }} />
              <span className="text-xs font-mono ml-1" style={{ color: COLORS.text }}>{tsd.inv}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// =====================================================================
// ПЕЧАТЬ — ШТРИХКОД
// =====================================================================
const PrintBarcodePage = () => {
  const [barcode, setBarcode] = useState('');
  const [generated, setGenerated] = useState<string[]>([]);

  const handleGenerate = () => {
    if (!barcode) return;
    setGenerated(prev => [...prev, barcode]);
    setBarcode('');
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Штрихкод</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <div className="flex gap-2 mb-4">
          <input type="text" value={barcode} onChange={e => setBarcode(e.target.value)} placeholder="Введите штрихкод" className="flex-1 px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} onKeyDown={e => e.key === 'Enter' && handleGenerate()} />
          <button onClick={handleGenerate} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Tag className="w-4 h-4" /> Генерировать
          </button>
        </div>
        {generated.length > 0 && (
          <div className="space-y-3">
            {generated.map((code, i) => (
              <div key={i} className="flex items-center justify-between p-3 border rounded-lg" style={{ borderColor: '#dee2e6' }}>
                <div>
                  <div className="font-mono text-lg" style={{ color: COLORS.heading }}>{code}</div>
                  {/* Визуальное представление штрихкода */}
                  <div className="flex gap-0.5 mt-1">
                    {code.split('').map((char, ci) => (
                      <div key={ci} className="flex gap-px">
                        {Array.from({ length: 4 }, (_, bi) => (
                          <div key={bi} className={`${(char.charCodeAt(0) + bi) % 2 === 0 ? 'bg-black' : 'bg-white'} ${bi < 2 ? 'w-0.5' : 'w-1'} h-6`} />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
                <button onClick={() => window.print()} className="p-2 rounded-lg hover:bg-gray-100" style={{ color: COLORS.primary }}>
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// =====================================================================
// ПЕЧАТЬ — КОНТЕЙНЕРЫ
// =====================================================================
const PrintContainersPage = () => {
  const [containerNum, setContainerNum] = useState('');
  const [containers, setContainers] = useState<string[]>([]);

  const handleAdd = () => {
    if (!containerNum) return;
    setContainers(prev => [...prev, containerNum]);
    setContainerNum('');
  };

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Контейнеры</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg">
        <div className="flex gap-2 mb-4">
          <input type="text" value={containerNum} onChange={e => setContainerNum(e.target.value)} placeholder="Номер контейнера" className="flex-1 px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} onKeyDown={e => e.key === 'Enter' && handleAdd()} />
          <button onClick={handleAdd} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Box className="w-4 h-4" /> Добавить
          </button>
        </div>
        {containers.length > 0 && (
          <>
            <div className="flex justify-end mb-3">
              <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
                <Printer className="w-4 h-4" /> Печать
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {containers.map((c, i) => (
                <div key={i} className="border-2 border-dashed p-4 text-center rounded-lg" style={{ borderColor: '#dee2e6' }}>
                  <div className="text-xl font-bold" style={{ color: COLORS.primary }}>Контейнер</div>
                  <div className="text-3xl font-bold mt-2" style={{ color: COLORS.heading }}>{c}</div>
                  {/* Визуальный штрихкод-заглушка */}
                  <div className="flex gap-0.5 justify-center mt-2">
                    {c.split('').map((char, ci) => (
                      <div key={ci} className="flex gap-px">
                        {Array.from({ length: 4 }, (_, bi) => (
                          <div key={bi} className={`${(char.charCodeAt(0) + bi) % 2 === 0 ? 'bg-black' : 'bg-white'} ${bi < 2 ? 'w-0.5' : 'w-1'} h-8`} />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// =====================================================================
// НАСТРОЙКИ — ПОЛЬЗОВАТЕЛИ
// =====================================================================
const SettingsUsersPage = ({ admins, groups, onNavigate }: { admins: AdminUser[]; groups: Group[]; onNavigate: (page: PageId) => void }) => (
  <div>
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Пользователи системы</h2>
      <button onClick={() => onNavigate('settings-user-add')} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
        <Plus className="w-4 h-4" /> Добавить пользователя
      </button>
    </div>
    <div className="bg-white rounded-xl shadow overflow-hidden">
      <table className="w-full">
        <thead>
          <tr style={{ backgroundColor: COLORS.alertBg }}>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Должность</th>
            <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Роль</th>
          </tr>
        </thead>
        <tbody>
          {admins.map(admin => (
            <tr key={admin.id} className="border-t hover:bg-gray-50" style={{ borderColor: '#f0f0f0' }}>
              <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{admin.fio}</td>
              <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{getGroupName(admin.groupId, groups)}</td>
              <td className="px-4 py-3">
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${admin.role === 'Админ' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'}`}>
                  {admin.role}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

// =====================================================================
// НАСТРОЙКИ — ДОБАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯ
// =====================================================================
const SettingsUserAddPage = ({ onSave, onNavigate }: { onSave: (u: AdminUser) => void; onNavigate: (page: PageId) => void }) => {
  const [form, setForm] = useState({ fio: '', login: '', password: '', role: 'Пользователь', groupId: 1 });

  const handleSave = () => {
    if (!form.fio || !form.login) return;
    onSave({ id: Date.now(), fio: form.fio, login: form.login, hash: '', role: form.role, groupId: form.groupId });
    onNavigate('settings-users');
  };

  return (
    <div>
      <Breadcrumbs items={[{ label: 'Пользователи', page: 'settings-users', onNavigate }, { label: 'Добавить', onNavigate }]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Добавить пользователя</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-lg space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>ФИО *</label>
          <input type="text" value={form.fio} onChange={e => setForm(p => ({ ...p, fio: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Логин *</label>
          <input type="text" value={form.login} onChange={e => setForm(p => ({ ...p, login: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Пароль *</label>
          <input type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Роль</label>
          <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            <option>Админ</option><option>Пользователь</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Должность</label>
          <select value={form.groupId} onChange={e => setForm(p => ({ ...p, groupId: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none" style={{ borderColor: '#dee2e6' }}>
            {INITIAL_GROUPS.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
        <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
          <Save className="w-4 h-4" /> Сохранить
        </button>
      </div>
    </div>
  );
};

// =====================================================================
// ГЛАВНЫЙ КОМПОНЕНТ ПРИЛОЖЕНИЯ
// =====================================================================
export default function SamsonSkladApp() {
  // Состояние навигации
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  // Состояние данных
  const [members, setMembers] = useState<Member[]>(INITIAL_MEMBERS);
  const [groups, setGroups] = useState<Group[]>(INITIAL_GROUPS);
  const [tsds, setTsds] = useState<TSD[]>(INITIAL_TSDS);
  const [kkms, setKkms] = useState<KKM[]>(INITIAL_KKMS);
  const [repairs, setRepairs] = useState<Repair[]>(INITIAL_REPAIRS);
  const [logs, setLogs] = useState<LogEntry[]>(INITIAL_LOGS);
  const [admins, setAdmins] = useState<AdminUser[]>(INITIAL_ADMINS);

  // ID редактируемого сотрудника
  const [editingMemberId, setEditingMemberId] = useState<number | null>(null);

  // Проверка авторизации из localStorage при загрузке
  // Используем ленивую инициализацию состояния вместо эффекта
  const [authUser, setAuthUser] = useState<AdminUser | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('samson_auth');
      if (stored) {
        try { return JSON.parse(stored); } catch { localStorage.removeItem('samson_auth'); }
      }
    }
    return null;
  });
  const [authChecked, setAuthChecked] = useState<boolean>(typeof window === 'undefined' ? false : true);

  // Обработка входа в систему
  const handleLogin = useCallback((user: AdminUser) => {
    setAuthUser(user);
    // Добавить запись о входе в логи
    setLogs(prev => [{
      id: Date.now(), adminId: user.id, text: 'Вход в систему',
      date: new Date().toISOString(),
    }, ...prev]);
  }, []);

  // Обработка выхода из системы
  const handleLogout = useCallback(() => {
    setAuthUser(null);
    setProfileOpen(false);
    setCurrentPage('home');
    localStorage.removeItem('samson_auth');
  }, []);

  // Навигация на страницу
  const navigate = useCallback((page: PageId) => {
    setCurrentPage(page);
    setProfileOpen(false);
  }, []);

  // Сохранение сотрудника
  const handleSaveMember = useCallback((member: Member) => {
    setMembers(prev => {
      const exists = prev.find(m => m.id === member.id);
      if (exists) {
        return prev.map(m => m.id === member.id ? member : m);
      }
      return [...prev, member];
    });
    setLogs(prev => [{
      id: Date.now(), adminId: authUser?.id || 1,
      text: exists(prev => prev.find(m => m.id === member.id))
        ? `Редактирование сотрудника: ${member.fio}`
        : `Добавление сотрудника: ${member.fio}`,
      date: new Date().toISOString(),
    }, ...prev]);
  }, [authUser]);

  // Удаление сотрудника
  const handleDeleteMember = useCallback((id: number) => {
    const member = members.find(m => m.id === id);
    setMembers(prev => prev.filter(m => m.id !== id));
    if (member) {
      setLogs(prev => [{
        id: Date.now(), adminId: authUser?.id || 1,
        text: `Удаление сотрудника: ${member.fio}`,
        date: new Date().toISOString(),
      }, ...prev]);
    }
  }, [members, authUser]);

  // Сохранение ТСД
  const handleSaveTSD = useCallback((tsd: TSD) => {
    setTsds(prev => [...prev, tsd]);
    setLogs(prev => [{
      id: Date.now(), adminId: authUser?.id || 1,
      text: `Добавление ТСД №${tsd.number}`,
      date: new Date().toISOString(),
    }, ...prev]);
  }, [authUser]);

  // Сохранение ККМ
  const handleSaveKKM = useCallback((kkm: KKM) => {
    setKkms(prev => [...prev, kkm]);
    setLogs(prev => [{
      id: Date.now(), adminId: authUser?.id || 1,
      text: `Добавление ККМ №${kkm.number}`,
      date: new Date().toISOString(),
    }, ...prev]);
  }, [authUser]);

  // Сохранение ремонта
  const handleSaveRepair = useCallback((repair: Repair) => {
    setRepairs(prev => [...prev, repair]);
    setLogs(prev => [{
      id: Date.now(), adminId: authUser?.id || 1,
      text: `Добавление ремонта ТСД`,
      date: new Date().toISOString(),
    }, ...prev]);
  }, [authUser]);

  // Сохранение должности
  const handleSaveGroup = useCallback((group: Group) => {
    setGroups(prev => [...prev, group]);
  }, []);

  // Сохранение пользователя
  const handleSaveAdmin = useCallback((admin: AdminUser) => {
    setAdmins(prev => [...prev, admin]);
    setLogs(prev => [{
      id: Date.now(), adminId: authUser?.id || 1,
      text: `Добавление пользователя: ${admin.login}`,
      date: new Date().toISOString(),
    }, ...prev]);
  }, [authUser]);

  // Загрузка страницы — показать спиннер пока проверяем авторизацию
  if (!authChecked) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: COLORS.bodyBg }}>
        <div className="w-8 h-8 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
      </div>
    );
  }

  // Если не авторизован — показать страницу входа
  if (!authUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Рендер содержимого текущей страницы
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} onNavigate={navigate} />;
      case 'members':
        return <MembersPage members={members} groups={groups} tsds={tsds} kkms={kkms} onEdit={id => { setEditingMemberId(id); navigate('member-edit'); }} onNavigate={navigate} />;
      case 'member-add':
        return <MemberEditPage memberId={null} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'member-edit':
        return <MemberEditPage memberId={editingMemberId} members={members} groups={groups} tsds={tsds} kkms={kkms} onSave={handleSaveMember} onDelete={handleDeleteMember} onNavigate={navigate} />;
      case 'groups':
        return <GroupsPage groups={groups} onNavigate={navigate} />;
      case 'group-add':
        return <GroupAddPage onSave={handleSaveGroup} onNavigate={navigate} />;
      case 'tsd-list':
        return <TSDListPage tsds={tsds} members={members} onNavigate={navigate} />;
      case 'tsd-add':
        return <TSDAddPage onSave={handleSaveTSD} onNavigate={navigate} />;
      case 'tsd-repairs':
        return <RepairsPage repairs={repairs} tsds={tsds} members={members} onNavigate={navigate} />;
      case 'tsd-repair-add':
        return <RepairAddPage tsds={tsds} onSave={handleSaveRepair} onNavigate={navigate} />;
      case 'tsd-repair-sz':
        return <RepairSZPage repairs={repairs} tsds={tsds} onNavigate={navigate} />;
      case 'kkm-list':
        return <KKMListPage kkms={kkms} members={members} onNavigate={navigate} />;
      case 'kkm-add':
        return <KKMAddPage onSave={handleSaveKKM} onNavigate={navigate} />;
      case 'stat-starshie':
        return <StatStarshiePage />;
      case 'stat-kladovshiki':
        return <StatKladovshikiPage />;
      case 'stat-import':
        return <ImportWMSPage />;
      case 'tools':
        return <ToolsPage />;
      case 'logs':
        return <LogsPage logs={logs} admins={admins} />;
      case 'print-tsd':
        return <PrintTSDPage tsds={tsds} members={members} />;
      case 'print-kkm':
        return <PrintKKMPage kkms={kkms} members={members} />;
      case 'print-stickers':
        return <PrintStickersPage tsds={tsds} />;
      case 'print-barcode':
        return <PrintBarcodePage />;
      case 'print-containers':
        return <PrintContainersPage />;
      case 'settings-users':
        return <SettingsUsersPage admins={admins} groups={groups} onNavigate={navigate} />;
      case 'settings-user-add':
        return <SettingsUserAddPage onSave={handleSaveAdmin} onNavigate={navigate} />;
      default:
        return <HomePage members={members} tsds={tsds} repairs={repairs} groups={groups} logs={logs} onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: COLORS.bodyBg }}>
      <div className="flex flex-1">
        {/* Боковое меню */}
        <Sidebar currentPage={currentPage} onNavigate={navigate} isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Основная область контента */}
        <div className="flex-1 lg:ml-[260px]">
          {/* Верхняя панель */}
          <header className="bg-white shadow-sm px-4 py-3 flex items-center justify-between sticky top-0 z-30">
            <div className="flex items-center gap-3">
              {/* Кнопка меню для мобильных */}
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100">
                <Menu className="w-5 h-5" style={{ color: COLORS.heading }} />
              </button>
            </div>

            {/* Профиль пользователя */}
            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition"
              >
                <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold" style={{ backgroundColor: COLORS.primary }}>
                  {authUser.fio.charAt(0)}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                  <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                </div>
                <ChevronDown className="w-4 h-4" style={{ color: COLORS.text }} />
              </button>

              {/* Выпадающее меню профиля */}
              {profileOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border py-2 w-48 z-50" style={{ borderColor: '#e9ecef' }}>
                  <div className="px-4 py-2 border-b" style={{ borderColor: '#f0f0f0' }}>
                    <div className="text-sm font-medium" style={{ color: COLORS.heading }}>{authUser.fio}</div>
                    <div className="text-xs" style={{ color: COLORS.text }}>{getGroupName(authUser.groupId, groups)}</div>
                  </div>
                  <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 transition">
                    <LogOut className="w-4 h-4" /> Выход
                  </button>
                </div>
              )}
            </div>
          </header>

          {/* Контент страницы */}
          <main className="p-4 md:p-6 flex-1">
            {renderPage()}
          </main>

          {/* Подвал */}
          <footer className="px-4 py-3 text-center text-sm border-t mt-auto" style={{ color: COLORS.text, borderColor: '#e9ecef' }}>
            © 2023-2026 Made with ❤ by Philipp Shklyaev.
          </footer>
        </div>
      </div>
    </div>
  );
}

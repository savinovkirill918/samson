import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/cartridge-models
export async function GET() {
  try {
    const models = await prisma.cartridgeModel.findMany({
      include: { cartridges: true },
      orderBy: { name: 'asc' }
    })
    return NextResponse.json(models)
  } catch (error) {
    console.error('Error fetching cartridge models:', error)
    return NextResponse.json({ error: 'Ошибка получения моделей картриджей' }, { status: 500 })
  }
}

// POST /api/cartridge-models
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const model = await prisma.cartridgeModel.create({
      data: {
        name: body.name,
        printerModel: body.printerModel,
        expectedYield: body.expectedYield ?? 0,
        maxRefills: body.maxRefills ?? 3,
      }
    })
    return NextResponse.json(model, { status: 201 })
  } catch (error) {
    console.error('Error creating cartridge model:', error)
    return NextResponse.json({ error: 'Ошибка создания модели картриджа' }, { status: 500 })
  }
}

// PUT /api/cartridge-models
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const model = await prisma.cartridgeModel.update({
      where: { id: body.id },
      data: {
        name: body.name,
        printerModel: body.printerModel,
        expectedYield: body.expectedYield ?? 0,
        maxRefills: body.maxRefills ?? 3,
      }
    })
    return NextResponse.json(model)
  } catch (error) {
    console.error('Error updating cartridge model:', error)
    return NextResponse.json({ error: 'Ошибка обновления модели картриджа' }, { status: 500 })
  }
}

// DELETE /api/cartridge-models?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.cartridgeModel.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting cartridge model:', error)
    return NextResponse.json({ error: 'Ошибка удаления модели картриджа' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/printer-consumption
export async function GET() {
  try {
    const consumption = await prisma.printerConsumption.findMany({
      include: { printer: true },
      orderBy: [{ month: 'desc' }, { printerId: 'asc' }]
    })
    return NextResponse.json(consumption)
  } catch (error) {
    console.error('Error fetching printer consumption:', error)
    return NextResponse.json({ error: 'Ошибка получения расхода принтеров' }, { status: 500 })
  }
}

// POST /api/printer-consumption
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const record = await prisma.printerConsumption.create({
      data: {
        printerId: body.printerId,
        month: body.month,
        pages: body.pages ?? 0,
        copies: body.copies ?? 0,
        notes: body.notes ?? '',
      }
    })
    return NextResponse.json(record, { status: 201 })
  } catch (error) {
    console.error('Error creating printer consumption:', error)
    return NextResponse.json({ error: 'Ошибка создания записи расхода' }, { status: 500 })
  }
}

// PUT /api/printer-consumption
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const record = await prisma.printerConsumption.update({
      where: { id: body.id },
      data: {
        printerId: body.printerId,
        month: body.month,
        pages: body.pages ?? 0,
        copies: body.copies ?? 0,
        notes: body.notes ?? '',
      }
    })
    return NextResponse.json(record)
  } catch (error) {
    console.error('Error updating printer consumption:', error)
    return NextResponse.json({ error: 'Ошибка обновления записи расхода' }, { status: 500 })
  }
}

// DELETE /api/printer-consumption?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.printerConsumption.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting printer consumption:', error)
    return NextResponse.json({ error: 'Ошибка удаления записи расхода' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/printers
export async function GET() {
  try {
    const printers = await prisma.printer.findMany({
      include: { members: true, repairs: true, consumptions: true, cartridges: { include: { cartridgeModel: true } } },
      orderBy: { number: 'asc' }
    })
    return NextResponse.json(printers)
  } catch (error) {
    console.error('Error fetching printers:', error)
    return NextResponse.json({ error: 'Ошибка получения принтеров' }, { status: 500 })
  }
}

// POST /api/printers
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const printer = await prisma.printer.create({
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        model: body.model ?? '',
        type: body.type ?? 'thermal',
        location: body.location ?? '',
        ipAddress: body.ipAddress ?? '',
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(printer, { status: 201 })
  } catch (error) {
    console.error('Error creating printer:', error)
    return NextResponse.json({ error: 'Ошибка создания принтера' }, { status: 500 })
  }
}

// PUT /api/printers
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const printer = await prisma.printer.update({
      where: { id: body.id },
      data: {
        number: body.number,
        sn: body.sn,
        inv: body.inv,
        model: body.model ?? '',
        type: body.type ?? 'thermal',
        location: body.location ?? '',
        ipAddress: body.ipAddress ?? '',
        isMulti: body.isMulti ?? false,
      }
    })
    return NextResponse.json(printer)
  } catch (error) {
    console.error('Error updating printer:', error)
    return NextResponse.json({ error: 'Ошибка обновления принтера' }, { status: 500 })
  }
}

// DELETE /api/printers?id=N
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number(searchParams.get('id'))
    await prisma.printer.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting printer:', error)
    return NextResponse.json({ error: 'Ошибка удаления принтера' }, { status: 500 })
  }
}

import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/cartridges/summary — агрегированная сводка по остаткам
export async function GET() {
  try {
    const models = await prisma.cartridgeModel.findMany({
      include: { cartridges: true },
      orderBy: { name: 'asc' }
    })

    const summary = models.map(model => {
      const cartridges = model.cartridges
      return {
        cartridgeModel: {
          id: model.id,
          name: model.name,
          printerModel: model.printerModel,
          expectedYield: model.expectedYield,
          maxRefills: model.maxRefills,
        },
        total: cartridges.length,
        onStock: cartridges.filter(c => c.status === 0).length,
        inUse: cartridges.filter(c => c.status === 1).length,
        needsRefill: cartridges.filter(c => c.status === 2).length,
        refilling: cartridges.filter(c => c.status === 3).length,
        writtenOff: cartridges.filter(c => c.status === 4).length,
      }
    })

    return NextResponse.json(summary)
  } catch (error) {
    console.error('Error fetching cartridge summary:', error)
    return NextResponse.json({ error: 'Ошибка получения сводки картриджей' }, { status: 500 })
  }
}

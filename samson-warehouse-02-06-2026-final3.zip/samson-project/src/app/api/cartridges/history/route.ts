import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// POST /api/cartridges/history — добавить запись в историю + обновить статус картриджа
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { cartridgeId, action, printerId, date, notes } = body

    // Получаем текущий картридж с моделью (для maxRefills)
    const cartridge = await prisma.cartridge.findUnique({
      where: { id: cartridgeId },
      include: { cartridgeModel: true }
    })

    if (!cartridge) {
      return NextResponse.json({ error: 'Картридж не найден' }, { status: 404 })
    }

    // Определяем новый статус и refillsCount в зависимости от действия
    let newStatus = cartridge.status
    let newRefillsCount = cartridge.refillsCount
    let newPrinterId = cartridge.printerId

    switch (action) {
      case 'installed':
        newStatus = 1  // В работе
        newPrinterId = printerId ?? null
        break
      case 'removed':
        newStatus = 0  // На остатке
        newPrinterId = null
        break
      case 'sent_refill':
        newStatus = 3  // В заправке
        newRefillsCount += 1
        newPrinterId = null
        break
      case 'returned_refill':
        // Автосписание: если количество заправок >= maxRefills → списать
        if (newRefillsCount >= (cartridge.cartridgeModel?.maxRefills ?? 3)) {
          newStatus = 4  // Списан
        } else {
          newStatus = 0  // На остатке
        }
        break
      case 'written_off':
        newStatus = 4  // Списан
        newPrinterId = null
        break
    }

    // Обновляем картридж
    await prisma.cartridge.update({
      where: { id: cartridgeId },
      data: {
        status: newStatus,
        refillsCount: newRefillsCount,
        printerId: newPrinterId,
      }
    })

    // Создаём запись в истории
    const historyEntry = await prisma.cartridgeHistory.create({
      data: {
        cartridgeId,
        action,
        printerId: printerId ?? null,
        date: date || new Date().toISOString(),
        notes: notes ?? '',
      }
    })

    return NextResponse.json(historyEntry, { status: 201 })
  } catch (error) {
    console.error('Error creating cartridge history:', error)
    return NextResponse.json({ error: 'Ошибка создания записи истории' }, { status: 500 })
  }
}

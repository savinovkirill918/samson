'use client';

import { useState, useEffect, useCallback } from 'react';
import type { PrinterConsumption } from '@/lib/types';
import * as api from '@/lib/api';

export function usePrinterConsumption() {
  const [consumption, setConsumption] = useState<PrinterConsumption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConsumption = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getPrinterConsumption();
      setConsumption(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки расхода');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchConsumption(); }, [fetchConsumption]);

  const saveConsumption = useCallback(async (record: { printerId: number; month: string; pages: number; copies: number; notes?: string }) => {
    await api.createPrinterConsumption(record);
    await fetchConsumption();
  }, [fetchConsumption]);

  const updateConsumption = useCallback(async (record: Partial<PrinterConsumption> & { id: number }) => {
    await api.updatePrinterConsumption(record);
    await fetchConsumption();
  }, [fetchConsumption]);

  return { consumption, loading, error, saveConsumption, updateConsumption, refetch: fetchConsumption };
}

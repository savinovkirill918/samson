'use client';

import { useState, useEffect, useCallback } from 'react';
import type { CartridgeModel } from '@/lib/types';
import * as api from '@/lib/api';

export function useCartridgeModels() {
  const [models, setModels] = useState<CartridgeModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchModels = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getCartridgeModels();
      setModels(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки моделей картриджей');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchModels(); }, [fetchModels]);

  const saveModel = useCallback(async (model: { name: string; printerModel: string; expectedYield: number; maxRefills: number }) => {
    await api.createCartridgeModel(model);
    await fetchModels();
  }, [fetchModels]);

  const updateModel = useCallback(async (model: Partial<CartridgeModel> & { id: number }) => {
    await api.updateCartridgeModel(model);
    await fetchModels();
  }, [fetchModels]);

  return { models, loading, error, saveModel, updateModel, refetch: fetchModels };
}

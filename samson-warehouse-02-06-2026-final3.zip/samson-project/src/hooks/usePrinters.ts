'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Printer } from '@/lib/types';
import * as api from '@/lib/api';

export function usePrinters() {
  const [printers, setPrinters] = useState<Printer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchPrinters = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getPrinters();
      setPrinters(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки принтеров');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPrinters(); }, [fetchPrinters]);

  const savePrinter = useCallback(async (printer: { number: number; sn: string; inv: string; model: string; type: string; location: string; ipAddress: string; isMulti: boolean }) => {
    await api.createPrinter(printer);
    await fetchPrinters();
  }, [fetchPrinters]);

  const updatePrinter = useCallback(async (printer: Partial<Printer> & { id: number }) => {
    await api.updatePrinter(printer);
    await fetchPrinters();
  }, [fetchPrinters]);

  return { printers, loading, error, savePrinter, updatePrinter, refetch: fetchPrinters };
}

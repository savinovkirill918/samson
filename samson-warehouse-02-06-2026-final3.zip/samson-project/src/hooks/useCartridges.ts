'use client';

import { useState, useEffect, useCallback } from 'react';
import type { Cartridge, CartridgeSummary } from '@/lib/types';
import * as api from '@/lib/api';

export function useCartridges() {
  const [cartridges, setCartridges] = useState<Cartridge[]>([]);
  const [summary, setSummary] = useState<CartridgeSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCartridges = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getCartridges();
      setCartridges(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки картриджей');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchSummary = useCallback(async () => {
    try {
      const data = await api.getCartridgeSummary();
      setSummary(data);
    } catch (err) {
      console.error('Error fetching cartridge summary:', err);
    }
  }, []);

  useEffect(() => {
    fetchCartridges();
    fetchSummary();
  }, [fetchCartridges, fetchSummary]);

  const saveCartridge = useCallback(async (cartridge: { cartridgeModelId: number; status?: number; notes?: string }) => {
    await api.createCartridge(cartridge);
    await fetchCartridges();
    await fetchSummary();
  }, [fetchCartridges, fetchSummary]);

  const updateCartridge = useCallback(async (cartridge: Partial<Cartridge> & { id: number }) => {
    await api.updateCartridge(cartridge);
    await fetchCartridges();
    await fetchSummary();
  }, [fetchCartridges, fetchSummary]);

  /** Выполнить действие с картриджем (установить/снять/заправка/списание) */
  const doAction = useCallback(async (data: { cartridgeId: number; action: string; printerId?: number | null; date?: string; notes?: string }) => {
    await api.createCartridgeHistory(data);
    await fetchCartridges();
    await fetchSummary();
  }, [fetchCartridges, fetchSummary]);

  return { cartridges, summary, loading, error, saveCartridge, updateCartridge, doAction, refetch: fetchCartridges, refetchSummary: fetchSummary };
}

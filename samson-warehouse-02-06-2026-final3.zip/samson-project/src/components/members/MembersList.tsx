'use client';

import React, { useMemo } from 'react';
import { Briefcase, Plus, Key, Heading, Copy } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Member, Group, TSD, KKM, Printer, PageId } from '@/lib/types';
import { getGroupName, getTsd, getKkm, getPrinter } from '@/lib/helpers';

interface MembersListProps {
  members: Member[];
  groups: Group[];
  tsds: TSD[];
  kkms: KKM[];
  printers: Printer[];
  onEdit: (id: number) => void;
  onNavigate: (page: PageId) => void;
}

export default function MembersList({ members, groups, tsds, kkms, printers, onEdit, onNavigate }: MembersListProps) {
  const sortedMembers = useMemo(() => {
    return [...members].sort((a, b) => {
      const groupA = groups.find(g => g.id === a.groupId);
      const groupB = groups.find(g => g.id === b.groupId);
      const sortA = groupA?.sort ?? 999;
      const sortB = groupB?.sort ?? 999;
      if (sortA !== sortB) return sortA - sortB;
      return a.fio.localeCompare(b.fio, 'ru');
    });
  }, [members, groups]);

  const copyToClipboard = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text).catch(() => {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    });
  };

  const getTsdKkmPrinterDisplay = (member: Member): string => {
    const tsd = getTsd(member.tsdId, tsds);
    const kkm = getKkm(member.kkmId, kkms);
    const printer = getPrinter(member.printerId, printers);
    const parts: string[] = [];
    if (tsd) parts.push(`ТСД №${tsd.number}`);
    if (kkm) parts.push(`ККМ №${kkm.number}`);
    if (printer) parts.push(`Пр. №${printer.number}`);
    return parts.length > 0 ? parts.join(', ') : 'Отсутствует';
  };

  const openBadgePdf = (member: Member, e: React.MouseEvent) => {
    e.stopPropagation();
    const tsd = getTsd(member.tsdId, tsds);
    const tsdNumber = tsd ? String(tsd.number) : '';
    const params = new URLSearchParams({
      fio: member.fio,
      login: member.login,
      password: member.password,
      tsdNumber: tsdNumber,
    });
    window.open(`/api/badge?${params.toString()}`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Сотрудники</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('groups')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: COLORS.primary, color: COLORS.primary }}
          >
            <Briefcase className="w-3.5 h-3.5" /> Должности
          </button>
          <button
            onClick={() => onNavigate('member-add')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#198754', color: '#198754' }}
          >
            <Plus className="w-3.5 h-3.5" /> Добавить сотрудника
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>ФИО</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Должность</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>ТСД/ККМ/Принтер</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Логин</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Действия</th>
              </tr>
            </thead>
            <tbody>
              {sortedMembers.length > 0 ? sortedMembers.map((member, idx) => (
                <tr
                  key={member.id}
                  onClick={() => onEdit(member.id)}
                  className="cursor-pointer transition-colors"
                  style={{
                    backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                    borderBottom: '1px solid #dee2e6',
                  }}
                  onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                >
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{member.fio}</td>
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{getGroupName(member.groupId, groups)}</td>
                  <td className="px-4 py-3" style={{ color: COLORS.heading }}>{getTsdKkmPrinterDisplay(member)}</td>
                  <td className="px-4 py-3">
                    <span
                      title="Скопировать логин"
                      onClick={e => copyToClipboard(member.login, e)}
                      className="cursor-pointer hover:underline inline-flex items-center gap-1"
                      style={{ color: COLORS.primary }}
                    >
                      {member.login}
                      <Copy className="w-3 h-3 opacity-50" />
                    </span>
                  </td>
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1">
                      <button
                        title="Скопировать пароль"
                        onClick={e => copyToClipboard(member.password, e)}
                        className="p-1.5 rounded text-white transition hover:opacity-80"
                        style={{ backgroundColor: COLORS.primary }}
                      >
                        <Key className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Печать бейджа"
                        onClick={e => openBadgePdf(member, e)}
                        className="p-1.5 rounded text-white transition hover:opacity-80"
                        style={{ backgroundColor: '#198754' }}
                      >
                        <Heading className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет данных</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

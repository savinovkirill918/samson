'use client';

import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { CartridgeModel, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface CartridgeModelFormProps {
  editingModel?: CartridgeModel | null;
  onSave: (data: { name: string; printerModel: string; expectedYield: number; maxRefills: number }) => void;
  onUpdate?: (data: Partial<CartridgeModel> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function CartridgeModelForm({ editingModel, onSave, onUpdate, onNavigate }: CartridgeModelFormProps) {
  const isEdit = !!editingModel;

  const [form, setForm] = useState({
    name: editingModel?.name ?? '',
    printerModel: editingModel?.printerModel ?? '',
    expectedYield: editingModel?.expectedYield ?? 0,
    maxRefills: editingModel?.maxRefills ?? 3,
  });

  const handleSave = () => {
    if (!form.name) return;
    if (isEdit && onUpdate && editingModel) {
      onUpdate({ id: editingModel.id, ...form });
    } else {
      onSave(form);
    }
    onNavigate('cartridge-models');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Справочник', page: 'cartridge-models', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Редактировать: ${editingModel?.name}` : 'Добавить модель картриджа'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Название *</label>
            <input type="text" value={form.name} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} placeholder="HP CF217A" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Для модели принтера</label>
            <input type="text" value={form.printerModel} onChange={e => setForm(prev => ({ ...prev, printerModel: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} placeholder="HP LaserJet Pro MFP M130" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Ресурс (страниц)</label>
              <input type="number" value={form.expectedYield} onChange={e => setForm(prev => ({ ...prev, expectedYield: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Макс. заправок до списания</label>
              <input type="number" value={form.maxRefills} onChange={e => setForm(prev => ({ ...prev, maxRefills: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>
          <div className="pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

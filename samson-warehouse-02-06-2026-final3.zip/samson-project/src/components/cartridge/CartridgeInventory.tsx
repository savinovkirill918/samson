'use client';

import React, { useState } from 'react';
import { Plus, ChevronRight, ChevronDown, AlertTriangle } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { CartridgeSummary, Cartridge, Printer, PageId } from '@/lib/types';
import { cartridgeStatusText, cartridgeStatusColor } from '@/lib/helpers';

interface CartridgeInventoryProps {
  summary: CartridgeSummary[];
  cartridges: Cartridge[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEditCartridge: (cartridge: Cartridge) => void;
}

export default function CartridgeInventory({ summary, cartridges, printers, onNavigate, onEditCartridge }: CartridgeInventoryProps) {
  const [expandedModel, setExpandedModel] = useState<number | null>(null);

  // Totals
  const totals = summary.reduce((acc, s) => ({
    total: acc.total + s.total,
    onStock: acc.onStock + s.onStock,
    inUse: acc.inUse + s.inUse,
    needsRefill: acc.needsRefill + s.needsRefill,
    refilling: acc.refilling + s.refilling,
    writtenOff: acc.writtenOff + s.writtenOff,
  }), { total: 0, onStock: 0, inUse: 0, needsRefill: 0, refilling: 0, writtenOff: 0 });

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Сводка по картриджам</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('cartridge-models')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: COLORS.primary, color: COLORS.primary }}
          >
            Справочник
          </button>
          <button
            onClick={() => onNavigate('cartridge-add')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
            style={{ borderColor: '#198754', color: '#198754' }}
          >
            <Plus className="w-3.5 h-3.5" /> Добавить
          </button>
        </div>
      </div>

      {/* Alert for zero stock */}
      {summary.some(s => s.onStock === 0 && (s.inUse > 0 || s.needsRefill > 0)) && (
        <div className="rounded-xl p-4 mb-4 flex items-start gap-3" style={{ backgroundColor: '#fff3cd' }}>
          <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: '#664d03' }} />
          <div>
            <h3 className="font-semibold text-sm" style={{ color: '#664d03' }}>Нет картриджей на остатке:</h3>
            <div className="text-sm mt-1" style={{ color: '#664d03' }}>
              {summary.filter(s => s.onStock === 0 && (s.inUse > 0 || s.needsRefill > 0)).map(s => s.cartridgeModel.name).join(', ')}
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Модель</th>
              <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Для принтера</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Всего</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>На ост.</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>В работе</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Треб. запр.</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>На заправке</th>
              <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Списано</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {summary.map(s => {
              const isExpanded = expandedModel === s.cartridgeModel.id;
              const modelCartridges = cartridges.filter(c => c.cartridgeModelId === s.cartridgeModel.id);
              const isCritical = s.onStock === 0 && (s.inUse > 0 || s.needsRefill > 0);
              return (
                <React.Fragment key={s.cartridgeModel.id}>
                  <tr
                    onClick={() => setExpandedModel(isExpanded ? null : s.cartridgeModel.id)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: isCritical ? '#fff3cd' : '#ffffff',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = isCritical ? '#fff3cd' : '#ffffff'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>
                      {isCritical && <AlertTriangle className="w-3.5 h-3.5 inline mr-1" style={{ color: '#664d03' }} />}
                      {s.cartridgeModel.name}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>{s.cartridgeModel.printerModel}</td>
                    <td className="px-4 py-3 text-right font-medium" style={{ color: COLORS.heading }}>{s.total}</td>
                    <td className="px-4 py-3 text-right" style={{ color: s.onStock > 0 ? '#0f5132' : '#dc3545', fontWeight: s.onStock === 0 ? 700 : 400 }}>{s.onStock}</td>
                    <td className="px-4 py-3 text-right" style={{ color: '#084298' }}>{s.inUse}</td>
                    <td className="px-4 py-3 text-right" style={{ color: s.needsRefill > 0 ? '#664d03' : COLORS.text, fontWeight: s.needsRefill > 0 ? 700 : 400 }}>{s.needsRefill || ''}</td>
                    <td className="px-4 py-3 text-right" style={{ color: s.refilling > 0 ? '#9a4800' : COLORS.text }}>{s.refilling || ''}</td>
                    <td className="px-4 py-3 text-right" style={{ color: COLORS.text }}>{s.writtenOff || ''}</td>
                    <td className="px-4 py-1">
                      {isExpanded ? <ChevronDown className="w-4 h-4" style={{ color: COLORS.text }} /> : <ChevronRight className="w-4 h-4" style={{ color: COLORS.text }} />}
                    </td>
                  </tr>
                  {isExpanded && modelCartridges.length > 0 && (
                    <tr>
                      <td colSpan={9} className="px-4 py-3" style={{ backgroundColor: '#f8f9fa' }}>
                        <div className="space-y-1">
                          {modelCartridges.map(c => {
                            const statusStyle = cartridgeStatusColor(c.status);
                            const printerName = c.printerId ? printers.find(p => p.id === c.printerId) : null;
                            return (
                              <div
                                key={c.id}
                                onClick={e => { e.stopPropagation(); onEditCartridge(c); }}
                                className="flex items-center gap-3 p-2 rounded-lg cursor-pointer hover:bg-gray-100"
                              >
                                <span className="text-xs" style={{ color: COLORS.text }}>#{c.id}</span>
                                <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: statusStyle.bg, color: statusStyle.text }}>
                                  {cartridgeStatusText(c.status)}
                                </span>
                                {printerName && <span className="text-xs" style={{ color: COLORS.primary }}>Принтер №{printerName.number}</span>}
                                <span className="text-xs" style={{ color: COLORS.text }}>Заправки: {c.refillsCount}/{s.cartridgeModel.maxRefills}</span>
                                {c.notes && <span className="text-xs" style={{ color: COLORS.text }}>({c.notes})</span>}
                              </div>
                            );
                          })}
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              );
            })}
            {/* Totals row */}
            <tr style={{ backgroundColor: '#e9ecef', borderTop: '2px solid #dee2e6' }}>
              <td className="px-4 py-3 font-bold" style={{ color: COLORS.heading }}>ИТОГО</td>
              <td></td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: COLORS.heading }}>{totals.total}</td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: totals.onStock === 0 ? '#dc3545' : '#0f5132' }}>{totals.onStock}</td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: '#084298' }}>{totals.inUse}</td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: totals.needsRefill > 0 ? '#664d03' : COLORS.text }}>{totals.needsRefill || ''}</td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: COLORS.text }}>{totals.refilling || ''}</td>
              <td className="px-4 py-3 text-right font-bold" style={{ color: COLORS.text }}>{totals.writtenOff || ''}</td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { PrinterConsumption, Printer, PageId } from '@/lib/types';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterConsumptionPageProps {
  consumption: PrinterConsumption[];
  printers: Printer[];
  onNavigate: (page: PageId) => void;
  onEdit: (record: PrinterConsumption) => void;
}

export default function PrinterConsumptionPage({ consumption, printers, onNavigate, onEdit }: PrinterConsumptionPageProps) {
  const [filterMonth, setFilterMonth] = useState('');
  const [filterPrinter, setFilterPrinter] = useState<number>(0);

  const filtered = useMemo(() => {
    return consumption.filter(c => {
      if (filterMonth && c.month !== filterMonth) return false;
      if (filterPrinter && c.printerId !== filterPrinter) return false;
      return true;
    });
  }, [consumption, filterMonth, filterPrinter]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4 pb-3 border-b" style={{ borderColor: '#dee2e6' }}>
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Расход принтеров</h2>
        <button
          onClick={() => onNavigate('printer-consumption-add')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium border hover:opacity-80 transition"
          style={{ borderColor: '#198754', color: '#198754' }}
        >
          <Plus className="w-3.5 h-3.5" /> Добавить
        </button>
      </div>

      <div className="flex flex-wrap gap-3 mb-4">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: COLORS.text }}>Месяц</label>
          <input type="month" value={filterMonth} onChange={e => setFilterMonth(e.target.value)} className="px-3 py-1.5 border rounded-lg text-sm" style={{ borderColor: '#dee2e6' }} />
        </div>
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: COLORS.text }}>Принтер</label>
          <select value={filterPrinter} onChange={e => setFilterPrinter(Number(e.target.value))} className="px-3 py-1.5 border rounded-lg text-sm" style={{ borderColor: '#dee2e6' }}>
            <option value={0}>Все</option>
            {printers.map(p => <option key={p.id} value={p.id}>№{p.number} {p.model}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa', borderBottom: '2px solid #dee2e6' }}>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Период</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Принтер</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Страниц</th>
                <th className="text-right px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Копий</th>
                <th className="text-left px-4 py-3 font-semibold" style={{ color: COLORS.heading }}>Заметки</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length > 0 ? filtered.map((record, idx) => {
                const printer = printers.find(p => p.id === record.printerId);
                return (
                  <tr
                    key={record.id}
                    onClick={() => onEdit(record)}
                    className="cursor-pointer transition-colors"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onMouseEnter={e => e.currentTarget.style.backgroundColor = '#e9ecef'}
                    onMouseLeave={e => e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#ffffff' : '#f8f9fa'}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>{record.month}</td>
                    <td className="px-4 py-3" style={{ color: COLORS.heading }}>№{printer?.number} {printer?.model}</td>
                    <td className="px-4 py-3 text-right" style={{ color: COLORS.heading }}>{record.pages.toLocaleString('ru')}</td>
                    <td className="px-4 py-3 text-right" style={{ color: COLORS.heading }}>{record.copies.toLocaleString('ru')}</td>
                    <td className="px-4 py-3 max-w-xs truncate" style={{ color: COLORS.text }}>{record.notes || '—'}</td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center" style={{ color: COLORS.text }}>Нет данных</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

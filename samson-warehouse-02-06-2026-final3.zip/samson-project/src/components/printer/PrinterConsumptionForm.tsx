'use client';

import React, { useState, useEffect } from 'react';
import { COLORS } from '@/lib/colors';
import type { PrinterConsumption, Printer, PageId } from '@/lib/types';
import { currentMonth } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterConsumptionFormProps {
  editingRecord?: PrinterConsumption | null;
  printers: Printer[];
  onSave: (data: { printerId: number; month: string; pages: number; copies: number; notes: string }) => void;
  onUpdate?: (data: Partial<PrinterConsumption> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

export default function PrinterConsumptionForm({ editingRecord, printers, onSave, onUpdate, onNavigate }: PrinterConsumptionFormProps) {
  const isEdit = !!editingRecord;

  const [form, setForm] = useState({
    printerId: editingRecord?.printerId ?? printers[0]?.id ?? 0,
    month: editingRecord?.month ?? currentMonth(),
    pages: editingRecord?.pages ?? 0,
    copies: editingRecord?.copies ?? 0,
    notes: editingRecord?.notes ?? '',
  });

  const handleSave = () => {
    if (!form.printerId || !form.month) return;
    if (isEdit && onUpdate && editingRecord) {
      onUpdate({ id: editingRecord.id, ...form });
    } else {
      onSave(form);
    }
    onNavigate('printer-consumption');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Расход принтеров', page: 'printer-consumption', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? 'Редактировать расход' : 'Ввести расход за месяц'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Принтер</label>
              <select value={form.printerId} onChange={e => setForm(prev => ({ ...prev, printerId: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }}>
                {printers.map(p => <option key={p.id} value={p.id}>№{p.number} {p.model}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Месяц</label>
              <input type="month" value={form.month} onChange={e => setForm(prev => ({ ...prev, month: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Страниц</label>
              <input type="number" value={form.pages} onChange={e => setForm(prev => ({ ...prev, pages: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Копий</label>
              <input type="number" value={form.copies} onChange={e => setForm(prev => ({ ...prev, copies: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Заметки</label>
            <textarea value={form.notes} onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))} className="w-full px-4 py-2 border rounded-lg" style={{ borderColor: '#dee2e6' }} rows={2} />
          </div>

          <div className="pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            <button onClick={handleSave} className="flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useEffect } from 'react';
import { Save, Trash2 } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Printer, PageId } from '@/lib/types';
import { printerTypeText } from '@/lib/helpers';
import Breadcrumbs from '@/components/layout/Breadcrumbs';

interface PrinterFormProps {
  editingPrinterId?: number | null;
  printers?: Printer[];
  onSave: (data: { number: number; sn: string; inv: string; model: string; type: string; location: string; ipAddress: string; isMulti: boolean }) => void;
  onUpdate?: (data: Partial<Printer> & { id: number }) => void;
  onNavigate: (page: PageId) => void;
}

const PRINTER_TYPES = [
  { value: 'thermal', label: 'Термопринтер' },
  { value: 'label', label: 'Этикетки' },
  { value: 'laser', label: 'Лазерный' },
  { value: 'inkjet', label: 'Струйный' },
];

export default function PrinterForm({ editingPrinterId, printers, onSave, onUpdate, onNavigate }: PrinterFormProps) {
  const isEdit = !!editingPrinterId;
  const existing = isEdit && printers ? printers.find(p => p.id === editingPrinterId) : null;

  const [form, setForm] = useState({
    number: existing?.number ?? 0,
    sn: existing?.sn ?? '',
    inv: existing?.inv ?? '',
    model: existing?.model ?? '',
    type: existing?.type ?? 'thermal',
    location: existing?.location ?? '',
    ipAddress: existing?.ipAddress ?? '',
    isMulti: existing?.isMulti ?? false,
  });

  useEffect(() => {
    if (existing) {
      setForm({
        number: existing.number,
        sn: existing.sn,
        inv: existing.inv,
        model: existing.model,
        type: existing.type,
        location: existing.location,
        ipAddress: existing.ipAddress,
        isMulti: existing.isMulti,
      });
    }
  }, [existing]);

  const handleSave = () => {
    if (!form.number || !form.sn) return;
    if (isEdit && onUpdate && editingPrinterId) {
      onUpdate({ id: editingPrinterId, ...form });
    } else {
      onSave(form);
    }
    onNavigate('printer-list');
  };

  return (
    <div>
      <Breadcrumbs items={[
        { label: 'Принтеры', page: 'printer-list', onNavigate },
        { label: isEdit ? 'Редактировать' : 'Добавить', onNavigate },
      ]} />
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>
        {isEdit ? `Редактировать принтер №${existing?.number}` : 'Добавить принтер'}
      </h2>

      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Номер *</label>
              <input type="number" value={form.number} onChange={e => setForm(prev => ({ ...prev, number: Number(e.target.value) }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Тип</label>
              <select value={form.type} onChange={e => setForm(prev => ({ ...prev, type: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }}>
                {PRINTER_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Модель</label>
            <input type="text" value={form.model} onChange={e => setForm(prev => ({ ...prev, model: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="HP LaserJet Pro MFP M130" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Серийный номер *</label>
              <input type="text" value={form.sn} onChange={e => setForm(prev => ({ ...prev, sn: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Инв. номер</label>
              <input type="text" value={form.inv} onChange={e => setForm(prev => ({ ...prev, inv: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>IP-адрес</label>
            <input type="text" value={form.ipAddress} onChange={e => setForm(prev => ({ ...prev, ipAddress: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="192.168.1.50" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1" style={{ color: COLORS.heading }}>Место размещения</label>
            <input type="text" value={form.location} onChange={e => setForm(prev => ({ ...prev, location: e.target.value }))} className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2" style={{ borderColor: '#dee2e6' }} placeholder="Склад №3 / Офис" />
          </div>

          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isMulti} onChange={e => setForm(prev => ({ ...prev, isMulti: e.target.checked }))} className="accent-[#3a57e8] w-4 h-4" />
            <span className="text-sm" style={{ color: COLORS.heading }}>Множественное назначение (несколько сотрудников)</span>
          </label>

          <div className="flex items-center justify-between pt-4 border-t" style={{ borderColor: '#e9ecef' }}>
            <button onClick={handleSave} className="ml-auto flex items-center gap-2 px-6 py-2 text-white rounded-lg font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
              <Save className="w-4 h-4" /> Сохранить
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

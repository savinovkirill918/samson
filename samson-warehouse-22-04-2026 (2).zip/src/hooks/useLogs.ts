'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import type { LogEntry } from '@/lib/types';
import * as api from '@/lib/api';

export function useLogs() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const logsRef = useRef(logs);
  logsRef.current = logs;

  const fetchLogs = useCallback(async () => {
    try {
      const data = await api.getLogs(500, 0);
      setLogs(data);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ошибка загрузки логов');
    } finally {
      setLoading(false);
    }
  }, []);

  // Загрузка при монтировании
  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  // Автообновление каждые 5 секунд
  useEffect(() => {
    const interval = setInterval(() => {
      fetchLogs();
    }, 5000);
    return () => clearInterval(interval);
  }, [fetchLogs]);

  const addLog = useCallback(async (adminId: number, text: string) => {
    try {
      await api.createLog({ adminId, text });
    } catch {
      // Log errors are non-critical
    }
    // Сразу обновляем после добавления
    await fetchLogs();
  }, [fetchLogs]);

  return { logs, loading, error, addLog, refetch: fetchLogs };
}

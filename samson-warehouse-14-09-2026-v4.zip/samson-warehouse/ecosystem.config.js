// PM2-конфигурация для продакшена.
// Перед запуском измените пути на актуальные для вашего сервера:
//  - cwd — путь к директории проекта
//  - DATABASE_URL — абсолютный путь к файлу базы данных
module.exports = {
  apps: [
    {
      name: 'samson-warehouse',
      script: '.next/standalone/server.js',
      cwd: '/opt/samson-warehouse',                                // <-- путь к проекту
      env: {
        NODE_ENV: 'production',
        DATABASE_URL: 'file:/opt/samson-warehouse/db/custom.db',   // <-- абсолютный путь к БД
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      time: true,
      merge_logs: true,
    },
  ],
};

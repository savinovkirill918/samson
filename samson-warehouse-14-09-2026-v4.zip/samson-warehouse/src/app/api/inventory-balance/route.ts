import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import {
  parse1COstatki,
  parseExcelWms,
  compareInventory,
} from '@/lib/inventoryCompare';

/* ================================================================== */
/*  POST /api/inventory-balance                                         */
/*  Серверная сверка остатков (file1 — 1С, file2 — WMS).                */
/*  Основной сценарий приложения — клиентская сверка в браузере         */
/*  (InventoryBalancePage), этот роут остаётся для API-совместимости.   */
/* ================================================================== */
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file1 = formData.get('file1') as File | null;
    const file2 = formData.get('file2') as File | null;

    if (!file1 || !file2) {
      return NextResponse.json({ error: 'Необходимо загрузить оба файла' }, { status: 400 });
    }

    // Parse file 1 — Остатки товаров на складах (1С)
    const buf1 = await file1.arrayBuffer();
    const wb1 = XLSX.read(Buffer.from(buf1), { type: 'buffer', dense: true });
    const ws1 = wb1.Sheets[wb1.SheetNames[0]];
    if (!ws1) throw new Error('Не удалось прочитать лист из файла 1С');
    const raw1 = XLSX.utils.sheet_to_json(ws1, { header: 1, defval: '' }) as unknown[][];
    const data1c = parse1COstatki(raw1);

    if (data1c.length === 0) {
      return NextResponse.json({ error: 'Файл «Остатки товаров на складах» не содержит данных. Проверьте формат файла.' }, { status: 400 });
    }

    // Parse file 2 — WMS
    const buf2 = await file2.arrayBuffer();
    const wb2 = XLSX.read(Buffer.from(buf2), { type: 'buffer', dense: true });
    const ws2 = wb2.Sheets[wb2.SheetNames[0]];
    if (!ws2) throw new Error('Не удалось прочитать лист из файла WMS');
    const raw2 = XLSX.utils.sheet_to_json(ws2, { header: 1, defval: '' }) as unknown[][];
    const wmsData = parseExcelWms(raw2);

    if (wmsData.length === 0) {
      return NextResponse.json({ error: 'Файл «остатки товаров 31 отчет» не содержит данных. Проверьте формат файла.' }, { status: 400 });
    }

    // Сравнение
    const { results, stats } = compareInventory(data1c, wmsData);

    return NextResponse.json({ results, stats });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Внутренняя ошибка сервера';
    console.error('Inventory balance API error:', err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

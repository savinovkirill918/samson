/* ================================================================== */
/*  Учет остатков — общая логика парсинга и сверки                      */
/*  Используется и на сервере (api/inventory-balance), и на клиенте     */
/*  (InventoryBalancePage) — файлы можно сверять без загрузки на сервер */
/*  Зависимостей нет: функции принимают «сырые» массивы строк           */
/*  (результат XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' }))  */
/* ================================================================== */

/* ---------------------------- Types ---------------------------- */

/** Строка из файла 1С «Остатки товаров на складах» */
export interface Data1CRow {
  code: string;
  name: string;
  totalQty: number;
  mainQty: number;
  accountQty: number;
}

/** Строка из WMS-отчёта «остатки товаров 31 отчет» */
export interface WmsRow {
  code1c: string;
  name: string;
  room: string;
  availableQty: number;
  transitQty: number;
}

/** Строка результата сверки */
export interface ResultRow {
  num: number;
  code1c: string;
  name: string;
  glavnyQty: number;
  uchetQty: number;
  excelQty: number;
  wmsQty: number;
}

/** Статистика сверки */
export interface CompareStats {
  excelTotal: number;
  excelFiltered: number;
  wmsTotal: number;
  wmsAfterFilter: number;
  matchedCount: number;
}

export interface CompareResult {
  results: ResultRow[];
  stats: CompareStats;
}

/* ---------------------------- Helpers ---------------------------- */

/** Parse number from string — handles spaces like "1 000", commas, etc. */
export const parseNum = (v: unknown): number => {
  if (v === null || v === undefined) return 0;
  if (typeof v === 'number') return v;
  const s = String(v).trim();
  if (s === '' || s === '-' || s === '—') return 0;
  const cleaned = s.replace(/\s+/g, '').replace(',', '.');
  const n = Number(cleaned);
  return isNaN(n) ? 0 : n;
};

/* ================================================================== */
/*  Parse файла 1 (Остатки товаров на складах — выгрузка из 1С)         */
/*  Структура (1С, лист TDSheet):                                       */
/*    шапка отчёта → строка заголовков:                                 */
/*      col 0  = Артикул                                                */
/*      col 3  = Номенклатура                                           */
/*      col 9  = Ед. изм.                                               */
/*      col 10 = Итого                                                  */
/*      col 11 = ДЦ Казань                                              */
/*      col 12 = ДЦ Учет Казань                                         */
/*    далее строки данных, в хвосте — итоговые строки («Итого» и т.п.)  */
/* ================================================================== */
export const parse1COstatki = (raw: unknown[][]): Data1CRow[] => {
  if (raw.length < 8) {
    throw new Error('Файл «Остатки товаров на складах» содержит слишком мало строк. Проверьте формат файла.');
  }

  // --- Поиск строки заголовков: колонки «Артикул» и «Номенклатура» ---
  let headerRowIdx = -1;
  for (let i = 0; i < Math.min(30, raw.length); i++) {
    const row = raw[i] || [];
    const flat = row.map((c: unknown) => String(c ?? '').trim().toLowerCase());
    if (flat.includes('артикул') && flat.includes('номенклатура')) {
      headerRowIdx = i;
      break;
    }
  }
  if (headerRowIdx === -1) {
    throw new Error('Не найдена строка заголовков в файле 1С. Убедитесь, что колонка «Артикул» присутствует.');
  }

  const header = (raw[headerRowIdx] || []).map((c: unknown) => String(c ?? '').trim().toLowerCase());

  // --- Определение колонок ---
  const artIdx = header.findIndex(h => h === 'артикул');
  const nameIdx = header.findIndex(h => h === 'номенклатура');
  if (artIdx === -1 || nameIdx === -1) {
    throw new Error('В файле 1С не найдены колонки «Артикул» / «Номенклатура»');
  }

  // Колонки остатков: все, у которых в строке ниже стоит «Количество», кроме «Итого»
  const subRow = (raw[headerRowIdx + 1] || []).map((c: unknown) => String(c ?? '').trim().toLowerCase());
  const qtyCols: number[] = [];
  for (let c = 0; c < header.length; c++) {
    const h = header[c];
    if (!h || h === 'итого' || h === 'ед. изм.' || h === 'артикул' || h === 'номенклатура') continue;
    if (subRow[c] === 'количество' || h.includes('казань')) {
      qtyCols.push(c);
    }
  }

  // Склад «Учет» — колонка с «учет» в названии; склад «Главный» — первая прочая колонка остатков
  const uchetCol = qtyCols.find(c => header[c].includes('учет'));
  const glavnyCol = qtyCols.find(c => c !== uchetCol);

  // Колонка «Итого» — первая с таким заголовком
  const itogoCol = header.findIndex(h => h === 'итого');

  // --- Строки данных ---
  const results: Data1CRow[] = [];

  for (let i = headerRowIdx + 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row) continue;

    const code = String(row[artIdx] ?? '').trim();
    const name = String(row[nameIdx] ?? '').trim();

    // Строка данных: и Артикул, и Номенклатура непустые.
    // Итоговые строки хвоста («Итого», «Ед. изм.», «шт», пустые) отсеиваются.
    if (!code || !name) continue;
    if (code.toLowerCase() === 'итого' || code.toLowerCase() === 'артикул') continue;

    const mainQty = glavnyCol !== undefined && glavnyCol !== -1 ? parseNum(row[glavnyCol]) : 0;
    const accountQty = uchetCol !== undefined && uchetCol !== -1 ? parseNum(row[uchetCol]) : 0;

    // Итого: из колонки «Итого», при отсутствии — сумма складов
    let totalQty = itogoCol !== -1 ? parseNum(row[itogoCol]) : 0;
    if (!totalQty) totalQty = mainQty + accountQty;

    results.push({ code, name, totalQty, mainQty, accountQty });
  }

  return results;
};

/* ================================================================== */
/*  Parse файла 2 (WMS — остатки товаров 31 отчет)                      */
/*  Header: [Код 1С, Наименование, Ячейка хранения, Помещение, ...      */
/*           Доступное кол-во, Кол-во в транзите, ...]                  */
/* ================================================================== */
export const parseExcelWms = (raw: unknown[][]): WmsRow[] => {
  if (raw.length < 2) throw new Error('Файл WMS содержит слишком мало данных');

  // Validate header row
  const header = (raw[0] || []).map((h: unknown) => String(h ?? '').trim().toLowerCase());
  const codeIdx = header.findIndex(h => h.includes('код 1с') || h === 'код1с' || (h === 'код' && header.indexOf(h) === 0));
  const nameIdx = header.findIndex(h => h.includes('наименование'));
  const roomIdx = header.findIndex(h => h.includes('помещение'));
  const availIdx = header.findIndex(h => h.includes('доступное кол') || h.includes('доступное'));
  const transitIdx = header.findIndex(h => h.includes('транзит'));

  if (codeIdx === -1) throw new Error('Не найдена колонка «Код 1С» в файле WMS');
  if (roomIdx === -1) throw new Error('Не найдена колонка «Помещение» в файле WMS');
  if (availIdx === -1) throw new Error('Не найдена колонка «Доступное кол-во» в файле WMS');

  const results: WmsRow[] = [];

  for (let i = 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row || !row[codeIdx]) continue;

    const code1c = String(row[codeIdx]).trim();
    if (!code1c) continue;

    results.push({
      code1c,
      name: nameIdx >= 0 ? String(row[nameIdx] ?? '').trim() : '',
      room: roomIdx >= 0 ? String(row[roomIdx] ?? '').trim() : '',
      availableQty: availIdx >= 0 ? parseNum(row[availIdx]) : 0,
      transitQty: transitIdx >= 0 ? parseNum(row[transitIdx]) : 0,
    });
  }

  return results;
};

/* ================================================================== */
/*  Сравнение остатков                                                  */
/*  1С:   фильтр ДЦ Учет Казань > 0, Итого_1С = Итого (или сумма складов) */
/*  WMS:  исключить Помещение = BR/PACK, агрегация по Код 1С            */
/*  Итог: позиции где Итого_1С == Итого_WMS                             */
/* ================================================================== */
export const compareInventory = (data1c: Data1CRow[], wmsData: WmsRow[]): CompareResult => {
  // === Шаг 1: Обработка 1С ===
  const map1c = new Map<string, { itogo1c: number; mainQty: number; accountQty: number; name: string }>();

  for (const row of data1c) {
    if (row.accountQty <= 0) continue;
    const itogo1c = row.totalQty || (row.mainQty + row.accountQty);
    map1c.set(row.code, { itogo1c, mainQty: row.mainQty, accountQty: row.accountQty, name: row.name });
  }

  // === Шаг 2: Обработка WMS ===
  const wmsMap = new Map<string, { itogoWms: number; name: string }>();

  for (const row of wmsData) {
    if (row.room === 'BR' || row.room === 'PACK') continue;

    const existing = wmsMap.get(row.code1c);
    if (existing) {
      existing.itogoWms += row.availableQty;
    } else {
      wmsMap.set(row.code1c, {
        itogoWms: row.availableQty,
        name: row.name,
      });
    }
  }

  // === Шаг 3: Сравнение ===
  const results: ResultRow[] = [];
  let num = 0;

  for (const [code, info] of map1c) {
    const wmsInfo = wmsMap.get(code);
    if (!wmsInfo) continue;

    if (info.itogo1c === wmsInfo.itogoWms) {
      num++;
      results.push({
        num,
        code1c: code,
        name: wmsInfo.name || info.name,
        glavnyQty: info.mainQty,
        uchetQty: info.accountQty,
        excelQty: info.itogo1c,
        wmsQty: wmsInfo.itogoWms,
      });
    }
  }

  return {
    results,
    stats: {
      excelTotal: data1c.length,
      excelFiltered: map1c.size,
      wmsTotal: wmsData.length,
      wmsAfterFilter: wmsMap.size,
      matchedCount: results.length,
    },
  };
};

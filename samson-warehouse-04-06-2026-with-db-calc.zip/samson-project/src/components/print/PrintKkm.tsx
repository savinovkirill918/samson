'use client';

import React from 'react';
import { Printer } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { KKM, Member } from '@/lib/types';

interface PrintKkmProps {
  kkms: KKM[];
  members: Member[];
}

export default function PrintKkm({ kkms, members }: PrintKkmProps) {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Реестр ККМ</h2>
      <div className="bg-white rounded-xl shadow p-6">
        <div className="flex justify-end mb-4">
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition" style={{ backgroundColor: COLORS.primary }}>
            <Printer className="w-4 h-4" /> Печать
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: COLORS.alertBg }}>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>№</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>С/N</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Инв. №</th>
                <th className="border px-3 py-2 text-left text-sm font-semibold" style={{ color: COLORS.heading }}>Пользователь</th>
              </tr>
            </thead>
            <tbody>
              {kkms.map(kkm => {
                const assigned = members.filter(m => m.kkmId === kkm.id).map(m => m.fio).join(', ');
                return (
                  <tr key={kkm.id}>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.heading }}>{kkm.number}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{kkm.sn}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: COLORS.text }}>{kkm.inv}</td>
                    <td className="border px-3 py-2 text-sm" style={{ color: assigned ? COLORS.heading : '#dc3545' }}>{assigned || 'Отсутствует'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

'use client';

import React from 'react';
import { Pencil } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { TSD, Member, PageId } from '@/lib/types';

interface TsdListProps {
  tsds: TSD[];
  members: Member[];
  onNavigate: (page: PageId) => void;
  onEditTsd?: (tsd: TSD) => void;
}

export default function TsdList({ tsds, members, onNavigate, onEditTsd }: TsdListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
          <table className="w-full text-sm">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th className="px-4 py-3 text-left font-semibold" style={{ color: COLORS.heading, minWidth: '70px' }}>#</th>
                <th className="px-4 py-3 text-left font-semibold" style={{ color: COLORS.heading, minWidth: '180px' }}>Привязан</th>
                <th className="px-4 py-3 text-left font-semibold" style={{ color: COLORS.heading, minWidth: '200px' }}>S/N</th>
                <th className="px-4 py-3 text-left font-semibold" style={{ color: COLORS.heading, minWidth: '120px' }}>ИНВ. №</th>
                <th className="px-4 py-3 text-left font-semibold" style={{ color: COLORS.heading, minWidth: '140px' }}>Модель</th>
                <th className="px-4 py-3 text-center font-semibold" style={{ color: COLORS.heading, width: '50px' }}></th>
              </tr>
            </thead>
            <tbody>
              {tsds.map(tsd => {
                const assignedMembers = members.filter(m => m.tsdId === tsd.id);
                const hasMembers = assignedMembers.length > 0;

                return (
                  <tr
                    key={tsd.id}
                    className="border-t transition-colors cursor-pointer hover:bg-blue-50"
                    style={{ borderColor: '#f0f0f0' }}
                    onClick={() => onEditTsd?.(tsd)}
                  >
                    <td className="px-4 py-3 font-medium" style={{ color: COLORS.heading }}>
                      {tsd.number}
                    </td>
                    <td className="px-4 py-3">
                      {hasMembers ? (
                        <div className="flex flex-wrap gap-1">
                          {assignedMembers.map(m => (
                            <span
                              key={m.id}
                              className="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium text-white"
                              style={{ backgroundColor: '#3b82f6' }}
                            >
                              {m.login}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span style={{ color: '#dc3545' }}>Отсутствует</span>
                      )}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>
                      {tsd.sn}
                    </td>
                    <td className="px-4 py-3" style={{ color: COLORS.text }}>
                      {tsd.inv}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium"
                        style={{ backgroundColor: '#e9ecef', color: COLORS.text }}
                      >
                        {tsd.model}
                      </span>

                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        title="Редактировать"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditTsd?.(tsd);
                        }}
                        className="p-1.5 rounded text-white transition hover:opacity-80 inline-flex items-center justify-center"
                        style={{ backgroundColor: '#6c757d' }}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

'use client';

import React, { useState, useMemo } from 'react';
import { Calculator, Package, ChevronDown, ChevronUp } from 'lucide-react';
import { COLORS } from '@/lib/colors';

interface OriResult {
  label: string;
  byLen: number;
  byWid: number;
  byHei: number;
  total: number;
}

interface CalcResult {
  best: OriResult;
  variants: OriResult[];
}

const ORI_LABELS = [
  'Д \u00d7 Ш \u00d7 В',
  'Д \u00d7 В \u00d7 Ш',
  'Ш \u00d7 Д \u00d7 В',
  'Ш \u00d7 В \u00d7 Д',
  'В \u00d7 Д \u00d7 Ш',
  'В \u00d7 Ш \u00d7 Д',
];

function calcOrientations(
  boxL: number, boxW: number, boxH: number,
  cellL: number, cellW: number, effH: number,
  canRotate: boolean,
): CalcResult {
  const perms: [number, number, number][] = canRotate
    ? [
        [boxL, boxW, boxH],
        [boxL, boxH, boxW],
        [boxW, boxL, boxH],
        [boxW, boxH, boxL],
        [boxH, boxL, boxW],
        [boxH, boxW, boxL],
      ]
    : [
        [boxL, boxW, boxH],
      ];

  const variants: OriResult[] = perms.map(([bl, bw, bh], i) => {
    const byLen = Math.floor(cellL / bl);
    const byWid = Math.floor(cellW / bw);
    const byHei = Math.floor(effH / bh);
    return { label: ORI_LABELS[i], byLen, byWid, byHei, total: byLen * byWid * byHei };
  });

  const best = variants.reduce((a, b) => (b.total > a.total ? b : a), variants[0]);
  return { best, variants };
}

export default function ToolsPage() {
  const [inputs, setInputs] = useState({
    taraLen: '', taraWid: '', taraHei: '',
    cellLen: '', cellWid: '', cellHei: '',
    kr3: '', heightPercent: '10',
  });

  const [canRotate, setCanRotate] = useState(false);
  const [showAllOri, setShowAllOri] = useState(false);

  const result = useMemo(() => {
    const tL = parseFloat(inputs.taraLen) || 0;
    const tW = parseFloat(inputs.taraWid) || 0;
    const tH = parseFloat(inputs.taraHei) || 0;
    const cL = parseFloat(inputs.cellLen) || 0;
    const cW = parseFloat(inputs.cellWid) || 0;
    const cH = parseFloat(inputs.cellHei) || 0;
    const kr3 = parseFloat(inputs.kr3) || 1;
    const hPct = parseFloat(inputs.heightPercent) || 0;

    if (!tL || !tW || !tH || !cL || !cW || !cH) {
      return null;
    }

    const effectiveHeight = cH * (1 - hPct / 100);
    const taraCalc = calcOrientations(tL, tW, tH, cL, cW, effectiveHeight, canRotate);

    return { taraCalc, kr3, effectiveHeight };
  }, [inputs, canRotate]);

  const updateInput = (key: string, value: string) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  const inputField = (key: string, label: string) => (
    <div>
      <label className="block text-xs mb-1" style={{ color: COLORS.text }}>{label}</label>
      <input
        type="number"
        min="0"
        step="any"
        value={(inputs as Record<string, string>)[key]}
        onChange={e => updateInput(key, e.target.value)}
        className="w-full px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-200"
        style={{ borderColor: '#dee2e6' }}
      />
    </div>
  );

  const renderOriTable = (variants: OriResult[], bestTotal: number) => (
    <table className="w-full text-xs mt-2">
      <thead>
        <tr style={{ color: COLORS.text }}>
          <th className="text-left py-1 font-medium">Ориентация тары</th>
          <th className="text-center py-1 font-medium">По длине</th>
          <th className="text-center py-1 font-medium">По ширине</th>
          <th className="text-center py-1 font-medium">По высоте</th>
          <th className="text-center py-1 font-medium">Тар в ячейке</th>
        </tr>
      </thead>
      <tbody>
        {variants.map((v) => {
          const isBest = v.total === bestTotal && v.total > 0;
          return (
            <tr key={v.label} className={isBest ? 'font-bold' : ''} style={{ color: isBest ? COLORS.primary : COLORS.heading }}>
              <td className="py-1">
                {isBest && <span className="mr-1">&#9733;</span>}
                {v.label}
              </td>
              <td className="text-center py-1">{v.byLen}</td>
              <td className="text-center py-1">{v.byWid}</td>
              <td className="text-center py-1">{v.byHei}</td>
              <td className="text-center py-1">{v.total}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );

  return (
    <div>
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Инструменты</h2>
      <div className="bg-white rounded-xl shadow p-6 max-w-2xl">
        <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.heading }}>
          <Calculator className="w-5 h-5" style={{ color: COLORS.primary }} /> Калькулятор вместимости ячейки
        </h3>

        {/* Тара и Ячейка */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-medium mb-2 flex items-center gap-1" style={{ color: COLORS.primary }}>
              <Package className="w-4 h-4" /> Тара
            </h4>
            <div className="space-y-2">
              {inputField('taraLen', 'Длина тары')}
              {inputField('taraWid', 'Ширина тары')}
              {inputField('taraHei', 'Высота тары')}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-2" style={{ color: COLORS.primary }}>Ячейка</h4>
            <div className="space-y-2">
              {inputField('cellLen', 'Длина ячейки')}
              {inputField('cellWid', 'Ширина ячейки')}
              {inputField('cellHei', 'Высота ячейки')}
            </div>
          </div>
        </div>

        {/* КР3, % вычета, галочка поворота */}
        <div className="grid grid-cols-2 gap-4 mt-4">
          {inputField('kr3', 'КР3 (шт. в таре)')}
          {inputField('heightPercent', '% вычитаемый из высоты')}
        </div>

        <div className="mt-4 flex items-center gap-3 p-3 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
          <input
            type="checkbox"
            id="canRotate"
            checked={canRotate}
            onChange={e => {
              setCanRotate(e.target.checked);
              setShowAllOri(false);
            }}
            className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
          />
          <label htmlFor="canRotate" className="text-sm cursor-pointer select-none" style={{ color: COLORS.heading }}>
            Можно переворачивать тару
          </label>
          <span className="text-xs ml-auto" style={{ color: COLORS.text }}>
            {canRotate ? 'Перебор 6 ориентаций' : 'Фиксированная: Д \u00d7 Ш \u00d7 В'}
          </span>
        </div>

        {/* Результат */}
        {result && (
          <div className="mt-6 space-y-4">
            <div className="p-4 rounded-lg" style={{ backgroundColor: COLORS.alertBg }}>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium" style={{ color: COLORS.heading }}>
                  Вместимость тары в ячейку
                </label>
                <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: COLORS.primary, color: '#fff' }}>
                  {result.taraCalc.best.label}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2 mb-3 text-xs" style={{ color: COLORS.text }}>
                <span>По длине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byLen}</strong></span>
                <span>По ширине: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byWid}</strong></span>
                <span>По высоте: <strong style={{ color: COLORS.heading }}>{result.taraCalc.best.byHei}</strong></span>
                <span>Эфф. высота: <strong style={{ color: COLORS.heading }}>{result.effectiveHeight.toFixed(1)}</strong></span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: COLORS.text }}>Тар в ячейке</label>
                  <input
                    type="text"
                    value={result.taraCalc.best.total}
                    disabled
                    className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                    style={{ borderColor: '#dee2e6', color: '#856404' }}
                  />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: COLORS.text }}>
                    Итого шт. ({result.taraCalc.best.total} тар &times; {result.kr3} КР3)
                  </label>
                  <input
                    type="text"
                    value={result.taraCalc.best.total * result.kr3}
                    disabled
                    className="w-full px-4 py-2 border rounded-lg text-lg font-bold bg-white"
                    style={{ borderColor: '#dee2e6', color: COLORS.primary }}
                  />
                </div>
              </div>

              {/* Кнопка показа всех ориентаций — только если разрешён поворот */}
              {canRotate && result.taraCalc.variants.length > 1 && (
                <button
                  onClick={() => setShowAllOri(!showAllOri)}
                  className="mt-3 text-xs flex items-center gap-1 hover:underline"
                  style={{ color: COLORS.primary }}
                >
                  {showAllOri ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  {showAllOri ? 'Скрыть все ориентации' : 'Показать все ориентации'}
                </button>
              )}
              {showAllOri && renderOriTable(result.taraCalc.variants, result.taraCalc.best.total)}
            </div>
          </div>
        )}

        {!result && (
          <div className="mt-6 p-4 rounded-lg text-center text-sm" style={{ backgroundColor: COLORS.alertBg, color: COLORS.text }}>
            Заполните габариты тары и ячейки для расчёта
          </div>
        )}
      </div>
    </div>
  );
}

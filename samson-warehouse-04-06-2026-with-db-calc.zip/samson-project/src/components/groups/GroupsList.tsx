'use client';

import React from 'react';
import { COLORS } from '@/lib/colors';
import type { Group, PageId } from '@/lib/types';

interface GroupsListProps {
  groups: Group[];
  onNavigate: (page: PageId) => void;
}

export default function GroupsList({ groups, onNavigate }: GroupsListProps) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="bg-white rounded-xl shadow" style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <div style={{ overflow: 'auto', height: '100%' }}>
        <table className="w-full">
          <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
            <tr style={{ backgroundColor: COLORS.alertBg }}>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>ID</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Название</th>
              <th className="text-left px-4 py-3 text-sm font-semibold" style={{ color: COLORS.heading }}>Сортировка</th>
            </tr>
          </thead>
          <tbody>
            {groups.sort((a, b) => a.sort - b.sort).map(g => (
              <tr key={g.id} className="border-t" style={{ borderColor: '#f0f0f0' }}>
                <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.id}</td>
                <td className="px-4 py-3 text-sm font-medium" style={{ color: COLORS.heading }}>{g.name}</td>
                <td className="px-4 py-3 text-sm" style={{ color: COLORS.text }}>{g.sort}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

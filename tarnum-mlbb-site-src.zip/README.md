# Tarnum MLBB — сайт-портфолио Twitch-стримера

Одностраничный сайт для Twitch-канала [tarnum_mlbb](https://www.twitch.tv/tarnum_mlbb) по игре Mobile Legends: Bang Bang. Тёмная игровая тема (золото + арканный фиолетовый), встроенный живой Twitch-плеер, обратный отсчёт до стрима, расписание с авто-конвертацией часовых поясов, пул героев, соцсети.

## Стек

- **Next.js 16** (App Router, output: standalone) + **TypeScript**
- **Tailwind CSS 4** + shadcn/ui
- **framer-motion** — анимации
- **Prisma** (SQLite) — присутствует в шаблоне, сайтом фактически не используется

## Структура проекта

```
src/
├── config/site.ts            ← ВСЁ содержимое сайта: факты, расписание, герои, соцсети
├── app/
│   ├── layout.tsx            ← метаданные, шрифты (Unbounded / Rubik)
│   ├── page.tsx              ← сборка страницы из секций
│   └── globals.css           ← тема, цвета, фоны
├── components/tarnum/        ← секции сайта
│   ├── navbar.tsx            ← навигация + scrollspy
│   ├── hero.tsx              ← первый экран
│   ├── about.tsx             ← о стримере
│   ├── live-section.tsx      ← Twitch-плеер + обратный отсчёт до стрима
│   ├── heroes.tsx            ← пул героев
│   ├── schedule.tsx          ← расписание трансляций
│   ├── socials.tsx           ← карточки соцсетей (скрываются, если ссылка пустая)
│   ├── content.tsx           ← контентный блок
│   └── footer.tsx
└── components/ui/            ← библиотека shadcn/ui
public/images/                ← все картинки (аватар, арты героев, фон и т.д.)
prisma/schema.prisma
```

## Где что править

**99% правок — в одном файле `src/config/site.ts`:**

- `twitchLogin` — логин Twitch (уже `tarnum_mlbb`);
- факты о стримере (ранг Mythical Glory, роли, часы стрима);
- `schedule` — расписание (время указывается в MSK, на сайте автоматически
  конвертируется в часовой пояс посетителя; «сегодня» подсвечивается по MSK);
- `heroes` — список героев (имя, роль, сложность, картинка);
- `socials` — ссылки на YouTube / Telegram / Discord / VK. **Пустая строка = карточка
  автоматически скрывается.** Впишите ссылки — блоки появятся сами.

**Картинки:** замените файлы с теми же именами в `public/images/`
(`tarnum-avatar.png`, `hero-*.png`, `hero-bg.png` и т.д.) — код менять не нужно.

**Twitch-плеер:** домен для параметра `parent` подставляется автоматически из
`window.location.hostname`, поэтому эмбед работает на любом домене без правок кода.
Плеер корректно работает и по HTTPS.

## Запуск в режиме разработки

Требования: **Node.js 20.9+** или **Bun 1.1+**.

```bash
cp .env.example .env      # создать .env (если ещё нет)
npm install               # или: bun install
npm run db:push           # создать SQLite-базу (нужно для генерации Prisma-клиента)
npm run dev               # http://localhost:3000
```

С Bun быстрее: `bun install && bun run db:push && bun run dev`.

## Продакшн-деплой на VPS

### 1. Сборка

```bash
npm install
npm run db:push
npm run build     # Next.js standalone: соберёт .next/standalone/server.js
                  # и скопирует туда static/ и public/
```

### 2. Запуск

В `package.json` скрипт `start` использует bun. Варианты:

**Через Node (стандартно):**
```bash
NODE_ENV=production PORT=3000 HOSTNAME=0.0.0.0 node .next/standalone/server.js
```

**Через Bun:**
```bash
bun run start
```

Проверка: `curl http://localhost:3000`.

### 3. Автозапуск через PM2 (рекомендуется)

```bash
npm i -g pm2
pm2 start .next/standalone/server.js --name tarnum-site \
  --env NODE_ENV=production -- --port 3000
# если порт не подхватился, задайте явно:
# PORT=3000 HOSTNAME=0.0.0.0 pm2 start .next/standalone/server.js --name tarnum-site
pm2 save && pm2 startup
```

Альтернатива — systemd-юнит `/etc/systemd/system/tarnum.service`:

```ini
[Unit]
Description=Tarnum MLBB site
After=network.target

[Service]
WorkingDirectory=/opt/tarnum
ExecStart=/usr/bin/node /opt/tarnum/.next/standalone/server.js
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=HOSTNAME=0.0.0.0
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now tarnum
```

### 4. Nginx как reverse-proxy + HTTPS

```nginx
server {
    listen 80;
    server_name ваш-домен.ru;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

HTTPS проще всего через certbot: `sudo certbot --nginx -d ваш-домен.ru`.

> Важно: Twitch-эмбед требует, чтобы домен страницы совпадал с `parent` — здесь
> это решается автоматически. Для эмбеда обязателен доступ по домену (не по IP
> изнутри iframe в некоторых браузерах — лучше сразу привязать домен).

## Полезные команды

| Команда | Что делает |
|---|---|
| `npm run dev` | дев-сервер на :3000 с логом dev.log |
| `npm run build` | продакшн-сборка (standalone) |
| `npm run lint` | проверка ESLint |
| `npm run db:push` | применить prisma-схему к SQLite |
| `npm run db:generate` | сгенерировать Prisma-клиент |

## Частые вопросы

**Сайт не стартует после `npm install` на новом сервере.**
Выполните `npm run db:generate` (или `npm run db:push`) — Prisma-клиент должен
быть сгенерирован до сборки.

**Хочу поменять цвета темы.** Палитра и CSS-переменные — в `src/app/globals.css`
(золото `#f0b23e`, фиолетовый `#8b5cf6`).

**Расписание показывает не мой часовой пояс.** Так и задумано: время хранится в
MSK и конвертируется в пояс посетителя автоматически.

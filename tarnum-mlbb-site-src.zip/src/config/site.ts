/**
 * Центральный конфиг сайта TARNUM MLBB.
 * Все факты и ссылки — в одном месте. Пустая ссылка соцсети = секция скрывается.
 * Чтобы добавить площадку, впишите URL, например: youtube: 'https://youtube.com/@...'
 */

export const SITE = {
  /** Логин Twitch-канала (используется для ссылок и встроенного плеера) */
  twitchLogin: 'tarnum_mlbb',

  /** Текущий ранг в MLBB (подтверждён стримером) */
  rank: 'Mythical Glory',

  /** Расписание стримов (подтверждено стримером) */
  schedule: {
    mode: 'Ежедневно',
    startTime: 18, // часов, МСК
    endTime: 24, // часов, МСК (полночь)
    label: '18:00 – 00:00 МСК',
  },

  /** Скромные честные показатели для хиро-блока */
  stats: [
    { value: '1K+', label: 'Фолловеров' },
    { value: '100+', label: 'Часов эфира' },
    { value: '18:00', label: 'Старт каждый день' },
    { value: 'МГ', label: 'Ранг Mythical Glory' },
  ],

  /** Соцсети: впишите URL — карточка появится автоматически */
  socials: {
    youtube: '',
    discord: '',
    telegram: '',
    vk: '',
  },
} as const

export const TWITCH_CHANNEL_URL = `https://www.twitch.tv/${SITE.twitchLogin}`

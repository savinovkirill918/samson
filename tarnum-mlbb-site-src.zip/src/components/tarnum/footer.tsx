'use client'

import { Swords } from 'lucide-react'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'

export function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="relative mt-auto border-t border-gold/15 bg-surface/80">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-5 px-4 py-8 sm:px-6 md:flex-row md:justify-between lg:px-8">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-gold/40 bg-gold/10 text-gold">
            <Swords className="h-4 w-4" aria-hidden="true" />
          </span>
          <div className="text-center md:text-left">
            <p className="font-display text-sm font-bold tracking-wider text-foreground">
              TARNUM<span className="text-gold">.MLBB</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Портфолио стримера Mobile Legends: Bang Bang
            </p>
          </div>
        </div>

        <div className="flex flex-col items-center gap-1.5 text-center md:items-end md:text-right">
          <a
            href={TWITCH_CHANNEL_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-semibold text-gold transition-colors hover:text-gold-light"
          >
            twitch.tv/{SITE.twitchLogin}
          </a>
          <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
            © {year} Tarnum MLBB. Fan-made сайт. Mobile Legends: Bang Bang — торговая марка
            Moonton. Сайт не аффилирован с Moonton и Twitch.
          </p>
        </div>
      </div>
    </footer>
  )
}

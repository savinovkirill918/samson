'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { CalendarDays, Clock, Globe2, Twitch } from 'lucide-react'
import { SectionHeading } from './section-heading'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'

const DAYS = [
  { short: 'ПН', full: 'Понедельник' },
  { short: 'ВТ', full: 'Вторник' },
  { short: 'СР', full: 'Среда' },
  { short: 'ЧТ', full: 'Четверг' },
  { short: 'ПТ', full: 'Пятница' },
  { short: 'СБ', full: 'Суббота' },
  { short: 'ВС', full: 'Воскресенье' },
]

const WEEKDAY_INDEX: Record<string, number> = {
  Mon: 0,
  Tue: 1,
  Wed: 2,
  Thu: 3,
  Fri: 4,
  Sat: 5,
  Sun: 6,
}

/** 18:00 МСК = 15:00 UTC (МСК = UTC+3 без перехода на летнее время) */
function mskRangeToLocalLabel(startHour: number, endHour: number): string | null {
  try {
    const now = new Date()
    const startLocal = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), startHour - 3, 0)
    )
    const endLocal = new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), endHour - 3, 0)
    )
    const opts: Intl.DateTimeFormatOptions = { hour: '2-digit', minute: '2-digit' }
    return `${startLocal.toLocaleTimeString([], opts)} – ${endLocal.toLocaleTimeString([], opts)}`
  } catch {
    return null
  }
}

export function Schedule() {
  const [todayIndex, setTodayIndex] = useState<number | null>(null)
  const [localLabel, setLocalLabel] = useState<string | null>(null)
  const [isMskVisitor, setIsMskVisitor] = useState(false)

  useEffect(() => {
    const update = () => {
      // День недели по МСК, чтобы подсветка совпадала с графиком стримера
      const weekday = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Europe/Moscow',
        weekday: 'short',
      }).format(new Date())
      setTodayIndex(WEEKDAY_INDEX[weekday] ?? null)

      const label = mskRangeToLocalLabel(SITE.schedule.startTime, SITE.schedule.endTime)
      setLocalLabel(label)

      const localOffset = -new Date().getTimezoneOffset() / 60
      setIsMskVisitor(localOffset === 3)
    }
    update()
    const timer = window.setInterval(update, 30_000)
    return () => window.clearInterval(timer)
  }, [])

  return (
    <section id="schedule" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Когда в эфире"
          title="Расписание стримов"
          description="Один график на всю неделю — просто и без исключений. Время указано по Москве."
        />

        <div className="grid gap-5 lg:grid-cols-3">
          {/* Main schedule card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.55 }}
            className="relative overflow-hidden rounded-2xl border border-gold/30 bg-gradient-to-br from-gold/12 via-card to-card p-6 md:p-8"
          >
            <div
              className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gold/15 blur-2xl"
              aria-hidden="true"
            />
            <div className="mb-5 flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold/15 text-gold">
                <CalendarDays className="h-6 w-6" aria-hidden="true" />
              </span>
              <div>
                <p className="font-display text-lg font-bold text-foreground">
                  {SITE.schedule.mode}
                </p>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">
                  без выходных
                </p>
              </div>
            </div>

            <p className="font-display text-4xl font-bold tabular-nums text-gold text-glow-gold md:text-5xl">
              {SITE.schedule.label}
            </p>

            {localLabel && !isMskVisitor && (
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <Globe2 className="h-4 w-4 shrink-0 text-arcane" aria-hidden="true" />
                <span>
                  В твоём часовом поясе:{' '}
                  <span className="font-semibold text-foreground">{localLabel}</span>
                </span>
              </p>
            )}
            {isMskVisitor && localLabel && (
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <Globe2 className="h-4 w-4 shrink-0 text-arcane" aria-hidden="true" />
                <span>У тебя московское время — всё совпадает</span>
              </p>
            )}

            <a
              href={TWITCH_CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-lg border border-gold/30 bg-gold/10 px-4 py-2.5 text-sm font-semibold text-gold transition-all hover:bg-gold/20 hover:shadow-[0_0_20px_rgba(240,178,62,0.25)]"
            >
              <Twitch className="h-4 w-4" aria-hidden="true" />
              twitch.tv/{SITE.twitchLogin}
            </a>
          </motion.div>

          {/* Week grid */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.1, duration: 0.55 }}
            className="lg:col-span-2"
          >
            <div className="grid h-full grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7 lg:grid-rows-1">
              {DAYS.map((day, i) => {
                const isToday = todayIndex === i
                return (
                  <div
                    key={day.short}
                    className={`flex flex-col items-center gap-2.5 rounded-xl border p-4 text-center transition-all lg:justify-center ${
                      isToday
                        ? 'border-gold/60 bg-gradient-to-b from-gold/15 to-card shadow-[0_0_24px_rgba(240,178,62,0.2)]'
                        : 'border-gold/15 bg-card hover:border-gold/35'
                    }`}
                  >
                    <span
                      className={`font-display text-sm font-bold tracking-widest ${
                        isToday ? 'text-gold' : 'text-foreground/80'
                      }`}
                    >
                      {day.short}
                    </span>
                    <span className="flex items-center gap-1 text-xs font-medium tabular-nums text-muted-foreground">
                      <Clock className="h-3 w-3 text-gold/60" aria-hidden="true" />
                      18:00
                    </span>
                    {isToday && (
                      <span className="flex items-center gap-1.5 rounded-full border border-blood/50 bg-blood/15 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-blood">
                        <span className="relative flex h-1.5 w-1.5">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blood opacity-75" />
                          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-blood" />
                        </span>
                        Сегодня
                      </span>
                    )}
                  </div>
                )
              })}
            </div>
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Подсветка дня работает по московскому времени. О внеплановых изменениях сообщаю
              в начале стрима или в описании канала.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { ArrowUpRight, Swords, Sparkles, GraduationCap } from 'lucide-react'
import { SectionHeading } from './section-heading'
import { TWITCH_CHANNEL_URL } from '@/config/site'

const CONTENT = [
  {
    image: '/images/clip-duel.png',
    icon: Swords,
    title: 'Ранкед-марафоны',
    desc: 'Живые катки на Mythical Glory: пики, ротации и решения в реальном времени — без монтажа.',
  },
  {
    image: '/images/clip-pentakill.png',
    icon: Sparkles,
    title: 'Эпичные моменты',
    desc: 'Лучшие драки, клатчи и пента-киллы с эфиров. То, ради чего собирается чат.',
  },
  {
    image: '/images/clip-lord.png',
    icon: GraduationCap,
    title: 'Разборы и тактика',
    desc: 'Как таймить Лорда, когда идти на ротацию и почему драка была проиграна — простым языком.',
  },
]

export function Content() {
  return (
    <section id="content" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Что смотреть"
          title="Контент канала"
          description="Три формата, которые идут на стримах регулярно. Всё это — в прямом эфире на Twitch."
        />

        <div className="grid grid-cols-1 gap-5 md:grid-cols-3 lg:gap-6">
          {CONTENT.map((item, i) => (
            <motion.a
              key={item.title}
              href={TWITCH_CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: 0.1 * i, duration: 0.55, ease: 'easeOut' }}
              className="group relative block overflow-hidden rounded-2xl border border-gold/20 bg-card transition-all hover:-translate-y-1.5 hover:border-gold/50 hover:shadow-[0_16px_44px_rgba(0,0,0,0.5)]"
              aria-label={`${item.title} — смотреть на Twitch`}
            >
              <div className="relative aspect-video overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                  sizes="(max-width: 768px) 100vw, 33vw"
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent"
                  aria-hidden="true"
                />
                <span className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-lg border border-gold/40 bg-background/70 text-gold backdrop-blur-md">
                  <item.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="absolute bottom-3 right-4 flex items-center gap-1 text-xs font-medium text-foreground/90 opacity-0 transition-opacity group-hover:opacity-100">
                  Смотреть
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
              </div>

              <div className="p-5">
                <h3 className="mb-2 font-display text-base font-bold text-foreground transition-colors group-hover:text-gold md:text-lg">
                  {item.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}

'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { Crown, Clock3, Swords, MonitorPlay } from 'lucide-react'
import { SectionHeading } from './section-heading'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'

const FACTS = [
  {
    icon: Crown,
    title: SITE.rank,
    desc: 'Высший ранг Mobile Legends: Bang Bang',
  },
  {
    icon: Clock3,
    title: 'Каждый день в 18:00',
    desc: 'Ежедневные стримы, 18:00 – 00:00 МСК',
  },
  {
    icon: Swords,
    title: 'Ассасины и танки',
    desc: 'Основной пул: ассасины, танки и бойцы',
  },
  {
    icon: MonitorPlay,
    title: 'Ранкед и разборы',
    desc: 'Живые матчи, решения в игре и общение с чатом',
  },
]

export function About() {
  return (
    <section id="about" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Кто такой Tarnum"
          title="О стримере"
          description="Коротко и по фактам: кто это, во что играет и когда зайти на эфир."
        />

        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          {/* Image side */}
          <motion.div
            initial={{ opacity: 0, x: -32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="relative mx-auto w-full max-w-md"
          >
            <div
              className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-arcane/30 via-gold/20 to-transparent blur-xl"
              aria-hidden="true"
            />
            <div className="relative overflow-hidden rounded-3xl border border-gold/30 shadow-[0_20px_60px_rgba(0,0,0,0.6)]">
              <Image
                src="/images/tarnum-avatar.png"
                alt="Tarnum — образ стримера"
                width={1024}
                height={1024}
                className="h-auto w-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background via-background/60 to-transparent p-5 pt-14">
                <p className="font-display text-lg font-bold text-gold">TARNUM</p>
                <p className="text-sm text-muted-foreground">
                  Стример MLBB • twitch.tv/{SITE.twitchLogin}
                </p>
              </div>
            </div>
            {/* Floating badge */}
            <div className="absolute -right-3 -top-3 rounded-xl border border-gold/40 bg-card px-4 py-2 shadow-[0_0_24px_rgba(240,178,62,0.3)] md:-right-6">
              <span className="font-display text-xl font-bold text-gold">{SITE.rank}</span>
              <span className="block text-[10px] uppercase tracking-widest text-muted-foreground">
                текущий ранг
              </span>
            </div>
          </motion.div>

          {/* Text side */}
          <motion.div
            initial={{ opacity: 0, x: 32 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
            className="flex flex-col gap-6"
          >
            <div className="flex flex-col gap-4 text-sm leading-relaxed text-muted-foreground md:text-base">
              <p>
                Привет! Я <span className="font-semibold text-foreground">Tarnum</span> —
                стример по Mobile Legends: Bang Bang, играю на уровне{' '}
                <span className="text-gold">{SITE.rank}</span>. Свой путь в ранге показываю
                в прямом эфире: без монтажа и ретуши — так, как есть в реальных катках.
              </p>
              <p>
                Основной пул героев — <span className="text-foreground">ассасины, танки и бойцы</span>.
                На стримах объясняю решения в игре: когда идти на ротацию, как таймить
                Лорда и что делать после проигранной драки. Если хочешь не просто смотреть,
                а понимать, что происходит на карте, — тебе ко мне.
              </p>
              <p>
                Эфиры идут <span className="text-foreground">каждый день с 18:00 до 00:00 МСК</span> на{' '}
                <a
                  href={TWITCH_CHANNEL_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium text-gold underline-offset-4 hover:text-gold-light hover:underline"
                >
                  twitch.tv/{SITE.twitchLogin}
                </a>
                . Заглядывай в чат — отвечаю каждому, а вопросы по игре разбираю прямо
                в эфире.
              </p>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              {FACTS.map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * i, duration: 0.5 }}
                  className="flex items-start gap-3 rounded-xl border border-gold/15 bg-surface px-4 py-3.5 transition-all hover:border-gold/40 hover:shadow-[0_0_20px_rgba(240,178,62,0.12)]"
                >
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gold/12 text-gold">
                    <item.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span>
                    <span className="block font-display text-sm font-semibold text-foreground">
                      {item.title}
                    </span>
                    <span className="text-xs leading-relaxed text-muted-foreground">
                      {item.desc}
                    </span>
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

'use client'

import { motion } from 'framer-motion'
import { Twitch, Youtube, MessageCircle, Send, Globe, Heart, ShieldCheck } from 'lucide-react'
import { SectionHeading } from './section-heading'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'

/**
 * Карточки соцсетей рендерятся только для заполненных ссылок в src/config/site.ts.
 * Никаких заглушек: пусто = площадка не показывается.
 */
const SOCIAL_DEFS = [
  {
    key: 'youtube' as const,
    name: 'YouTube',
    icon: Youtube,
    url: SITE.socials.youtube,
    desc: 'Нарезки и записи эфиров',
    accent: 'hover:border-[#ff4e45]/60 hover:shadow-[0_0_28px_rgba(255,78,69,0.3)]',
    iconColor: 'text-[#ff6b61]',
    iconBg: 'bg-[#ff4e45]/15',
  },
  {
    key: 'discord' as const,
    name: 'Discord',
    icon: MessageCircle,
    url: SITE.socials.discord,
    desc: 'Комьюнити и поиск пати',
    accent: 'hover:border-[#7289ff]/60 hover:shadow-[0_0_28px_rgba(114,137,255,0.3)]',
    iconColor: 'text-[#8c9dff]',
    iconBg: 'bg-[#7289ff]/15',
  },
  {
    key: 'telegram' as const,
    name: 'Telegram',
    icon: Send,
    url: SITE.socials.telegram,
    desc: 'Анонсы стримов',
    accent: 'hover:border-[#2aabee]/60 hover:shadow-[0_0_28px_rgba(42,171,238,0.3)]',
    iconColor: 'text-[#5cc4f5]',
    iconBg: 'bg-[#2aabee]/15',
  },
  {
    key: 'vk' as const,
    name: 'VK',
    icon: Globe,
    url: SITE.socials.vk,
    desc: 'Клипы и обсуждения',
    accent: 'hover:border-[#0077ff]/60 hover:shadow-[0_0_28px_rgba(0,119,255,0.3)]',
    iconColor: 'text-[#4a9eff]',
    iconBg: 'bg-[#0077ff]/15',
  },
]

export function Socials() {
  const activeSocials = SOCIAL_DEFS.filter((s) => s.url.length > 0)

  return (
    <section id="contacts" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Где меня найти"
          title="Официальные ссылки"
          description="Здесь только проверенные адреса. Основная площадка — Twitch, эфиры идут там каждый день."
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 lg:gap-5">
          {/* Twitch — основная площадка */}
          <motion.a
            href={TWITCH_CHANNEL_URL}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.5 }}
            className={`group flex flex-col gap-3 rounded-2xl border border-gold/30 bg-card p-6 transition-all hover:-translate-y-1.5 hover:shadow-[0_0_28px_rgba(169,112,255,0.3)] sm:col-span-2 lg:col-span-1 lg:row-span-2 ${
              activeSocials.length === 0 ? 'lg:col-span-3' : ''
            }`}
            aria-label={`Twitch: twitch.tv/${SITE.twitchLogin}`}
          >
            <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-[#a970ff]/15 text-[#c9a0ff] transition-transform group-hover:scale-110">
              <Twitch className="h-7 w-7" aria-hidden="true" />
            </span>
            <span>
              <span className="block font-display text-xl font-bold text-foreground">Twitch</span>
              <span className="block text-sm font-medium text-gold/90">
                twitch.tv/{SITE.twitchLogin}
              </span>
            </span>
            <span className="text-sm leading-relaxed text-muted-foreground">
              Основная платформа: ежедневные стримы {SITE.schedule.label}. Подписка бесплатная
              с Amazon Prime — это лучший способ поддержать канал.
            </span>
            <span className="mt-auto inline-flex items-center gap-2 pt-2 text-sm font-semibold text-gold">
              Перейти на канал
              <span aria-hidden="true">→</span>
            </span>
          </motion.a>

          {/* Дополнительные площадки — только если ссылка заполнена */}
          {activeSocials.map((social, i) => (
            <motion.a
              key={social.key}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: 0.07 * (i + 1), duration: 0.5 }}
              className={`group flex flex-col gap-3 rounded-2xl border border-gold/15 bg-card p-6 transition-all hover:-translate-y-1.5 ${social.accent}`}
              aria-label={`${social.name}: ${social.url}`}
            >
              <span
                className={`flex h-12 w-12 items-center justify-center rounded-xl ${social.iconBg} ${social.iconColor} transition-transform group-hover:scale-110`}
              >
                <social.icon className="h-6 w-6" aria-hidden="true" />
              </span>
              <span>
                <span className="block font-display text-base font-bold text-foreground">
                  {social.name}
                </span>
                <span className="block break-all text-xs font-medium text-gold/80">
                  {social.url.replace(/^https?:\/\//, '')}
                </span>
              </span>
              <span className="text-xs leading-relaxed text-muted-foreground">{social.desc}</span>
            </motion.a>
          ))}

          {/* Честная заметка вместо заглушек */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.14, duration: 0.5 }}
            className="flex flex-col justify-center gap-3 rounded-2xl border border-dashed border-gold/25 bg-surface/60 p-6"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold/10 text-gold">
              <ShieldCheck className="h-6 w-6" aria-hidden="true" />
            </span>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Других официальных страниц пока нет. Если где-то встретишь «Tarnum» с другим
              адресом — это не я. Проверенный источник всегда один: Twitch-канал выше.
            </p>
          </motion.div>
        </div>

        {/* Big CTA banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="relative mt-12 overflow-hidden rounded-3xl border border-gold/30 bg-gradient-to-r from-arcane/20 via-surface-2 to-gold/15 p-8 text-center md:mt-16 md:p-12"
        >
          <div
            className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-gold/20 blur-3xl"
            aria-hidden="true"
          />
          <div
            className="absolute -bottom-10 -right-10 h-40 w-40 rounded-full bg-arcane/25 blur-3xl"
            aria-hidden="true"
          />
          <h3 className="font-display text-xl font-bold uppercase tracking-wide text-foreground md:text-3xl">
            Заходи на <span className="text-glow-gold text-gold">вечерний эфир</span>
          </h3>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
            Каждый день в 18:00 МСК. Вопросы по игре — прямо в чат, разберём в эфире.
          </p>
          <motion.a
            href={TWITCH_CHANNEL_URL}
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            className="clip-slant mt-7 inline-flex items-center gap-2.5 bg-gradient-to-r from-gold-dark via-gold to-gold-light px-8 py-4 font-display text-base font-bold uppercase tracking-wider text-primary-foreground shadow-[0_0_32px_rgba(240,178,62,0.45)] transition-shadow hover:shadow-[0_0_48px_rgba(240,178,62,0.65)] md:text-lg"
          >
            <Heart className="h-5 w-5" aria-hidden="true" />
            Подписаться на Twitch
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}

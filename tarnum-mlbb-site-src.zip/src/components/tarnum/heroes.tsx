'use client'

import { useState } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { Signal } from 'lucide-react'
import { SectionHeading } from './section-heading'

type Role = 'Ассасин' | 'Танк' | 'Боец'
type Difficulty = 'Низкая' | 'Средняя' | 'Высокая' | 'Очень высокая'

interface HeroCard {
  name: string
  role: Role
  image: string
  difficulty: Difficulty
  note: string
}

/** Пул героев Tarnum: ассасины + танки/бойцы. Сложность — внутриигровая оценка MLBB. */
const HEROES: HeroCard[] = [
  {
    name: 'Ланселот',
    role: 'Ассасин',
    image: '/images/hero-assassin.png',
    difficulty: 'Средняя',
    note: 'Рывки с неуязвимостью и мгновенные комбо',
  },
  {
    name: 'Гусион',
    role: 'Ассасин',
    image: '/images/hero-gusion.png',
    difficulty: 'Высокая',
    note: 'Парящие кинжалы и магический бурст',
  },
  {
    name: 'Фанни',
    role: 'Ассасин',
    image: '/images/hero-fanny.png',
    difficulty: 'Очень высокая',
    note: 'Полёт на тросах — самый сложный герой игры',
  },
  {
    name: 'Хаябуса',
    role: 'Ассасин',
    image: '/images/hero-hayabusa.png',
    difficulty: 'Средняя',
    note: 'Тени, сплит-пуш и добивание одной цели',
  },
  {
    name: 'Франко',
    role: 'Танк',
    image: '/images/hero-tank.png',
    difficulty: 'Низкая',
    note: 'Крюк и захват — начинает драки первым',
  },
  {
    name: 'Тигрел',
    role: 'Танк',
    image: '/images/hero-tigreal.png',
    difficulty: 'Низкая',
    note: 'Масс-контроль: ульта собирает врагов в кучу',
  },
  {
    name: 'Хильда',
    role: 'Боец',
    image: '/images/hero-hilda.png',
    difficulty: 'Низкая',
    note: 'Молот из кустов и высокая живучесть',
  },
  {
    name: 'Юй Чжун',
    role: 'Боец',
    image: '/images/hero-fighter.png',
    difficulty: 'Высокая',
    note: 'Драконья форма и урон по площади',
  },
]

const DIFFICULTY_STARS: Record<Difficulty, number> = {
  'Низкая': 1,
  'Средняя': 2,
  'Высокая': 3,
  'Очень высокая': 4,
}

const ROLES_FILTER: Array<'Все' | Role> = ['Все', 'Ассасин', 'Танк', 'Боец']

export function Heroes() {
  const [filter, setFilter] = useState<'Все' | Role>('Все')
  const visible = filter === 'Все' ? HEROES : HEROES.filter((h) => h.role === filter)

  return (
    <section id="heroes" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Пул героев"
          title="Ассасины, танки и бойцы"
          description="Основные герои Tarnum. Сложность указана по внутриигровой оценке Mobile Legends — без прикрас."
        />

        {/* Filters */}
        <div
          className="mb-10 flex flex-wrap items-center justify-center gap-2"
          role="group"
          aria-label="Фильтр героев по роли"
        >
          {ROLES_FILTER.map((role) => {
            const active = filter === role
            return (
              <button
                key={role}
                type="button"
                onClick={() => setFilter(role)}
                aria-pressed={active}
                className={`relative rounded-lg px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-colors md:text-sm ${
                  active ? 'text-primary-foreground' : 'text-muted-foreground hover:text-gold'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="role-pill"
                    className="absolute inset-0 rounded-lg bg-gradient-to-r from-gold-dark via-gold to-gold-light shadow-[0_0_18px_rgba(240,178,62,0.4)]"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{role}</span>
              </button>
            )
          })}
        </div>

        {/* Cards */}
        <motion.div layout className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 lg:gap-5">
          <AnimatePresence mode="popLayout">
            {visible.map((hero) => (
              <motion.article
                layout
                key={hero.name}
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.92 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="group relative overflow-hidden rounded-2xl border border-gold/20 bg-card transition-all hover:-translate-y-1.5 hover:border-gold/50 hover:shadow-[0_18px_50px_rgba(139,92,246,0.18)]"
              >
                {/* Portrait */}
                <div className="relative h-60 overflow-hidden">
                  <Image
                    src={hero.image}
                    alt={`${hero.name} — портрет героя`}
                    fill
                    className="object-cover object-top transition-transform duration-700 group-hover:scale-110"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                  />
                  <div
                    className="absolute inset-0 bg-gradient-to-t from-card via-card/25 to-transparent"
                    aria-hidden="true"
                  />
                  <span className="absolute right-3.5 top-3.5 rounded-md border border-arcane/50 bg-arcane/25 px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-foreground backdrop-blur-md">
                    {hero.role}
                  </span>
                </div>

                {/* Info */}
                <div className="flex flex-col gap-3 p-4">
                  <h3 className="font-display text-lg font-bold text-foreground transition-colors group-hover:text-gold">
                    {hero.name}
                  </h3>
                  <p className="min-h-10 text-xs leading-relaxed text-muted-foreground">
                    {hero.note}
                  </p>
                  <div className="flex items-center gap-2 border-t border-gold/10 pt-3">
                    <Signal className="h-3.5 w-3.5 text-gold/70" aria-hidden="true" />
                    <span className="text-[11px] uppercase tracking-wider text-muted-foreground">
                      Сложность:
                    </span>
                    <span className="ml-auto flex items-center gap-1" aria-label={`Сложность: ${hero.difficulty}`}>
                      {[1, 2, 3, 4].map((dot) => (
                        <span
                          key={dot}
                          className={`h-1.5 w-4 rounded-full ${
                            dot <= DIFFICULTY_STARS[hero.difficulty]
                              ? 'bg-gradient-to-r from-gold-dark to-gold-light'
                              : 'bg-secondary'
                          }`}
                        />
                      ))}
                    </span>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  )
}

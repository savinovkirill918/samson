'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { Play, Radio, Crown } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: 0.15 * i, duration: 0.65, ease: 'easeOut' as const },
  }),
}

export function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen flex-col overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 -z-10" aria-hidden="true">
        <Image
          src="/images/hero-bg.png"
          alt=""
          fill
          priority
          className="object-cover object-center opacity-45"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/55 to-background" />
        <div className="absolute inset-0 bg-noise" />
      </div>

      <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col items-center justify-center gap-8 px-4 pb-16 pt-32 text-center sm:px-6 md:pt-36 lg:px-8">
        {/* Live badge */}
        <motion.div variants={fadeUp} initial="hidden" animate="show" custom={0}>
          <span className="inline-flex items-center gap-2.5 rounded-full border border-blood/40 bg-blood/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-blood">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-blood opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-blood" />
            </span>
            Стримим каждый день в 18:00 МСК
          </span>
        </motion.div>

        {/* Avatar */}
        <motion.div variants={fadeUp} initial="hidden" animate="show" custom={1}>
          <div className="relative mx-auto h-36 w-36 md:h-44 md:w-44">
            <div
              className="absolute -inset-3 rounded-full bg-gradient-to-tr from-gold-dark via-gold to-arcane opacity-70 blur-md animate-pulse"
              aria-hidden="true"
            />
            <div className="absolute -inset-1.5 rounded-full bg-gradient-to-tr from-gold-dark via-gold to-arcane" aria-hidden="true" />
            <Image
              src="/images/tarnum-avatar.png"
              alt="Tarnum — аватар стримера"
              fill
              priority
              className="relative rounded-full border-4 border-background object-cover"
              sizes="176px"
            />
          </div>
        </motion.div>

        {/* Title */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          custom={2}
          className="flex flex-col gap-3"
        >
          <h1 className="font-display text-4xl font-black uppercase leading-tight tracking-wide sm:text-6xl md:text-7xl">
            <span className="text-glow-gold bg-gradient-to-b from-gold-light via-gold to-gold-dark bg-clip-text text-transparent">
              TARNUM
            </span>
          </h1>
          <p className="font-display text-sm font-medium uppercase tracking-[0.35em] text-foreground/90 sm:text-base">
            Стример <span className="text-gold">Mobile Legends: Bang Bang</span>
          </p>
          <p className="mx-auto mt-1 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Ранг {SITE.rank} • ассасины, танки и бойцы • ежедневные стримы на twitch.tv/{SITE.twitchLogin}.
            Заходи на эфир — играем, разбираем матчи и растим ранг вместе.
          </p>
        </motion.div>

        {/* CTA */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          custom={3}
          className="flex flex-col items-center gap-3 sm:flex-row"
        >
          <Button
            asChild
            size="lg"
            className="clip-slant min-w-56 bg-gradient-to-r from-gold-dark via-gold to-gold-light text-lg font-bold text-primary-foreground shadow-[0_0_28px_rgba(240,178,62,0.4)] transition-shadow hover:shadow-[0_0_44px_rgba(240,178,62,0.6)]"
          >
            <a href={TWITCH_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
              <Play className="mr-2 h-5 w-5" /> Смотреть на Twitch
            </a>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="min-w-56 border-arcane/50 bg-arcane/10 text-base font-semibold text-foreground hover:bg-arcane/25 hover:text-foreground"
          >
            <a href="#live">
              <Radio className="mr-2 h-5 w-5 text-arcane" /> Плеер на сайте
            </a>
          </Button>
        </motion.div>

        {/* Honest stats strip */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          animate="show"
          custom={4}
          className="mt-6 grid w-full max-w-4xl grid-cols-2 gap-3 md:grid-cols-4 md:gap-4"
        >
          {SITE.stats.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center gap-1.5 rounded-xl border border-gold/20 bg-card/70 px-4 py-5 backdrop-blur-md transition-all hover:border-gold/45 hover:shadow-[0_0_24px_rgba(240,178,62,0.15)]"
            >
              {stat.value === 'МГ' ? (
                <Crown className="mb-1 h-5 w-5 text-gold" aria-hidden="true" />
              ) : null}
              <span className="font-display text-2xl font-bold text-foreground md:text-3xl">
                {stat.value}
              </span>
              <span className="text-center text-[11px] uppercase tracking-widest text-muted-foreground md:text-xs">
                {stat.label}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4 }}
        className="pb-6 text-center"
        aria-hidden="true"
      >
        <div className="mx-auto h-9 w-5 rounded-full border-2 border-gold/40 p-1">
          <div className="h-2 w-1 animate-bounce rounded-full bg-gold/70" />
        </div>
      </motion.div>
    </section>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Swords } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { TWITCH_CHANNEL_URL } from '@/config/site'

const NAV_LINKS = [
  { href: '#home', label: 'Главная' },
  { href: '#about', label: 'О стримере' },
  { href: '#live', label: 'Эфир' },
  { href: '#heroes', label: 'Герои' },
  { href: '#schedule', label: 'Расписание' },
  { href: '#content', label: 'Контент' },
  { href: '#contacts', label: 'Контакты' },
]

function goToSection(href: string) {
  const el = document.querySelector(href)
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
}

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState<string>('#home')

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Scrollspy: подсветка текущей секции в меню
  useEffect(() => {
    const sections = NAV_LINKS.map((l) => document.getElementById(l.href.slice(1))).filter(
      (el): el is HTMLElement => el !== null
    )
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActive(`#${entry.target.id}`)
          }
        }
      },
      { rootMargin: '-35% 0px -60% 0px' }
    )
    sections.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  const linkClass = (href: string) =>
    `relative px-3.5 py-2 text-[13px] font-medium uppercase tracking-wide transition-colors rounded-md ${
      active === href ? 'text-gold' : 'text-muted-foreground hover:text-gold hover:bg-gold/5'
    }`

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/85 backdrop-blur-xl border-b border-gold/20 shadow-[0_4px_30px_rgba(0,0,0,0.5)]'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <nav
        aria-label="Основная навигация"
        className="mx-auto flex h-16 md:h-18 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8"
      >
        <a href="#home" className="flex items-center gap-2.5 group" aria-label="TARNUM — на главную">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-gold/40 bg-gold/10 text-gold transition-all group-hover:bg-gold/20 group-hover:shadow-[0_0_16px_rgba(240,178,62,0.4)]">
            <Swords className="h-5 w-5" aria-hidden="true" />
          </span>
          <span className="font-display text-lg font-bold tracking-wider text-foreground">
            TARNUM<span className="text-gold">.MLBB</span>
          </span>
        </a>

        {/* Desktop nav */}
        <ul className="hidden lg:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                aria-current={active === link.href ? 'true' : undefined}
                className={linkClass(link.href)}
              >
                {link.label}
                {active === link.href && (
                  <motion.span
                    layoutId="nav-underline"
                    className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-r from-gold-dark to-gold-light"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:block">
          <Button
            asChild
            className="clip-slant bg-gradient-to-r from-gold-dark via-gold to-gold-light text-primary-foreground font-semibold shadow-[0_0_20px_rgba(240,178,62,0.35)] hover:shadow-[0_0_30px_rgba(240,178,62,0.55)] transition-shadow"
          >
            <a href={TWITCH_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
              Twitch
            </a>
          </Button>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label={open ? 'Закрыть меню' : 'Открыть меню'}
          className="lg:hidden flex h-11 w-11 items-center justify-center rounded-lg border border-gold/30 bg-gold/10 text-gold"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="lg:hidden overflow-hidden border-b border-gold/20 bg-background/95 backdrop-blur-xl"
          >
            <ul className="flex flex-col gap-1 px-4 pb-5 pt-2">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault()
                      setOpen(false)
                      goToSection(link.href)
                    }}
                    className={`block rounded-lg px-4 py-3 text-sm font-medium uppercase tracking-wide transition-colors ${
                      active === link.href
                        ? 'bg-gold/10 text-gold'
                        : 'text-muted-foreground hover:bg-gold/10 hover:text-gold'
                    }`}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <Button
                  asChild
                  className="w-full clip-slant bg-gradient-to-r from-gold-dark via-gold to-gold-light text-primary-foreground font-semibold"
                >
                  <a href={TWITCH_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
                    Открыть Twitch
                  </a>
                </Button>
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

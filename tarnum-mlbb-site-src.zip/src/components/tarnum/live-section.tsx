'use client'

import { useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ExternalLink, Radio, CalendarClock, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SITE, TWITCH_CHANNEL_URL } from '@/config/site'
import { SectionHeading } from './section-heading'

type StreamState = 'loading' | 'live-window' | 'countdown'

interface MskClock {
  /** Часы по МСК (0-23) */
  hours: number
  minutes: number
  seconds: number
}

function getMskClock(): MskClock {
  const parts = new Intl.DateTimeFormat('ru-RU', {
    timeZone: 'Europe/Moscow',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(new Date())

  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0)
  return { hours: get('hour') % 24, minutes: get('minute'), seconds: get('second') }
}

function useStreamCountdown() {
  const [clock, setClock] = useState<MskClock | null>(null)

  useEffect(() => {
    const update = () => setClock(getMskClock())
    const timer = window.setInterval(update, 1000)
    update()
    return () => window.clearInterval(timer)
  }, [])

  return useMemo(() => {
    if (!clock) return { state: 'loading' as StreamState, label: '--:--:--', clock: null }
    const { startTime, endTime } = SITE.schedule
    const inWindow = clock.hours >= startTime && clock.hours < endTime
    if (inWindow) {
      return { state: 'live-window' as StreamState, label: 'Сейчас окно стрима', clock }
    }
    // Секунды до 18:00 МСК следующего раза
    const nowSeconds = clock.hours * 3600 + clock.minutes * 60 + clock.seconds
    const startSeconds = startTime * 3600
    const diff = nowSeconds < startSeconds ? startSeconds - nowSeconds : 86400 - nowSeconds + startSeconds
    const h = Math.floor(diff / 3600)
    const m = Math.floor((diff % 3600) / 60)
    const s = diff % 60
    const pad = (n: number) => String(n).padStart(2, '0')
    return { state: 'countdown' as StreamState, label: `${pad(h)}:${pad(m)}:${pad(s)}`, clock }
  }, [clock])
}

export function LiveSection() {
  const [parent, setParent] = useState<string | null>(null)
  const { state, label } = useStreamCountdown()

  useEffect(() => {
    // parent для Twitch-эмбеда обязан совпадать с доменом страницы
    const setHost = () => setParent(window.location.hostname)
    const timer = window.setTimeout(setHost, 0)
    return () => window.clearTimeout(timer)
  }, [])

  const playerSrc = useMemo(() => {
    if (!parent) return null
    return `https://player.twitch.tv/?channel=${SITE.twitchLogin}&parent=${parent}&autoplay=false&muted=false`
  }, [parent])

  return (
    <section id="live" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Прямой эфир"
          title="Смотреть прямо здесь"
          description="Плеер показывает эфир, когда канал онлайн, а в остальное время — последние записи и клипы канала."
        />

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Twitch player */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2"
          >
            <div className="relative aspect-video overflow-hidden rounded-2xl border border-gold/30 bg-surface shadow-[0_20px_60px_rgba(0,0,0,0.5)]">
              {playerSrc ? (
                <iframe
                  key={playerSrc}
                  src={playerSrc}
                  title={`Twitch-плеер канала ${SITE.twitchLogin}`}
                  allowFullScreen
                  className="absolute inset-0 h-full w-full"
                />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-muted-foreground" aria-hidden="true">
                  <Loader2 className="h-8 w-8 animate-spin text-gold" />
                  <span className="text-sm">Загружаем плеер…</span>
                </div>
              )}
            </div>
            <p className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
              <span>Если плеер не отобразился —</span>
              <a
                href={TWITCH_CHANNEL_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 font-medium text-gold hover:text-gold-light"
              >
                откройте канал на Twitch
                <ExternalLink className="h-3 w-3" aria-hidden="true" />
              </a>
            </p>
          </motion.div>

          {/* Status panel */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ delay: 0.12, duration: 0.6 }}
            className="flex flex-col gap-4"
          >
            {/* Countdown card */}
            <div
              className={`rounded-2xl border p-6 transition-colors ${
                state === 'live-window'
                  ? 'border-blood/50 bg-gradient-to-b from-blood/15 to-card shadow-[0_0_32px_rgba(224,69,90,0.2)]'
                  : 'border-gold/25 bg-card'
              }`}
            >
              <div className="mb-4 flex items-center gap-3">
                <span
                  className={`flex h-11 w-11 items-center justify-center rounded-xl ${
                    state === 'live-window' ? 'bg-blood/15 text-blood' : 'bg-gold/12 text-gold'
                  }`}
                >
                  {state === 'live-window' ? (
                    <Radio className="h-5 w-5" aria-hidden="true" />
                  ) : (
                    <CalendarClock className="h-5 w-5" aria-hidden="true" />
                  )}
                </span>
                <p className="font-display text-sm font-semibold uppercase tracking-wider text-foreground">
                  {state === 'live-window' ? 'Окно стрима' : 'До начала стрима'}
                </p>
              </div>

              {state === 'loading' ? (
                <p className="font-display text-3xl font-bold text-muted-foreground md:text-4xl" aria-hidden="true">
                  --:--:--
                </p>
              ) : state === 'live-window' ? (
                <>
                  <p className="font-display text-2xl font-bold text-blood md:text-3xl">
                    {label}
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    Окно стрима: ежедневно {SITE.schedule.label}. Если канал ещё офлайн — старт скоро.
                  </p>
                </>
              ) : (
                <>
                  <p
                    className="font-display text-3xl font-bold tabular-nums text-gold text-glow-gold md:text-4xl"
                    aria-live="polite"
                  >
                    {label}
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    Время московское. Стрим стартует в {String(SITE.schedule.startTime).padStart(2, '0')}:00 МСК каждый день.
                  </p>
                </>
              )}
            </div>

            {/* Quick facts */}
            <div className="rounded-2xl border border-gold/15 bg-surface p-6">
              <ul className="flex flex-col gap-3 text-sm text-muted-foreground">
                <li className="flex items-center justify-between gap-3">
                  <span>Канал</span>
                  <span className="font-medium text-foreground">{SITE.twitchLogin}</span>
                </li>
                <li className="flex items-center justify-between gap-3">
                  <span>Ранг</span>
                  <span className="font-medium text-gold">{SITE.rank}</span>
                </li>
                <li className="flex items-center justify-between gap-3">
                  <span>График</span>
                  <span className="font-medium text-foreground">{SITE.schedule.mode}</span>
                </li>
                <li className="flex items-center justify-between gap-3">
                  <span>Время</span>
                  <span className="font-medium text-foreground">{SITE.schedule.label}</span>
                </li>
              </ul>
              <Button
                asChild
                className="clip-slant mt-5 w-full bg-gradient-to-r from-gold-dark via-gold to-gold-light font-bold text-primary-foreground shadow-[0_0_22px_rgba(240,178,62,0.35)] transition-shadow hover:shadow-[0_0_36px_rgba(240,178,62,0.55)]"
              >
                <a href={TWITCH_CHANNEL_URL} target="_blank" rel="noopener noreferrer">
                  Открыть канал на Twitch
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

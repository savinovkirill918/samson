'use client'

import { motion } from 'framer-motion'

interface SectionHeadingProps {
  kicker: string
  title: string
  description?: string
  align?: 'left' | 'center'
}

export function SectionHeading({
  kicker,
  title,
  description,
  align = 'center',
}: SectionHeadingProps) {
  const alignClass = align === 'center' ? 'text-center items-center' : 'text-left items-start'

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`flex flex-col gap-3 mb-10 md:mb-14 ${alignClass}`}
    >
      <div className="flex items-center gap-3">
        <span className="h-px w-8 bg-gradient-to-r from-transparent to-gold" aria-hidden="true" />
        <span className="font-display text-[11px] md:text-xs font-semibold uppercase tracking-[0.3em] text-gold">
          {kicker}
        </span>
        <span className="h-px w-8 bg-gradient-to-l from-transparent to-gold" aria-hidden="true" />
      </div>
      <h2 className="font-display text-2xl md:text-4xl font-bold uppercase tracking-wide text-foreground">
        {title}
      </h2>
      {description && (
        <p className="max-w-2xl text-sm md:text-base text-muted-foreground leading-relaxed">
          {description}
        </p>
      )}
    </motion.div>
  )
}

import { Navbar } from '@/components/tarnum/navbar'
import { Hero } from '@/components/tarnum/hero'
import { LiveSection } from '@/components/tarnum/live-section'
import { About } from '@/components/tarnum/about'
import { Heroes } from '@/components/tarnum/heroes'
import { Schedule } from '@/components/tarnum/schedule'
import { Content } from '@/components/tarnum/content'
import { Socials } from '@/components/tarnum/socials'
import { Footer } from '@/components/tarnum/footer'

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <LiveSection />
        <About />
        <Heroes />
        <Schedule />
        <Content />
        <Socials />
      </main>
      <Footer />
    </div>
  )
}

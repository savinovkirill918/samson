import type { Metadata } from "next";
import { Unbounded, Rubik } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const unbounded = Unbounded({
  variable: "--font-unbounded",
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800", "900"],
});

const rubik = Rubik({
  variable: "--font-rubik",
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "TARNUM — Стример Mobile Legends: Bang Bang",
  description:
    "Официальное портфолио Tarnum — топового стримера Mobile Legends: Bang Bang на Twitch. Ранкед-игры, турниры, гайды по героям и эпичные моменты.",
  keywords: [
    "Tarnum",
    "MLBB",
    "Mobile Legends",
    "Twitch",
    "стример",
    "Mobile Legends Bang Bang",
    "стрим",
  ],
  authors: [{ name: "Tarnum MLBB" }],
  openGraph: {
    title: "TARNUM — Стример Mobile Legends: Bang Bang",
    description:
      "Топовый стример MLBB на Twitch. Мифический ранг, эпичные моменты и живое комьюнити.",
    siteName: "TARNUM MLBB",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "TARNUM — Стример Mobile Legends: Bang Bang",
    description:
      "Топовый стример MLBB на Twitch. Мифический ранг, эпичные моменты и живое комьюнити.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${unbounded.variable} ${rubik.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

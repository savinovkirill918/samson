'use client';

import React, { useState, useRef, useCallback } from 'react';
import { Upload, CheckCircle, AlertCircle, FileSpreadsheet, X, RefreshCw, Download, FileText } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { AdminUser, Group } from '@/lib/types';
import { getGroupName } from '@/lib/helpers';

/* ================================================================== */
/*  Types                                                               */
/* ================================================================== */

interface ResultRow {
  num: number;
  code1c: string;
  name: string;
  glavnyQty: number;
  uchetQty: number;
  uchetCost: number;
  excelQty: number;
  wmsQty: number;
}

interface CompareStats {
  excelTotal: number;
  excelFiltered: number;
  wmsTotal: number;
  wmsAfterFilter: number;
  matchedCount: number;
}

interface InventoryBalancePageProps {
  authUser: AdminUser | null;
  groups: Group[];
}

/* ================================================================== */
/*  Component                                                           */
/* ================================================================== */

export default function InventoryBalancePage({ authUser, groups }: InventoryBalancePageProps) {
  const [file1, setFile1] = useState<File | null>(null);
  const [file2, setFile2] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<ResultRow[]>([]);
  const [stats, setStats] = useState<CompareStats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [szModalOpen, setSzModalOpen] = useState(false);
  const [szNumber, setSzNumber] = useState('');
  const [szLoading, setSzLoading] = useState(false);

  const file1Ref = useRef<HTMLInputElement>(null);
  const file2Ref = useRef<HTMLInputElement>(null);

  const handleFile1Change = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    setFile1(f);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);
  }, []);

  const handleFile2Change = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null;
    setFile2(f);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);
  }, []);

  const clearFile1 = useCallback(() => {
    setFile1(null);
    if (file1Ref.current) file1Ref.current.value = '';
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
  }, []);

  const clearFile2 = useCallback(() => {
    setFile2(null);
    if (file2Ref.current) file2Ref.current.value = '';
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
  }, []);

  const handleCompare = async () => {
    if (!file1 || !file2) {
      setError('Загрузите оба файла для сверки');
      return;
    }

    setLoading(true);
    setError(null);
    setSuccess(null);
    setResults([]);
    setStats(null);

    try {
      const formData = new FormData();
      formData.append('file1', file1);
      formData.append('file2', file2);

      const response = await fetch('/api/inventory-balance', {
        method: 'POST',
        body: formData,
      });

      const text = await response.text();
      let data: any;
      try {
        data = JSON.parse(text);
      } catch {
        throw new Error(`Сервер вернул ошибку (HTTP ${response.status}). Возможно, файл слишком большой.`);
      }

      if (!response.ok) {
        throw new Error(data?.error || 'Ошибка сервера при обработке файлов');
      }

      const matched: ResultRow[] = data.results || [];
      const compareStats: CompareStats = data.stats || {};

      setResults(matched);
      setStats(compareStats);

      if (matched.length === 0) {
        setError('Нет номенклатуры с совпадающими остатками. Проверьте файлы и ключи сопоставления.');
      } else {
        setSuccess(`Найдено ${matched.length} позиций с совпадающими остатками`);
      }
    } catch (err: any) {
      setError(`Ошибка обработки: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const hasResults = results.length > 0 && !loading;

  // Filter results by search
  const filteredResults = searchQuery
    ? results.filter(r =>
        r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.code1c.includes(searchQuery)
      )
    : results;

  const handleExportExcel = useCallback(() => {
    if (filteredResults.length === 0) return;

    const XLSX = require('xlsx');
    const wsData = [
      ['', '', '', 'Данные из 1С', '', '', '', 'WMS'],
      ['№ п.п', 'Код 1С', 'Наименование', 'Остаток (Главный)', 'Остаток (Учет)', 'Стоимость остатка (Учет), руб.', 'Итого (Главный + Учет)', 'Остаток WMS'],
      ...filteredResults.map(r => [r.num, r.code1c, r.name, r.glavnyQty, r.uchetQty, r.uchetCost, r.excelQty, r.wmsQty]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws['!cols'] = [{ wch: 8 }, { wch: 14 }, { wch: 50 }, { wch: 16 }, { wch: 14 }, { wch: 22 }, { wch: 22 }, { wch: 16 }];
    ws['!merges'] = [
      { s: { r: 0, c: 3 }, e: { r: 0, c: 6 } },
      { s: { r: 0, c: 7 }, e: { r: 0, c: 7 } },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Сверка остатков');
    XLSX.writeFile(wb, 'сверка_остатков.xlsx');
  }, [filteredResults]);

  const handleCreateSz = useCallback(async () => {
    if (!szNumber.trim()) return;
    setSzLoading(true);
    setError(null);

    try {
      const position = authUser ? getGroupName(authUser.groupId, groups) : '';
      const fio = authUser?.fio || '';

      const response = await fetch('/api/generate-sz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          szNumber: szNumber.trim(),
          date: new Date().toISOString(),
          position,
          fio,
          rows: filteredResults,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({ error: 'Ошибка генерации документа' }));
        throw new Error(errData.error || 'Ошибка генерации документа');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `СЗ №${szNumber.trim()}.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setSzModalOpen(false);
      setSzNumber('');
    } catch (err: any) {
      setError(`Ошибка создания СЗ: ${err.message}`);
    } finally {
      setSzLoading(false);
    }
  }, [szNumber, filteredResults, authUser, groups]);

  const handleReset = useCallback(() => {
    setFile1(null);
    setFile2(null);
    setResults([]);
    setStats(null);
    setError(null);
    setSuccess(null);
    setSearchQuery('');
    if (file1Ref.current) file1Ref.current.value = '';
    if (file2Ref.current) file2Ref.current.value = '';
  }, []);

  return (
    <div>
      {/* ====== Заголовок, описание, загрузка файлов + кнопка (скрываются при наличии результатов) ====== */}
      {!hasResults && (
        <>
          <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.heading }}>Учет остатков</h2>
          <p className="text-sm mb-6" style={{ color: COLORS.text }}>
            Сверка складских остатков из двух источников. Загрузите оба файла и нажмите «Сверить остатки» для получения списка номенклатуры, где остатки совпадают.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {/* File 1 — Учет + Главный */}
            <div className="bg-white rounded-xl shadow p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileSpreadsheet className="w-5 h-5" style={{ color: COLORS.primary }} />
                <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>Учет + Главный</h3>
              </div>
              <p className="text-xs mb-3" style={{ color: COLORS.text }}>Excel файл с остатками по складам Главный и Учет (.xls / .xlsx)</p>
              <div className="relative">
                <label className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: file1 ? '#3a57e8' : '#dee2e6', backgroundColor: file1 ? '#f0f4ff' : 'transparent' }}>
                  <Upload className="w-4 h-4" style={{ color: file1 ? COLORS.primary : COLORS.text }} />
                  <span className="text-sm" style={{ color: file1 ? COLORS.primary : COLORS.text }}>
                    {file1 ? file1.name : 'Выберите файл .xls / .xlsx'}
                  </span>
                  <input
                    ref={file1Ref}
                    type="file"
                    accept=".xls,.xlsx"
                    onChange={handleFile1Change}
                    className="hidden"
                  />
                </label>
                {file1 && (
                  <button onClick={clearFile1} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* File 2 — WMS остатки */}
            <div className="bg-white rounded-xl shadow p-5">
              <div className="flex items-center gap-2 mb-3">
                <FileSpreadsheet className="w-5 h-5" style={{ color: COLORS.primary }} />
                <h3 className="font-semibold text-sm" style={{ color: COLORS.heading }}>Остатки товаров 31 отчет</h3>
              </div>
              <p className="text-xs mb-3" style={{ color: COLORS.text }}>Excel файл с остатками товаров из WMS (.xls / .xlsx)</p>
              <div className="relative">
                <label className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed rounded-lg cursor-pointer hover:border-blue-400 transition" style={{ borderColor: file2 ? '#3a57e8' : '#dee2e6', backgroundColor: file2 ? '#f0f4ff' : 'transparent' }}>
                  <Upload className="w-4 h-4" style={{ color: file2 ? COLORS.primary : COLORS.text }} />
                  <span className="text-sm" style={{ color: file2 ? COLORS.primary : COLORS.text }}>
                    {file2 ? file2.name : 'Выберите файл .xls / .xlsx'}
                  </span>
                  <input
                    ref={file2Ref}
                    type="file"
                    accept=".xls,.xlsx"
                    onChange={handleFile2Change}
                    className="hidden"
                  />
                </label>
                {file2 && (
                  <button onClick={clearFile2} className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Кнопка сверки */}
          <div className="mb-6">
            <button
              onClick={handleCompare}
              disabled={!file1 || !file2 || loading}
              className="px-6 py-3 text-white rounded-lg text-sm font-medium hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              style={{ backgroundColor: COLORS.primary }}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Обработка...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Сверить остатки
                </>
              )}
            </button>
          </div>
        </>
      )}

      {/* ====== Сообщения ====== */}
      {error && (
        <div className="mb-2 flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-red-50 text-red-700">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* ====== Loading spinner ====== */}
      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="w-10 h-10 border-4 rounded-full animate-spin" style={{ borderColor: `${COLORS.primary} transparent transparent transparent` }} />
          <span className="ml-3 text-sm" style={{ color: COLORS.text }}>Обработка файлов на сервере...</span>
        </div>
      )}

      {/* ====== Результаты ====== */}
      {hasResults && (
        <div className="bg-white rounded-xl shadow overflow-hidden">
          {/* Заголовок с кнопками */}
          <div className="px-5 py-3 border-b flex items-center justify-between gap-3" style={{ borderColor: '#f0f0f0' }}>
            <h3 className="font-semibold text-sm whitespace-nowrap" style={{ color: COLORS.heading }}>
              Результаты сверки ({results.length})
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSzModalOpen(true)}
                className="px-4 py-1.5 text-sm font-medium rounded-lg transition flex items-center gap-1.5 whitespace-nowrap text-white"
                style={{ backgroundColor: COLORS.primary }}
              >
                <FileText className="w-3.5 h-3.5" />
                Создать СЗ
              </button>
              <button
                onClick={handleExportExcel}
                className="px-4 py-1.5 text-sm font-medium rounded-lg transition flex items-center gap-1.5 whitespace-nowrap text-white"
                style={{ backgroundColor: '#22c55e' }}
              >
                <Download className="w-3.5 h-3.5" />
                Выгрузить в Excel
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-1.5 text-sm font-medium rounded-lg border hover:bg-gray-50 transition flex items-center gap-1.5 whitespace-nowrap"
                style={{ borderColor: '#dee2e6', color: COLORS.heading }}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Новая сверка
              </button>
            </div>
          </div>

          {/* Таблица */}
          <div className="overflow-x-auto max-h-[calc(100vh-200px)] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-10" style={{ backgroundColor: '#f8f9fa' }}>
                {/* Верхняя строка заголовков — группировка */}
                <tr style={{ borderBottom: '1px solid #e5e7eb' }}>
                  <th className="px-4 py-2 text-center font-semibold text-xs" style={{ color: COLORS.heading }} colSpan={3}></th>
                  <th className="px-4 py-2 text-center font-semibold text-xs" style={{ color: '#ffffff', backgroundColor: COLORS.primary }} colSpan={4}>Данные из 1С</th>
                  <th className="px-4 py-2 text-center font-semibold text-xs" style={{ color: '#ffffff', backgroundColor: '#6b7280' }}>WMS</th>
                </tr>
                {/* Нижняя строка заголовков — названия колонок */}
                <tr>
                  <th className="px-4 py-2.5 text-left font-medium w-14" style={{ color: COLORS.heading }}>№ п.п</th>
                  <th className="px-4 py-2.5 text-left font-medium w-28" style={{ color: COLORS.heading }}>Код 1С</th>
                  <th className="px-4 py-2.5 text-left font-medium" style={{ color: COLORS.heading }}>Наименование</th>
                  <th className="px-4 py-2.5 text-right font-medium w-24" style={{ color: COLORS.heading }}>Остаток (Главный)</th>
                  <th className="px-4 py-2.5 text-right font-medium w-22" style={{ color: COLORS.heading }}>Остаток (Учет)</th>
                  <th className="px-4 py-2.5 text-right font-medium w-28" style={{ color: COLORS.heading }}>Стоимость (Учет), руб.</th>
                  <th className="px-4 py-2.5 text-right font-medium w-32" style={{ color: COLORS.heading }}>Итого (Главный + Учет)</th>
                  <th className="px-4 py-2.5 text-right font-medium w-24" style={{ color: COLORS.heading }}>Остаток WMS</th>
                </tr>
              </thead>
              <tbody>
                {filteredResults.map((row) => (
                  <tr key={row.code1c} className="border-t hover:bg-gray-50 transition" style={{ borderColor: '#f0f0f0' }}>
                    <td className="px-4 py-2.5" style={{ color: COLORS.text }}>{row.num}</td>
                    <td className="px-4 py-2.5 font-mono text-xs" style={{ color: COLORS.heading }}>{row.code1c}</td>
                    <td className="px-4 py-2.5" style={{ color: COLORS.heading }}>{row.name}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.glavnyQty.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.uchetQty.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.uchetCost.toLocaleString('ru-RU', { minimumFractionDigits: 2 })}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.excelQty.toLocaleString('ru-RU')}</td>
                    <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.heading }}>{row.wmsQty.toLocaleString('ru-RU')}</td>
                  </tr>
                ))}
                {/* Строка Итого */}
                <tr className="border-t-2" style={{ borderColor: '#d1d5db', backgroundColor: '#f0f4ff' }}>
                  <td className="px-4 py-2.5" colSpan={5} style={{ color: COLORS.heading, fontWeight: 600 }}>Итого</td>
                  <td className="px-4 py-2.5 text-right font-mono" style={{ color: COLORS.primary, fontWeight: 700 }}>
                    {filteredResults.reduce((sum, r) => sum + r.uchetCost, 0).toLocaleString('ru-RU', { minimumFractionDigits: 2 })}
                  </td>
                  <td colSpan={2}></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ====== Модальное окно создания СЗ ====== */}
      {szModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}>
          <div className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold mb-4" style={{ color: COLORS.heading }}>Создание служебной записки</h3>
            <label className="block text-sm font-medium mb-2" style={{ color: COLORS.text }}>
              Введите номер СЗ
            </label>
            <input
              type="text"
              value={szNumber}
              onChange={(e) => setSzNumber(e.target.value)}
              placeholder="Например: 2327"
              className="w-full px-4 py-2.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
              style={{ borderColor: '#dee2e6' }}
              autoFocus
              onKeyDown={(e) => { if (e.key === 'Enter' && szNumber.trim()) handleCreateSz(); }}
            />
            <div className="flex items-center gap-3 mt-5 justify-end">
              <button
                onClick={() => { setSzModalOpen(false); setSzNumber(''); }}
                className="px-5 py-2 text-sm font-medium rounded-lg border hover:bg-gray-50 transition"
                style={{ borderColor: '#dee2e6', color: COLORS.heading }}
                disabled={szLoading}
              >
                Отмена
              </button>
              <button
                onClick={handleCreateSz}
                disabled={!szNumber.trim() || szLoading}
                className="px-5 py-2 text-sm font-medium rounded-lg text-white transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                style={{ backgroundColor: COLORS.primary }}
              >
                {szLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Создание...
                  </>
                ) : (
                  'Создать'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Пустое состояние — до сверки */}
      {results.length === 0 && !loading && !error && success === null && (
        <div className="bg-white rounded-xl shadow p-8 text-center">
          <FileSpreadsheet className="w-12 h-12 mx-auto mb-3" style={{ color: '#d1d5db' }} />
          <p className="text-sm" style={{ color: COLORS.text }}>
            Загрузите оба файла и нажмите «Сверить остатки» для получения результатов
          </p>
        </div>
      )}
    </div>
  );
}

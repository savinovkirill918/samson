import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';

/* ================================================================== */
/*  Helpers                                                             */
/* ================================================================== */

/** Parse number from string — handles spaces like "1 000", commas, etc. */
const parseNum = (v: any): number => {
  if (v === null || v === undefined) return 0;
  if (typeof v === 'number') return v;
  const s = String(v).trim();
  if (s === '' || s === '-' || s === '—') return 0;
  const cleaned = s.replace(/\s+/g, '').replace(',', '.');
  const n = Number(cleaned);
  return isNaN(n) ? 0 : n;
};

/* ================================================================== */
/*  Parse Excel file 1 (Учет + Главный)                                */
/*  Header structure (rows 5-6):                                        */
/*    Row 5: [№, Код, Товар, Всего, Всего, Главный, '', Учет, '']       */
/*    Row 6: [п/п, '', '', Остаток шт, Стоимость руб, ...]              */
/*  Data starts at row 7.                                               */
/*  Columns: 0=№, 1=Код, 2=Товар, 3=Всего Остаток шт,                 */
/*           4=Всего Стоимость, 5=Главный Остаток шт,                   */
/*           6=Главный Стоимость, 7=Учет Остаток шт, 8=Учет Стоимость   */
/* ================================================================== */
const parseExcelUchetGlavny = (wb: XLSX.WorkBook) => {
  const ws = wb.Sheets[wb.SheetNames[0]];
  if (!ws) throw new Error('Не удалось прочитать лист из файла Учет + Главный');

  const raw: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

  if (raw.length < 8) {
    throw new Error('Файл "Учет + Главный" содержит слишком мало строк. Проверьте формат файла.');
  }

  // Find header row — look for row where column 1 contains "Код"
  let headerRowIdx = -1;
  for (let i = 0; i < Math.min(20, raw.length); i++) {
    const row = raw[i];
    if (row && row.length > 1) {
      const val = String(row[1]).trim();
      if (val === 'Код' || val.toLowerCase() === 'код') {
        headerRowIdx = i;
        break;
      }
    }
  }

  if (headerRowIdx === -1) {
    // Fallback: try to find any row where column 1 looks like a product code
    // and column 2 is a long product name (typical data row)
    for (let i = 0; i < Math.min(20, raw.length); i++) {
      const row = raw[i];
      if (row && row.length >= 9) {
        const col0 = String(row[0]).trim();
        const col1 = String(row[1]).trim();
        const col2 = String(row[2]).trim();
        if (col0 === '№' && col1 === 'Код') {
          headerRowIdx = i;
          break;
        }
      }
    }
  }

  if (headerRowIdx === -1) {
    // Last resort: assume data starts at row 7 (standard format)
    // Check if row 7 has a numeric value in column 0 and a code in column 1
    if (raw.length > 7) {
      const testRow = raw[7];
      if (testRow && typeof testRow[0] === 'number' && testRow[1] && String(testRow[1]).trim().length > 0) {
        headerRowIdx = 5; // Assume standard header at row 5
      }
    }
  }

  if (headerRowIdx === -1) {
    throw new Error('Не найдена строка заголовков в файле Учет + Главный. Убедитесь, что колонка "Код" присутствует.');
  }

  // Data starts after header (skip possible sub-header row with "п/п")
  let dataStartIdx = headerRowIdx + 1;
  if (dataStartIdx < raw.length) {
    const firstVal = String(raw[dataStartIdx][0]).trim().toLowerCase();
    if (firstVal.includes('п/п') || firstVal === 'п/п') {
      dataStartIdx++;
    }
  }

  const results: {
    code: string;
    totalQty: number;
    totalCost: number;
    mainQty: number;
    mainCost: number;
    accountQty: number;
    accountCost: number;
  }[] = [];

  for (let i = dataStartIdx; i < raw.length; i++) {
    const row = raw[i];
    if (!row || !row[1]) continue;

    const code = String(row[1]).trim();
    if (!code || code === 'Итого' || code === 'Всего') continue;

    const totalQty = parseNum(row[3]);
    const totalCost = parseNum(row[4]);
    const mainQty = parseNum(row[5]);
    const mainCost = parseNum(row[6]);
    const accountQty = parseNum(row[7]);
    const accountCost = parseNum(row[8]);

    results.push({ code, totalQty, totalCost, mainQty, mainCost, accountQty, accountCost });
  }

  return results;
};

/* ================================================================== */
/*  Parse Excel file 2 (WMS — остатки товаров 31 отчет)                */
/*  Header: [Код 1С, Наименование, Ячейка хранения, Помещение, ...     */
/*           Доступное кол-во, Кол-во в транзите, ...]                  */
/* ================================================================== */
const parseExcelWms = (wb: XLSX.WorkBook) => {
  const ws = wb.Sheets[wb.SheetNames[0]];
  if (!ws) throw new Error('Не удалось прочитать лист из файла WMS');

  const raw: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

  if (raw.length < 2) throw new Error('Файл WMS содержит слишком мало данных');

  // Validate header row
  const header = raw[0].map((h: any) => String(h || '').trim().toLowerCase());
  const codeIdx = header.findIndex(h => h.includes('код 1с') || h === 'код1с' || (h === 'код' && header.indexOf(h) === 0));
  const nameIdx = header.findIndex(h => h.includes('наименование'));
  const roomIdx = header.findIndex(h => h.includes('помещение'));
  const availIdx = header.findIndex(h => h.includes('доступное кол') || h.includes('доступное'));
  const transitIdx = header.findIndex(h => h.includes('транзит'));

  if (codeIdx === -1) throw new Error('Не найдена колонка "Код 1С" в файле WMS');
  if (roomIdx === -1) throw new Error('Не найдена колонка "Помещение" в файле WMS');
  if (availIdx === -1) throw new Error('Не найдена колонка "Доступное кол-во" в файле WMS');

  const results: {
    code1c: string;
    name: string;
    room: string;
    availableQty: number;
    transitQty: number;
  }[] = [];

  for (let i = 1; i < raw.length; i++) {
    const row = raw[i];
    if (!row || !row[codeIdx]) continue;

    const code1c = String(row[codeIdx]).trim();
    if (!code1c) continue;

    results.push({
      code1c,
      name: nameIdx >= 0 ? String(row[nameIdx] || '').trim() : '',
      room: roomIdx >= 0 ? String(row[roomIdx] || '').trim() : '',
      availableQty: availIdx >= 0 ? parseNum(row[availIdx]) : 0,
      transitQty: transitIdx >= 0 ? parseNum(row[transitIdx]) : 0,
    });
  }

  return results;
};

/* ================================================================== */
/*  POST handler                                                        */
/* ================================================================== */
export const config = {
  api: {
    bodyParser: {
      sizeLimit: '50mb',
    },
  },
};

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file1 = formData.get('file1') as File | null;
    const file2 = formData.get('file2') as File | null;

    if (!file1 || !file2) {
      return NextResponse.json({ error: 'Необходимо загрузить оба файла' }, { status: 400 });
    }

    // Parse file 1 — Учет + Главный
    const buf1 = await file1.arrayBuffer();
    const wb1 = XLSX.read(Buffer.from(buf1), { type: 'buffer' });
    const excelData = parseExcelUchetGlavny(wb1);

    if (excelData.length === 0) {
      return NextResponse.json({ error: 'Файл "Учет + Главный" не содержит данных. Проверьте формат файла.' }, { status: 400 });
    }

    // Parse file 2 — WMS
    const buf2 = await file2.arrayBuffer();
    const wb2 = XLSX.read(Buffer.from(buf2), { type: 'buffer' });
    const wmsData = parseExcelWms(wb2);

    if (wmsData.length === 0) {
      return NextResponse.json({ error: 'Файл "остатки товаров 31 отчет" не содержит данных. Проверьте формат файла.' }, { status: 400 });
    }

    // === Шаг 1: Обработка Excel (Учет + Главный) ===
    // Фильтр: Учет Остаток шт > 0
    // Итого_Excel = Главный Остаток шт + Учет Остаток шт
    const excelMap = new Map<string, { itogoExcel: number; mainQty: number; accountQty: number; accountCost: number }>();

    for (const row of excelData) {
      if (row.accountQty <= 0) continue;
      const itogoExcel = row.mainQty + row.accountQty;
      excelMap.set(row.code, { itogoExcel, mainQty: row.mainQty, accountQty: row.accountQty, accountCost: row.accountCost });
    }

    // === Шаг 2: Обработка WMS ===
    // Фильтр: исключить строки где Помещение = "BR" или "PACK"
    // Группировка по Код 1С — суммируем Доступное количество
    const wmsMap = new Map<string, { itogoWms: number; name: string }>();

    for (const row of wmsData) {
      if (row.room === 'BR' || row.room === 'PACK') continue;

      const existing = wmsMap.get(row.code1c);
      if (existing) {
        existing.itogoWms += row.availableQty;
      } else {
        wmsMap.set(row.code1c, {
          itogoWms: row.availableQty,
          name: row.name,
        });
      }
    }

    // === Шаг 3: Сравнение ===
    const matched: {
      num: number;
      code1c: string;
      name: string;
      glavnyQty: number;
      uchetQty: number;
      uchetCost: number;
      excelQty: number;
      wmsQty: number;
    }[] = [];
    let num = 0;

    for (const [code, excelInfo] of excelMap) {
      const wmsInfo = wmsMap.get(code);
      if (!wmsInfo) continue;

      if (excelInfo.itogoExcel === wmsInfo.itogoWms) {
        num++;
        matched.push({
          num,
          code1c: code,
          name: wmsInfo.name,
          glavnyQty: excelInfo.mainQty,
          uchetQty: excelInfo.accountQty,
          uchetCost: excelInfo.accountCost,
          excelQty: excelInfo.itogoExcel,
          wmsQty: wmsInfo.itogoWms,
        });
      }
    }

    // Stats for debugging
    const stats = {
      excelTotal: excelData.length,
      excelFiltered: excelMap.size,
      wmsTotal: wmsData.length,
      wmsAfterFilter: wmsMap.size,
      matchedCount: matched.length,
    };

    return NextResponse.json({ results: matched, stats });
  } catch (err: any) {
    console.error('Inventory balance API error:', err);
    return NextResponse.json({ error: err.message || 'Внутренняя ошибка сервера' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import PizZip from 'pizzip';
import * as fs from 'fs';
import * as path from 'path';

/* ================================================================== */
/*  Generate СЗ (Служебная записка) Word document                       */
/* ================================================================== */

interface SzRow {
  num: number;
  code1c: string;
  name: string;
  glavnyQty: number;
  uchetQty: number;
  uchetCost: number;
  excelQty: number;
  wmsQty: number;
}

function escapeXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Extract plain text from a <w:tr>...</w:tr> block by stripping all XML tags */
function trToPlainText(tr: string): string {
  return tr.replace(/<[^>]+>/g, '');
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { szNumber, date, position, fio, rows }: {
      szNumber: string;
      date: string;
      position: string;
      fio: string;
      rows: SzRow[];
    } = body;

    if (!szNumber || !rows || rows.length === 0) {
      return NextResponse.json({ error: 'Не указан номер СЗ или нет данных' }, { status: 400 });
    }

    // Read template
    const templatePath = path.join(process.cwd(), 'templates', 'sz-template.docx');
    if (!fs.existsSync(templatePath)) {
      return NextResponse.json({ error: 'Шаблон СЗ не найден на сервере' }, { status: 500 });
    }

    const templateContent = fs.readFileSync(templatePath);
    const zip = new PizZip(templateContent);
    let docXml = zip.file('word/document.xml')!.asText();

    // Parse date parts
    const dateObj = new Date(date);
    const day = String(dateObj.getDate()).padStart(2, '0');
    const month = String(dateObj.getMonth() + 1).padStart(2, '0');
    const year = dateObj.getFullYear();

    // ---- Step 1: Replace simple text values ----

    // Replace СЗ number (was " 2327")
    docXml = docXml.replace(/> 2327</g, `> ${escapeXml(szNumber)}<`);

    // Replace date parts after "СКФ от" (unique context to avoid replacing table data)
    const skfIdx = docXml.indexOf('СКФ от');
    if (skfIdx !== -1) {
      const dateSection = docXml.substring(skfIdx, skfIdx + 300);
      const replacedDate = dateSection
        .replace(/>11<\/w:t>/, `>${day}</w:t>`)
        .replace(/>\.06<\/w:t>/, `>.${month}</w:t>`)
        .replace(/>2026<\/w:t>/, `>${year}</w:t>`);
      docXml = docXml.substring(0, skfIdx) + replacedDate + docXml.substring(skfIdx + dateSection.length);
    }

    // Replace position and FIO at the bottom
    docXml = docXml.replace(/>Администратор смены</g, `>${escapeXml(position)}<`);
    docXml = docXml.replace(/>Санков Я\.А\.</g, `>${escapeXml(fio)}.<`);

    // ---- Step 2: Replace table data rows ----
    // The template has 6 columns: № п.п | Код 1С | Наименование | Главный | Учет | WMS
    // We keep the original header rows from template and only replace data rows

    const trRegex = /<w:tr[^>]*>[\s\S]*?<\/w:tr>/g;
    const allTrs: { match: string; index: number }[] = [];
    let m;
    while ((m = trRegex.exec(docXml)) !== null) {
      allTrs.push({ match: m[0], index: m.index });
    }

    // Identify header rows (contain "Данные из 1С", "WMS", "№ п.п"/"Код 1С")
    // and data rows (contain product codes, numbered 1-28)
    // and post-table rows (contain "Прошу Вас" etc.)

    let headerEndIdx = -1;   // Index in allTrs after which data rows start
    let dataEndIdx = -1;     // Index in allTrs where data rows end (before post-table)

    for (let i = 0; i < allTrs.length; i++) {
      const text = trToPlainText(allTrs[i].match);

      // Header rows: contain "Данные из 1С" or "№ п.п" or "Код 1С"
      if (text.includes('Данные из 1С') || text.includes('№ п.п') || text.includes('Код 1С')) {
        headerEndIdx = i;
      }

      // Post-table row: contains "Прошу"
      if (text.includes('Прошу') || text.includes('рошу')) {
        if (dataEndIdx === -1) {
          dataEndIdx = i;
        }
      }
    }

    if (headerEndIdx === -1) {
      return NextResponse.json({ error: 'Не найдены заголовки таблицы в шаблоне' }, { status: 500 });
    }

    if (dataEndIdx === -1) {
      dataEndIdx = allTrs.length;
    }

    // Get a sample data row to extract cell formatting
    let sampleDataRow = '';
    const firstDataIdx = headerEndIdx + 1;
    if (firstDataIdx < dataEndIdx) {
      sampleDataRow = allTrs[firstDataIdx].match;
    }

    if (!sampleDataRow) {
      return NextResponse.json({ error: 'Не найдена строка данных в шаблоне' }, { status: 500 });
    }

    // Extract cell properties from sample row (6 cells)
    const tcRegex = /<w:tc[^>]*>[\s\S]*?<\/w:tc>/g;
    const sampleCells = sampleDataRow.match(tcRegex) || [];

    function makeTextRun(text: string): string {
      return `<w:r w:rsidRPr="00E1038F"><w:rPr><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr><w:t xml:space="preserve">${escapeXml(String(text))}</w:t></w:r>`;
    }

    // Build new data rows XML — 6 columns: num, code1c, name, glavnyQty, uchetQty, wmsQty
    let newDataRowsXml = '';
    for (const row of rows) {
      const values = [
        String(row.num),
        row.code1c,
        row.name,
        String(row.glavnyQty),
        String(row.uchetQty),
        String(row.wmsQty),
      ];

      let newRow = '<w:tr>';
      for (let ci = 0; ci < Math.min(sampleCells.length, values.length); ci++) {
        // Preserve cell properties (width, borders) from template
        const tcPrMatch = sampleCells[ci].match(/<w:tcPr>[\s\S]*?<\/w:tcPr>/);
        const tcPr = tcPrMatch ? tcPrMatch[0] : '';

        newRow += `<w:tc>${tcPr}<w:p w:rsidR="00E1038F" w:rsidRPr="00E1038F" w:rsidRDefault="00E1038F" w:rsidP="00E1038F"><w:pPr><w:widowControl w:val="0"/><w:autoSpaceDE w:val="0"/><w:autoSpaceDN w:val="0"/><w:adjustRightInd w:val="0"/></w:pPr>${makeTextRun(values[ci])}</w:p></w:tc>`;
      }
      newRow += '</w:tr>';
      newDataRowsXml += newRow;
    }

    // Rebuild the document XML:
    // 1. Keep everything before data rows
    // 2. Insert our new data rows
    // 3. Keep everything after data rows

    const dataStartPos = allTrs[firstDataIdx].index;
    const dataEndPos = allTrs[dataEndIdx - 1].index + allTrs[dataEndIdx - 1].match.length;

    docXml = docXml.substring(0, dataStartPos) + newDataRowsXml + docXml.substring(dataEndPos);

    // Update the document in the zip
    zip.file('word/document.xml', docXml);

    // Generate the docx
    const output = zip.generate({ type: 'nodebuffer' });

    // Return as downloadable file
    return new NextResponse(output, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(`СЗ №${szNumber}.docx`)}`,
      },
    });
  } catch (err: any) {
    console.error('Generate SZ error:', err);
    return NextResponse.json({ error: err.message || 'Ошибка генерации документа' }, { status: 500 });
  }
}

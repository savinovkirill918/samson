// =====================================================================
// API маршрут: Генерация PDF с бейджем и наклейкой на ТСД
// Документ формата A4 (210мм × 297мм) содержит два элемента:
//
//   1. Наклейка на ТСД (сплошная рамка, 45мм × 10мм)
//      - Номер ТСД (крупно, по центру)
//      - Фамилия и инициалы (например: "Кузнецов А.В.")
//
//   2. Бейджик (пунктирная рамка для вырезания, 80мм × 47мм)
//      Контент центрирован по вертикали и горизонтали:
//      - Штрихкод логина (CODE128, уменьшенный)
//      - Подпись: "логин ТСД-№" (с переносом слов)
//      - ФИО сотрудника (с переносом слов)
//      - Штрихкод пароля (CODE128, уменьшенный)
//
// Шрифт: Liberation Serif (как в реестре выдачи ТСД)
// =====================================================================

import { NextRequest, NextResponse } from 'next/server';
import jsPDF from 'jspdf';
import JsBarcode from 'jsbarcode';
import { createCanvas } from 'canvas';
import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * Генерация штрихкода CODE128 как PNG data URL (base64)
 * Использует node-canvas для серверного рендеринга
 * @param text - Текст для кодирования в штрихкод
 * @param barWidth - Ширина одной полоски штрихкода
 * @param barHeight - Высота штрихкода в пикселях
 * @returns Строка data URL (base64 PNG)
 */
function generateBarcodeDataUrl(text: string, barWidth: number = 1.5, barHeight: number = 35): string {
  const canvas = createCanvas(300, barHeight + 10);
  JsBarcode(canvas as unknown as HTMLCanvasElement, text, {
    format: 'CODE128',
    width: barWidth,
    height: barHeight,
    displayValue: false,
    margin: 0,
  });
  return canvas.toDataURL('image/png');
}

/**
 * Рисует пунктирный прямоугольник на PDF (для вырезания бейджа)
 */
function drawDashedRect(doc: jsPDF, x: number, y: number, w: number, h: number, dashLen: number = 2, gapLen: number = 1.5): void {
  doc.setLineDashPattern([dashLen, gapLen], 0);
  doc.line(x, y, x + w, y);
  doc.line(x, y + h, x + w, y + h);
  doc.line(x, y, x, y + h);
  doc.line(x + w, y, x + w, y + h);
  doc.setLineDashPattern([], 0);
}

/**
 * Рисует сплошной прямоугольник на PDF (для наклейки на ТСД)
 */
function drawSolidRect(doc: jsPDF, x: number, y: number, w: number, h: number, lineWidth: number = 0.5): void {
  doc.setLineDashPattern([], 0);
  doc.setLineWidth(lineWidth);
  doc.rect(x, y, w, h);
}

/**
 * Преобразует полное ФИО в формат "Фамилия И.О."
 * Пример: "Кузнецов Алексей Владимирович" → "Кузнецов А.В."
 */
function shortenFio(fullFio: string): string {
  const parts = fullFio.trim().split(/\s+/);
  if (parts.length === 0) return '';
  const lastName = parts[0];
  if (parts.length === 1) return lastName;
  const initials = parts.slice(1).map(p => p.charAt(0) + '.').join('');
  return `${lastName} ${initials}`;
}

/**
 * Разбивает текст на строки с переносом по словам (целое слово переносится)
 * Если слово не помещается в ширину — оно всё равно переносится на новую строку
 * @param doc - Экземпляр jsPDF (для измерения ширины текста)
 * @param text - Исходный текст
 * @param maxWidth - Максимальная ширина строки в мм
 * @returns Массив строк
 */
function wrapTextByWords(doc: jsPDF, text: string, maxWidth: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let currentLine = '';

  for (const word of words) {
    // Пробуем добавить слово к текущей строке
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const testWidth = doc.getTextWidth(testLine);

    if (testWidth <= maxWidth) {
      // Слово помещается — добавляем к текущей строке
      currentLine = testLine;
    } else {
      // Слово не помещается
      if (currentLine) {
        // Сохраняем текущую строку и начинаем новую с этого слова
        lines.push(currentLine);
        currentLine = word;
      } else {
        // Даже одно слово не помещается — всё равно ставим (переносить по буквам не будем)
        currentLine = word;
      }
    }
  }

  // Добавляем последнюю строку
  if (currentLine) {
    lines.push(currentLine);
  }

  return lines;
}

/**
 * GET /api/badge?fio=...&login=...&password=...&tsdNumber=...
 * Генерирует PDF-документ A4 с наклейкой на ТСД и бейджем сотрудника
 */
export async function GET(request: NextRequest) {
  try {
    // Получаем параметры из query string
    const { searchParams } = new URL(request.url);
    const fio = searchParams.get('fio') || '';
    const login = searchParams.get('login') || '';
    const password = searchParams.get('password') || '';
    const tsdNumber = searchParams.get('tsdNumber') || '';

    // Декодируем URI-компоненты (кириллица)
    const decodedFio = decodeURIComponent(fio);
    const decodedLogin = decodeURIComponent(login);
    const decodedPassword = decodeURIComponent(password);
    const decodedTsdNumber = decodeURIComponent(tsdNumber);

    // Сокращённое ФИО для наклейки: "Кузнецов А.В."
    const shortFio = shortenFio(decodedFio);

    // ============================================================
    // Создаём PDF-документ формата A4 (210мм × 297мм)
    // ============================================================
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    // ============================================================
    // Добавляем шрифт Liberation Serif (как в реестре выдачи ТСД)
    // ============================================================
    const fontsDir = '/usr/share/fonts/truetype/liberation';
    const fontRegularBase64 = readFileSync(join(fontsDir, 'LiberationSerif-Regular.ttf')).toString('base64');
    const fontBoldBase64 = readFileSync(join(fontsDir, 'LiberationSerif-Bold.ttf')).toString('base64');
    doc.addFileToVFS('LibSerif-Regular.ttf', fontRegularBase64);
    doc.addFileToVFS('LibSerif-Bold.ttf', fontBoldBase64);
    doc.addFont('LibSerif-Regular.ttf', 'LibSerif', 'normal');
    doc.addFont('LibSerif-Bold.ttf', 'LibSerif', 'bold');

    const FONT = 'LibSerif';

    // ============================================================
    // Общие размеры и позиционирование
    // ============================================================
    const pageWidth = 210;  // Ширина A4 в мм

    // Размеры наклейки на ТСД: 45мм × 15мм
    const stickerWidth = 45;
    const stickerHeight = 15;

    // Размеры бейджа: 80мм × 47мм (фиксированные, не меняются)
    const badgeWidth = 80;
    const badgeHeight = 47;

    // Центрируем элементы по горизонтали
    const stickerX = (pageWidth - stickerWidth) / 2;
    const badgeX = (pageWidth - badgeWidth) / 2;

    // Вертикальные позиции
    const stickerY = 30;
    const badgeY = 60;

    // ============================================================
    // 1. НАКЛЕЙКА НА ТСД (сплошная рамка, 45мм × 10мм)
    // ============================================================

    // Подпись «Наклейка на ТСД:» над рамкой
    doc.setFontSize(10);
    doc.setFont(FONT, 'normal');
    doc.text('Наклейка на ТСД:', stickerX, stickerY - 2);

    // Сплошная рамка
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.5);
    drawSolidRect(doc, stickerX, stickerY, stickerWidth, stickerHeight, 0.5);

    const stickerCenterX = stickerX + stickerWidth / 2;

    // Номер ТСД (шрифт 12, bold)
    doc.setFontSize(12);
    doc.setFont(FONT, 'bold');
    doc.text(decodedTsdNumber || '', stickerCenterX, stickerY + 5.5, { align: 'center' });

    // Фамилия и инициалы (шрифт 12, bold)
    doc.setFontSize(12);
    doc.setFont(FONT, 'bold');
    doc.text(shortFio, stickerCenterX, stickerY + 11.5, { align: 'center' });

    // ============================================================
    // 2. БЕЙДЖИК (пунктирная рамка для вырезания)
    // Контент центрирован по вертикали и горизонтали
    // Текст переносится по словам, если не влезает
    // ============================================================

    // Подпись «Бейджик:» над рамкой
    doc.setFontSize(10);
    doc.setFont(FONT, 'normal');
    doc.text('Бейджик:', badgeX, badgeY - 3);

    // Пунктирная рамка (для вырезания) — размер фиксирован
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.3);
    drawDashedRect(doc, badgeX, badgeY, badgeWidth, badgeHeight, 2, 1.5);

    // Внутренние отступы бейджа от рамки
    const bPadding = 3;
    const bInnerLeft = badgeX + bPadding;
    const bInnerWidth = badgeWidth - bPadding * 2;
    const badgeCenterX = badgeX + badgeWidth / 2;

    // ============================================================
    // Подготавливаем текст с переносом слов
    // ============================================================
    const barcodeH = 8;          // Высота каждого штрихкода
    const labelFontSize = 11;    // Размер шрифта подписи "логин ТСД-№"
    const fioFontSize = 17;      // Размер шрифта ФИО
    const lineHeightFactor = 1.2; // Множитель межстрочного интервала
    const gapSmall = 1;          // Отступ между штрихкодом и подписью
    const gapMedium = 2;         // Отступ между блоками

    // Разбиваем подпись на строки (перенос по словам)
    doc.setFontSize(labelFontSize);
    doc.setFont(FONT, 'normal');
    const bLoginLabel = decodedTsdNumber
      ? `${decodedLogin} - ТСД ${decodedTsdNumber}`
      : decodedLogin;
    const labelLines = wrapTextByWords(doc, bLoginLabel, bInnerWidth);

    // Разбиваем ФИО на строки (перенос по словам)
    doc.setFontSize(fioFontSize);
    doc.setFont(FONT, 'bold');
    const fioLines = wrapTextByWords(doc, decodedFio, bInnerWidth);

    // Вычисляем высоту каждого блока
    const labelLineH = labelFontSize * 0.35 * lineHeightFactor; // Высота одной строки подписи
    const fioLineH = fioFontSize * 0.35 * lineHeightFactor;    // Высота одной строки ФИО
    const labelBlockH = labelLines.length * labelLineH;         // Общая высота блока подписи
    const fioBlockH = fioLines.length * fioLineH;               // Общая высота блока ФИО

    // Общая высота контента
    const totalContentH = barcodeH + gapSmall + labelBlockH + gapMedium + fioBlockH + gapMedium + barcodeH;

    // Вертикальное центрирование
    const topOffset = (badgeHeight - totalContentH) / 2;
    let currentY = badgeY + topOffset;

    // --- Штрихкод логина ---
    const bLoginBarcodeDataUrl = generateBarcodeDataUrl(decodedLogin, 1.0, 25);
    doc.addImage(bLoginBarcodeDataUrl, 'PNG', bInnerLeft, currentY, bInnerWidth, barcodeH);
    currentY += barcodeH + gapSmall;

    // --- Подпись "логин ТСД-№" (с переносом строк) ---
    doc.setFontSize(labelFontSize);
    doc.setFont(FONT, 'normal');
    for (const line of labelLines) {
      doc.text(line, badgeCenterX, currentY + labelLineH * 0.7, { align: 'center' });
      currentY += labelLineH;
    }
    currentY += gapMedium;

    // --- ФИО сотрудника (с переносом строк) ---
    doc.setFontSize(fioFontSize);
    doc.setFont(FONT, 'bold');
    for (const line of fioLines) {
      doc.text(line, badgeCenterX, currentY + fioLineH * 0.7, { align: 'center' });
      currentY += fioLineH;
    }
    currentY += gapMedium;

    // --- Штрихкод пароля ---
    const bPasswordBarcodeDataUrl = generateBarcodeDataUrl(decodedPassword, 1.0, 25);
    doc.addImage(bPasswordBarcodeDataUrl, 'PNG', bInnerLeft, currentY, bInnerWidth, barcodeH);

    // ============================================================
    // Возвращаем PDF как ответ
    // ============================================================
    const pdfBuffer = Buffer.from(doc.output('arraybuffer'));

    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${decodedLogin}.pdf"`,
      },
    });
  } catch (error) {
    console.error('Ошибка генерации бейджа:', error);
    return NextResponse.json(
      { error: 'Ошибка генерации бейджа' },
      { status: 500 }
    );
  }
}

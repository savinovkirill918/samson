'use client';

import React from 'react';
import { Plus } from 'lucide-react';
import { COLORS } from '@/lib/colors';
import type { Repair, TSD, Member, PageId } from '@/lib/types';
import { formatDate, repairStatusText } from '@/lib/helpers';

interface RepairsListProps {
  repairs: Repair[];
  tsds: TSD[];
  members: Member[];
  onNavigate: (page: PageId) => void;
  onEditRepair?: (repair: Repair) => void;
}

/** Статус-бейджи как на оригинальном сайте (Bootstrap badge стили) */
const statusBadgeMap: Record<string, { color: string; bg: string }> = {
  'Сломан не отправлен': { color: '#fff', bg: '#dc3545' },       // bg-danger
  'Отправлен': { color: '#fff', bg: '#ffc107' },                 // bg-warning
  'Вернулся с ремонта': { color: '#fff', bg: '#198754' },        // bg-success
};

export default function RepairsList({ repairs, tsds, members, onNavigate, onEditRepair }: RepairsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold" style={{ color: COLORS.heading }}>Ремонты ТСД</h2>
        <button
          onClick={() => onNavigate('tsd-repair-add')}
          className="flex items-center gap-2 px-4 py-2 text-white rounded-lg text-sm font-medium hover:opacity-90 transition"
          style={{ backgroundColor: COLORS.primary }}
        >
          <Plus className="w-4 h-4" /> Добавить
        </button>
      </div>

      <div className="bg-white rounded-xl shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table
            className="w-full text-sm"
            style={{
              borderCollapse: 'collapse',
            }}
          >
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>#</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>№ ТСД</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Модель</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Дата создания</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Дата отправки</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, textAlign: 'center', borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Дата<br />возвращения</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Статус</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, borderBottom: '2px solid #dee2e6', borderRight: '1px solid #dee2e6' }}>Описание</th>
                <th className="px-3 py-3 font-semibold" style={{ color: COLORS.heading, borderBottom: '2px solid #dee2e6' }}>Виновен сотрудник</th>
              </tr>
            </thead>
            <tbody>
              {[...repairs]
                .sort((a, b) => b.id - a.id)
                .map((repair, idx) => {
                const displayNum = repair.id;
                const tsd = tsds.find(t => t.id === repair.tsdId);
                const statusText = repairStatusText(repair.status);
                const badge = statusBadgeMap[statusText] || { color: '#333', bg: '#dee2e6' };

                return (
                  <tr
                    key={repair.id}
                    className="transition-colors cursor-pointer"
                    style={{
                      backgroundColor: idx % 2 === 0 ? '#fff' : '#f8f9fa',
                      borderBottom: '1px solid #dee2e6',
                    }}
                    onClick={() => onEditRepair?.(repair)}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = '#e7f1ff')}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = idx % 2 === 0 ? '#fff' : '#f8f9fa')}
                  >
                    <td className="px-3 py-2.5 font-medium" style={{ color: COLORS.heading, textAlign: 'center', borderRight: '1px solid #dee2e6' }}>
                      {displayNum}
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.heading, textAlign: 'center', borderRight: '1px solid #dee2e6' }}>
                      {tsd ? tsd.number : '?'}
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.text, whiteSpace: 'normal', borderRight: '1px solid #dee2e6' }}>
                      {tsd?.model || '—'}
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.text, borderRight: '1px solid #dee2e6' }}>
                      {formatDate(repair.brokenDate)}
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.text, borderRight: '1px solid #dee2e6' }}>
                      {repair.sentDate ? formatDate(repair.sentDate) : '—'}
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.text, borderRight: '1px solid #dee2e6' }}>
                      {repair.returnedDate ? formatDate(repair.returnedDate) : '—'}
                    </td>
                    <td className="px-3 py-2.5" style={{ whiteSpace: 'normal', borderRight: '1px solid #dee2e6' }}>
                      <span
                        className="inline-block text-xs font-medium"
                        style={{
                          color: badge.color,
                          backgroundColor: badge.bg,
                          padding: '3px 8px',
                          borderRadius: '4px',
                          fontSize: '12px',
                        }}
                      >
                        {statusText}
                      </span>
                    </td>
                    <td className="px-3 py-2.5" style={{ color: COLORS.text, whiteSpace: 'normal', borderRight: '1px solid #dee2e6' }}>
                      {repair.description || '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      {repair.isGuilty ? (
                        <span style={{ color: '#dc3545', fontWeight: 500 }}>Да</span>
                      ) : (
                        <span style={{ color: COLORS.text }}>Нет</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
